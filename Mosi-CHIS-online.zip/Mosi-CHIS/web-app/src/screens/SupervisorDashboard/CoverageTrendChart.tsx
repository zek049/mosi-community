import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

// The palette's forest-800 (#0F3D34) - chosen deliberately, not eyeballed: it
// clears 11:1 contrast against this app's cream/white surfaces (the
// WCAG >=3:1 floor for graphical marks), and it's the same forest green used for every
// primary action elsewhere in the app, so the chart reads as part of the
// same product rather than a dropped-in widget.
const SERIES_COLOR = "#0F3D34";

type TrendPoint = { date: string; visits: number };

function formatDateShort(value: string): string {
  const date = new Date(`${value}T00:00:00`);
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: { value: number }[]; label?: string }) {
  if (!active || !payload || payload.length === 0 || !label) return null;

  return (
    <div className="rounded-lg border border-stone-200 bg-white px-3 py-2 shadow-sm">
      <p className="text-sm font-semibold text-stone-900">{payload[0].value} visits</p>
      <p className="text-xs text-stone-500">{formatDateShort(label)}</p>
    </div>
  );
}

function CoverageTrendChart({ data }: { data: TrendPoint[] }) {
  // Single series: no legend box (the card title above already names what's
  // plotted), and only every ~5th tick labelled so 30 daily points don't
  // collide on the x-axis.
  return (
    <ResponsiveContainer width="100%" height={220}>
      <AreaChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }} accessibilityLayer={false}>
        <defs>
          <linearGradient id="visitsFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={SERIES_COLOR} stopOpacity={0.12} />
            <stop offset="100%" stopColor={SERIES_COLOR} stopOpacity={0.01} />
          </linearGradient>
        </defs>
        <CartesianGrid vertical={false} stroke="#e7e5e4" strokeWidth={1} />
        <XAxis
          dataKey="date"
          tickFormatter={formatDateShort}
          interval={4}
          tick={{ fontSize: 11, fill: "#57534e" }}
          axisLine={{ stroke: "#e7e5e4" }}
          tickLine={false}
        />
        <YAxis
          allowDecimals={false}
          width={28}
          tick={{ fontSize: 11, fill: "#57534e" }}
          axisLine={false}
          tickLine={false}
        />
        <Tooltip content={<ChartTooltip />} cursor={{ stroke: "#d6d3d1", strokeWidth: 1 }} />
        <Area
          type="monotone"
          dataKey="visits"
          stroke={SERIES_COLOR}
          strokeWidth={2}
          fill="url(#visitsFill)"
          activeDot={{ r: 4, stroke: "#ffffff", strokeWidth: 2 }}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export default CoverageTrendChart;
