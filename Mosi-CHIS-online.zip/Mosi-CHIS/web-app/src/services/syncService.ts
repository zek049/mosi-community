import { db } from "../db/indexedDb";
import * as api from "./api";
import { NetworkError } from "./api";
import { assertCanContactServer } from "./connectivity";
import { generateHouseholdCode } from "../utils/householdCode";
import type { Patient } from "../models/patient";
import type { Visit } from "../models/visit";

// Section 18's retry policy: after the immediate first attempt, up to 3
// retries at 5s / 10s / 20s. This only ever retries a NetworkError (couldn't
// reach the server at all) - a per-record rejection the server DID respond
// with (bad data, a flagged conflict) is never retried automatically, since
// retrying identical data would just fail again the same way. Those surface
// on the Sync Status screen (Step 6) with a manual "Retry" action instead.
const RETRY_DELAYS_MS = [5000, 10000, 20000];

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export type SyncOutcome = {
  attempted: number;
  synced: number;
  conflicts: number;
  failed: number;
};

async function postSyncWithRetry(payload: Parameters<typeof api.postSync>[0]): Promise<api.SyncBatchResponse> {
  for (let attempt = 0; ; attempt++) {
    // Re-checked before EVERY attempt, so switching on Work Offline (or
    // losing the connection) during the backoff stops further tries.
    assertCanContactServer();
    try {
      return await api.postSync(payload);
    } catch (error) {
      const outOfRetries = attempt >= RETRY_DELAYS_MS.length;
      if (!(error instanceof NetworkError) || outOfRetries) {
        throw error;
      }
      await sleep(RETRY_DELAYS_MS[attempt]);
    }
  }
}

// Gathers every locally pending patient/visit, pushes them as one batch, and
// applies the server's per-record verdict back to IndexedDB. Safe to call
// repeatedly - "Sync Now", or automatically on reconnect (Step 6) - since a
// record already marked synced is simply excluded from the next batch. If
// the whole request ultimately fails (connection never came back), every
// record stays "pending" and nothing here throws away that state.
export async function runSync(): Promise<SyncOutcome> {
  const [pendingHouseholds, pendingPatients, pendingVisits] = await Promise.all([
    db.households.where("sync_status").equals("pending").toArray(),
    db.patients.where("sync_status").equals("pending").toArray(),
    db.visits.where("sync_status").equals("pending").toArray(),
  ]);

  const outcome: SyncOutcome = {
    attempted: pendingHouseholds.length + pendingPatients.length + pendingVisits.length,
    synced: 0,
    conflicts: 0,
    failed: 0,
  };

  if (outcome.attempted === 0) {
    return outcome;
  }

  // Households only when there are some, so older servers (no households
  // support) keep accepting batches without them.
  const response = await postSyncWithRetry({
    ...(pendingHouseholds.length > 0 ? { households: pendingHouseholds } : {}),
    patients: pendingPatients,
    visits: pendingVisits,
  });

  async function applyResult(
    result: api.SyncRecordResult,
    table: typeof db.patients | typeof db.visits | typeof db.households,
    recordType: "patient" | "visit" | "household",
  ): Promise<void> {
    if (result.status === "failed") {
      outcome.failed += 1;
      // A household whose device-made code clashed with another: give it a
      // new code so the next sync succeeds (it stays pending until then).
      if (recordType === "household" && /already used/i.test(result.message ?? "")) {
        const household = await db.households.get(result.id);
        if (household) await db.households.update(result.id, { household_code: generateHouseholdCode(household.village) });
      }
      // Left "pending" so the next Sync Now naturally retries it - the
      // attempt record is purely so Sync Status can show it as Failed
      // (with why) instead of indistinguishable from never-yet-tried.
      await db.syncAttempts.put({
        id: result.id,
        record_type: recordType,
        status: "failed",
        message: result.message,
        attempted_at: new Date().toISOString(),
      });
      return;
    }

    if (result.status === "conflict") {
      outcome.conflicts += 1;
      await db.syncAttempts.put({
        id: result.id,
        record_type: recordType,
        status: "conflict",
        message: result.message,
        attempted_at: new Date().toISOString(),
      });
    } else {
      outcome.synced += 1;
      // Clears any earlier failed/conflict flag now that this attempt
      // succeeded cleanly.
      await db.syncAttempts.delete(result.id);
    }

    // "conflict" still clears the local pending flag: the client's edit was
    // received and a decision was made (even if that decision was "keep the
    // server's version and flag it for review") - retrying won't change
    // that outcome, only a supervisor can.
    // The server says what review state the record is now in (a CHW's new
    // or changed record waits for a supervisor) - kept so the device never
    // shows it as confirmed when it isn't.
    await table.update(result.id, {
      sync_status: "synced",
      ...(recordType !== "household" && result.review_status ? { review_status: result.review_status } : {}),
    });
  }

  await Promise.all([
    ...(response.households ?? []).map((result) => applyResult(result, db.households, "household")),
    ...response.patients.map((result) => applyResult(result, db.patients, "patient")),
    ...response.visits.map((result) => applyResult(result, db.visits, "visit")),
  ]);

  return outcome;
}
