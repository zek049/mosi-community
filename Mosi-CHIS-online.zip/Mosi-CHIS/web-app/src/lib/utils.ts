import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

// Standard shadcn/ui-style helper: lets every component accept a
// `className` override without two conflicting Tailwind classes (e.g. two
// different `px-*`) both landing in the output string.
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}
