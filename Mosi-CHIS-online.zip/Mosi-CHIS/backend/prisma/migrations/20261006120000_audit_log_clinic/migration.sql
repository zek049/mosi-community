-- Feature 11 - activity log. Additive: a nullable clinic per audit entry so
-- the log can be limited to a supervisor's clinic. Existing entries are NOT
-- backfilled (audit history is never rewritten); they keep clinic_id NULL
-- and the activity log falls back to "made by an account in this clinic"
-- for them. No foreign key on purpose: an audit entry must outlive anything
-- it refers to.
ALTER TABLE "audit_log" ADD COLUMN "clinic_id" TEXT;
CREATE INDEX "audit_log_clinic_id_idx" ON "audit_log"("clinic_id");
