import { useState } from "react";
import { Link } from "react-router-dom";
import { Wifi, ShieldCheck, Eye, ArrowRight, Menu, X, RefreshCw, Users2, Activity, AlertCircle } from "lucide-react";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { Logo } from "../../components/Logo";
import { InfoDialog } from "../../components/ui/InfoDialog";
import { usePageTitle } from "../../hooks/usePageTitle";
import { readPublicContact } from "../../config/contact";

const PUBLIC_CONTACT = readPublicContact();

// Photo credits (Pexels License - free to use, no attribution legally
// required, credited here as good practice and per the redesign brief):
//   hero-chw.jpg          - Photo by Khanh Hoang Minh 2 / Pexels
//   field-context.jpg     - Photo by Denis Ngai / Pexels
//   community-checkup.jpg - Photo by Lagos Food Bank Initiative / Pexels
// All three are genuine documentary/photojournalism photos of African
// community health work, not staged/generic stock or AI-generated imagery.
// Downloaded at a fixed display width via Pexels' own resize+compress query
// params (no local image-processing tooling was available in this
// environment - see the redesign report for why WebP/AVIF conversion was
// not done) and self-hosted under public/images/ rather than hotlinked, so
// the CSP's img-src can stay locked to 'self' with no external dependency.

type Notice = "privacy" | "accessibility" | "contact";

// Short, honest MVP notices - not stand-in legal pages. They describe only
// what this pilot actually does.
const NOTICES: Record<Notice, { title: string; body: string[] }> = {
  privacy: {
    title: "Privacy",
    body: [
      "Mosi is a controlled-pilot MVP. This demonstration uses synthetic data only - please don't enter real patient information.",
      "So Mosi works without a connection, records are stored in the browser on the device - separately for each account, so the app only ever shows you your own. This stored data is not encrypted, so use Mosi only on devices your clinic controls.",
      "Signing out removes the records that are already safely on the server. Changes that haven't synced yet are kept on the device for you (never shown to anyone else who signs in there) and sync the next time you sign in. On the Sync screen, \"Remove my data from this device\" deletes everything, after warning you about anything unsynced.",
      "On the server, access is limited by role and clinic, and changes are recorded in an audit log. A full privacy notice will be needed before any use with real patients.",
    ],
  },
  accessibility: {
    title: "Accessibility",
    body: [
      "Mosi aims to meet WCAG 2.2 level AA. It is designed to work with a keyboard alone, at phone screen sizes, and with text that meets contrast guidelines.",
      "Automated accessibility and keyboard testing passed. Testing with specialist screen readers (such as NVDA, JAWS, VoiceOver or TalkBack) has not been done yet, so some problems may remain.",
      "If something doesn't work for you, please tell your clinic supervisor so it can be passed to the pilot team.",
    ],
  },
  contact: {
    title: "Contact",
    body: [
      "Mosi is in a controlled pilot. If you're a CHW or supervisor in the pilot, your clinic supervisor is your first point of contact for help, PIN resets and feedback.",
      // Filled from build configuration only - see src/config/contact.ts.
      PUBLIC_CONTACT
        ? `For anything else, contact ${PUBLIC_CONTACT.name}:`
        : "For anything else, contact your system administrator. A public contact address hasn't been configured for this installation.",
    ],
  },
};

const NAV_LINKS = [
  { href: "#why-mosi", label: "Why Mosi" },
  { href: "#how-it-works", label: "How it works" },
  { href: "#for-supervisors", label: "For supervisors" },
  { href: "#about", label: "About" },
];

const VALUE_PROPS = [
  {
    icon: Wifi,
    title: "Offline-first",
    body: "A CHW can register patients and record visits with zero signal. Nothing waits for a connection.",
  },
  {
    icon: ShieldCheck,
    title: "Secure records",
    body: "Every account is clinic-scoped and access-controlled. A CHW only ever sees their own clinic's patients.",
  },
  {
    icon: Eye,
    title: "Supervisor visibility",
    body: "Coverage, CHW activity, and sync health in one place, syncing the moment a connection is available.",
  },
];

const STEPS = [
  {
    number: "01",
    title: "Record offline",
    body: "Log a patient or a visit on a phone in the field. It saves to the device immediately, connection or not.",
    tone: "sage" as const,
  },
  {
    number: "02",
    title: "Sync when connected",
    body: "The moment the CHW's device finds a signal, pending records upload automatically, or with one tap.",
    tone: "gold" as const,
  },
  {
    number: "03",
    title: "Review and act",
    body: "Supervisors see coverage, activity, and anything that needs attention, without waiting for paper.",
    tone: "sage" as const,
  },
];

const STEP_TONE = {
  sage: "bg-sage-100 text-forest-800",
  gold: "bg-gold-400/25 text-gold-700",
} as const;

function SyntheticDataNotice({ className = "" }: { className?: string }) {
  return <p className={`text-xs text-stone-500 ${className}`}>Synthetic demonstration data — not real patient records.</p>;
}

function HeroStatCard({ value, sub, icon: Icon }: { value: string; sub: string; icon: typeof Wifi }) {
  return (
    <div aria-hidden="true" className="flex items-center gap-3 rounded-xl bg-white/95 backdrop-blur-sm border border-stone-200 shadow-lg shadow-forest-900/5 px-4 py-3 w-56">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-sage-100 text-forest-800">
        <Icon className="h-4 w-4" aria-hidden="true" />
      </span>
      <div className="min-w-0">
        <p className="text-sm font-semibold text-stone-900 leading-tight">{value}</p>
        <p className="text-xs text-stone-500 leading-tight truncate">{sub}</p>
      </div>
    </div>
  );
}

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-stone-200/70 bg-cream/90 backdrop-blur-sm">
      <div className="mx-auto max-w-6xl px-5 sm:px-6 py-4 flex items-center justify-between gap-4">
        <Logo />
        <nav className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map((link) => (
            <a key={link.href} href={link.href} className="text-sm text-stone-600 hover:text-forest-900 transition-colors">
              {link.label}
            </a>
          ))}
        </nav>
        <div className="hidden md:block">
          <Button asChild size="sm">
            <Link to="/login">
              Sign in
              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </Link>
          </Button>
        </div>
        <button
          type="button"
          onClick={() => setMenuOpen((open) => !open)}
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
          className="md:hidden flex h-9 w-9 items-center justify-center rounded-lg text-forest-900 hover:bg-forest-50"
        >
          {menuOpen ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
        </button>
      </div>
      {menuOpen && (
        <div className="md:hidden border-t border-stone-200/70 bg-cream px-5 py-4 space-y-4">
          <nav className="flex flex-col gap-3">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="text-sm font-medium text-stone-700 hover:text-forest-900"
              >
                {link.label}
              </a>
            ))}
          </nav>
          <Button asChild className="w-full">
            <Link to="/login">Sign in</Link>
          </Button>
        </div>
      )}
    </header>
  );
}

function Landing() {
  usePageTitle("Community health, offline-first");
  const [notice, setNotice] = useState<Notice | null>(null);
  return (
    <div className="min-h-screen bg-cream text-stone-900">
      <Header />

      <main>
        {/* Hero */}
        <section className="mx-auto max-w-6xl px-5 sm:px-6 pt-14 pb-20 sm:pt-20 sm:pb-24">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            <div>
              <span className="inline-flex items-center rounded-full bg-gold-400/20 text-gold-700 text-xs font-semibold tracking-wide px-3 py-1">
                MOSI PILOT
              </span>
              <h1 className="mt-6 text-4xl sm:text-5xl font-semibold tracking-tight text-forest-900 leading-[1.08]">
                Community health,
                <br />
                connected — even offline.
              </h1>
              <p className="mt-6 text-lg text-stone-600 leading-relaxed max-w-lg">
                Mosi helps community health workers in Zimbabwe record patient visits and track
                care from a phone, in areas where a connection can't be counted on — and syncs
                the moment one is.
              </p>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <Button asChild size="lg">
                  <Link to="/login">
                    Explore Mosi
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </Link>
                </Button>
                <a
                  href="#how-it-works"
                  className="inline-flex items-center gap-2 text-sm font-medium text-forest-800 hover:text-forest-900 transition-colors"
                >
                  See how it works
                </a>
              </div>
              <div className="mt-8 pt-6 border-t border-stone-200/70 max-w-sm">
                <p className="text-xs font-semibold tracking-wider text-gold-700">
                  PEOPLE · COMMUNITIES · A HEALTHIER ZIMBABWE
                </p>
              </div>
            </div>

            <div className="relative">
              <img
                src="/images/hero-chw.jpg"
                alt="A community health worker sits with two children she cares for in her community, wearing a stethoscope and white coat."
                width={1200}
                height={675}
                className="w-full rounded-2xl object-cover aspect-[4/3] shadow-xl shadow-forest-900/10"
              />
              <div className="hidden sm:block absolute -bottom-6 -left-6">
                <HeroStatCard icon={Activity} value="18 visits" sub="today" />
              </div>
              <div className="hidden sm:block absolute top-6 -right-6">
                <HeroStatCard icon={Wifi} value="Offline ready" sub="no signal needed" />
              </div>
            </div>
          </div>

          <h2 className="sr-only">Why Mosi</h2>
          <div className="mt-20 sm:mt-24 grid gap-8 sm:grid-cols-3" id="why-mosi">
            {VALUE_PROPS.map((benefit) => (
              <div key={benefit.title} className="flex items-start gap-3.5">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-sage-100 text-forest-800">
                  <benefit.icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <div>
                  <h3 className="text-sm font-semibold text-forest-900">{benefit.title}</h3>
                  <p className="mt-1 text-sm text-stone-600 leading-relaxed">{benefit.body}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* How it works */}
        <section id="how-it-works" className="border-t border-stone-200/70 bg-white">
          <div className="mx-auto max-w-6xl px-5 sm:px-6 py-20">
            <h2 className="text-2xl sm:text-3xl font-semibold text-forest-900">A simple workflow for greater impact</h2>
            <p className="mt-2 text-stone-600 max-w-2xl">
              From the community to the clinic — three steps, and only the first one needs no
              connection at all.
            </p>
            <ol className="mt-12 grid gap-10 sm:grid-cols-3">
              {STEPS.map((step) => (
                <li key={step.title}>
                  <span
                    className={`inline-flex h-10 w-10 items-center justify-center rounded-full text-sm font-semibold ${STEP_TONE[step.tone]}`}
                  >
                    {step.number}
                  </span>
                  <h3 className="mt-4 text-base font-semibold text-forest-900">{step.title}</h3>
                  <p className="mt-2 text-sm text-stone-600 leading-relaxed">{step.body}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* Field context / About */}
        <section id="about" className="border-t border-stone-200/70">
          <div className="mx-auto max-w-6xl px-5 sm:px-6 py-20 grid lg:grid-cols-2 gap-12 items-center">
            <img
              src="/images/field-context.jpg"
              alt="A community health outreach event in a rural compound, with a health worker attending to seated patients."
              width={900}
              height={600}
              loading="lazy"
              className="w-full rounded-2xl object-cover aspect-[4/3] shadow-lg shadow-forest-900/10"
            />
            <div>
              <p className="text-xs font-semibold tracking-wider text-gold-700">ABOUT MOSI</p>
              <h2 className="mt-3 text-2xl sm:text-3xl font-semibold text-forest-900">
                Built for the realities of the field
              </h2>
              <p className="mt-4 text-stone-600 leading-relaxed">
                Mosi began as a BCom Honours Information Systems research project on
                offline-first health reporting for Zimbabwean CHWs, and has since grown into a
                working pilot: real accounts, clinic-scoped access, and a sync engine that
                resolves conflicts instead of silently overwriting them.
              </p>
              <p className="mt-4 text-stone-600 leading-relaxed">
                It's designed for the connectivity CHWs actually have — not the connectivity a
                product demo assumes — so essential reporting keeps working offline and catches
                up automatically once a signal returns.
              </p>
            </div>
          </div>
        </section>

        {/* Supervisor value */}
        <section id="for-supervisors" className="border-t border-stone-200/70 bg-white">
          <div className="mx-auto max-w-6xl px-5 sm:px-6 py-20 grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <p className="text-xs font-semibold tracking-wider text-gold-700">FOR SUPERVISORS</p>
              <h2 className="mt-3 text-2xl sm:text-3xl font-semibold text-forest-900">
                Visibility, without waiting for paper
              </h2>
              <p className="mt-4 text-stone-600 leading-relaxed max-w-lg">
                A supervisor's dashboard shows clinic activity, CHW activity, and sync health as
                records catch up — plus anything that genuinely needs attention, like a sync
                conflict or a CHW who's gone quiet.
              </p>
            </div>
            <Card className="order-1 lg:order-2 p-6 space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-forest-900">Clinic activity</p>
                <span className="text-xs text-stone-500">Synthetic demo data</span>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { icon: Users2, label: "Active CHWs", value: "12" },
                  { icon: Activity, label: "Visits (7d)", value: "134" },
                  { icon: RefreshCw, label: "Pending sync", value: "3" },
                ].map((stat) => (
                  <div key={stat.label} className="rounded-lg bg-cream border border-stone-200 p-3">
                    <stat.icon className="h-4 w-4 text-forest-700" aria-hidden="true" />
                    <p className="mt-2 text-lg font-semibold text-forest-900">{stat.value}</p>
                    <p className="text-[11px] text-stone-500 leading-tight">{stat.label}</p>
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2.5 rounded-lg bg-amber-50 border border-amber-200 px-3 py-2.5">
                <AlertCircle className="h-4 w-4 shrink-0 text-amber-700" aria-hidden="true" />
                <p className="text-xs text-amber-800">1 sync conflict needs review</p>
              </div>
            </Card>
          </div>
        </section>

        {/* CTA */}
        <section className="border-t border-stone-200/70">
          <div className="mx-auto max-w-6xl px-5 sm:px-6 py-20">
            <Card className="px-8 py-12 sm:px-12 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-8">
              <div className="max-w-md">
                <h2 className="text-xl font-semibold text-forest-900">Ready to see it in motion?</h2>
                <p className="mt-2 text-sm text-stone-600 leading-relaxed">
                  Sign in with a demo CHW or supervisor account — this pilot uses pre-configured
                  accounts rather than open registration.
                </p>
              </div>
              <div className="flex flex-col sm:items-end gap-3 shrink-0">
                <Button asChild size="lg">
                  <Link to="/login">
                    Sign in
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </Link>
                </Button>
                <SyntheticDataNotice />
              </div>
            </Card>
          </div>
        </section>
      </main>

      <footer className="bg-forest-900 text-white">
        <div className="mx-auto max-w-6xl px-5 sm:px-6 py-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
          <div>
            <Logo onDark />
            <p className="mt-3 text-sm text-white/60 max-w-xs leading-relaxed">
              Stronger communities. Healthier tomorrows.
            </p>
          </div>
          <nav aria-label="Footer" className="flex flex-col gap-2.5 text-sm">
            {NAV_LINKS.map((link) => (
              <a key={link.href} href={link.href} className="text-white/70 hover:text-white transition-colors">
                {link.label}
              </a>
            ))}
          </nav>
          <div className="flex flex-col items-start gap-1 text-sm">
            {(Object.keys(NOTICES) as Notice[]).map((key) => (
              <button
                key={key}
                type="button"
                onClick={() => setNotice(key)}
                aria-haspopup="dialog"
                className="min-h-9 text-white/70 underline-offset-4 transition-colors hover:text-white hover:underline"
              >
                {NOTICES[key].title}
              </button>
            ))}
          </div>
        </div>
        <div className="border-t border-white/10">
          <div className="mx-auto max-w-6xl px-5 sm:px-6 py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <p className="text-xs text-white/50">
                Mosi is a controlled-pilot MVP, not an officially deployed national health
                platform. All data shown is synthetic demonstration data.
              </p>
              <p className="text-xs text-white/60">
                Images are representative of community health work and do not depict Mosi
                patients or real patient records.
              </p>
            </div>
            <p className="text-xs text-white/60 shrink-0">© {new Date().getFullYear()} Mosi</p>
          </div>
        </div>
      </footer>

      <InfoDialog open={notice !== null} title={notice ? NOTICES[notice].title : ""} onClose={() => setNotice(null)}>
        {notice && NOTICES[notice].body.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
        {notice === "contact" && PUBLIC_CONTACT && (
          <p>
            <a href={`mailto:${PUBLIC_CONTACT.email}`} className="font-medium text-forest-800 underline underline-offset-2">
              {PUBLIC_CONTACT.email}
            </a>
          </p>
        )}
      </InfoDialog>
    </div>
  );
}

export default Landing;
