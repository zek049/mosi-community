import { describe, expect, it } from "vitest";
import { findPossibleDuplicates, isPossibleDuplicate, normalizeForMatch } from "../findPossibleDuplicates";

// Same table as backend/src/__tests__/duplicates.test.ts.
const base = { first_name: "Chiedza", last_name: "Moyo", village: "Mbare", date_of_birth: "2022-03-14" };
const CASES: Array<[string, Partial<typeof base>, boolean]> = [
  ["identical", {}, true],
  ["different case", { first_name: "CHIEDZA", last_name: "moyo", village: "mbare" }, true],
  ["extra / inner spaces", { first_name: "  Chiedza ", village: "Mbare " }, true],
  ["accents ignored", { last_name: "Möyo" }, true],
  ["DOB given as a server timestamp", { date_of_birth: "2022-03-14T00:00:00.000Z" }, true],
  ["different first name", { first_name: "Rudo" }, false],
  ["different village", { village: "Epworth" }, false],
  ["different DOB", { date_of_birth: "2022-03-15" }, false],
  ["first/last swapped", { first_name: "Moyo", last_name: "Chiedza" }, false],
];

describe("duplicate matching rule", () => {
  it.each(CASES)("%s", (_label, change, expected) => {
    expect(isPossibleDuplicate(base, { ...base, ...change })).toBe(expected);
  });

  it("normalises names", () => {
    expect(normalizeForMatch("  Tendai   Mütasa ")).toBe("tendai mutasa");
    expect(normalizeForMatch(undefined)).toBe("");
  });

  it("finds matches in a list, ignoring archived patients, newest first", () => {
    const list = [
      { ...base, id: "old", created_at: "2026-01-01T00:00:00Z" },
      { ...base, id: "archived", created_at: "2026-06-01T00:00:00Z", deleted_at: "2026-07-01T00:00:00Z" },
      { ...base, id: "new", created_at: "2026-05-01T00:00:00Z", first_name: "chiedza " },
      { ...base, id: "other", first_name: "Rudo", created_at: "2026-02-01T00:00:00Z" },
    ];
    expect(findPossibleDuplicates(base, list).map((p) => p.id)).toEqual(["new", "old"]);
    expect(findPossibleDuplicates(base, [])).toEqual([]);
  });
});
