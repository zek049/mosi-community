import { logger } from "../logger";
import { Prisma } from "@prisma/client";
import { prisma } from "../db";
import { validateHouseholdFields, validatePatientFields, validateVisitFields } from "./validation";
import { resolveConflict } from "./conflictResolver";
import { canAccessClinic } from "../middleware/authz";
import type { AuthenticatedUser } from "../middleware/auth";
import { writeAuditLog } from "../utils/audit";
import { reviewOnCreate, reviewOnEdit, type ReviewStatus } from "../utils/review";
import { isReasonableRecordTimestamp } from "../utils/timestampGuard";

// Per-record outcome returned to the client for each patient/visit in a
// sync batch. `status` is the exact contract the frontend's
// services/syncService.ts parses (only "synced" | "conflict" | "failed" are
// ever checked - anything else falls through to "treat as synced", so this
// set can never grow without a matching frontend change). `reason` is a
// newer, more granular, OPTIONAL field for observability/debugging that the
// current frontend simply ignores - it does not replace `status`.
export type SyncOutcomeReason =
  | "created"
  | "updated"
  | "identical"
  | "stale"
  | "hash_mismatch"
  | "validation_error"
  | "unauthorized"
  | "archived"
  | "clock_skew"
  | "error";

export type SyncRecordResult = {
  id: string;
  status: "synced" | "conflict" | "failed";
  message?: string;
  reason?: SyncOutcomeReason;
  /** Patients/visits: the record's review state on the server after this sync. */
  review_status?: ReviewStatus;
};

// The "existing" side always comes from Prisma as a Date object; the
// "incoming" side always comes from the client as an unparsed date string.
// Both must normalise to the exact same ISO string before hashing, or two
// records that represent the same date would hash differently and every
// idempotent retry would be misreported as a conflict.
function toIsoOrNull(value: unknown): string | null {
  if (value === null || value === undefined) return null;
  const date = value instanceof Date ? value : new Date(value as string);
  return date.toISOString();
}

function patientContent(fields: {
  patient_id: unknown;
  first_name: unknown;
  last_name: unknown;
  date_of_birth: unknown;
  gender: unknown;
  village: unknown;
  phone_number: unknown;
}) {
  return {
    patient_id: fields.patient_id,
    first_name: fields.first_name,
    last_name: fields.last_name,
    date_of_birth: toIsoOrNull(fields.date_of_birth),
    gender: fields.gender,
    village: fields.village,
    phone_number: fields.phone_number ?? null,
  };
}

function visitContent(fields: {
  patient_id: unknown;
  chw_id: unknown;
  visit_date: unknown;
  visit_type: unknown;
  weight: unknown;
  height: unknown;
  blood_pressure: unknown;
  notes: unknown;
}) {
  return {
    patient_id: fields.patient_id,
    chw_id: fields.chw_id,
    visit_date: toIsoOrNull(fields.visit_date),
    visit_type: fields.visit_type,
    weight: fields.weight ?? null,
    height: fields.height ?? null,
    blood_pressure: fields.blood_pressure ?? null,
    notes: fields.notes ?? null,
  };
}

// Two concurrent sync requests for the same not-yet-synced record (e.g. a
// device retrying a request whose earlier response was lost, arriving
// alongside the retry) can both pass the "does this exist yet" check before
// either commits - only one create() can win the id's primary key
// constraint. Found via adversarial concurrency testing: the loser used to
// be reported as a raw "failed"/error, even though no data was lost or
// duplicated (the constraint did its job) - a single bounded retry lets the
// loser fall through to the normal existing-record conflict-resolution
// path instead, which is what should have happened if it had simply lost
// the race by a wider margin.
function isUniqueIdRaceError(error: unknown): boolean {
  return (
    error instanceof Prisma.PrismaClientKnownRequestError &&
    error.code === "P2002" &&
    Array.isArray(error.meta?.target) &&
    (error.meta.target as string[]).includes("id")
  );
}

async function recordConflict(params: {
  recordType: "patient" | "visit";
  recordId: string;
  incomingContent: Record<string, unknown>;
  existingContent: Record<string, unknown>;
  incomingUpdatedAt: Date;
  existingUpdatedAt: Date;
  detectedBy: string;
}) {
  await prisma.syncConflict.create({
    data: {
      record_type: params.recordType,
      record_id: params.recordId,
      incoming_version: params.incomingContent as object,
      server_version: params.existingContent as object,
      incoming_timestamp: params.incomingUpdatedAt,
      server_timestamp: params.existingUpdatedAt,
      detected_by: params.detectedBy,
      status: "open",
    },
  });
}

// Households are created on devices (offline) and only ever created here -
// there is nothing to edit on one yet, so a re-sent household that already
// exists is simply acknowledged. A code already used by a DIFFERENT
// household is a per-record failure (the device keeps it pending).
export async function syncHousehold(input: Record<string, unknown>, actor: AuthenticatedUser): Promise<SyncRecordResult> {
  const id = input?.id;
  if (typeof id !== "string" || !id.trim()) {
    return { id: String(id ?? "unknown"), status: "failed", message: "id is required", reason: "validation_error" };
  }
  const errors = validateHouseholdFields(input);
  if (errors.length > 0) {
    await prisma.syncLog.create({ data: { record_type: "household", record_id: id, action: "create", status: "failed" } });
    return { id, status: "failed", message: errors.join(". "), reason: "validation_error" };
  }
  try {
    const existing = await prisma.household.findUnique({ where: { id } });
    if (existing) {
      if (!canAccessClinic(actor, existing.clinic_id)) {
        return { id, status: "failed", message: "You do not have permission to modify this household", reason: "unauthorized" };
      }
      return { id, status: "synced", reason: "identical" };
    }
    const clash = await prisma.household.findUnique({ where: { household_code: input.household_code as string } });
    if (clash) {
      await prisma.syncLog.create({ data: { record_type: "household", record_id: id, action: "create", status: "failed" } });
      return { id, status: "failed", message: `Household code "${input.household_code}" is already used`, reason: "validation_error" };
    }
    await prisma.$transaction([
      prisma.household.create({
        data: {
          id,
          household_code: input.household_code as string,
          village: (input.village as string).trim(),
          created_at: new Date(input.created_at as string),
          // from the authenticated actor, never the payload
          clinic_id: actor.clinicId,
          created_by_chw_id: actor.chwId,
        },
      }),
      prisma.syncLog.create({ data: { record_type: "household", record_id: id, action: "create", status: "success" } }),
    ]);
    return { id, status: "synced", reason: "created" };
  } catch (error) {
    logger.error({ err: error, id }, "Household sync failed");
    return { id, status: "failed", message: "Unexpected error while saving this household", reason: "error" };
  }
}

// A patient may point at a household: it must exist and be in the same
// clinic as the actor. Returns an error message, or null when acceptable.
async function checkHouseholdLink(householdId: unknown, actor: AuthenticatedUser): Promise<string | null> {
  if (householdId === undefined || householdId === null) return null;
  if (typeof householdId !== "string") return "household_id must be a string";
  const household = await prisma.household.findUnique({ where: { id: householdId }, select: { clinic_id: true } });
  if (!household || !canAccessClinic(actor, household.clinic_id)) return "That household doesn't exist (yet) on the server";
  return null;
}

export async function syncPatient(
  input: Record<string, unknown>,
  actor: AuthenticatedUser,
  allowRaceRetry = true,
): Promise<SyncRecordResult> {
  const id = input?.id;
  if (typeof id !== "string" || !id.trim()) {
    return { id: String(id ?? "unknown"), status: "failed", message: "id is required", reason: "validation_error" };
  }

  const fieldErrors = validatePatientFields(input, { partial: false });
  if (fieldErrors.length > 0 || typeof input.updated_at !== "string" || typeof input.created_at !== "string") {
    if (typeof input.updated_at !== "string") fieldErrors.push("updated_at is required");
    if (typeof input.created_at !== "string") fieldErrors.push("created_at is required");
    await prisma.syncLog.create({
      data: { record_type: "patient", record_id: id, action: "create", status: "failed" },
    });
    return { id, status: "failed", message: fieldErrors.join(". "), reason: "validation_error" };
  }

  if (!isReasonableRecordTimestamp(new Date(input.created_at)) || !isReasonableRecordTimestamp(new Date(input.updated_at))) {
    await prisma.syncLog.create({
      data: { record_type: "patient", record_id: id, action: "create", status: "failed" },
    });
    return {
      id,
      status: "failed",
      message: "created_at/updated_at is too far in the future or implausibly old - check this device's clock",
      reason: "clock_skew",
    };
  }

  const householdError = await checkHouseholdLink(input.household_id, actor);
  if (householdError) {
    await prisma.syncLog.create({ data: { record_type: "patient", record_id: id, action: "create", status: "failed" } });
    return { id, status: "failed", message: householdError, reason: "validation_error" };
  }

  try {
    const existing = await prisma.patient.findUnique({ where: { id } });
    const incomingUpdatedAt = new Date(input.updated_at);

    if (!existing) {
      const clash = await prisma.patient.findUnique({
        where: { patient_id: input.patient_id as string },
      });
      if (clash) {
        await prisma.syncLog.create({
          data: { record_type: "patient", record_id: id, action: "create", status: "failed" },
        });
        return { id, status: "failed", message: `Patient ID "${input.patient_id}" already exists`, reason: "validation_error" };
      }

      const createReview = reviewOnCreate(actor);
      // clinic_id/registered_by_chw_id come from the authenticated actor,
      // never the client payload (section 25) - identical rule to the
      // direct POST /patients route, enforced again here because sync is a
      // separate write path with its own database access.
      await prisma.$transaction([
        prisma.patient.create({
          data: {
            id,
            patient_id: input.patient_id as string,
            first_name: input.first_name as string,
            last_name: input.last_name as string,
            date_of_birth: new Date(input.date_of_birth as string),
            gender: input.gender as "M" | "F",
            village: input.village as string,
            phone_number: (input.phone_number as string | undefined) ?? null,
            household_id: (input.household_id as string | null | undefined) ?? null,
            created_at: new Date(input.created_at),
            updated_at: incomingUpdatedAt,
            sync_status: "synced",
            clinic_id: actor.clinicId,
            registered_by_chw_id: actor.chwId,
            ...createReview,
          },
        }),
        prisma.syncLog.create({
          data: { record_type: "patient", record_id: id, action: "create", status: "success" },
        }),
      ]);

      return { id, status: "synced", reason: "created", review_status: createReview.review_status };
    }

    if (!canAccessClinic(actor, existing.clinic_id)) {
      await prisma.syncLog.create({
        data: { record_type: "patient", record_id: id, action: "update", status: "failed" },
      });
      return { id, status: "failed", message: "You do not have permission to modify this patient", reason: "unauthorized" };
    }

    // An archived record is frozen (section 19) - the direct PUT route
    // already refuses to edit one (404), and sync must refuse the same way
    // rather than silently applying content changes underneath the
    // deleted_at flag. Found via adversarial testing: this check was
    // missing here even though it existed on the direct route.
    if (existing.deleted_at) {
      await prisma.syncLog.create({
        data: { record_type: "patient", record_id: id, action: "update", status: "failed" },
      });
      return { id, status: "failed", message: "This patient has been archived and can no longer be edited", reason: "archived" };
    }

    const decision = resolveConflict({
      incomingUpdatedAt,
      existingUpdatedAt: existing.updated_at,
      incomingContent: patientContent({
        patient_id: input.patient_id,
        first_name: input.first_name,
        last_name: input.last_name,
        date_of_birth: input.date_of_birth,
        gender: input.gender,
        village: input.village,
        phone_number: input.phone_number,
      }),
      existingContent: patientContent(existing),
    });

    if (decision.outcome === "apply") {
      const editReview = reviewOnEdit(actor);
      await prisma.$transaction([
        prisma.patient.update({
          where: { id },
          data: {
            first_name: input.first_name as string,
            last_name: input.last_name as string,
            date_of_birth: new Date(input.date_of_birth as string),
            gender: input.gender as "M" | "F",
            village: input.village as string,
            phone_number: (input.phone_number as string | undefined) ?? null,
            household_id: (input.household_id as string | null | undefined) ?? null,
            updated_at: incomingUpdatedAt,
            ...editReview,
          },
        }),
        prisma.syncLog.create({
          data: { record_type: "patient", record_id: id, action: "update", status: "success" },
        }),
      ]);
      return { id, status: "synced", reason: "updated", review_status: editReview.review_status };
    }

    if (decision.outcome === "flag_conflict") {
      await prisma.syncLog.create({
        data: { record_type: "patient", record_id: id, action: "conflict", status: "conflict" },
      });
      await recordConflict({
        recordType: "patient",
        recordId: id,
        incomingContent: patientContent({
          patient_id: input.patient_id,
          first_name: input.first_name,
          last_name: input.last_name,
          date_of_birth: input.date_of_birth,
          gender: input.gender,
          village: input.village,
          phone_number: input.phone_number,
        }),
        existingContent: patientContent(existing),
        incomingUpdatedAt,
        existingUpdatedAt: existing.updated_at,
        detectedBy: actor.chwId,
      });
      await writeAuditLog({
        actor,
        action: "SYNC_CONFLICT",
        resourceType: "patient",
        resourceId: id,
      });
      return {
        id,
        status: "conflict",
        message: "Edited differently on another device at the same time - flagged for supervisor review",
        reason: "hash_mismatch",
      };
    }

    await prisma.syncLog.create({
      data: {
        record_type: "patient",
        record_id: id,
        action: decision.reason === "identical" ? "no_change" : "conflict_resolved",
        status: "success",
      },
    });
    // Nothing was applied, so the review state is whatever it already was.
    return { id, status: "synced", reason: decision.reason === "identical" ? "identical" : "stale", review_status: existing.review_status };
  } catch (error) {
    if (allowRaceRetry && isUniqueIdRaceError(error)) {
      return syncPatient(input, actor, false);
    }
    await prisma.syncLog.create({
      data: { record_type: "patient", record_id: id, action: "create", status: "failed" },
    });
    return { id, status: "failed", message: error instanceof Error ? error.message : "Sync failed", reason: "error" };
  }
}

export async function syncVisit(
  input: Record<string, unknown>,
  actor: AuthenticatedUser,
  allowRaceRetry = true,
): Promise<SyncRecordResult> {
  const id = input?.id;
  if (typeof id !== "string" || !id.trim()) {
    return { id: String(id ?? "unknown"), status: "failed", message: "id is required", reason: "validation_error" };
  }

  // Same anti-impersonation rule as the direct POST /visits route: a CHW
  // can only ever sync a visit recorded as themselves.
  const record = actor.role === "CHW" ? { ...input, chw_id: actor.chwId } : input;

  const fieldErrors = await validateVisitFields(record, { partial: false });
  if (fieldErrors.length > 0 || typeof record.updated_at !== "string" || typeof record.created_at !== "string") {
    if (typeof record.updated_at !== "string") fieldErrors.push("updated_at is required");
    if (typeof record.created_at !== "string") fieldErrors.push("created_at is required");
    await prisma.syncLog.create({
      data: { record_type: "visit", record_id: id, action: "create", status: "failed" },
    });
    return { id, status: "failed", message: fieldErrors.join(". "), reason: "validation_error" };
  }

  if (
    !isReasonableRecordTimestamp(new Date(record.created_at as string)) ||
    !isReasonableRecordTimestamp(new Date(record.updated_at as string))
  ) {
    await prisma.syncLog.create({
      data: { record_type: "visit", record_id: id, action: "create", status: "failed" },
    });
    return {
      id,
      status: "failed",
      message: "created_at/updated_at is too far in the future or implausibly old - check this device's clock",
      reason: "clock_skew",
    };
  }

  try {
    const existing = await prisma.visit.findUnique({ where: { id } });
    const incomingUpdatedAt = new Date(record.updated_at as string);

    if (!existing) {
      const patient = await prisma.patient.findUnique({ where: { id: record.patient_id as string } });
      if (!patient || patient.deleted_at) {
        await prisma.syncLog.create({
          data: { record_type: "visit", record_id: id, action: "create", status: "failed" },
        });
        return { id, status: "failed", message: "Patient not found", reason: "validation_error" };
      }
      if (!canAccessClinic(actor, patient.clinic_id)) {
        await prisma.syncLog.create({
          data: { record_type: "visit", record_id: id, action: "create", status: "failed" },
        });
        return { id, status: "failed", message: "You do not have permission to record a visit for this patient", reason: "unauthorized" };
      }

      const createReview = reviewOnCreate(actor);
      await prisma.$transaction([
        prisma.visit.create({
          data: {
            id,
            patient_id: record.patient_id as string,
            chw_id: record.chw_id as string,
            visit_date: new Date(record.visit_date as string),
            visit_type: record.visit_type as string,
            weight: (record.weight as number | undefined) ?? null,
            height: (record.height as number | undefined) ?? null,
            blood_pressure: (record.blood_pressure as string | undefined) ?? null,
            notes: (record.notes as string | undefined) ?? null,
            created_at: new Date(record.created_at as string),
            updated_at: incomingUpdatedAt,
            sync_status: "synced",
            clinic_id: patient.clinic_id,
            ...createReview,
          },
        }),
        prisma.syncLog.create({
          data: { record_type: "visit", record_id: id, action: "create", status: "success" },
        }),
      ]);

      return { id, status: "synced", reason: "created", review_status: createReview.review_status };
    }

    if (!canAccessClinic(actor, existing.clinic_id)) {
      await prisma.syncLog.create({
        data: { record_type: "visit", record_id: id, action: "update", status: "failed" },
      });
      return { id, status: "failed", message: "You do not have permission to modify this visit", reason: "unauthorized" };
    }

    // Same archived-record freeze as syncPatient above.
    if (existing.deleted_at) {
      await prisma.syncLog.create({
        data: { record_type: "visit", record_id: id, action: "update", status: "failed" },
      });
      return { id, status: "failed", message: "This visit has been archived and can no longer be edited", reason: "archived" };
    }

    const decision = resolveConflict({
      incomingUpdatedAt,
      existingUpdatedAt: existing.updated_at,
      incomingContent: visitContent({
        patient_id: record.patient_id,
        chw_id: record.chw_id,
        visit_date: record.visit_date,
        visit_type: record.visit_type,
        weight: record.weight,
        height: record.height,
        blood_pressure: record.blood_pressure,
        notes: record.notes,
      }),
      existingContent: visitContent(existing),
    });

    if (decision.outcome === "apply") {
      const editReview = reviewOnEdit(actor);
      await prisma.$transaction([
        prisma.visit.update({
          where: { id },
          data: {
            visit_date: new Date(record.visit_date as string),
            visit_type: record.visit_type as string,
            weight: (record.weight as number | undefined) ?? null,
            height: (record.height as number | undefined) ?? null,
            blood_pressure: (record.blood_pressure as string | undefined) ?? null,
            notes: (record.notes as string | undefined) ?? null,
            updated_at: incomingUpdatedAt,
            ...editReview,
          },
        }),
        prisma.syncLog.create({
          data: { record_type: "visit", record_id: id, action: "update", status: "success" },
        }),
      ]);
      return { id, status: "synced", reason: "updated", review_status: editReview.review_status };
    }

    if (decision.outcome === "flag_conflict") {
      await prisma.syncLog.create({
        data: { record_type: "visit", record_id: id, action: "conflict", status: "conflict" },
      });
      await recordConflict({
        recordType: "visit",
        recordId: id,
        incomingContent: visitContent({
          patient_id: record.patient_id,
          chw_id: record.chw_id,
          visit_date: record.visit_date,
          visit_type: record.visit_type,
          weight: record.weight,
          height: record.height,
          blood_pressure: record.blood_pressure,
          notes: record.notes,
        }),
        existingContent: visitContent(existing),
        incomingUpdatedAt,
        existingUpdatedAt: existing.updated_at,
        detectedBy: actor.chwId,
      });
      await writeAuditLog({
        actor,
        action: "SYNC_CONFLICT",
        resourceType: "visit",
        resourceId: id,
      });
      return {
        id,
        status: "conflict",
        message: "Edited differently on another device at the same time - flagged for supervisor review",
        reason: "hash_mismatch",
      };
    }

    await prisma.syncLog.create({
      data: {
        record_type: "visit",
        record_id: id,
        action: decision.reason === "identical" ? "no_change" : "conflict_resolved",
        status: "success",
      },
    });
    // Nothing was applied, so the review state is whatever it already was.
    return { id, status: "synced", reason: decision.reason === "identical" ? "identical" : "stale", review_status: existing.review_status };
  } catch (error) {
    if (allowRaceRetry && isUniqueIdRaceError(error)) {
      return syncVisit(input, actor, false);
    }
    await prisma.syncLog.create({
      data: { record_type: "visit", record_id: id, action: "create", status: "failed" },
    });
    return { id, status: "failed", message: error instanceof Error ? error.message : "Sync failed", reason: "error" };
  }
}
