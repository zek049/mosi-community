import type { AuthenticatedUser } from "../middleware/auth";

// Review queue rules, in one place so every write path (sync, the direct
// patient/visit routes) applies them identically:
//  1. A CHW's new record waits for review; a supervisor's is confirmed.
//  2. An edit that changes a record sends it back to awaiting_review - but
//     review_flag_reason / reviewed_at / reviewed_by are left as they were,
//     so the previous decision (e.g. why it was flagged) stays visible.
//     A supervisor's own edit counts as reviewed.
//  3. Re-sending identical content changes nothing (callers only apply
//     these on a real create/update).

export type ReviewStatus = "awaiting_review" | "confirmed" | "flagged";

export function isReviewer(actor: Pick<AuthenticatedUser, "role">): boolean {
  return actor.role === "SUPERVISOR" || actor.role === "ADMIN";
}

export function reviewOnCreate(actor: Pick<AuthenticatedUser, "role" | "chwId">, now = new Date()) {
  return isReviewer(actor)
    ? { review_status: "confirmed" as const, reviewed_at: now, reviewed_by: actor.chwId }
    : { review_status: "awaiting_review" as const };
}

export function reviewOnEdit(actor: Pick<AuthenticatedUser, "role" | "chwId">, now = new Date()) {
  return isReviewer(actor)
    ? { review_status: "confirmed" as const, reviewed_at: now, reviewed_by: actor.chwId }
    : { review_status: "awaiting_review" as const };
}

// Allowed decisions. Anything else (confirming something already confirmed,
// flagging something already flagged) is refused with 409 rather than
// silently re-stamping the reviewer/time.
export const CAN_CONFIRM_FROM: readonly ReviewStatus[] = ["awaiting_review", "flagged"];
export const CAN_FLAG_FROM: readonly ReviewStatus[] = ["awaiting_review", "confirmed"];
