import { useEffect, useRef, useState, type FormEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Ban, CheckCircle2, Plus, RotateCcw, Trash2, UsersRound } from "lucide-react";
import * as api from "../../services/api";
import { ApiError, type ManagedChw } from "../../services/api";
import { usePageTitle } from "../../hooks/usePageTitle";
import * as authService from "../../services/authService";
import { validateAccountRequest, type AccountRequestErrors } from "../../utils/validators";
import { PageHeader } from "../../components/ui/PageHeader";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { Badge } from "../../components/ui/Badge";
import { Select } from "../../components/ui/Select";
import { TextField } from "../../components/ui/TextField";
import { EmptyState } from "../../components/ui/EmptyState";
import { ModalDialog } from "../../components/ui/ModalDialog";
import { LoadErrorNotice } from "../../components/LoadErrorNotice";

type Action = { kind: "revoke" | "reactivate" | "delete"; chw: ManagedChw } | null;

const COPY = {
  revoke: {
    title: (n: string) => `Revoke ${n}'s access?`,
    body: "They're signed out on their next request and can't sign in again until reactivated. All their patients, visits and history are kept.",
    confirm: "Revoke access",
    done: (n: string) => `${n}'s access was revoked. Their records are kept.`,
  },
  reactivate: {
    title: (n: string) => `Reactivate ${n}?`,
    body: "They can sign in again with their existing PIN. Any sign-in lockout is cleared.",
    confirm: "Reactivate",
    done: (n: string) => `${n} can sign in again.`,
  },
  delete: {
    title: (n: string) => `Permanently delete ${n}'s account?`,
    body: "This can't be undone. It's only allowed because this account never recorded any patients or visits.",
    confirm: "Delete permanently",
    done: (n: string) => `${n}'s account was deleted.`,
  },
} as const;

function errorMessage(error: unknown): string {
  if (error instanceof ApiError && error.status < 500) return error.message;
  return "Couldn't save the change. Check your connection and try again.";
}

const EMPTY_FORM = { full_name: "", chw_id: "", clinic_id: "", phone_number: "", pin: "", confirm: "" };

const TEXT = {
  CHW: {
    title: "Manage CHWs",
    description: "Add CHW accounts, revoke or restore access, and remove accounts created by mistake.",
    add: "Add CHW",
    addHeading: "Add a CHW",
    idLabel: "CHW ID",
    idPlaceholder: "e.g. CHW010",
    pinNote: "Tell the CHW this PIN. They choose their own PIN the first time they sign in.",
    listLabel: "CHW accounts",
    empty: "No CHW accounts yet",
    emptyHint: "Add one, or approve an account request.",
    what: "CHW accounts",
  },
  SUPERVISOR: {
    title: "Manage supervisors",
    description: "Supervisor accounts for each clinic. A supervisor sees and manages only their own clinic.",
    add: "Add supervisor",
    addHeading: "Add a supervisor",
    idLabel: "Supervisor ID",
    idPlaceholder: "e.g. SUP010",
    pinNote: "Tell the supervisor this PIN. They choose their own PIN the first time they sign in.",
    listLabel: "Supervisor accounts",
    empty: "No supervisor accounts yet",
    emptyHint: "Add one for each clinic.",
    what: "supervisor accounts",
  },
} as const;

// Account management for CHWs (supervisors: own clinic; administrators: all)
// and for supervisors (administrators only). The server decides what's
// allowed; this screen only offers what makes sense for the viewer.
export function ManageAccounts({ role }: { role: "CHW" | "SUPERVISOR" }) {
  const text = TEXT[role];
  usePageTitle(text.title);
  const queryClient = useQueryClient();
  const session = authService.getSession();
  const chwsQuery = useQuery({ queryKey: ["managedChws", role], queryFn: () => api.getManagedChws(role) });
  const clinicsQuery = useQuery({ queryKey: ["requestableClinics"], queryFn: api.getRequestableClinics });
  // A clinic supervisor can only add CHWs to their own clinic.
  const ownClinicOnly = session?.chw.role === "SUPERVISOR";
  const clinicOptions = (clinicsQuery.data ?? []).filter(
    (c) => !ownClinicOnly || c.name === session?.chw.clinic,
  );

  const [action, setAction] = useState<Action>(null);
  const [message, setMessage] = useState<string | null>(null);
  const messageRef = useRef<HTMLDivElement>(null);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [errors, setErrors] = useState<AccountRequestErrors>({});
  const firstFieldRef = useRef<HTMLDivElement>(null);

  const refresh = () => {
    void queryClient.invalidateQueries({ queryKey: ["managedChws", role] });
    void queryClient.invalidateQueries({ queryKey: ["chws"] });
    void queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
  };

  const act = useMutation({
    mutationFn: async (a: NonNullable<Action>): Promise<void> => {
      if (a.kind === "revoke") await api.revokeChw(a.chw.chw_id);
      else if (a.kind === "reactivate") await api.reactivateChw(a.chw.chw_id);
      else await api.deleteChw(a.chw.chw_id);
    },
    onSuccess: (_d, a) => {
      setAction(null);
      setMessage(COPY[a.kind].done(a.chw.full_name));
      refresh();
    },
  });

  const create = useMutation({
    mutationFn: () =>
      api.createChw({ chw_id: form.chw_id.trim(), full_name: form.full_name.trim(), clinic_id: form.clinic_id, phone_number: form.phone_number.trim() || null, pin: form.pin, role }),
    onSuccess: (chw) => {
      setAdding(false);
      setForm(EMPTY_FORM); // don't keep the PIN around
      setMessage(`${chw.full_name} (${chw.chw_id}) was added. Give them their PIN in person.`);
      refresh();
    },
  });

  useEffect(() => {
    if (message) messageRef.current?.focus();
  }, [message]);
  useEffect(() => {
    if (adding) firstFieldRef.current?.querySelector("input")?.focus();
  }, [adding]);
  // With only one clinic to choose from, choose it.
  useEffect(() => {
    if (adding && ownClinicOnly && clinicOptions.length === 1 && !form.clinic_id) setForm((f) => ({ ...f, clinic_id: clinicOptions[0].id }));
  }, [adding, ownClinicOnly, clinicOptions, form.clinic_id]);

  function submitAdd(event: FormEvent) {
    event.preventDefault();
    const found = validateAccountRequest(form);
    setErrors(found);
    if (Object.keys(found).length === 0) create.mutate();
  }

  const chws = chwsQuery.data;

  return (
    <div className="max-w-4xl space-y-6">
      <PageHeader
        title={text.title}
        description={text.description}
        actions={
          !adding && (
            <Button onClick={() => { setAdding(true); setMessage(null); create.reset(); }}>
              <Plus className="h-4 w-4" aria-hidden="true" />
              {text.add}
            </Button>
          )
        }
      />

      {message && (
        <div ref={messageRef} tabIndex={-1} role="status" className="flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 outline-none focus-visible:ring-2 focus-visible:ring-emerald-700">
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-800" aria-hidden="true" />
          <p className="text-sm text-emerald-900">{message}</p>
        </div>
      )}

      {adding && (
        <Card>
          <form onSubmit={submitAdd} noValidate className="space-y-4" aria-labelledby="add-chw-heading">
            <h2 id="add-chw-heading" className="text-base font-semibold text-stone-900">{text.addHeading}</h2>
            <div ref={firstFieldRef} className="grid gap-4 sm:grid-cols-2">
              <TextField label="Full name" name="new_full_name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} error={errors.full_name} className="text-base sm:text-sm" />
              <TextField label={text.idLabel} name="new_chw_id" placeholder={text.idPlaceholder} value={form.chw_id} onChange={(e) => setForm({ ...form, chw_id: e.target.value.toUpperCase() })} error={errors.chw_id} className="text-base sm:text-sm" />
              <Select
                label="Clinic"
                id="new_clinic_id"
                value={form.clinic_id}
                onValueChange={(v) => setForm({ ...form, clinic_id: v })}
                placeholder="Choose a clinic"
                options={clinicOptions.map((c) => ({ value: c.id, label: c.name }))}
                error={errors.clinic_id}
              />
              <TextField label="Phone number (optional)" name="new_phone" type="tel" inputMode="numeric" value={form.phone_number} onChange={(e) => setForm({ ...form, phone_number: e.target.value.replace(/\D/g, "") })} error={errors.phone_number} className="text-base sm:text-sm" />
              <TextField label="Temporary PIN" name="new_pin" type="password" inputMode="numeric" autoComplete="new-password" maxLength={4} value={form.pin} onChange={(e) => setForm({ ...form, pin: e.target.value.replace(/\D/g, "").slice(0, 4) })} error={errors.pin} className="text-base sm:text-sm" />
              <TextField label="Type it again" name="new_confirm" type="password" inputMode="numeric" autoComplete="new-password" maxLength={4} value={form.confirm} onChange={(e) => setForm({ ...form, confirm: e.target.value.replace(/\D/g, "").slice(0, 4) })} error={errors.confirm} className="text-base sm:text-sm" />
            </div>
            <p className="text-sm text-stone-600">{text.pinNote}</p>
            {create.isError && (
              <p role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">{errorMessage(create.error)}</p>
            )}
            <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
              <Button type="button" variant="secondary" onClick={() => { setAdding(false); setForm(EMPTY_FORM); setErrors({}); }}>Cancel</Button>
              <Button type="submit" disabled={create.isPending}>{create.isPending ? "Adding…" : text.add}</Button>
            </div>
          </form>
        </Card>
      )}

      {chwsQuery.isError && <LoadErrorNotice error={chwsQuery.error} what={text.what} onRetry={() => void chwsQuery.refetch()} />}
      {chwsQuery.isPending && <p className="text-sm text-stone-500">Loading…</p>}
      {chws && chws.length === 0 && <EmptyState icon={UsersRound} title={text.empty} description={text.emptyHint} />}

      {chws && chws.length > 0 && (
        <ul className="space-y-3" aria-label={text.listLabel}>
          {chws.map((chw) => (
            <li key={chw.chw_id}>
              <Card className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-base font-semibold text-stone-900">{chw.full_name}</p>
                    {chw.status === "active" ? (
                      <Badge variant="success"><CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />Active</Badge>
                    ) : (
                      <Badge variant="neutral"><Ban className="h-3.5 w-3.5" aria-hidden="true" />Revoked</Badge>
                    )}
                  </div>
                  <p className="mt-0.5 text-sm text-stone-600">
                    {chw.chw_id} · {chw.clinic}
                    {role === "CHW" && ` · ${chw.visit_count} ${chw.visit_count === 1 ? "visit" : "visits"}`}
                  </p>
                </div>
                <div className="flex shrink-0 flex-wrap gap-2">
                  {chw.status === "active" ? (
                    <Button variant="secondary" onClick={() => { act.reset(); setAction({ kind: "revoke", chw }); }}>
                      <Ban className="h-4 w-4" aria-hidden="true" />Revoke<span className="sr-only"> {chw.full_name}</span>
                    </Button>
                  ) : (
                    <Button variant="secondary" onClick={() => { act.reset(); setAction({ kind: "reactivate", chw }); }}>
                      <RotateCcw className="h-4 w-4" aria-hidden="true" />Reactivate<span className="sr-only"> {chw.full_name}</span>
                    </Button>
                  )}
                  {chw.can_delete ? (
                    <Button variant="secondary" onClick={() => { act.reset(); setAction({ kind: "delete", chw }); }}>
                      <Trash2 className="h-4 w-4" aria-hidden="true" />Delete<span className="sr-only"> {chw.full_name}</span>
                    </Button>
                  ) : (
                    <p className="self-center text-xs text-stone-600">Has records - can't be deleted</p>
                  )}
                </div>
              </Card>
            </li>
          ))}
        </ul>
      )}

      <ModalDialog
        open={action !== null}
        title={action ? COPY[action.kind].title(action.chw.full_name) : ""}
        onClose={() => setAction(null)}
        busy={act.isPending}
        actions={
          <>
            <Button type="button" variant="secondary" onClick={() => setAction(null)} disabled={act.isPending}>Cancel</Button>
            <Button type="button" variant={action?.kind === "reactivate" ? "primary" : "danger"} onClick={() => action && act.mutate(action)} disabled={act.isPending}>
              {act.isPending ? "Saving…" : action ? COPY[action.kind].confirm : ""}
            </Button>
          </>
        }
      >
        {action && <p>{COPY[action.kind].body}</p>}
        {act.isError && <p role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-red-800">{errorMessage(act.error)}</p>}
      </ModalDialog>
    </div>
  );
}

function ManageChws() {
  return <ManageAccounts role="CHW" />;
}

export function ManageSupervisors() {
  return <ManageAccounts role="SUPERVISOR" />;
}

export default ManageChws;
