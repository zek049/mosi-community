import { useEffect, useRef, useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { CloudOff, UploadCloud } from "lucide-react";
import { db } from "../../db/indexedDb";
import * as api from "../../services/api";
import { findPossibleDuplicates, isPossibleDuplicate } from "../../utils/findPossibleDuplicates";
import { formatDate } from "../../utils/formatDate";
import { ModalDialog } from "../../components/ui/ModalDialog";
import { HouseholdField, type HouseholdChoice } from "../../components/HouseholdField";
import type { Household } from "../../models/household";
import { generateId } from "../../utils/uuid";
import { localIsoDate } from "../../utils/localDate";
import { useNetwork } from "../../contexts/NetworkContext";
import { offlineSaveExplanation, syncLaterHint } from "../../services/connectivity";
import { useSync } from "../../contexts/SyncContext";
import { useAnnouncer } from "../../contexts/AnnouncerContext";
import { usePageTitle } from "../../hooks/usePageTitle";
import { validatePatientForm, type PatientFormInput, type FormErrors } from "../../utils/validators";
import { TextField } from "../../components/ui/TextField";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { PageHeader } from "../../components/ui/PageHeader";
import { SavedRecordStatus } from "../../components/SavedRecordStatus";
import { cn } from "../../lib/utils";
import type { Patient } from "../../models/patient";

const FIELD_LABELS: Record<string, string> = {
  patient_id: "Patient ID",
  first_name: "First name",
  last_name: "Last name",
  date_of_birth: "Date of birth",
  gender: "Gender",
  village: "Village",
  phone_number: "Phone number",
  household: "Household",
};

const INITIAL_FORM: PatientFormInput = {
  patient_id: "",
  first_name: "",
  last_name: "",
  date_of_birth: "",
  gender: "",
  village: "",
  phone_number: "",
};

// Offline-first: validate -> generate UUID -> save to IndexedDB with
// sync_status "pending" -> show it immediately. Saving never touches the
// network; syncing is a separate step that only follows if there's a
// connection. The duplicate-ID check needs Dexie, so it runs after the
// synchronous rules.
function AddPatient() {
  usePageTitle("Add patient");
  const navigate = useNavigate();
  const { isOnline, status: connectivity } = useNetwork();
  const { syncNow } = useSync();
  const { announce } = useAnnouncer();
  const [form, setForm] = useState<PatientFormInput>(INITIAL_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [savedPatient, setSavedPatient] = useState<Patient | null>(null);
  // Possible duplicates found for the form as it stands: a warning only.
  const [duplicates, setDuplicates] = useState<api.PossibleDuplicate[] | null>(null);
  const [household, setHousehold] = useState<HouseholdChoice>({ kind: "none" });
  const errorSummaryRef = useRef<HTMLDivElement>(null);
  const savedHeadingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    if (savedPatient) savedHeadingRef.current?.focus();
  }, [savedPatient]);

  function updateField<K extends keyof PatientFormInput>(key: K, value: PatientFormInput[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  // Local check always (works offline); the server check too when online,
  // so patients registered on other devices are caught. Never blocks: a slow
  // or failed server check just falls back to the local result.
  async function lookForDuplicates(): Promise<api.PossibleDuplicate[]> {
    const candidate = { first_name: form.first_name, last_name: form.last_name, village: form.village, date_of_birth: form.date_of_birth };
    const local = findPossibleDuplicates(candidate, await db.patients.toArray());
    let remote: api.PossibleDuplicate[] = [];
    if (isOnline) {
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), 4000);
      try {
        remote = (await api.getPossibleDuplicates(candidate, controller.signal)).filter((p) => isPossibleDuplicate(candidate, p));
      } catch {
        remote = [];
      } finally {
        window.clearTimeout(timer);
      }
    }
    const byId = new Map<string, api.PossibleDuplicate>();
    for (const p of [...local, ...remote]) if (!byId.has(p.id)) byId.set(p.id, p);
    return [...byId.values()];
  }

  async function viewExisting(match: api.PossibleDuplicate) {
    // A match found only on the server isn't in this device's cache yet;
    // store it (as a synced record, like a cache refresh) so it can open.
    if (!(await db.patients.get(match.id))) {
      try {
        const full = await api.getPatient(match.id);
        const { visits: _visits, ...patient } = full;
        await db.patients.put({ ...patient, sync_status: "synced" });
      } catch {
        // Offline or not allowed: Patient detail will say it isn't on this device.
      }
    }
    navigate(`/patients/${match.id}`);
  }

  async function handleSubmit(event?: FormEvent, { skipDuplicateCheck = false }: { skipDuplicateCheck?: boolean } = {}) {
    event?.preventDefault();
    setSubmitting(true);

    const validationErrors = validatePatientForm(form);

    if (!validationErrors.patient_id && form.patient_id.trim()) {
      const existing = await db.patients.where("patient_id").equals(form.patient_id.trim()).first();
      if (existing) {
        validationErrors.patient_id = `${form.patient_id.trim()} is already used by another patient. Check the ID and try again.`;
      }
    }

    if (household.kind === "existing" && !household.id) {
      validationErrors.household = "Choose the household, or pick 'No household'.";
    }

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmitting(false);
      window.setTimeout(() => errorSummaryRef.current?.focus(), 0);
      return;
    }

    if (!skipDuplicateCheck) {
      const found = await lookForDuplicates();
      if (found.length > 0) {
        setDuplicates(found);
        setSubmitting(false);
        return;
      }
    }
    setDuplicates(null);

    const now = new Date().toISOString();
    const patient: Patient = {
      id: generateId(),
      patient_id: form.patient_id.trim(),
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      date_of_birth: form.date_of_birth,
      gender: form.gender as "M" | "F",
      village: form.village.trim(),
      phone_number: form.phone_number.trim() || null,
      created_at: now,
      updated_at: now,
      sync_status: "pending",
    };

    // A new household is created on this device together with the patient
    // (both pending; the household syncs first in the same batch).
    let newHousehold: Household | null = null;
    if (household.kind === "new") {
      newHousehold = { id: generateId(), household_code: household.code, village: patient.village, created_at: now, sync_status: "pending" };
      patient.household_id = newHousehold.id;
    } else if (household.kind === "existing") {
      patient.household_id = household.id;
    }

    await db.transaction("rw", [db.households, db.patients], async () => {
      if (newHousehold) await db.households.add(newHousehold);
      await db.patients.add(patient);
    });
    setErrors({});
    setSavedPatient(patient);
    setSubmitting(false);
    announce(
      isOnline ? "Patient saved on this device. Syncing now." : `Patient saved on this device. ${syncLaterHint(connectivity)}`,
    );
    if (isOnline) void syncNow();
  }

  function handleAddAnother() {
    setForm(INITIAL_FORM);
    setHousehold({ kind: "none" });
    setSavedPatient(null);
    setErrors({});
  }

  if (savedPatient) {
    return (
      <div className="max-w-2xl mx-auto space-y-5">
        <h1 ref={savedHeadingRef} tabIndex={-1} className="text-xl sm:text-2xl font-semibold text-stone-900 outline-none">
          Patient registered
        </h1>
        <SavedRecordStatus table="patients" id={savedPatient.id} noun="patient" />
        <Card className="text-sm text-stone-700">
          <span className="font-medium text-stone-900">
            {savedPatient.first_name} {savedPatient.last_name}
          </span>{" "}
          · {savedPatient.patient_id} · {savedPatient.village}
        </Card>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button asChild size="lg" className="sm:flex-1">
            <Link to={`/chw/visits/new?patient_id=${savedPatient.id}`}>Record a visit for this patient</Link>
          </Button>
          <Button asChild variant="secondary" size="lg" className="sm:flex-1">
            <Link to={`/patients/${savedPatient.id}`}>View patient</Link>
          </Button>
        </div>
        <Button type="button" variant="ghost" onClick={handleAddAnother}>
          Register another patient
        </Button>
      </div>
    );
  }

  const errorEntries = Object.entries(errors);

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      <PageHeader title="Add patient" description="Saved on this device straight away - no connection needed." />

      {errorEntries.length > 0 && (
        <div ref={errorSummaryRef} tabIndex={-1} role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 outline-none">
          <p className="text-sm font-semibold text-red-800">
            {errorEntries.length === 1 ? "One thing needs fixing:" : `${errorEntries.length} things need fixing:`}
          </p>
          <ul className="mt-1 list-disc pl-5 text-sm text-red-800">
            {errorEntries.map(([field, message]) => (
              <li key={field}>
                <span className="font-medium">{FIELD_LABELS[field] ?? field}:</span> {message}
              </li>
            ))}
          </ul>
        </div>
      )}

      <Card>
        <form onSubmit={(e) => void handleSubmit(e)} noValidate className="space-y-4">
          <TextField
            label="Patient ID"
            name="patient_id"
            autoComplete="off"
            placeholder="e.g. MBR-0026"
            value={form.patient_id}
            onChange={(e) => updateField("patient_id", e.target.value)}
            error={errors.patient_id}
            className="text-base sm:text-sm"
          />

          <div className="grid sm:grid-cols-2 gap-4">
            <TextField
              label="First name"
              name="first_name"
              autoComplete="off"
              value={form.first_name}
              onChange={(e) => updateField("first_name", e.target.value)}
              error={errors.first_name}
              className="text-base sm:text-sm"
            />
            <TextField
              label="Last name"
              name="last_name"
              autoComplete="off"
              value={form.last_name}
              onChange={(e) => updateField("last_name", e.target.value)}
              error={errors.last_name}
              className="text-base sm:text-sm"
            />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <TextField
              label="Date of birth"
              name="date_of_birth"
              type="date"
              max={localIsoDate()}
              value={form.date_of_birth}
              onChange={(e) => updateField("date_of_birth", e.target.value)}
              error={errors.date_of_birth}
              className="text-base sm:text-sm"
            />
            <fieldset aria-describedby={errors.gender ? "gender-error" : undefined} className="space-y-1.5">
              <legend className="text-sm font-medium text-stone-700">Gender</legend>
              <div className="grid grid-cols-2 gap-2">
                {(["F", "M"] as const).map((option) => (
                  <label
                    key={option}
                    className={cn(
                      "flex min-h-11 cursor-pointer items-center gap-2.5 rounded-lg border px-3 text-sm transition-colors has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-forest-700/40",
                      form.gender === option
                        ? "border-forest-700 bg-sage-50 font-medium text-forest-900"
                        : errors.gender
                          ? "border-red-400 text-stone-700"
                          : "border-stone-300 text-stone-700 hover:bg-stone-50",
                    )}
                  >
                    <input
                      type="radio"
                      name="gender"
                      value={option}
                      checked={form.gender === option}
                      onChange={() => updateField("gender", option)}
                      className="h-4 w-4 accent-forest-800"
                    />
                    {option === "F" ? "Female" : "Male"}
                  </label>
                ))}
              </div>
              {errors.gender && (
                <p id="gender-error" className="text-sm text-red-700">
                  {errors.gender}
                </p>
              )}
            </fieldset>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <TextField
              label="Village"
              name="village"
              autoComplete="off"
              value={form.village}
              onChange={(e) => updateField("village", e.target.value)}
              error={errors.village}
              className="text-base sm:text-sm"
            />
            <TextField
              label="Phone number (optional)"
              name="phone_number"
              type="tel"
              inputMode="numeric"
              autoComplete="off"
              placeholder="0771234567"
              value={form.phone_number}
              onChange={(e) => updateField("phone_number", e.target.value.replace(/[^\d]/g, ""))}
              error={errors.phone_number}
              className="text-base sm:text-sm"
            />
          </div>

          <HouseholdField village={form.village} value={household} onChange={setHousehold} error={errors.household} />

          <div className="space-y-4 border-t border-stone-100 pt-4">
            <p className="flex items-start gap-2 text-sm text-stone-600">
              {isOnline ? (
                <UploadCloud className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              ) : (
                <CloudOff className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              )}
              {isOnline
                ? "Saved on this device first, then synced to the server."
                : offlineSaveExplanation(connectivity, "patient")}
            </p>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-3">
              <Button type="button" variant="secondary" size="lg" onClick={() => navigate(-1)}>
                Cancel
              </Button>
              <Button type="submit" size="lg" disabled={submitting}>
                {submitting ? "Saving…" : "Save patient"}
              </Button>
            </div>
          </div>
        </form>
      </Card>

      {/* Possible duplicate: a warning, never a block. Focus starts on
          "Cancel" (the first action) so nothing happens by accident. */}
      <ModalDialog
        open={duplicates !== null}
        title={duplicates && duplicates.length > 1 ? "Similar patients already exist" : "A similar patient already exists"}
        onClose={() => setDuplicates(null)}
        actions={
          <>
            <Button type="button" variant="secondary" onClick={() => setDuplicates(null)}>
              Cancel
            </Button>
            {duplicates && duplicates.length === 1 && (
              <Button type="button" variant="secondary" onClick={() => void viewExisting(duplicates[0])}>
                View existing patient
              </Button>
            )}
            <Button type="button" onClick={() => void handleSubmit(undefined, { skipDuplicateCheck: true })}>
              Register anyway
            </Button>
          </>
        }
      >
        <p>
          {duplicates && duplicates.length > 1 ? "These patients have" : "This patient has"} the same name, village and date of
          birth. Check it isn't the same person before registering again.
        </p>
        <ul className="space-y-2">
          {duplicates?.map((d) => (
            <li key={d.id} className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-amber-950">
              <span className="font-semibold">
                {d.first_name} {d.last_name}
              </span>
              , {d.village}, born {formatDate(d.date_of_birth)}
              <span className="block text-xs text-amber-900">{d.patient_id}</span>
              {duplicates.length > 1 && (
                <button type="button" onClick={() => void viewExisting(d)} className="mt-1 min-h-11 text-sm font-medium text-forest-800 underline underline-offset-2">
                  View this patient<span className="sr-only">: {d.first_name} {d.last_name}</span>
                </button>
              )}
            </li>
          ))}
        </ul>
      </ModalDialog>
    </div>
  );
}

export default AddPatient;
