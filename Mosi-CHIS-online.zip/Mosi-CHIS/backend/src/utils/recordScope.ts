import { Prisma } from "@prisma/client";
import { prisma } from "../db";

// sync_log and sync_conflicts don't store a clinic: they point at a record
// (record_type + record_id). These helpers find the rows whose record
// belongs to one clinic, by joining to that record. Used only when the
// caller is clinic-scoped (clinicScope() returned a clinic id); an
// administrator's queries skip them. A row whose record never reached the
// server (e.g. a rejected create) has no clinic and is visible to
// administrators only.
const RECORD_CLINIC = Prisma.sql`COALESCE(p.clinic_id, v.clinic_id, h.clinic_id)`;
const RECORD_JOINS = (alias: string) => Prisma.sql`
  LEFT JOIN patients p ON ${Prisma.raw(alias)}.record_type = 'patient' AND p.id = ${Prisma.raw(alias)}.record_id
  LEFT JOIN visits v ON ${Prisma.raw(alias)}.record_type = 'visit' AND v.id = ${Prisma.raw(alias)}.record_id
  LEFT JOIN households h ON ${Prisma.raw(alias)}.record_type = 'household' AND h.id = ${Prisma.raw(alias)}.record_id`;

export async function syncLogIdsInClinic(clinicId: string, limit: number): Promise<number[]> {
  const rows = await prisma.$queryRaw<{ id: number }[]>`
    SELECT l.id FROM sync_log l ${RECORD_JOINS("l")}
    WHERE ${RECORD_CLINIC} = ${clinicId}
    ORDER BY l.synced_at DESC
    LIMIT ${limit}`;
  return rows.map((r) => Number(r.id));
}

export async function syncLogStatusCountsInClinic(clinicId: string, since: Date): Promise<{ status: string; count: number }[]> {
  const rows = await prisma.$queryRaw<{ status: string; count: bigint | number }[]>`
    SELECT l.status, COUNT(*) AS count FROM sync_log l ${RECORD_JOINS("l")}
    WHERE ${RECORD_CLINIC} = ${clinicId} AND l.synced_at >= ${since}
    GROUP BY l.status`;
  return rows.map((r) => ({ status: r.status, count: Number(r.count) }));
}

export async function conflictIdsInClinic(clinicId: string): Promise<number[]> {
  const rows = await prisma.$queryRaw<{ id: number }[]>`
    SELECT c.id FROM sync_conflicts c ${RECORD_JOINS("c")}
    WHERE ${RECORD_CLINIC} = ${clinicId}`;
  return rows.map((r) => Number(r.id));
}

// The clinic of the record a conflict points at (null if it's gone).
export async function recordClinic(recordType: string, recordId: string): Promise<string | null> {
  if (recordType === "patient") return (await prisma.patient.findUnique({ where: { id: recordId }, select: { clinic_id: true } }))?.clinic_id ?? null;
  if (recordType === "visit") return (await prisma.visit.findUnique({ where: { id: recordId }, select: { clinic_id: true } }))?.clinic_id ?? null;
  if (recordType === "household") return (await prisma.household.findUnique({ where: { id: recordId }, select: { clinic_id: true } }))?.clinic_id ?? null;
  return null;
}
