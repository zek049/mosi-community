import type { VisitType } from "../../models/visit";
import { Badge } from "./Badge";

// Shared by Patient Detail and Visit List so a visit's type always reads
// the same way wherever it's shown.
export function VisitTypeBadge({ type }: { type: VisitType }) {
  return <Badge variant="info">{type}</Badge>;
}
