// Every sync status sentence the app shows or announces, in one place.
//
// The server accepts one batch per request and answers with a verdict per
// record only when the whole batch is done, so the app can truthfully know:
// how many changes it sent (before), and how each one turned out (after).
// It cannot know "3 of 8 done" mid-request - so nothing here claims that.

export type BatchOutcome = {
  /** Records sent in the batch. */
  attempted: number;
  /** Accepted cleanly by the server. */
  synced: number;
  /** Received by the server but flagged for a supervisor to review. */
  conflicts: number;
  /** Rejected by the server; still waiting on this device. */
  failed: number;
};

export function plural(n: number, one: string, many: string): string {
  return `${n} ${n === 1 ? one : many}`;
}

/** Visible label while a batch is in flight. */
export function syncingLabel(count: number): string {
  return count > 0 ? `Syncing ${plural(count, "change", "changes")}…` : "Checking with the server…";
}

/** Screen-reader announcement when a batch starts (no ellipsis - it's read aloud). */
export function syncStartAnnouncement(count: number): string | null {
  return count > 0 ? `Syncing ${plural(count, "change", "changes")}.` : null;
}

/** What happened, from the server's own per-record verdicts. */
export function syncResultMessage(outcome: BatchOutcome): string {
  if (outcome.attempted === 0) return "Everything is up to date.";
  const parts: string[] = [];
  if (outcome.synced > 0) parts.push(`${plural(outcome.synced, "change", "changes")} synced.`);
  if (outcome.conflicts > 0) parts.push(`${plural(outcome.conflicts, "change needs", "changes need")} review.`);
  if (outcome.failed > 0) parts.push(`${plural(outcome.failed, "change", "changes")} couldn't sync and ${outcome.failed === 1 ? "is" : "are"} still waiting.`);
  return parts.join(" ");
}

/** The batch never got an answer (offline, server unreachable, session ended). */
export function syncPausedMessage(waiting: number): string {
  return waiting > 0
    ? `Sync paused. ${plural(waiting, "change is", "changes are")} still waiting.`
    : "Sync paused.";
}
