// Shown while a lazily-loaded screen's code chunk arrives - shaped like a
// page header plus a content card, so the layout doesn't jump when the
// real screen renders. Pulse is disabled under prefers-reduced-motion.
export function ScreenSkeleton() {
  return (
    <div className="space-y-4" role="status" aria-label="Loading">
      <div className="h-7 w-48 rounded-md bg-stone-200/70 animate-pulse motion-reduce:animate-none" />
      <div className="h-4 w-72 max-w-full rounded-md bg-stone-200/50 animate-pulse motion-reduce:animate-none" />
      <div className="h-40 rounded-xl bg-white border border-stone-200" />
    </div>
  );
}
