import { describe, expect, it } from "vitest";
import { classifySyncBuckets } from "../syncBuckets";
import type { Patient } from "../../models/patient";
import type { Visit } from "../../models/visit";

const now = "2026-10-05T09:00:00.000Z";
const patient = (id: string, extra: Partial<Patient> = {}): Patient => ({
  id,
  patient_id: id.toUpperCase(),
  first_name: "A",
  last_name: id,
  date_of_birth: "1990-01-01",
  gender: "F",
  village: "Mbare",
  phone_number: null,
  created_at: now,
  updated_at: now,
  sync_status: "synced",
  registered_by_chw_id: "CHW001",
  ...extra,
});
const visit = (id: string, extra: Partial<Visit> = {}): Visit => ({
  id,
  patient_id: "p-conf",
  chw_id: "CHW001",
  visit_date: "2026-10-05",
  visit_type: "Antenatal",
  weight: null,
  height: null,
  blood_pressure: null,
  notes: null,
  created_at: now,
  updated_at: now,
  sync_status: "synced",
  ...extra,
});

describe("CHW sync status buckets", () => {
  const b = classifySyncBuckets(
    "CHW001",
    [
      patient("p-wait", { sync_status: "pending", review_status: "confirmed" }), // edited locally: still just waiting
      patient("p-fail", { sync_status: "pending" }),
      patient("p-conflict", { review_status: "confirmed" }),
      patient("p-await", { review_status: "awaiting_review" }),
      patient("p-conf", { review_status: "confirmed" }),
      patient("p-flag", { review_status: "flagged", review_flag_reason: "Wrong DOB" }),
      patient("p-unknown"),
      patient("p-other", { registered_by_chw_id: "CHW002", review_status: "awaiting_review" }),
      patient("p-archived", { review_status: "awaiting_review", deleted_at: now }),
    ],
    [visit("v-await", { review_status: "awaiting_review" }), visit("v-other", { chw_id: "CHW002", review_status: "flagged" })],
    [
      { id: "p-fail", record_type: "patient", status: "failed", attempted_at: now },
      { id: "p-conflict", record_type: "patient", status: "conflict", attempted_at: now },
    ],
  );
  const ids = (rows: { id: string }[]) => rows.map((r) => r.id).sort();

  it("pending/local records are Waiting or Couldn't sync, whatever their last review state", () => {
    expect(ids(b.waiting)).toEqual(["p-wait"]);
    expect(ids(b.failed)).toEqual(["p-fail"]);
  });
  it("a sync conflict is its own bucket (not the review queue)", () => {
    expect(ids(b.conflict)).toEqual(["p-conflict"]);
  });
  it("awaiting review / confirmed / flagged are kept apart; awaiting is never counted as confirmed", () => {
    expect(ids(b.awaiting)).toEqual(["p-await", "v-await"]);
    expect(ids(b.confirmed)).toEqual(["p-conf"]);
    expect(ids(b.flagged)).toEqual(["p-flag"]);
  });
  it("flagged rows carry the supervisor's reason", () => {
    expect(b.flagged[0].flagReason).toBe("Wrong DOB");
  });
  it("unknown review state is 'Synced', not 'Confirmed'", () => {
    expect(ids(b.synced)).toEqual(["p-unknown"]);
  });
  it("colleagues' cached records and archived ones aren't counted as this CHW's work", () => {
    const all = Object.values(b).flat().map((r) => r.id);
    expect(all).not.toContain("p-other");
    expect(all).not.toContain("v-other");
    expect(all).not.toContain("p-archived");
  });
});
