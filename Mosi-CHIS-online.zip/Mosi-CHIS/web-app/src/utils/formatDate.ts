import { calendarDay } from "./localDate";

// Calendar dates (visit_date, date_of_birth) arrive either as "YYYY-MM-DD"
// (created on this device) or as UTC midnight "YYYY-MM-DDT00:00:00.000Z"
// (from the server). Both mean a day, not an instant - so they're shown as
// that day in every time zone rather than shifted by the UTC offset.
const CALENDAR_DATE = /^\d{4}-\d{2}-\d{2}(T00:00:00(\.000)?Z)?$/;

export function formatDate(value: string): string {
  const date = CALENDAR_DATE.test(value) ? new Date(`${calendarDay(value)}T00:00:00`) : new Date(value);
  return date.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}
