import { Link } from "react-router-dom";
import { AlertCircle, CalendarClock, ChevronRight } from "lucide-react";
import { describeDue } from "../utils/due";
import { cn } from "../lib/utils";

export type DueRow = {
  key: string;
  patientRecordId: string; // the patient's database id, for the link
  name: string;
  detail: string; // e.g. "MBR-0012 · Mbare"
  visitType: string;
  daysOverdue: number;
};

// Follow-ups list shared by CHW Home (from the device) and the supervisor
// dashboard (from the server). Overdue is shown with an icon AND words, not
// colour alone.
export function DueList({ rows }: { rows: DueRow[] }) {
  return (
    <ul className="divide-y divide-stone-100 overflow-hidden rounded-xl border border-stone-200 bg-white">
      {rows.map((row) => {
        const overdue = row.daysOverdue > 0;
        const Icon = overdue ? AlertCircle : CalendarClock;
        return (
          <li key={row.key}>
            <Link to={`/patients/${row.patientRecordId}`} className="flex min-h-14 items-center justify-between gap-3 px-4 py-3 hover:bg-stone-50">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium text-stone-900">{row.name}</p>
                <p className="truncate text-xs text-stone-600">
                  {row.visitType} · {row.detail}
                </p>
              </div>
              <span className={cn("flex shrink-0 items-center gap-1 text-xs font-medium", overdue ? "text-red-700" : "text-stone-700")}>
                <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                {describeDue(row.daysOverdue)}
              </span>
              <ChevronRight className="h-4 w-4 shrink-0 text-stone-400" aria-hidden="true" />
            </Link>
          </li>
        );
      })}
    </ul>
  );
}
