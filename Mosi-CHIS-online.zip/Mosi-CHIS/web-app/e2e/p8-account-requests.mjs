// Feature 2 - account requests + supervisor approval. Production build (:4173), real backend.
import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const SUFFIX = String(Date.now()).slice(-6);
const ID_A = `T8A${SUFFIX}`; // will be approved
const ID_R = `T8R${SUFFIX}`; // will be rejected
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
function track(page, who, allow = []) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => {
    if (m.type() !== "error") return;
    if (allow.some((re) => re.test(m.text()))) return;
    errors.push(`${who}: ${m.text()}`);
  });
}
async function axe(page, label) {
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
const active = (page) => page.evaluate(() => ({ tag: document.activeElement?.tagName, text: (document.activeElement?.textContent || "").trim().slice(0, 50), role: document.activeElement?.getAttribute("role") }));
async function waitOnline(page) {
  await page.waitForFunction(() => [...document.querySelectorAll("span.sr-only")].some((s) => s.textContent === "Connection: " && s.parentElement.textContent.includes("Online")), null, { timeout: 10000 });
}
async function login(page, id, pin) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await waitOnline(page);
  await page.fill("#chwId", id); await page.fill("#pin", pin); await page.press("#pin", "Enter");
}
async function fillRequest(page, id, name) {
  await page.fill("#full_name", name);
  await page.fill("#chw_id", id);
  await page.click("#clinic_id");
  await page.click('[role="option"]:has-text("Mbare Clinic")');
  await page.fill("#phone_number", "0771234567");
  await page.fill("#pin", "4821");
  await page.fill("#confirm", "4821");
}

const browser = await chromium.launch();

// 1. Public request
{
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "request", [/status of 409/, /status of 403/, /status of 401/]);
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.click("text=Request an account");
  await page.waitForURL("**/request-account");
  await waitOnline(page);
  report("Request: reachable from the Sign in page", true);
  await axe(page, "Request form (375px)");
  await page.click('button:has-text("Send request")');
  await page.waitForTimeout(200);
  const a = await active(page);
  report("Request: empty submit -> focused error summary naming fields", a.role === "alert" && /Full name/.test(a.text) || /things need fixing/.test(a.text), a);
  await fillRequest(page, ID_A.toLowerCase(), "Approve Me");
  report("Request: CHW ID is upper-cased as typed", (await page.inputValue("#chw_id")) === ID_A);
  await page.fill("#confirm", "4822");
  await page.click('button:has-text("Send request")');
  await page.waitForTimeout(200);
  report("Request: mismatched PIN confirmation caught before sending", await page.isVisible("text=The two PINs don't match"));
  await page.fill("#confirm", "4821");
  await page.click('button:has-text("Send request")');
  await page.waitForSelector("text=Request submitted", { timeout: 8000 });
  const body = await page.locator("main").innerText();
  report("Request: shows the exact pending message", body.includes("Your request has been submitted and is pending supervisor approval"));
  report("Request: shows the CHW ID and clinic, and says they're NOT signed in", body.includes(ID_A) && body.includes("Mbare Clinic") && /haven't been signed in/.test(body));
  report("Request: success heading receives focus", (await active(page)).tag === "H1");
  report("Request: no session created", (await page.evaluate(() => localStorage.getItem("mosi.session"))) === null);
  await axe(page, "Request submitted");
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  report("Request: no horizontal scroll at 375px", overflow <= 0, overflow);

  // Duplicate request for the same ID
  await page.goto(`${BASE}/request-account`, { waitUntil: "networkidle" });
  await waitOnline(page);
  await fillRequest(page, ID_A, "Someone Else");
  await page.click('button:has-text("Send request")');
  await page.waitForSelector("text=That CHW ID can't be used", { timeout: 8000 });
  report("Request: duplicate ID -> generic 'can't be used' message, focus on it", (await active(page)).role === "alert");

  // Second request (to be rejected)
  await page.goto(`${BASE}/request-account`, { waitUntil: "networkidle" });
  await waitOnline(page);
  await fillRequest(page, ID_R, "Reject Me");
  await page.click('button:has-text("Send request")');
  await page.waitForSelector("text=Request submitted", { timeout: 8000 });

  // Signing in before approval
  await login(page, ID_A, "4821");
  await page.waitForSelector("text=waiting for a supervisor to approve it", { timeout: 8000 });
  report("Sign in before approval (right PIN): told it's pending, not signed in", new URL(page.url()).pathname === "/login");
  await login(page, ID_A, "0000");
  await page.waitForSelector("text=Invalid CHW ID or PIN", { timeout: 8000 });
  report("Sign in before approval (wrong PIN): generic message only", !(await page.isVisible("text=waiting for a supervisor")));
  await ctx.close();
}

// 2. CHW cannot review
{
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const page = await ctx.newPage();
  track(page, "chw", [/status of 403/]);
  await login(page, "CHW001", "1234");
  await page.waitForURL("**/chw");
  await page.goto(`${BASE}/supervisor/account-requests`, { waitUntil: "networkidle" });
  report("CHW: redirected away from the Account requests screen", new URL(page.url()).pathname === "/chw");
  const status = await page.evaluate(async (API) => (await fetch(`${API}/account-requests`, { credentials: "include" })).status, API);
  report("CHW: server refuses the review API (403)", status === 403, status);
  await ctx.close();
}

// 3. Supervisor review
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "supervisor");
  await login(page, "SUP001", "1234");
  await page.waitForURL("**/supervisor");
  await page.waitForTimeout(1500);
  const navText = await page.locator('aside a[href="/supervisor/account-requests"]').innerText();
  report("Supervisor: 'Account requests' in the sidebar with a pending count", /Account requests/.test(navText) && /\b2\b/.test(navText), navText);
  await page.click('aside a[href="/supervisor/account-requests"]');
  await page.waitForSelector(`text=${ID_A}`);
  const list = await page.locator("main").innerText();
  report("Supervisor: shows name, requested ID, clinic, phone, request date", list.includes("Approve Me") && list.includes(ID_A) && list.includes("Mbare Clinic") && list.includes("0771234567") && /Requested/.test(list));
  report("Supervisor: never shows a PIN or hash", !/4821|\$2[aby]\$/.test(list));
  await axe(page, "Account requests screen");

  // Approve via keyboard; Escape first
  const approveA = page.getByRole("button", { name: `Approve Approve Me` });
  await approveA.focus();
  await page.keyboard.press("Enter");
  await page.waitForSelector("dialog[open]");
  report("Supervisor: approve dialog opens with focus on Cancel", (await active(page)).text === "Cancel");
  await axe(page, "Approve dialog open");
  await page.keyboard.press("Escape");
  await page.waitForTimeout(200);
  report("Supervisor: Escape cancels, focus back on the Approve button", /Approve/.test((await active(page)).text) && !(await page.isVisible("dialog[open]")));
  await approveA.click();
  await page.click('dialog[open] button:has-text("Approve and create account")');
  await page.waitForSelector("text=Approved. Approve Me can now sign in", { timeout: 8000 });
  report("Supervisor: approval confirmed in a focused status message", (await active(page)).role === "status");

  // Reject the other
  await page.getByRole("button", { name: "Reject Reject Me" }).click();
  await page.fill("dialog[open] textarea", "Test: not on the staff list");
  await page.click('dialog[open] button:has-text("Reject request")');
  await page.waitForSelector("text=Rejected. No account was created for Reject Me", { timeout: 8000 });
  const reviewed = await page.locator("section[aria-labelledby='reviewed-heading']").innerText();
  report("Supervisor: Reviewed list shows outcomes and the reviewer", /Approve Me/.test(reviewed) && /Approved by Grace Chikwanha/.test(reviewed) && /Rejected by Grace Chikwanha/.test(reviewed), reviewed.slice(0, 400));
  report("Supervisor: badge cleared after review", !/\d/.test(await page.locator('aside a[href="/supervisor/account-requests"]').innerText()));
  await ctx.close();
}

// 4. Outcomes for the requesters
{
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const page = await ctx.newPage();
  track(page, "after", [/status of 401/]);
  await login(page, ID_A, "4821");
  report("Approved requester: signs in with the PIN they chose -> CHW home", await page.waitForURL("**/chw", { timeout: 8000 }).then(() => true).catch(() => false));
  await page.evaluate(() => localStorage.clear());
  await login(page, ID_R, "4821");
  await page.waitForSelector("text=Invalid CHW ID or PIN", { timeout: 8000 });
  report("Rejected requester: no account exists (generic message)", new URL(page.url()).pathname === "/login");
  await ctx.close();
}

await browser.close();
console.log(`\nConsole/page errors: ${errors.length}`); errors.forEach((e) => console.log("  ", e));
console.log(`${pass} passed, ${fail} failed. IDS=${ID_A},${ID_R}`);
