// Feature 3 - CHW account management. Production build (:4173), real backend.
import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const NEW_ID = `T9X${String(Date.now()).slice(-6)}`;
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
function track(page, who, allow = []) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => { if (m.type() === "error" && !allow.some((re) => re.test(m.text()))) errors.push(`${who}: ${m.text()}`); });
}
async function axe(page, label) {
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
const active = (page) => page.evaluate(() => ({ tag: document.activeElement?.tagName, text: (document.activeElement?.textContent || "").trim().slice(0, 60), role: document.activeElement?.getAttribute("role") }));
async function login(page, id, pin) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => document.body.innerText.includes("Online"), null, { timeout: 10000 });
  await page.fill("#chwId", id); await page.fill("#pin", pin); await page.press("#pin", "Enter");
}
const card = (page, name) => page.locator('ul[aria-label="CHW accounts"] > li', { hasText: name });

const browser = await chromium.launch();
const sctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
const sp = await sctx.newPage();
track(sp, "supervisor", [/status of 409/]);
await login(sp, "SUP001", "1234");
await sp.waitForURL("**/supervisor");
await sp.click('aside a[href="/supervisor/chws"]');
await sp.waitForSelector('ul[aria-label="CHW accounts"]');
const jane = await card(sp, "Jane Moyo").innerText();
report("List: name, ID, clinic, Active status, visit count", /CHW001/.test(jane) && /Mbare Clinic/.test(jane) && /Active/.test(jane) && /\d+ visits/.test(jane), jane);
report("List: a CHW with records can't be deleted (no Delete button, says why)", /Has records - can't be deleted/.test(jane) && (await card(sp, "Jane Moyo").locator('button:has-text("Delete")').count()) === 0);
report("List: CHW004 shows as Revoked with Reactivate", /Revoked/.test(await card(sp, "Nyasha Chidziva").innerText()) && (await card(sp, "Nyasha Chidziva").locator('button:has-text("Reactivate")').count()) === 1);
report("List: supervisors aren't listed (managed by admins only)", (await sp.locator('ul[aria-label="CHW accounts"]').innerText()).includes("Grace Chikwanha") === false);
await axe(sp, "Manage CHWs list");

// Add a CHW
await sp.click('button:has-text("Add CHW")');
await sp.waitForSelector("#add-chw-heading");
report("Add: form opens with focus on the first field", (await active(sp)).tag === "INPUT");
await sp.click('form button[type="submit"]:has-text("Add CHW")');
await sp.waitForTimeout(150);
report("Add: validation names missing fields", await sp.isVisible("text=Enter your full name.") || await sp.isVisible("text=Choose your clinic."));
await axe(sp, "Add CHW form with errors");
await sp.fill("#new_full_name", "Test Addition");
await sp.fill("#new_chw_id", NEW_ID);
await sp.click("#new_clinic_id"); await sp.click('[role="option"]:has-text("Mbare Clinic")');
await sp.fill("#new_pin", "4829"); await sp.fill("#new_confirm", "4829");
await sp.click('form button[type="submit"]:has-text("Add CHW")');
await sp.waitForSelector(`text=Test Addition (${NEW_ID}) was added`, { timeout: 8000 });
report("Add: confirmed in a focused status message", (await active(sp)).role === "status");
const fresh = await card(sp, "Test Addition").innerText();
report("Add: new account listed Active, 0 visits, deletable", /Active/.test(fresh) && /0 visits/.test(fresh) && (await card(sp, "Test Addition").locator('button:has-text("Delete")').count()) === 1);

// The new CHW signs in (in its own browser) and stays signed in
const cctx = await browser.newContext({ viewport: { width: 375, height: 812 } });
const cp = await cctx.newPage();
track(cp, "new-chw", [/status of 403/]);
await login(cp, NEW_ID, "4829");
report("New CHW's first sign-in goes to 'Choose a new PIN' (supervisor knows the temporary one)", await cp.waitForURL("**/change-pin", { timeout: 8000 }).then(() => true).catch(() => false));
await cp.fill("#current_pin", "4829"); await cp.fill("#new_pin", "5917"); await cp.fill("#confirm_pin", "5917");
await cp.press("#confirm_pin", "Enter");
report("New CHW chooses their own PIN, then lands on Home", await cp.waitForURL("**/chw", { timeout: 8000 }).then(() => true).catch(() => false));

// Revoke (Escape first)
const revokeBtn = card(sp, "Test Addition").getByRole("button", { name: /Revoke/ });
await revokeBtn.focus();
await sp.keyboard.press("Enter");
await sp.waitForSelector("dialog[open]");
report("Revoke: confirmation dialog, focus on Cancel, explains history is kept", (await active(sp)).text === "Cancel" && /history are kept/.test(await sp.locator("dialog[open]").innerText()));
await axe(sp, "Revoke dialog");
await sp.keyboard.press("Escape");
await sp.waitForTimeout(200);
report("Revoke: Escape cancels, focus back on Revoke", /Revoke/.test((await active(sp)).text));
await revokeBtn.click();
await sp.click('dialog[open] button:has-text("Revoke access")');
await sp.waitForSelector("text=access was revoked", { timeout: 8000 });
report("Revoke: shown as Revoked", /Revoked/.test(await card(sp, "Test Addition").innerText()));
const afterRevoke = await cp.evaluate(async (API) => { const r = await fetch(`${API}/chws`, { credentials: "include" }); return { status: r.status, body: await r.json() }; }, API);
report("Revoke: the CHW's open session is refused on its next request", afterRevoke.status === 403 && afterRevoke.body.message === "This account has been deactivated", afterRevoke);
await cp.evaluate(() => localStorage.clear());
await login(cp, NEW_ID, "5917");
await cp.waitForSelector("text=This account has been deactivated", { timeout: 8000 });
report("Revoke: correct PIN -> 'This account has been deactivated', not signed in", new URL(cp.url()).pathname === "/login");
await login(cp, "CHW004", "1234");
await cp.waitForSelector("text=This account has been deactivated", { timeout: 8000 });
report("Seed CHW004 (migrated inactive -> revoked) is also refused", true);

// Reactivate
await card(sp, "Test Addition").getByRole("button", { name: /Reactivate/ }).click();
await sp.click('dialog[open] button:has-text("Reactivate")');
await sp.waitForSelector("text=can sign in again", { timeout: 8000 });
await login(cp, NEW_ID, "5917");
report("Reactivate: the CHW can sign in again", await cp.waitForURL("**/chw", { timeout: 8000 }).then(() => true).catch(() => false));

// Delete rules
const delJane = await sp.evaluate(async (API) => { const r = await fetch(`${API}/chws/CHW001`, { method: "DELETE", credentials: "include" }); return { status: r.status, body: await r.json() }; }, API);
report("Delete: server refuses a CHW with records (409, revoke instead)", delJane.status === 409 && delJane.body.code === "HAS_HISTORY", delJane.status);
await card(sp, "Test Addition").getByRole("button", { name: /Delete/ }).click();
report("Delete: dialog warns it's permanent", /can't be undone/.test(await sp.locator("dialog[open]").innerText()));
await sp.click('dialog[open] button:has-text("Delete permanently")');
await sp.waitForSelector("text=account was deleted", { timeout: 8000 });
report("Delete: account removed from the list", (await card(sp, "Test Addition").count()) === 0);

// Phone width
await sp.setViewportSize({ width: 360, height: 780 });
await sp.reload({ waitUntil: "networkidle" });
await sp.waitForSelector('ul[aria-label="CHW accounts"]');
const overflow = await sp.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
report("Phone 360px: no horizontal scroll", overflow <= 0, overflow);
await axe(sp, "Manage CHWs at 360px");
await sctx.close();

// CHW can't manage
const xctx = await browser.newContext({ viewport: { width: 375, height: 812 } });
const xp = await xctx.newPage();
track(xp, "chw", [/status of 403/]);
await login(xp, "CHW001", "1234");
await xp.waitForURL("**/chw");
await xp.goto(`${BASE}/supervisor/chws`, { waitUntil: "networkidle" });
report("CHW: redirected away from Manage CHWs", new URL(xp.url()).pathname === "/chw");
const r = await xp.evaluate(async (API) => (await fetch(`${API}/chws/CHW002/revoke`, { method: "POST", credentials: "include" })).status, API);
report("CHW: server refuses revoke (403)", r === 403, r);
await xctx.close();
await cctx.close();

await browser.close();
console.log(`\nConsole/page errors: ${errors.length}`); errors.forEach((e) => console.log("  ", e));
console.log(`${pass} passed, ${fail} failed. NEW_ID=${NEW_ID}`);
