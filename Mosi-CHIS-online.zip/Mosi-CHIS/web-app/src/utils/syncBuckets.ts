import type { SyncAttemptRecord } from "../db/indexedDb";
import type { Patient } from "../models/patient";
import type { Visit } from "../models/visit";

export type BucketRow = {
  id: string;
  title: string;
  subtitle: string;
  timestamp: string;
  attempt?: SyncAttemptRecord;
  /** Why a supervisor flagged it (flagged bucket only). */
  flagReason?: string | null;
};

export type SyncBuckets = {
  /** On this device only, not sent yet. */
  waiting: BucketRow[];
  /** On this device only; the server refused the last attempt. */
  failed: BucketRow[];
  /** Sent, but edited in two places at once - a supervisor picks a version. */
  conflict: BucketRow[];
  /** On the server, waiting for a supervisor to check it. */
  awaiting: BucketRow[];
  confirmed: BucketRow[];
  flagged: BucketRow[];
  /** On the server, review state not known on this device yet. */
  synced: BucketRow[];
};

// Where each of THIS CHW's records stands. Records still on the device are
// always this CHW's own; for records on the server, only ones this CHW
// registered/recorded are counted (the device also caches colleagues'
// records for lookups - those aren't "your work").
export function classifySyncBuckets(chwId: string, patients: Patient[], visits: Visit[], attempts: SyncAttemptRecord[]): SyncBuckets {
  const attemptById = new Map(attempts.map((a) => [a.id, a]));
  const patientById = new Map(patients.map((p) => [p.id, p]));
  const buckets: SyncBuckets = { waiting: [], failed: [], conflict: [], awaiting: [], confirmed: [], flagged: [], synced: [] };

  function place(row: BucketRow, record: Patient | Visit, mine: boolean) {
    if (record.deleted_at) return;
    if (record.sync_status === "pending") {
      (row.attempt?.status === "failed" ? buckets.failed : buckets.waiting).push(row);
      return;
    }
    if (row.attempt?.status === "conflict") {
      buckets.conflict.push(row);
      return;
    }
    if (!mine) return;
    switch (record.review_status) {
      case "awaiting_review":
        buckets.awaiting.push(row);
        break;
      case "confirmed":
        buckets.confirmed.push(row);
        break;
      case "flagged":
        buckets.flagged.push({ ...row, flagReason: record.review_flag_reason ?? null });
        break;
      default:
        buckets.synced.push(row);
    }
  }

  for (const p of patients) {
    place(
      { id: p.id, title: `${p.first_name} ${p.last_name}`, subtitle: `Patient · ${p.patient_id}`, timestamp: p.updated_at, attempt: attemptById.get(p.id) },
      p,
      p.registered_by_chw_id === chwId,
    );
  }
  for (const v of visits) {
    const patient = patientById.get(v.patient_id);
    place(
      {
        id: v.id,
        title: `${v.visit_type} visit`,
        subtitle: patient ? `Visit · ${patient.first_name} ${patient.last_name}` : "Visit",
        timestamp: v.updated_at,
        attempt: attemptById.get(v.id),
      },
      v,
      v.chw_id === chwId,
    );
  }
  return buckets;
}
