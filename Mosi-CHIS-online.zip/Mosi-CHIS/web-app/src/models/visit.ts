import type { ReviewStatus, SyncStatus } from "./patient";

// Same mirroring rule as models/patient.ts: fields match
// backend/prisma/schema.prisma's Visit model exactly.

export const VISIT_TYPES = [
  "Immunization",
  "Antenatal",
  "Growth Monitoring",
  "HIV/TB Support",
  "Health Education",
  "Disease Surveillance",
  "Other",
] as const;

export type VisitType = (typeof VISIT_TYPES)[number];

export interface Visit {
  id: string;
  patient_id: string;
  chw_id: string;
  visit_date: string;
  visit_type: VisitType;
  weight: number | null;
  height: number | null;
  blood_pressure: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  sync_status: SyncStatus;
  // Server-assigned (backend MVP hardening) - see models/patient.ts's
  // matching comment.
  clinic_id?: string;
  deleted_at?: string | null;
  // Supervisor review (server-owned, read-only here): filled from sync
  // results and cache refreshes. Absent = not known on this device yet.
  review_status?: ReviewStatus;
  review_flag_reason?: string | null;
  reviewed_at?: string | null;
  reviewed_by?: string | null;
}
