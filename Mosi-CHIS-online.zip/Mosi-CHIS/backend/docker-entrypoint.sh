#!/bin/sh
set -e

# The postgres container's own healthcheck (see docker-compose.yml) already
# makes docker-compose wait before starting this one, but "healthy" only
# means Postgres accepts TCP connections - the retry loop below is a
# defensive backstop for the rare case a migration still races it.
echo "Applying database migrations..."
until npx prisma migrate deploy; do
  echo "Migration attempt failed - retrying in 2s..."
  sleep 2
done

# Reseeding wipes every patient/visit/sync-log row (see prisma/seed.ts) and
# replaces them with fresh synthetic data - correct for a demo stack where a
# clean, deterministic dataset on every start is wanted, but catastrophic for
# any deployment holding real records: a routine restart would destroy them.
# Opt-in only, via SEED_ON_START=true (docker-compose.yml sets it for the
# local demo stack; a real deployment must never set it).
if [ "$SEED_ON_START" = "true" ]; then
  echo "SEED_ON_START=true - seeding demo data (this deletes all existing patients/visits/sync log entries)..."
  npm run db:seed
else
  echo "Skipping demo seed (SEED_ON_START is not \"true\")."
fi

echo "Starting Mosi API..."
exec npm start
