import { z, ZodError, type ZodTypeAny } from "zod";
import { AppError } from "../utils/AppError";

// Thin wrapper so every route gets the same 400 AppError shape from a zod
// failure, with all issues joined into one readable message (matching the
// existing hand-rolled validators' error-list style rather than exposing
// zod's own nested issue format to clients).
export function parseBody<T extends ZodTypeAny>(schema: T, body: unknown): z.infer<T> {
  const result = schema.safeParse(body);
  if (!result.success) {
    throw new AppError(400, formatZodError(result.error));
  }
  return result.data;
}

function formatZodError(error: ZodError): string {
  return error.issues
    .map((issue) => {
      const path = issue.path.length > 0 ? `${issue.path.join(".")}: ` : "";
      return `${path}${issue.message}`;
    })
    .join(". ");
}

export const loginSchema = z
  .object({
    chw_id: z.string().trim().min(1, "CHW ID is required"),
    pin: z.string().regex(/^\d{4}$/, "PIN must be exactly 4 digits"),
  })
  .strict();

export const chwCreateSchema = z
  .object({
    chw_id: z
      .string()
      .trim()
      .min(3, "chw_id must be at least 3 characters")
      .max(20, "chw_id must be at most 20 characters")
      .regex(/^[A-Za-z0-9_-]+$/, "chw_id may only contain letters, numbers, hyphens and underscores"),
    full_name: z.string().trim().min(1, "full_name is required").max(120),
    clinic_id: z.string().trim().min(1, "clinic_id is required"),
    phone_number: z
      .string()
      .regex(/^0\d{9}$/, "phone_number must be 10 digits starting with 0, e.g. 0771234567")
      .optional()
      .nullable(),
    role: z.enum(["CHW", "SUPERVISOR"]).default("CHW"),
    pin: z.string().regex(/^\d{4}$/, "pin must be exactly 4 digits"),
  })
  .strict();

// Public account request. Deliberately has NO role/status fields and is
// .strict(), so a requester can't send them: the server always creates a
// CHW-role account in status "pending".
export const accountRequestSchema = z
  .object({
    chw_id: z
      .string()
      .trim()
      .min(3, "CHW ID must be at least 3 characters")
      .max(20, "CHW ID must be at most 20 characters")
      .regex(/^[A-Za-z0-9_-]+$/, "CHW ID may only contain letters, numbers, hyphens and underscores")
      .transform((v) => v.toUpperCase()),
    full_name: z.string().trim().min(2, "Full name is required").max(120),
    clinic_id: z.string().trim().min(1, "Choose a clinic"),
    phone_number: z
      .string()
      .regex(/^0\d{9}$/, "Phone number must be 10 digits starting with 0, e.g. 0771234567")
      .optional()
      .nullable(),
    pin: z.string().regex(/^\d{4}$/, "PIN must be exactly 4 digits"),
  })
  .strict();

// Supervisor approval: may confirm or change the clinic. No role field -
// a request can only ever become a CHW account (strict: "role" is a 400).
export const accountApprovalSchema = z
  .object({
    clinic_id: z.string().trim().min(1).optional(),
  })
  .strict();

export const accountRejectionSchema = z
  .object({
    // Kept only in the audit log, never shown to the applicant.
    reason: z.string().trim().max(300).optional(),
  })
  .strict();

export const pinResetRequestSchema = z
  .object({ chw_id: z.string().trim().min(1, "Enter your CHW ID").max(40) })
  .strict();

export const pinResetCompleteSchema = z
  .object({ new_pin: z.string().regex(/^\d{4}$/, "The new PIN must be exactly 4 digits") })
  .strict();

export const changePinSchema = z
  .object({
    current_pin: z.string().regex(/^\d{4}$/, "Enter your current 4-digit PIN"),
    new_pin: z.string().regex(/^\d{4}$/, "The new PIN must be exactly 4 digits"),
  })
  .strict();

export const chwUpdateSchema = z
  .object({
    full_name: z.string().trim().min(1).max(120).optional(),
    clinic_id: z.string().trim().min(1).optional(),
    phone_number: z
      .string()
      .regex(/^0\d{9}$/, "phone_number must be 10 digits starting with 0, e.g. 0771234567")
      .optional()
      .nullable(),
    // Supervisor-set PIN reset - optional, only present when a supervisor is
    // deliberately resetting a CHW's PIN (e.g. after a lockout).
    pin: z.string().regex(/^\d{4}$/, "pin must be exactly 4 digits").optional(),
  })
  .strict()
  .refine((data) => Object.keys(data).length > 0, { message: "At least one field is required" });

export const clinicCreateSchema = z
  .object({
    code: z
      .string()
      .trim()
      .min(2)
      .max(12)
      .regex(/^[A-Za-z0-9_-]+$/, "code may only contain letters, numbers, hyphens and underscores"),
    name: z.string().trim().min(1).max(120),
    location: z.string().trim().max(200).optional().nullable(),
  })
  .strict();

export const conflictResolutionSchema = z
  .object({
    resolution: z.enum(["KEEP_SERVER", "APPLY_INCOMING"]),
  })
  .strict();

// Bounds only (section 29) - individual patient/visit field validation
// stays in services/validation.ts, which is also reused by the sync path
// for per-record (not whole-batch) failure reporting.
export const MAX_SYNC_BATCH_RECORDS = 200;

// Review queue decisions. A flag must say why (the CHW sees it).
export const reviewConfirmSchema = z.object({}).strict();
export const reviewFlagSchema = z
  .object({
    reason: z.string().trim().min(3, "Say why the record is flagged (at least 3 characters)").max(500, "Keep the reason under 500 characters"),
  })
  .strict();

export const householdCreateSchema = z
  .object({
    id: z.string().uuid("id must be a UUID"),
    household_code: z.string().regex(/^[A-Za-z0-9-]{3,40}$/, "Household code must be 3-40 letters, numbers or hyphens"),
    village: z.string().trim().min(1, "Village is required").max(100),
    created_at: z.string().optional(),
  })
  .strict();

export const syncBatchSchema = z
  .object({
    patients: z.array(z.record(z.string(), z.unknown())).max(MAX_SYNC_BATCH_RECORDS, {
      message: `A sync batch may contain at most ${MAX_SYNC_BATCH_RECORDS} patients`,
    }),
    visits: z.array(z.record(z.string(), z.unknown())).max(MAX_SYNC_BATCH_RECORDS, {
      message: `A sync batch may contain at most ${MAX_SYNC_BATCH_RECORDS} visits`,
    }),
    // Optional so older app versions (patients + visits only) keep working.
    households: z
      .array(z.record(z.string(), z.unknown()))
      .max(MAX_SYNC_BATCH_RECORDS, { message: `A sync batch may contain at most ${MAX_SYNC_BATCH_RECORDS} households` })
      .default([]),
    // Optional metadata the client may send for observability - never
    // trusted for authorization (see routes/sync.ts).
    device_id: z.string().max(200).optional(),
    batch_id: z.string().max(200).optional(),
  })
  .strict();
