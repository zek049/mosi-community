import { useEffect } from "react";

// Every screen gets its own document title - it's the first thing a screen
// reader announces after a route change, and what a browser tab/history
// entry shows. Without this every page was "Mosi — Community Health
// Information System".
export function usePageTitle(title: string) {
  useEffect(() => {
    document.title = `${title} · Mosi`;
  }, [title]);
}
