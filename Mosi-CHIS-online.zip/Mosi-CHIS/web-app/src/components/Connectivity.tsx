import { useId } from "react";
import { CloudOff, Loader2, PlugZap, ServerCrash, Wifi } from "lucide-react";
import { useNetwork } from "../contexts/NetworkContext";
import { connectivityLabel, type ConnectivityStatus } from "../services/connectivity";
import { cn } from "../lib/utils";

const STYLE: Record<ConnectivityStatus, { icon: typeof Wifi; className: string }> = {
  online: { icon: Wifi, className: "border-emerald-200 bg-emerald-50 text-emerald-800" },
  checking: { icon: Loader2, className: "border-stone-200 bg-stone-50 text-stone-700" },
  offline: { icon: CloudOff, className: "border-stone-300 bg-stone-100 text-stone-800" },
  "server-unreachable": { icon: ServerCrash, className: "border-amber-200 bg-amber-50 text-amber-900" },
  "work-offline": { icon: PlugZap, className: "border-sage-100 bg-sage-50 text-forest-900" },
};

// Small, unobtrusive connection indicator: icon + text + colour (never
// colour alone). It reflects the real state from NetworkContext.
export function ConnectivityIndicator({ className }: { className?: string }) {
  const { status } = useNetwork();
  const { icon: Icon, className: tone } = STYLE[status];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium", tone, className)}>
      <Icon className={cn("h-3.5 w-3.5", status === "checking" && "animate-spin motion-reduce:animate-none")} aria-hidden="true" />
      <span>
        <span className="sr-only">Connection: </span>
        {connectivityLabel(status)}
      </span>
    </span>
  );
}

// The deliberate "Work Offline" choice. A real switch (role="switch"): while
// on, Mosi makes no sync, refresh or health-check requests at all.
export function WorkOfflineSwitch({ showHint = false, className }: { showHint?: boolean; className?: string }) {
  const { workOffline, setWorkOffline } = useNetwork();
  const hintId = useId();
  return (
    <div className={cn("flex flex-col gap-1", className)}>
      <button
        type="button"
        role="switch"
        aria-checked={workOffline}
        aria-describedby={showHint ? hintId : undefined}
        onClick={() => setWorkOffline(!workOffline)}
        className="inline-flex min-h-11 items-center gap-2.5 rounded-lg px-1 text-sm font-medium text-stone-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-forest-700/40"
      >
        <span
          aria-hidden="true"
          className={cn(
            "relative inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition-colors",
            workOffline ? "border-forest-800 bg-forest-800" : "border-stone-300 bg-stone-200",
          )}
        >
          <span
            className={cn(
              "inline-block h-5 w-5 rounded-full bg-white shadow transition-transform motion-reduce:transition-none",
              workOffline ? "translate-x-5" : "translate-x-0.5",
            )}
          />
        </span>
        Work offline
      </button>
      {showHint && (
        <p id={hintId} className="text-xs text-stone-600">
          {workOffline
            ? "On: nothing is sent to the server. Turn off to sync."
            : "Turn on to stop all syncing, e.g. on a costly or unreliable connection."}
        </p>
      )}
    </div>
  );
}
