import type { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import * as authService from "../../services/authService";
import { homeRouteForRole } from "../../utils/roleRoutes";
import type { Role } from "../../models/chw";

type ProtectedRouteProps = {
  allowedRoles: Role[];
  children: ReactNode;
};

// Section 12: "Role-based routing must prevent a CHW from accessing
// supervisor-only screens" - and, symmetrically, a supervisor from landing
// on CHW-only screens. getSession() is a pure localStorage read (see
// authService.ts), so this guard works fully offline too.
function ProtectedRoute({ allowedRoles, children }: ProtectedRouteProps) {
  const session = authService.getSession();

  if (!session) {
    return <Navigate to="/login" replace />;
  }

  if (session.mustChangePin) {
    return <Navigate to="/change-pin" replace />;
  }

  if (!allowedRoles.includes(session.chw.role)) {
    return <Navigate to={homeRouteForRole(session.chw.role)} replace />;
  }

  return children;
}

export default ProtectedRoute;
