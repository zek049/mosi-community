import { AppError } from "./AppError";
import { isReasonableRecordTimestamp } from "./timestampGuard";

// Route-layer helper: turns an unvalidated request field into a Date, or a
// proper 400 AppError. Distinct from services/validation.ts's
// isValidDateString, which only reports problems (as strings) and is used
// by callers - like the batch sync service - that must not throw.
export function parseDate(value: unknown, field: string): Date {
  if (typeof value !== "string") {
    throw new AppError(400, `${field} is required`);
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    throw new AppError(400, `${field} is not a valid date`);
  }
  return date;
}

// Same as parseDate, plus the clock-skew bound from services/syncService.ts
// - used specifically for created_at/updated_at (the fields last-write-wins
// conflict resolution compares), never for date_of_birth or visit_date,
// which have no such bound and can legitimately be far in the past.
export function parseTimestampField(value: unknown, field: string): Date {
  const date = parseDate(value, field);
  if (!isReasonableRecordTimestamp(date)) {
    throw new AppError(400, `${field} is too far in the future or implausibly old - check this device's clock`);
  }
  return date;
}
