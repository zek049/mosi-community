import type { Request } from "express";

export type PageParams = {
  page: number;
  limit: number;
  skip: number;
  take: number;
};

export type Pagination = {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
};

const DEFAULT_LIMIT = 50;
// A hard ceiling (section 32): no caller, however it asks, can make the
// server return more than this in one response. Kept high enough that
// existing frontend calls with no `limit` at all (see cacheRefresh.ts,
// which needs "everything" for its offline-cache pull) still get a single
// page covering realistic pilot-sized data without the frontend having to
// paginate through multiple requests.
const MAX_LIMIT = 2000;

// `limit` defaults to MAX_LIMIT (not DEFAULT_LIMIT) when the caller passes
// neither `page` nor `limit` at all, so existing untouched frontend call
// sites (api.getPatients(), api.getVisits(), api.getChws() with no params)
// keep getting one page covering the whole table, exactly like before
// pagination existed - real page/limit values only kick in once a caller
// actually asks for them.
export function parsePageParams(req: Request): PageParams {
  const hasPage = req.query.page !== undefined;
  const hasLimit = req.query.limit !== undefined;

  const rawPage = Number(req.query.page);
  const page = hasPage && Number.isFinite(rawPage) && rawPage > 0 ? Math.floor(rawPage) : 1;

  const rawLimit = Number(req.query.limit);
  const defaultLimit = hasPage || hasLimit ? DEFAULT_LIMIT : MAX_LIMIT;
  const limit =
    hasLimit && Number.isFinite(rawLimit) && rawLimit > 0 ? Math.min(Math.floor(rawLimit), MAX_LIMIT) : defaultLimit;

  return { page, limit, skip: (page - 1) * limit, take: limit };
}

export function buildPagination(params: PageParams, total: number): Pagination {
  return {
    page: params.page,
    limit: params.limit,
    total,
    totalPages: Math.max(1, Math.ceil(total / params.limit)),
  };
}
