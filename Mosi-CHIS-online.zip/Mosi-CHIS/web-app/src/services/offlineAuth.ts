import Dexie, { type Table } from "dexie";
import type { StoredSession } from "../utils/session";

// ---------------------------------------------------------------------------
// Offline sign-in
//
// The server is the only authority for accounts. Offline sign-in is a LOCAL
// unlock, based on the last state the server approved on THIS device:
//
//   * A profile is created only after a successful ONLINE sign-in (so only
//     for accounts the server says are approved + active), and only for the
//     CHW role (supervisor screens need the server anyway).
//   * It stores a PBKDF2-SHA256 verifier of the PIN (random 16-byte salt,
//     600,000 iterations, Web Crypto) - never the PIN itself - in its own
//     IndexedDB database, not localStorage.
//   * Offline access lapses OFFLINE_ACCESS_DAYS after the last online
//     sign-in; the next online sign-in renews it.
//   * 5 wrong offline attempts on this device (any account) pause offline
//     sign-in for 15 minutes - the same numbers as the server's lockout.
//   * The server refusing an account (pending, rejected, deactivated)
//     deletes its profile, as does "Remove my data from this device".
//
// Limits, stated plainly: a 4-digit PIN has 10,000 values, so anyone who
// copies this verifier off the device can recover the PIN by brute force
// (PBKDF2 slows that down but can't prevent it), and a deactivation made on
// the server only reaches the device at its next online sign-in. See README.
// ---------------------------------------------------------------------------

export const OFFLINE_ACCESS_DAYS = 14;
export const MAX_OFFLINE_FAILURES = 5;
export const OFFLINE_LOCK_MINUTES = 15;
const PBKDF2_ITERATIONS = 600_000;
const DAY_MS = 24 * 60 * 60 * 1000;

export type OfflineProfile = {
  chw_id: string; // upper-cased key
  chw: StoredSession["chw"];
  salt: string; // base64
  verifier: string; // base64 PBKDF2 output
  iterations: number;
  verified_online_at: string; // ISO - last successful ONLINE sign-in
};

type Meta = { key: string; failures: number; locked_until: number | null };

class OfflineAuthDatabase extends Dexie {
  profiles!: Table<OfflineProfile, string>;
  meta!: Table<Meta, string>;
  constructor() {
    super("mosi-offline-auth");
    this.version(1).stores({ profiles: "chw_id", meta: "key" });
  }
}

const authDb = new OfflineAuthDatabase();
const LOCK_KEY = "device-lock";

const toB64 = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes));
const fromB64 = (text: string) => Uint8Array.from(atob(text), (c) => c.charCodeAt(0));
const normalise = (chwId: string) => chwId.trim().toUpperCase();

async function derive(pin: string, salt: Uint8Array, iterations: number): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(pin), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: salt as BufferSource, iterations }, key, 256);
  return new Uint8Array(bits);
}

function constantTimeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

/** Called after a successful ONLINE sign-in. Supervisors are never cached. */
export async function rememberForOffline(chw: StoredSession["chw"], pin: string, iterations = PBKDF2_ITERATIONS): Promise<void> {
  if (chw.role !== "CHW") {
    await forgetOfflineProfile(chw.chw_id);
    return;
  }
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const verifier = await derive(pin, salt, iterations);
  await authDb.profiles.put({
    chw_id: normalise(chw.chw_id),
    chw,
    salt: toB64(salt),
    verifier: toB64(verifier),
    iterations,
    verified_online_at: new Date().toISOString(),
  });
}

export async function forgetOfflineProfile(chwId: string): Promise<void> {
  await authDb.profiles.delete(normalise(chwId));
}

/** Whether ANY account can sign in offline on this device (drives the Sign in page hint). */
export async function hasAnyOfflineProfile(): Promise<boolean> {
  return (await authDb.profiles.count()) > 0;
}

export type OfflineSignInResult =
  | { ok: true; chw: StoredSession["chw"] }
  | { ok: false; reason: "not-set-up" } // no account has signed in online on this device
  | { ok: false; reason: "invalid" } // wrong PIN OR unknown ID - deliberately the same
  | { ok: false; reason: "locked"; minutes: number }
  | { ok: false; reason: "expired" }; // correct PIN, but offline access has lapsed

export async function offlineSignIn(chwId: string, pin: string, now = Date.now()): Promise<OfflineSignInResult> {
  if (!(await hasAnyOfflineProfile())) return { ok: false, reason: "not-set-up" };

  const lock = (await authDb.meta.get(LOCK_KEY)) ?? { key: LOCK_KEY, failures: 0, locked_until: null };
  if (lock.locked_until && lock.locked_until > now) {
    return { ok: false, reason: "locked", minutes: Math.ceil((lock.locked_until - now) / 60000) };
  }

  const profile = await authDb.profiles.get(normalise(chwId));
  // Unknown IDs still pay the full derivation cost, so timing doesn't reveal
  // which accounts are set up on this device.
  const salt = profile ? fromB64(profile.salt) : crypto.getRandomValues(new Uint8Array(16));
  const candidate = await derive(pin, salt, profile?.iterations ?? PBKDF2_ITERATIONS);
  const matches = profile ? constantTimeEqual(candidate, fromB64(profile.verifier)) : false;

  if (!matches) {
    const failures = lock.failures + 1;
    const locking = failures >= MAX_OFFLINE_FAILURES;
    await authDb.meta.put({ key: LOCK_KEY, failures: locking ? 0 : failures, locked_until: locking ? now + OFFLINE_LOCK_MINUTES * 60000 : null });
    return locking ? { ok: false, reason: "locked", minutes: OFFLINE_LOCK_MINUTES } : { ok: false, reason: "invalid" };
  }

  await authDb.meta.put({ key: LOCK_KEY, failures: 0, locked_until: null });
  if (now - Date.parse(profile!.verified_online_at) > OFFLINE_ACCESS_DAYS * DAY_MS) return { ok: false, reason: "expired" };
  return { ok: true, chw: profile!.chw };
}
