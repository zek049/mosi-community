import { beforeEach, describe, expect, it, vi } from "vitest";
import bcrypt from "bcryptjs";

// Runs before any import below is evaluated (vitest hoists vi.hoisted/vi.mock
// calls above imports) - app.ts's assertRequiredEnv() needs this to already
// be set the moment the module loads, and "../db" is mocked out below so the
// real .env-loading path in db.ts never runs for these tests.
vi.hoisted(() => {
  process.env.JWT_SECRET = "test-secret-for-integration-tests";
});

const mocks = vi.hoisted(() => ({
  chwFindUnique: vi.fn(),
  chwUpdate: vi.fn(),
  chwCount: vi.fn(),
  chwCreate: vi.fn(),
  chwFindMany: vi.fn(),
  accountRequestFindFirst: vi.fn(),
  patientFindUnique: vi.fn(),
  patientCount: vi.fn(),
  patientFindMany: vi.fn(),
  patientGroupBy: vi.fn(),
  patientUpdate: vi.fn(),
  patientCreate: vi.fn(),
  visitCount: vi.fn(),
  visitFindMany: vi.fn(),
  visitCreate: vi.fn(),
  visitFindUnique: vi.fn(),
  clinicFindMany: vi.fn(),
  clinicFindUnique: vi.fn(),
  syncConflictCount: vi.fn(),
  syncConflictCreate: vi.fn(),
  syncLogCreate: vi.fn(),
  syncLogGroupBy: vi.fn(),
  auditLogCreate: vi.fn(),
  queryRaw: vi.fn(),
  transaction: vi.fn(),
}));

vi.mock("../db", () => ({
  prisma: {
    chw: { findUnique: mocks.chwFindUnique, update: mocks.chwUpdate, count: mocks.chwCount, create: mocks.chwCreate, findMany: mocks.chwFindMany },
    patient: {
      findUnique: mocks.patientFindUnique,
      count: mocks.patientCount,
      findMany: mocks.patientFindMany,
      groupBy: mocks.patientGroupBy,
      update: mocks.patientUpdate,
      create: mocks.patientCreate,
    },
    visit: {
      count: mocks.visitCount,
      findMany: mocks.visitFindMany,
      create: mocks.visitCreate,
      findUnique: mocks.visitFindUnique,
    },
    clinic: { findMany: mocks.clinicFindMany, findUnique: mocks.clinicFindUnique },
    accountRequest: { findFirst: mocks.accountRequestFindFirst },
    syncConflict: { count: mocks.syncConflictCount, create: mocks.syncConflictCreate },
    syncLog: { create: mocks.syncLogCreate, groupBy: mocks.syncLogGroupBy },
    auditLog: { create: mocks.auditLogCreate },
    $queryRaw: mocks.queryRaw,
    $transaction: mocks.transaction,
  },
}));

import request from "supertest";
import app from "../app";
import { signSessionToken } from "../middleware/auth";

const CLINIC_A = "clinic-a-id";
const CLINIC_B = "clinic-b-id";

function activeChw(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    chw_id: "CHW001",
    role: "CHW",
    status: "active",
    locked_until: null,
    clinic_id: CLINIC_A,
    failed_login_count: 0,
    full_name: "Test CHW",
    clinic: "Clinic A",
    ...overrides,
  };
}

beforeEach(() => {
  vi.clearAllMocks();
  mocks.auditLogCreate.mockResolvedValue({});
  mocks.accountRequestFindFirst.mockResolvedValue(null); // no pending account requests
  mocks.syncLogCreate.mockResolvedValue({});
  // $transaction as used here is always called with an array of prisma
  // promises (prisma.$transaction([...])) - resolving each mocked call and
  // returning the array is a faithful enough stand-in for these tests.
  mocks.transaction.mockImplementation(async (ops: unknown[]) => Promise.all(ops));
});

describe("authentication", () => {
  it("rejects a protected route with no token", async () => {
    const res = await request(app).get("/api/patients");
    expect(res.status).toBe(401);
  });

  it("rejects a garbage bearer token", async () => {
    const res = await request(app).get("/api/patients").set("Authorization", "Bearer not-a-real-token");
    expect(res.status).toBe(401);
  });

  it("authenticates via the httpOnly session cookie, not just the Authorization header", async () => {
    mocks.chwFindUnique.mockResolvedValue(activeChw());
    mocks.patientFindMany.mockResolvedValue([]);
    mocks.patientCount.mockResolvedValue(0);
    const token = signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Test CHW" });
    const res = await request(app).get("/api/patients").set("Cookie", [`mosi_session=${token}`]);
    expect(res.status).toBe(200);
  });

  it("logout clears the session cookie", async () => {
    const res = await request(app).post("/api/auth/logout");
    expect(res.status).toBe(200);
    expect(String(res.headers["set-cookie"])).toContain("mosi_session=;");
  });

  it("rejects a token signed with the wrong issuer/audience", async () => {
    const jwt = await import("jsonwebtoken");
    const badToken = jwt.default.sign({ chwId: "CHW001", role: "CHW", fullName: "Test" }, "test-secret-for-integration-tests", {
      subject: "CHW001",
      issuer: "someone-else",
      audience: "mosi-app",
    });
    const res = await request(app).get("/api/patients").set("Authorization", `Bearer ${badToken}`);
    expect(res.status).toBe(401);
  });

  it("rejects an expired token", async () => {
    const jwt = await import("jsonwebtoken");
    const expiredToken = jwt.default.sign({ chwId: "CHW001", role: "CHW", fullName: "Test" }, "test-secret-for-integration-tests", {
      subject: "CHW001",
      issuer: "mosi-api",
      audience: "mosi-app",
      expiresIn: -1,
    });
    const res = await request(app).get("/api/patients").set("Authorization", `Bearer ${expiredToken}`);
    expect(res.status).toBe(401);
  });

  it("rejects a token with no subject claim", async () => {
    const jwt = await import("jsonwebtoken");
    const noSubjectToken = jwt.default.sign({ chwId: "CHW001", role: "CHW", fullName: "Test" }, "test-secret-for-integration-tests", {
      issuer: "mosi-api",
      audience: "mosi-app",
    });
    const res = await request(app).get("/api/patients").set("Authorization", `Bearer ${noSubjectToken}`);
    expect(res.status).toBe(401);
  });

  it("denies access immediately once the account is revoked, even with a still-valid token", async () => {
    mocks.chwFindUnique.mockResolvedValue(activeChw({ status: "revoked" }));
    const token = signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Test CHW" });
    const res = await request(app).get("/api/patients").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(403);
  });

  it("denies access while the account is locked", async () => {
    mocks.chwFindUnique.mockResolvedValue(activeChw({ locked_until: new Date(Date.now() + 60_000) }));
    const token = signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Test CHW" });
    const res = await request(app).get("/api/patients").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(403);
  });
});

describe("role-based authorization", () => {
  it("rejects a CHW-role token on the supervisor-only dashboard route", async () => {
    mocks.chwFindUnique.mockResolvedValue(activeChw());
    const token = signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Test CHW" });
    const res = await request(app).get("/api/dashboard/stats").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(403);
  });

  it("allows a SUPERVISOR-role token on the dashboard route", async () => {
    mocks.chwFindUnique.mockResolvedValue(activeChw({ chw_id: "SUP001", role: "SUPERVISOR" }));
    mocks.chwCount.mockResolvedValue(2);
    mocks.patientCount.mockResolvedValue(0);
    mocks.visitCount.mockResolvedValue(0);
    mocks.visitFindMany.mockResolvedValue([]);
    mocks.syncConflictCount.mockResolvedValue(0);
    mocks.patientGroupBy.mockResolvedValue([]);
    mocks.clinicFindMany.mockResolvedValue([]);
    mocks.syncLogGroupBy.mockResolvedValue([]);
    mocks.queryRaw.mockResolvedValue([]); // clinic-scoped conflict/sync-log lookups

    const token = signSessionToken({ chwId: "SUP001", role: "SUPERVISOR", fullName: "Test Supervisor" });
    const res = await request(app).get("/api/dashboard/stats").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
  });

  it("rejects a CHW-role token creating a new CHW account", async () => {
    mocks.chwFindUnique.mockResolvedValue(activeChw());
    const token = signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Test CHW" });
    const res = await request(app)
      .post("/api/chws")
      .set("Authorization", `Bearer ${token}`)
      .send({ chw_id: "CHW999", full_name: "New CHW", clinic_id: CLINIC_A, pin: "1111" });
    expect(res.status).toBe(403);
  });
});

describe("clinic-scoped patient authorization", () => {
  it("denies a CHW reading a patient that belongs to a different clinic", async () => {
    mocks.chwFindUnique.mockResolvedValue(activeChw({ clinic_id: CLINIC_A }));
    mocks.patientFindUnique.mockResolvedValue({
      id: "patient-1",
      clinic_id: CLINIC_B,
      deleted_at: null,
      visits: [],
    });

    const token = signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Test CHW" });
    const res = await request(app).get("/api/patients/patient-1").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(403);
  });

  it("allows a CHW reading a patient in their own clinic", async () => {
    mocks.chwFindUnique.mockResolvedValue(activeChw({ clinic_id: CLINIC_A }));
    mocks.patientFindUnique.mockResolvedValue({
      id: "patient-1",
      clinic_id: CLINIC_A,
      deleted_at: null,
      visits: [],
    });

    const token = signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Test CHW" });
    const res = await request(app).get("/api/patients/patient-1").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(200);
  });

  it("a 404 for an archived patient looks the same as a genuinely missing one", async () => {
    mocks.chwFindUnique.mockResolvedValue(activeChw({ clinic_id: CLINIC_A }));
    mocks.patientFindUnique.mockResolvedValue({
      id: "patient-1",
      clinic_id: CLINIC_A,
      deleted_at: new Date(),
      visits: [],
    });

    const token = signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Test CHW" });
    const res = await request(app).get("/api/patients/patient-1").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(404);
  });
});

describe("visit chw_id spoofing prevention", () => {
  it("a CHW cannot record a visit as a different CHW", async () => {
    mocks.chwFindUnique.mockResolvedValue(activeChw({ chw_id: "CHW001", clinic_id: CLINIC_A }));
    mocks.patientFindUnique.mockResolvedValue({ id: "patient-1", clinic_id: CLINIC_A, deleted_at: null });
    mocks.visitCreate.mockResolvedValue({ id: "visit-1", chw_id: "CHW001", clinic_id: CLINIC_A });

    const token = signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Test CHW" });
    const res = await request(app)
      .post("/api/visits")
      .set("Authorization", `Bearer ${token}`)
      .send({
        id: "visit-1",
        patient_id: "patient-1",
        chw_id: "SOMEONE_ELSE",
        visit_date: new Date().toISOString(),
        visit_type: "Health Education",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });

    expect(res.status).toBe(201);
    // The route overrides chw_id server-side before create() is ever
    // called - this asserts the actual write used the authenticated
    // actor's id, not the spoofed one from the request body.
    expect(mocks.visitCreate).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ chw_id: "CHW001" }) }),
    );
  });
});

describe("health check", () => {
  it("reports the database as connected when it responds", async () => {
    mocks.queryRaw.mockResolvedValueOnce([{ "?column?": 1 }]);
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ success: true, database: "connected" });
  });

  it("returns 503 when the database is unreachable", async () => {
    mocks.queryRaw.mockRejectedValueOnce(new Error("connection refused"));
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(503);
    expect(res.body).toMatchObject({ success: false, database: "disconnected" });
  });

  it("reports liveness without touching the database", async () => {
    const res = await request(app).get("/api/health/live");
    expect(res.status).toBe(200);
    expect(mocks.queryRaw).not.toHaveBeenCalled();
  });
});

describe("login", () => {
  it("returns the same generic message for a nonexistent CHW ID", async () => {
    mocks.chwFindUnique.mockResolvedValue(null);
    const res = await request(app).post("/api/auth/login").send({ chw_id: "GHOST001", pin: "1234" });
    expect(res.status).toBe(401);
    expect(res.body.message).toBe("Invalid CHW ID or PIN");
  });

  it("a wrong PIN on a revoked account gets the same generic 401 (status never leaks)", async () => {
    const pinHash = await bcrypt.hash("1234", 10);
    mocks.chwFindUnique.mockResolvedValue(activeChw({ status: "revoked", pin_hash: pinHash }));
    const res = await request(app).post("/api/auth/login").send({ chw_id: "CHW001", pin: "0000" });
    expect(res.status).toBe(401);
    expect(res.body.message).toBe("Invalid CHW ID or PIN");
    expect(res.body.code).toBeUndefined();
  });

  it("a revoked CHW can't sign in even with the correct PIN: 'This account has been deactivated', no session", async () => {
    const pinHash = await bcrypt.hash("1234", 10);
    mocks.chwFindUnique.mockResolvedValue(activeChw({ status: "revoked", pin_hash: pinHash }));
    const res = await request(app).post("/api/auth/login").send({ chw_id: "CHW001", pin: "1234" });
    expect(res.status).toBe(403);
    expect(res.body.code).toBe("ACCOUNT_REVOKED");
    expect(res.body.message).toBe("This account has been deactivated");
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("locks the account after 5 failed PIN attempts", async () => {
    const pinHash = await bcrypt.hash("1234", 10);
    mocks.chwFindUnique.mockResolvedValue(activeChw({ pin_hash: pinHash, failed_login_count: 4 }));
    mocks.chwUpdate.mockResolvedValue({});

    const res = await request(app).post("/api/auth/login").send({ chw_id: "CHW001", pin: "0000" });
    expect(res.status).toBe(401);
    expect(mocks.chwUpdate).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ locked_until: expect.any(Date) }) }),
    );
  });

  it("logs in successfully with the correct PIN and resets lockout counters", async () => {
    const pinHash = await bcrypt.hash("1234", 10);
    mocks.chwFindUnique.mockResolvedValue(activeChw({ pin_hash: pinHash }));
    mocks.chwUpdate.mockResolvedValue({});

    const res = await request(app).post("/api/auth/login").send({ chw_id: "CHW001", pin: "1234" });
    expect(res.status).toBe(200);
    // The token is never in the response body (see routes/auth.ts) - only
    // in an httpOnly Set-Cookie header, which JS (including this response
    // body assertion) can't read the contents of, only confirm is present.
    expect(res.body.data.token).toBeUndefined();
    const setCookie = String(res.headers["set-cookie"]);
    expect(setCookie).toContain("mosi_session=");
    expect(setCookie).toContain("HttpOnly");
    expect(mocks.chwUpdate).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ failed_login_count: 0, locked_until: null }) }),
    );
  });
});

describe("login rate limiting", () => {
  it("returns 429 after too many failed attempts for the same CHW ID", async () => {
    mocks.chwFindUnique.mockResolvedValue(null);

    for (let attempt = 0; attempt < 10; attempt++) {
      const res = await request(app).post("/api/auth/login").send({ chw_id: "RATE-LIMIT-TEST", pin: "0000" });
      expect(res.status).toBe(401);
    }

    const blocked = await request(app).post("/api/auth/login").send({ chw_id: "RATE-LIMIT-TEST", pin: "0000" });
    expect(blocked.status).toBe(429);
  });

  it("never throttles correct-PIN sign-ins, however many", async () => {
    const pinHash = await bcrypt.hash("1234", 10);
    mocks.chwFindUnique.mockResolvedValue(activeChw({ chw_id: "RATE-OK-TEST", pin_hash: pinHash }));
    mocks.chwUpdate.mockResolvedValue({});

    for (let attempt = 0; attempt < 12; attempt++) {
      const res = await request(app).post("/api/auth/login").send({ chw_id: "RATE-OK-TEST", pin: "1234" });
      expect(res.status).toBe(200);
    }
  });
});

describe("supervisor PIN reset (PATCH /api/chws/:chwId)", () => {
  // authenticate() looks up the signed-in actor, then the route looks up the
  // target account - both through chw.findUnique, told apart by chw_id.
  function accounts(actor: Record<string, unknown>, target: Record<string, unknown> | null) {
    mocks.chwFindUnique.mockImplementation(async ({ where }: { where: { chw_id: string } }) =>
      where.chw_id === actor.chw_id ? actor : target && where.chw_id === target.chw_id ? target : null,
    );
  }
  const supervisor = activeChw({ chw_id: "SUP001", role: "SUPERVISOR" });
  const target = activeChw({ chw_id: "CHW002", failed_login_count: 5, locked_until: new Date(Date.now() + 60_000) });
  const supToken = () => signSessionToken({ chwId: "SUP001", role: "SUPERVISOR", fullName: "Test Supervisor" });

  it("refuses a CHW-role user, and never touches the account", async () => {
    accounts(activeChw(), target);
    const token = signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Test CHW" });
    const res = await request(app).patch("/api/chws/CHW002").set("Authorization", `Bearer ${token}`).send({ pin: "4321" });
    expect(res.status).toBe(403);
    expect(mocks.chwUpdate).not.toHaveBeenCalled();
  });

  it("lets a supervisor reset it: stores only a bcrypt hash, clears lockout, never returns or audits the PIN", async () => {
    accounts(supervisor, target);
    mocks.chwUpdate.mockResolvedValue({ chw_id: "CHW002", full_name: "Test CHW", role: "CHW", status: "active" });
    const res = await request(app).patch("/api/chws/CHW002").set("Authorization", `Bearer ${supToken()}`).send({ pin: "4321" });

    expect(res.status).toBe(200);
    const data = mocks.chwUpdate.mock.calls[0][0].data;
    expect(data.pin_hash).not.toBe("4321");
    expect(await bcrypt.compare("4321", data.pin_hash)).toBe(true);
    expect(data.failed_login_count).toBe(0);
    expect(data.locked_until).toBeNull();
    expect(mocks.chwUpdate.mock.calls[0][0].select.pin_hash).toBeUndefined();
    expect(JSON.stringify(res.body)).not.toContain("4321");
    expect(JSON.stringify(res.body)).not.toContain("pin_hash");

    const audit = JSON.stringify(mocks.auditLogCreate.mock.calls);
    expect(audit).toContain('"pin_reset":true');
    expect(audit).not.toContain("4321");
    expect(audit).not.toContain(data.pin_hash);
  });

  it("rejects a PIN that isn't exactly 4 digits", async () => {
    accounts(supervisor, target);
    for (const pin of ["123", "12345", "12a4"]) {
      const res = await request(app).patch("/api/chws/CHW002").set("Authorization", `Bearer ${supToken()}`).send({ pin });
      expect(res.status).toBe(400);
    }
    expect(mocks.chwUpdate).not.toHaveBeenCalled();
  });

  it("returns 404 for an account that doesn't exist", async () => {
    accounts(supervisor, null);
    const res = await request(app).patch("/api/chws/GHOST01").set("Authorization", `Bearer ${supToken()}`).send({ pin: "4321" });
    expect(res.status).toBe(404);
    expect(mocks.chwUpdate).not.toHaveBeenCalled();
  });
});

describe("CORS", () => {
  it("lets the web app read Retry-After, so it can back off after a 429", async () => {
    const res = await request(app).get("/api/health/live").set("Origin", "http://localhost:5173");
    expect(res.headers["access-control-expose-headers"]).toContain("Retry-After");
  });
});
