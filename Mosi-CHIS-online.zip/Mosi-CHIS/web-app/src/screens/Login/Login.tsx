import { useEffect, useState, type FormEvent } from "react";
import { InstallHint } from "../../components/InstallHint";
import { Link, useNavigate } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { User, Lock, Eye, EyeOff, Heart } from "lucide-react";
import * as authService from "../../services/authService";
import { ApiError, NetworkError } from "../../services/api";
import { useNetwork } from "../../contexts/NetworkContext";
import { usePageTitle } from "../../hooks/usePageTitle";
import { ConnectivityIndicator, WorkOfflineSwitch } from "../../components/Connectivity";
import { isValidPin } from "../../utils/validators";
import { homeRouteForRole } from "../../utils/roleRoutes";
import { Button } from "../../components/ui/Button";
import { TextField } from "../../components/ui/TextField";
import { Card } from "../../components/ui/Card";
import { Logo } from "../../components/Logo";

// Synthetic demo accounts from backend/prisma/seed.ts (DEMO ONLY). Listed
// on screen only in development or when a build explicitly opts in with
// VITE_SHOW_DEMO_ACCOUNTS=true (the demo Docker stack does) - a pilot build
// never advertises these credentials.
const SHOW_DEMO_ACCOUNTS = import.meta.env.DEV || import.meta.env.VITE_SHOW_DEMO_ACCOUNTS === "true";

const DEMO_ACCOUNTS = [
  { chwId: "CHW001", name: "Jane Moyo", clinic: "Mbare Clinic" },
  { chwId: "CHW002", name: "John Ncube", clinic: "Hatcliffe Clinic" },
  { chwId: "SUP001", name: "Grace Chikwanha", clinic: "Supervisor" },
];

function Login() {
  usePageTitle("Sign in");
  const navigate = useNavigate();
  const { isOnline, status: connectivity, recheck } = useNetwork();
  // Shown once, right after signing out (set by authService.signOut).
  const [signedOut] = useState(authService.readSignOutNotice);
  useEffect(() => authService.dismissSignOutNotice(), []);

  const [chwId, setChwId] = useState("");
  const [pin, setPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<{ chwId?: string; pin?: string }>({});

  // Already logged in (e.g. reopening the app) - skip straight to the
  // right home screen instead of asking for credentials again.
  useEffect(() => {
    const session = authService.getSession();
    if (session) {
      navigate(authService.entryRoute(session), { replace: true });
    }
  }, [navigate]);

  const loginMutation = useMutation({
    mutationFn: () => authService.login(chwId.trim(), pin),
    onSuccess: (chw) => {
      const session = authService.getSession();
      navigate(session ? authService.entryRoute(session) : homeRouteForRole(chw.role), { replace: true });
    },
  });

  const formError = !loginMutation.isError
    ? null
    : loginMutation.error instanceof NetworkError
      ? "Couldn't reach the Mosi server. Signing in needs a connection - try again when you're online."
      : loginMutation.error instanceof ApiError && loginMutation.error.status < 500
        ? loginMutation.error.message
        : "Something went wrong on the server. Please try again in a moment.";

  function handleSubmit(event: FormEvent) {
    event.preventDefault();

    const errors: { chwId?: string; pin?: string } = {};
    if (!chwId.trim()) errors.chwId = "Enter your CHW ID, for example CHW001.";
    if (!isValidPin(pin)) errors.pin = "Enter your 4-digit PIN.";
    setFieldErrors(errors);
    if (Object.keys(errors).length > 0) return;

    loginMutation.mutate();
  }

  return (
    <div className="min-h-screen bg-cream flex flex-col">
      <header className="px-6 py-5">
        <Link to="/" aria-label="Mosi home">
          <Logo size="sm" />
        </Link>
      </header>

      <main className="flex-1 flex items-center justify-center px-6 pb-16">
        <div className="w-full max-w-sm space-y-6">
          <Card className="p-8 space-y-6 shadow-sm">
            <div className="text-center">
              <div className="flex justify-center">
                <Logo tagline size="md" />
              </div>
              <h1 className="mt-6 text-xl font-semibold text-stone-900">Sign in</h1>
              <p className="mt-1 text-sm text-stone-600">Community health system</p>
              <div className="mt-3 flex justify-center">
                <ConnectivityIndicator />
              </div>
            </div>

            {signedOut && (
              <p role="status" className="rounded-lg border border-sage-100 bg-sage-50 px-3 py-2 text-sm text-forest-900">
                {signedOut.keptUnsynced > 0
                  ? `You've signed out. ${signedOut.keptUnsynced} unsynced ${signedOut.keptUnsynced === 1 ? "change is" : "changes are"} kept on this device for your next sign-in; everything else you had here was removed.`
                  : "You've signed out. Your records were removed from this device - they're safe on the server."}
              </p>
            )}

            <form onSubmit={handleSubmit} noValidate className="space-y-4">
              <TextField
                label="CHW ID"
                name="chwId"
                icon={User}
                autoComplete="username"
                placeholder="e.g. CHW001"
                value={chwId}
                onChange={(e) => setChwId(e.target.value)}
                error={fieldErrors.chwId}
                autoFocus
              />
              <TextField
                label="PIN"
                name="pin"
                icon={Lock}
                type={showPin ? "text" : "password"}
                inputMode="numeric"
                autoComplete="current-password"
                placeholder="Enter 4-digit PIN"
                maxLength={4}
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 4))}
                error={fieldErrors.pin}
                endAdornment={
                  <button
                    type="button"
                    onClick={() => setShowPin((v) => !v)}
                    className="-mr-2 flex h-10 w-10 items-center justify-center rounded-md text-stone-500 hover:text-stone-700"
                    aria-label={showPin ? "Hide PIN" : "Show PIN"}
                    aria-pressed={showPin}
                  >
                    {showPin ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
                  </button>
                }
              />

              {formError && (
                <p role="alert" className="text-sm text-red-800 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                  {formError}
                </p>
              )}

              {!isOnline && connectivity === "checking" && (
                <p className="text-sm text-stone-600">Checking the connection to the Mosi server…</p>
              )}
              {!isOnline && connectivity !== "checking" && (
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2">
                  <p className="text-sm text-amber-900">
                    {connectivity === "work-offline"
                      ? "Work Offline is on. Signing in needs the Mosi server - turn Work Offline off to sign in."
                      : connectivity === "server-unreachable"
                        ? "Your device is online, but the Mosi server isn't answering. Try again in a moment."
                        : "You're offline. Signing in needs a connection to the Mosi server. Once you're signed in, you can keep working without one."}
                  </p>
                  {connectivity === "server-unreachable" && (
                    <Button type="button" variant="secondary" onClick={() => void recheck()}>
                      Check again
                    </Button>
                  )}
                </div>
              )}

              <Button type="submit" size="lg" className="w-full" disabled={loginMutation.isPending || !isOnline}>
                {loginMutation.isPending ? "Signing in…" : "Sign in"}
              </Button>

              <p className="text-center text-sm text-stone-600">
                <Link to="/forgot-pin" className="font-medium text-forest-800 underline underline-offset-2">
                  Forgot PIN?
                </Link>
              </p>
              <p className="text-center text-sm text-stone-600">
                New to Mosi?{" "}
                <Link to="/request-account" className="font-medium text-forest-800 underline underline-offset-2">
                  Request an account
                </Link>
              </p>
            </form>

            <div className="border-t border-stone-100 pt-4">
              <WorkOfflineSwitch showHint />
            </div>

            <InstallHint />
          </Card>

          {SHOW_DEMO_ACCOUNTS && (
          <Card className="bg-white/60 p-5">
            <h2 className="text-xs font-medium text-stone-600 uppercase tracking-wide">Demo accounts</h2>
            <ul className="mt-2 space-y-1.5 text-sm text-stone-700">
              {DEMO_ACCOUNTS.map((account) => (
                <li key={account.chwId} className="flex items-center justify-between gap-3">
                  <span>
                    <span className="font-medium">{account.chwId}</span> - {account.name} ({account.clinic})
                  </span>
                  <span className="text-stone-600 text-xs shrink-0">PIN 1234</span>
                </li>
              ))}
            </ul>
          </Card>
          )}

          <p className="flex items-center justify-center gap-1.5 text-xs text-stone-500">
            <Heart className="h-3.5 w-3.5 text-forest-700" aria-hidden="true" fill="currentColor" />
            Supporting healthier communities across Zimbabwe
          </p>
          <p className="text-xs text-stone-500 text-center">
            Synthetic demonstration data - not real patient records.
          </p>
        </div>
      </main>
    </div>
  );
}

export default Login;
