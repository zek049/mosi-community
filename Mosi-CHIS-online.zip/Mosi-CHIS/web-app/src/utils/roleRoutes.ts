import { isSupervisorRole, type Role } from "../models/chw";

// Shared by Login (post-login redirect) and ProtectedRoute (wrong-role
// redirect), so the two can never disagree about where a role's home is.
export function homeRouteForRole(role: Role): string {
  return isSupervisorRole(role) ? "/supervisor" : "/chw";
}
