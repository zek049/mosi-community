import type { Chw } from "../models/chw";

// Dependency-free storage primitive, deliberately separate from
// services/authService.ts and services/api.ts. Holds no secret material:
// the session token itself lives only in an httpOnly cookie the server sets
// at login (see backend/src/routes/auth.ts) and JavaScript never has access
// to it at all - this is purely a non-sensitive cache of who's logged in,
// so the UI can render the right shell/screen offline without needing to
// read a cookie it couldn't read anyway.
const STORAGE_KEY = "mosi.session";

export type StoredSession = {
  chw: Pick<Chw, "chw_id" | "full_name" | "clinic" | "role">;
  /**
   * "online": signed in against the server (a server session cookie exists).
   * "offline": unlocked on this device only (see services/offlineAuth.ts) -
   * nothing talks to the server until an online sign-in inside the app.
   * Missing (sessions saved by older builds) means "online".
   */
  mode?: "online" | "offline";
  /**
   * A supervisor set this account a temporary PIN: the app shows only the
   * "Choose a new PIN" screen until it's changed (the server refuses every
   * other request meanwhile).
   */
  mustChangePin?: boolean;
};

export function getStoredSession(): StoredSession | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as StoredSession;
  } catch {
    return null;
  }
}

export function setStoredSession(session: StoredSession): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  } catch {
    // Storage unavailable (e.g. a private-browsing edge case) - the app
    // still works for this tab, it just won't stay logged in on reload.
  }
}

export function clearStoredSession(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Nothing to do if storage is unavailable.
  }
}
