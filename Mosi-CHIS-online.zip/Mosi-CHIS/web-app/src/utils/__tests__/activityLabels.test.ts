import { describe, expect, it } from "vitest";
import { ACTION_GROUPS, ACTION_LABELS, activityDetail, activityTarget, actionLabel, type ActivityEntry } from "../activityLabels";

// Every audit action the backend can write (backend/src/utils/audit.ts AuditAction).
const BACKEND_ACTIONS = [
  "LOGIN_SUCCESS", "LOGIN_FAILURE", "ACCOUNT_LOCKED", "PATIENT_CREATED", "PATIENT_UPDATED", "PATIENT_ARCHIVED",
  "VISIT_CREATED", "VISIT_UPDATED", "VISIT_ARCHIVED", "SYNC_STARTED", "SYNC_COMPLETED", "SYNC_CONFLICT",
  "CONFLICT_RESOLVED", "CHW_CREATED", "CHW_UPDATED", "CHW_DEACTIVATED", "CLINIC_CREATED", "ACCOUNT_REQUESTED",
  "ACCOUNT_APPROVED", "ACCOUNT_REJECTED", "CHW_REVOKED", "CHW_REACTIVATED", "CHW_DELETED", "PIN_RESET_REQUESTED",
  "PIN_RESET_COMPLETED", "PIN_CHANGED", "RECORD_CONFIRMED", "RECORD_FLAGGED",
];

const entry = (action: string, metadata: Record<string, unknown> = {}, extra: Partial<ActivityEntry> = {}): ActivityEntry => ({
  action,
  actor_id: "SUP002",
  resource_type: "patient",
  resource_id: "0b8f3c2e-1111-4222-8333-444455556666",
  metadata,
  ...extra,
});

describe("activity labels", () => {
  it("every backend action has plain words, and every one can be filtered by a group", () => {
    for (const a of BACKEND_ACTIONS) expect(ACTION_LABELS[a], a).toBeTruthy();
    const grouped = ACTION_GROUPS.flatMap((g) => g.actions);
    for (const a of BACKEND_ACTIONS) expect(grouped, a).toContain(a);
  });

  it("an unknown action still reads as words, not a code", () => {
    expect(actionLabel("SOMETHING_NEW")).toBe("Something new");
  });

  it.each([
    [entry("LOGIN_FAILURE", { reason: "bad_pin", failedCount: 2 }), "Reason: wrong PIN"],
    [entry("RECORD_FLAGGED", { reason: "Weight looks wrong", clinic_id: "x", from: "awaiting_review" }), "Reason: Weight looks wrong"],
    [entry("RECORD_CONFIRMED", { from: "flagged" }), "Was flagged before"],
    [entry("CONFLICT_RESOLVED", { resolution: "APPLY_INCOMING", conflict_id: 4 }), "Kept the device's version"],
    [entry("SYNC_STARTED", { patients: 1, visits: 3, households: 0 }), "Sent 1 patient, 3 visits"],
    [entry("SYNC_COMPLETED", { synced: 4, conflicts: 1, failed: 0 }), "4 accepted, 1 conflict"],
    [entry("CHW_UPDATED", { changed: ["full_name", "clinic_id"], pin_reset: true }), "Set a temporary PIN; changed name, clinic"],
    [entry("CHW_UPDATED", { role: { from: "SUPERVISOR", to: "ADMIN" } }), "Role changed"],
    [entry("PIN_CHANGED", { was_temporary: true }), "Replaced a temporary PIN"],
    [entry("PATIENT_CREATED", { via: "sync" }), "Sent from a device"],
  ])("detail: %j", (e, text) => {
    expect(activityDetail(e)).toBe(text);
  });

  it("details never show raw JSON or internal ids", () => {
    for (const a of BACKEND_ACTIONS) {
      const d = activityDetail(entry(a, { clinic_id: "cmueempnf0000mo32dn6dx4j3", conflict_id: 9, nested: { secret: "x" }, batch_id: "b-1" }));
      if (d) {
        expect(d, a).not.toMatch(/[{}]|cmueempnf|secret|batch/);
      }
    }
  });

  it("targets: readable ids where known, a short form of long record ids otherwise", () => {
    expect(activityTarget(entry("PATIENT_CREATED", { patient_id: "MBR-0012" }))).toBe("patient MBR-0012");
    expect(activityTarget(entry("RECORD_CONFIRMED"))).toBe("patient 0b8f3c2e");
    expect(activityTarget(entry("CHW_REVOKED", {}, { resource_type: "chw", resource_id: "CHW002" }))).toBe("account CHW002");
    expect(activityTarget(entry("SYNC_STARTED", {}, { resource_type: null, resource_id: null }))).toBeNull();
  });
});
