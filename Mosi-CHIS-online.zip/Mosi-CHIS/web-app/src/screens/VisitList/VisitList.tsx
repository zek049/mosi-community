import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { Download, Plus, Stethoscope, X } from "lucide-react";
import { db } from "../../db/indexedDb";
import * as authService from "../../services/authService";
import { formatDate } from "../../utils/formatDate";
import { downloadCsv } from "../../utils/csvExport";
import { calendarDay, localIsoDate } from "../../utils/localDate";
import { usePageTitle } from "../../hooks/usePageTitle";
import { SyncStatusBadge } from "../../components/ui/SyncStatusBadge";
import { VisitTypeBadge } from "../../components/ui/VisitTypeBadge";
import { Button } from "../../components/ui/Button";
import { Select } from "../../components/ui/Select";
import { PageHeader } from "../../components/ui/PageHeader";
import { EmptyState } from "../../components/ui/EmptyState";
import { Pagination } from "../../components/ui/Pagination";
import { Card } from "../../components/ui/Card";
import { VISIT_TYPES, type Visit } from "../../models/visit";
import { isSupervisorRole } from "../../models/chw";

const PAGE_SIZE = 10;

const VISIT_CSV_HEADERS = [
  "id",
  "patient_id",
  "chw_id",
  "visit_date",
  "visit_type",
  "weight",
  "height",
  "blood_pressure",
  "notes",
  "created_at",
  "updated_at",
  "sync_status",
] as const;

function visitToCsvRow(visit: Visit) {
  return [
    visit.id,
    visit.patient_id,
    visit.chw_id,
    visit.visit_date,
    visit.visit_type,
    visit.weight,
    visit.height,
    visit.blood_pressure,
    visit.notes,
    visit.created_at,
    visit.updated_at,
    visit.sync_status,
  ];
}

function VisitList() {
  usePageTitle("Visits");
  const session = authService.getSession();
  const isSupervisor = isSupervisorRole(session?.chw.role);

  const [visitTypeFilter, setVisitTypeFilter] = useState("");
  const [chwFilter, setChwFilter] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [page, setPage] = useState(1);

  useEffect(() => setPage(1), [visitTypeFilter, chwFilter, dateFilter]);

  const chws = useLiveQuery(() => db.chws.where("role").equals("CHW").toArray(), []);
  const patients = useLiveQuery(() => db.patients.toArray(), []);

  const visits = useLiveQuery(async () => {
    let result = (await db.visits.toArray()).filter((v) => !v.deleted_at);

    if (visitTypeFilter) {
      result = result.filter((v) => v.visit_type === visitTypeFilter);
    }
    if (chwFilter) {
      result = result.filter((v) => v.chw_id === chwFilter);
    }
    if (dateFilter) {
      result = result.filter((v) => calendarDay(v.visit_date) === dateFilter);
    }

    result.sort((a, b) =>
      calendarDay(a.visit_date) === calendarDay(b.visit_date)
        ? a.created_at < b.created_at ? 1 : -1
        : calendarDay(a.visit_date) < calendarDay(b.visit_date) ? 1 : -1,
    );
    return result;
  }, [visitTypeFilter, chwFilter, dateFilter]);

  const pageItems = visits?.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function chwName(chwId: string): string {
    if (chwId === session?.chw.chw_id) return "You";
    return chws?.find((c) => c.chw_id === chwId)?.full_name ?? chwId;
  }

  function patientLabel(patientId: string): { id: string; name: string } {
    const patient = patients?.find((p) => p.id === patientId);
    return patient
      ? { id: patient.patient_id, name: `${patient.first_name} ${patient.last_name}` }
      : { id: patientId, name: "Unknown patient" };
  }

  function handleExport() {
    if (!visits || visits.length === 0) return;
    downloadCsv(
      `mosi-visits-${localIsoDate()}.csv`,
      [...VISIT_CSV_HEADERS],
      visits.map(visitToCsvRow),
    );
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Visits"
        description={isSupervisor ? "Every visit recorded in your clinic." : "Visits in your clinic, newest first."}
        actions={
          isSupervisor ? (
            <Button variant="secondary" onClick={handleExport} disabled={!visits || visits.length === 0}>
              <Download className="h-4 w-4" aria-hidden="true" />
              Export CSV
            </Button>
          ) : (
            <Button asChild>
              <Link to="/chw/visits/new">
                <Plus className="h-4 w-4" aria-hidden="true" />
                Record visit
              </Link>
            </Button>
          )
        }
      />

      <div className="flex flex-wrap items-center gap-3">
        <Select
          value={visitTypeFilter}
          onValueChange={setVisitTypeFilter}
          placeholder="All visit types"
          ariaLabel="Filter by visit type"
          className="w-auto min-w-[150px]"
          options={[
            { value: "", label: "All visit types" },
            ...VISIT_TYPES.map((type) => ({ value: type, label: type })),
          ]}
        />
        <Select
          value={chwFilter}
          onValueChange={setChwFilter}
          placeholder="All CHWs"
          ariaLabel="Filter by CHW"
          className="w-auto min-w-[140px]"
          options={[
            { value: "", label: "All CHWs" },
            ...(chws ?? []).map((chw) => ({ value: chw.chw_id, label: chw.full_name })),
          ]}
        />
        <input
          type="date"
          value={dateFilter}
          onChange={(e) => setDateFilter(e.target.value)}
          aria-label="Filter by visit date"
          className="min-h-11 rounded-lg border border-stone-300 px-3.5 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700"
        />
        {dateFilter && (
          <button
            type="button"
            onClick={() => setDateFilter("")}
            className="flex min-h-11 items-center gap-1 px-2 text-sm text-stone-600 hover:text-stone-900"
          >
            <X className="h-3.5 w-3.5" aria-hidden="true" />
            Clear date
          </button>
        )}
      </div>

      {visits === undefined && <p className="text-sm text-stone-500">Loading visits…</p>}

      {visits && visits.length === 0 && (
        <EmptyState icon={Stethoscope} title="No visits match your filters" description="Try a different filter combination." />
      )}

      {pageItems && pageItems.length > 0 && (
        <>
          {/* Desktop table */}
          <Card className="hidden md:block overflow-hidden p-0">
            <table className="w-full text-sm">
              <thead className="bg-stone-50 border-b border-stone-200 text-left text-xs text-stone-500">
                <tr>
                  <th scope="col" className="px-4 py-2.5 font-medium">Patient</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Visit type</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Date</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">CHW</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {pageItems.map((visit) => {
                  const patient = patientLabel(visit.patient_id);
                  return (
                    <tr key={visit.id} className="hover:bg-stone-50 transition-colors">
                      <td className="px-4 py-3">
                        <Link
                          to={`/patients/${visit.patient_id}`}
                          className="text-forest-800 underline underline-offset-2 hover:text-forest-900"
                        >
                          {patient.name}
                        </Link>
                        <span className="ml-1.5 text-xs text-stone-500">{patient.id}</span>
                      </td>
                      <td className="px-4 py-3">
                        <VisitTypeBadge type={visit.visit_type} />
                      </td>
                      <td className="px-4 py-3 text-stone-600">{formatDate(visit.visit_date)}</td>
                      <td className="px-4 py-3 text-stone-600">{chwName(visit.chw_id)}</td>
                      <td className="px-4 py-3">
                        <SyncStatusBadge status={visit.sync_status} review={visit.review_status} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Card>

          {/* Mobile cards */}
          <div className="md:hidden space-y-2">
            {pageItems.map((visit) => {
              const patient = patientLabel(visit.patient_id);
              return (
                <Link
                  key={visit.id}
                  to={`/patients/${visit.patient_id}`}
                  className="block rounded-xl border border-stone-200 bg-white px-4 py-3 hover:border-stone-300 transition-colors"
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-medium text-stone-900">{patient.name}</p>
                    <SyncStatusBadge status={visit.sync_status} review={visit.review_status} />
                  </div>
                  <div className="mt-1.5 flex items-center gap-2 flex-wrap">
                    <VisitTypeBadge type={visit.visit_type} />
                    <span className="text-xs text-stone-500">
                      {formatDate(visit.visit_date)} · {chwName(visit.chw_id)}
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>

          <Pagination page={page} pageSize={PAGE_SIZE} totalItems={visits?.length ?? 0} onPageChange={setPage} itemLabel="visits" />
        </>
      )}
    </div>
  );
}

export default VisitList;
