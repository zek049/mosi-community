import { describe, expect, it } from "vitest";
import { timeAgo } from "../timeAgo";
import { localIsoDate } from "../localDate";

describe("timeAgo", () => {
  const now = new Date("2026-09-24T12:00:00Z").getTime();
  const ago = (ms: number) => new Date(now - ms).toISOString();

  it("says 'just now' for under 45 seconds", () => {
    expect(timeAgo(ago(10_000), now)).toBe("just now");
  });
  it("uses singular and plural minutes", () => {
    expect(timeAgo(ago(60_000), now)).toBe("1 minute ago");
    expect(timeAgo(ago(2 * 60_000), now)).toBe("2 minutes ago");
  });
  it("uses hours and days", () => {
    expect(timeAgo(ago(3 * 3_600_000), now)).toBe("3 hours ago");
    expect(timeAgo(ago(2 * 86_400_000), now)).toBe("2 days ago");
  });
  it("falls back to a date after a week", () => {
    expect(timeAgo(ago(10 * 86_400_000), now)).not.toMatch(/ago/);
  });
});

describe("localIsoDate", () => {
  it("formats the local calendar date, zero-padded", () => {
    expect(localIsoDate(new Date(2026, 0, 5, 0, 30))).toBe("2026-01-05");
  });
  it("uses the local day, not the UTC day, just after local midnight", () => {
    // 00:30 local on 1 March is still 28 Feb in UTC for any zone east of UTC.
    expect(localIsoDate(new Date(2026, 2, 1, 0, 30))).toBe("2026-03-01");
  });
});

describe("calendar dates", () => {
  it("treats local and server forms of a visit date as the same day", async () => {
    const { calendarDay } = await import("../localDate");
    const { formatDate } = await import("../formatDate");
    expect(calendarDay("2026-09-24T00:00:00.000Z")).toBe("2026-09-24");
    expect(formatDate("2026-09-24")).toBe(formatDate("2026-09-24T00:00:00.000Z"));
    expect(formatDate("2026-09-24")).toBe(new Date(2026, 8, 24).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }));
  });
});
