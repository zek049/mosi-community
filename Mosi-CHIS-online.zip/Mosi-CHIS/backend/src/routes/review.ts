import { Router, type Request } from "express";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { clinicScope } from "../middleware/authz";
import { requireStringParam } from "../utils/params";
import { parseBody, reviewConfirmSchema, reviewFlagSchema } from "../validation/schemas";
import { writeAuditLog } from "../utils/audit";
import { CAN_CONFIRM_FROM, CAN_FLAG_FROM, type ReviewStatus } from "../utils/review";

// Supervisor review queue. Mounted behind authenticate + requireRole
// ("SUPERVISOR") in app.ts; every query here is also limited by
// clinicScope(), and a record outside the reviewer's scope answers 404 (the
// same as one that doesn't exist), so scope can't be probed.
const router = Router();

const PATIENT_FIELDS = {
  id: true,
  patient_id: true,
  first_name: true,
  last_name: true,
  date_of_birth: true,
  gender: true,
  village: true,
  phone_number: true,
  clinic_id: true,
  registered_by_chw_id: true,
  created_at: true,
  updated_at: true,
  review_status: true,
  review_flag_reason: true,
  reviewed_at: true,
  reviewed_by: true,
} as const;

const VISIT_FIELDS = {
  id: true,
  patient_id: true,
  chw_id: true,
  visit_date: true,
  visit_type: true,
  weight: true,
  height: true,
  blood_pressure: true,
  notes: true,
  clinic_id: true,
  created_at: true,
  updated_at: true,
  review_status: true,
  review_flag_reason: true,
  reviewed_at: true,
  reviewed_by: true,
  patient: { select: { id: true, patient_id: true, first_name: true, last_name: true, village: true } },
} as const;

const SUBMIT_ACTIONS = ["PATIENT_CREATED", "PATIENT_UPDATED", "VISIT_CREATED", "VISIT_UPDATED"];

type Submission = { chw_id: string | null; submitted_at: Date; kind: "new" | "edit"; request_id: string | null };

// Who sent each record, when, whether it was new or an edit, and in which
// request - from the audit trail (sync writes one entry per record it
// created/changed). Falls back to the record itself if no entry exists.
async function latestSubmissions(type: "patient" | "visit", ids: string[]): Promise<Map<string, Submission>> {
  if (ids.length === 0) return new Map();
  const entries = await prisma.auditLog.findMany({
    where: { resource_type: type, resource_id: { in: ids }, action: { in: SUBMIT_ACTIONS } },
    orderBy: { created_at: "desc" },
    select: { resource_id: true, actor_id: true, created_at: true, action: true, request_id: true },
  });
  const map = new Map<string, Submission>();
  for (const e of entries) {
    if (!e.resource_id || map.has(e.resource_id)) continue;
    map.set(e.resource_id, {
      chw_id: e.actor_id,
      submitted_at: e.created_at,
      kind: e.action.endsWith("_CREATED") ? "new" : "edit",
      request_id: e.request_id,
    });
  }
  return map;
}

function scopeWhere(scope: string | undefined) {
  return scope ? { clinic_id: scope } : {};
}

router.get("/pending", async (req, res) => {
  const scope = clinicScope(req.user!);
  const where = { deleted_at: null, review_status: "awaiting_review" as const, ...scopeWhere(scope) };
  const [patients, visits] = await Promise.all([
    prisma.patient.findMany({ where, select: PATIENT_FIELDS, orderBy: { updated_at: "asc" }, take: 500 }),
    prisma.visit.findMany({ where, select: VISIT_FIELDS, orderBy: { updated_at: "asc" }, take: 500 }),
  ]);
  const [patientSubs, visitSubs] = await Promise.all([
    latestSubmissions("patient", patients.map((p) => p.id)),
    latestSubmissions("visit", visits.map((v) => v.id)),
  ]);

  type Item = {
    record_type: "patient" | "visit";
    id: string;
    submitted_by: string | null;
    submitted_at: Date;
    submission: "new" | "edit";
    request_id: string | null;
    // The last review decision before this edit (kept, not wiped), if any.
    previous_review: { flag_reason: string | null; reviewed_at: Date | null } | null;
    patient: unknown;
    visit?: unknown;
  };
  const previous = (r: { review_flag_reason: string | null; reviewed_at: Date | null }) =>
    r.reviewed_at || r.review_flag_reason ? { flag_reason: r.review_flag_reason, reviewed_at: r.reviewed_at } : null;

  const items: Item[] = [
    ...patients.map((p): Item => {
      const s = patientSubs.get(p.id);
      return {
        record_type: "patient",
        id: p.id,
        submitted_by: s?.chw_id ?? p.registered_by_chw_id,
        submitted_at: s?.submitted_at ?? p.updated_at,
        submission: s?.kind ?? (p.created_at.getTime() === p.updated_at.getTime() ? "new" : "edit"),
        request_id: s?.request_id ?? null,
        previous_review: previous(p),
        patient: p,
      };
    }),
    ...visits.map((v): Item => {
      const s = visitSubs.get(v.id);
      const { patient, ...visit } = v;
      return {
        record_type: "visit",
        id: v.id,
        submitted_by: s?.chw_id ?? v.chw_id,
        submitted_at: s?.submitted_at ?? v.updated_at,
        submission: s?.kind ?? (v.created_at.getTime() === v.updated_at.getTime() ? "new" : "edit"),
        request_id: s?.request_id ?? null,
        previous_review: previous(v),
        patient,
        visit,
      };
    }),
  ];

  // Which of those requests were syncs (vs. entered online), and the
  // device's own batch id/time for them.
  const requestIds = [...new Set(items.map((i) => i.request_id).filter((id): id is string => !!id))];
  const syncStarts = requestIds.length
    ? await prisma.auditLog.findMany({
        where: { action: "SYNC_STARTED", request_id: { in: requestIds } },
        select: { request_id: true, created_at: true, metadata: true },
      })
    : [];
  const syncByRequest = new Map(syncStarts.map((s) => [s.request_id, s]));

  const chwIds = [...new Set(items.map((i) => i.submitted_by).filter((id): id is string => !!id))];
  const chws = await prisma.chw.findMany({ where: { chw_id: { in: chwIds } }, select: { chw_id: true, full_name: true } });
  const nameById = new Map(chws.map((c) => [c.chw_id, c.full_name]));

  // CHW -> batch (one sync request, or "entered online") -> records.
  // Oldest first: a queue is worked from the front.
  items.sort((a, b) => a.submitted_at.getTime() - b.submitted_at.getTime());
  type Batch = { key: string; via: "sync" | "online"; device_batch_id: string | null; sent_at: Date; items: Item[] };
  const groups = new Map<string, { chw: { chw_id: string | null; full_name: string | null }; batches: Map<string, Batch> }>();
  for (const item of items) {
    const chwKey = item.submitted_by ?? "unknown";
    if (!groups.has(chwKey)) {
      groups.set(chwKey, { chw: { chw_id: item.submitted_by, full_name: item.submitted_by ? (nameById.get(item.submitted_by) ?? null) : null }, batches: new Map() });
    }
    const group = groups.get(chwKey)!;
    const sync = item.request_id ? syncByRequest.get(item.request_id) : undefined;
    const batchKey = sync ? `sync:${item.request_id}` : `online:${item.id}`;
    if (!group.batches.has(batchKey)) {
      const meta = (sync?.metadata ?? null) as { batch_id?: unknown } | null;
      group.batches.set(batchKey, {
        key: batchKey,
        via: sync ? "sync" : "online",
        device_batch_id: typeof meta?.batch_id === "string" ? meta.batch_id : null,
        sent_at: sync?.created_at ?? item.submitted_at,
        items: [],
      });
    }
    group.batches.get(batchKey)!.items.push(item);
  }

  res.json({
    success: true,
    data: {
      total: items.length,
      counts: { patients: patients.length, visits: visits.length },
      groups: [...groups.values()].map((g) => ({ chw: g.chw, batches: [...g.batches.values()] })),
    },
  });
});

// Flagged records, for follow-up with the CHW. Newest decision first.
router.get("/flagged", async (req, res) => {
  const scope = clinicScope(req.user!);
  const where = { deleted_at: null, review_status: "flagged" as const, ...scopeWhere(scope) };
  const [patients, visits] = await Promise.all([
    prisma.patient.findMany({ where, select: PATIENT_FIELDS, orderBy: { reviewed_at: "desc" }, take: 200 }),
    prisma.visit.findMany({ where, select: VISIT_FIELDS, orderBy: { reviewed_at: "desc" }, take: 200 }),
  ]);
  const reviewerIds = [...new Set([...patients, ...visits].map((r) => r.reviewed_by).filter((id): id is string => !!id))];
  const submitterIds = [...new Set([...patients.map((p) => p.registered_by_chw_id), ...visits.map((v) => v.chw_id)].filter((id): id is string => !!id))];
  const people = await prisma.chw.findMany({ where: { chw_id: { in: [...reviewerIds, ...submitterIds] } }, select: { chw_id: true, full_name: true } });
  const nameById = new Map(people.map((c) => [c.chw_id, c.full_name]));
  const items = [
    ...patients.map((p) => ({ record_type: "patient" as const, id: p.id, flag_reason: p.review_flag_reason, flagged_at: p.reviewed_at, flagged_by: p.reviewed_by, flagged_by_name: p.reviewed_by ? (nameById.get(p.reviewed_by) ?? null) : null, chw_id: p.registered_by_chw_id, chw_name: p.registered_by_chw_id ? (nameById.get(p.registered_by_chw_id) ?? null) : null, patient: p })),
    ...visits.map(({ patient, ...v }) => ({ record_type: "visit" as const, id: v.id, flag_reason: v.review_flag_reason, flagged_at: v.reviewed_at, flagged_by: v.reviewed_by, flagged_by_name: v.reviewed_by ? (nameById.get(v.reviewed_by) ?? null) : null, chw_id: v.chw_id, chw_name: nameById.get(v.chw_id) ?? null, patient, visit: v })),
  ].sort((a, b) => (b.flagged_at?.getTime() ?? 0) - (a.flagged_at?.getTime() ?? 0));
  res.json({ success: true, data: { total: items.length, items } });
});

// --- Decisions ---------------------------------------------------------------

type Decision = { kind: "confirm" } | { kind: "flag"; reason: string };

async function decide(recordType: "patient" | "visit", id: string, decision: Decision, req: Request) {
  const actor = req.user!;
  const scope = clinicScope(actor);
  const table = recordType === "patient" ? prisma.patient : prisma.visit;
  // Prisma's per-model delegates don't share a callable type; both have the
  // same review columns, so this narrow cast is safe.
  const delegate = table as unknown as {
    findUnique: (a: unknown) => Promise<{ clinic_id: string; review_status: ReviewStatus; deleted_at: Date | null } | null>;
    updateMany: (a: unknown) => Promise<{ count: number }>;
  };
  const label = recordType === "patient" ? "Patient" : "Visit";

  const record = await delegate.findUnique({ where: { id }, select: { clinic_id: true, review_status: true, deleted_at: true } });
  if (!record || record.deleted_at || (scope && record.clinic_id !== scope)) {
    throw new AppError(404, `${label} not found`);
  }

  const allowed = decision.kind === "confirm" ? CAN_CONFIRM_FROM : CAN_FLAG_FROM;
  if (!allowed.includes(record.review_status)) {
    throw new AppError(
      409,
      record.review_status === "confirmed" ? `This ${recordType} is already confirmed` : `This ${recordType} is already flagged`,
      "INVALID_REVIEW_TRANSITION",
    );
  }

  const now = new Date();
  // Conditional on the status we just read, so two supervisors deciding at
  // once can't both win. updated_at is deliberately NOT touched: it's the
  // content timestamp the sync conflict check compares, and a review isn't
  // a content change.
  const result = await delegate.updateMany({
    where: { id, review_status: record.review_status, deleted_at: null },
    data:
      decision.kind === "confirm"
        ? { review_status: "confirmed", reviewed_at: now, reviewed_by: actor.chwId }
        : { review_status: "flagged", review_flag_reason: decision.reason, reviewed_at: now, reviewed_by: actor.chwId },
  });
  if (result.count === 0) {
    throw new AppError(409, `This ${recordType} was changed while you were reviewing it. Reload and try again.`, "REVIEW_STALE");
  }

  await writeAuditLog({
    actor,
    action: decision.kind === "confirm" ? "RECORD_CONFIRMED" : "RECORD_FLAGGED",
    resourceType: recordType,
    resourceId: id,
    requestId: req.requestId,
    metadata: { from: record.review_status, clinic_id: record.clinic_id, ...(decision.kind === "flag" ? { reason: decision.reason } : {}) },
  });

  return { id, review_status: decision.kind === "confirm" ? "confirmed" : "flagged", reviewed_at: now, reviewed_by: actor.chwId };
}

for (const recordType of ["patient", "visit"] as const) {
  router.post(`/${recordType}s/:id/confirm`, async (req, res) => {
    parseBody(reviewConfirmSchema, req.body ?? {});
    res.json({ success: true, data: await decide(recordType, requireStringParam(req, "id"), { kind: "confirm" }, req) });
  });
  router.post(`/${recordType}s/:id/flag`, async (req, res) => {
    const body = parseBody(reviewFlagSchema, req.body ?? {});
    res.json({ success: true, data: await decide(recordType, requireStringParam(req, "id"), { kind: "flag", reason: body.reason }, req) });
  });
}

export default router;
