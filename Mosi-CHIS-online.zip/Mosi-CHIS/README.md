# Mosi — Community Health Information System

**A clearer view of care in motion**

Mosi is an offline-first digital reporting prototype for community health
workers (CHWs), built as a BCom Honours Information Systems dissertation
project at Midlands State University, Zimbabwe:

> *A Community Health Information System (CHIS) Digital Reporting Tool with
> Offline Capabilities for Community Health Workers in Low Connectivity
> Areas: A Case of Zimbabwe.*

It demonstrates that a CHW in a low-connectivity area (e.g. Mbare or
Hatcliffe, Harare) can record patients and visits entirely offline, with
that data syncing automatically once a connection returns — and that a
supervisor can see coverage, sync health, and CHW activity from one
dashboard.

Beyond the academic prototype, the backend has been hardened to a
**pilot-ready MVP**: multi-clinic data isolation, CHW account lifecycle
(active/inactive, PIN lockout), a real audit trail, a resolvable sync-conflict
model, and the security/operational baseline a small real deployment would
need (see [Security & data isolation](#security--data-isolation) and
[MVP status](#mvp-status) below).

> **All data in this system is synthetic demonstration data — not real
> patient records.** Mosi incorporates privacy and security controls
> informed by applicable Zimbabwean data-protection requirements and should
> undergo formal organizational/legal review before any deployment handling
> real patient data. See [Scope and limitations](#scope-and-limitations)
> below.

---

## Contents

- [Tech stack](#tech-stack)
- [Quick start (Docker — recommended)](#quick-start-docker--recommended)
- [Manual setup (without Docker)](#manual-setup-without-docker)
- [Demo accounts](#demo-accounts)
- [Roles, clinics & data isolation](#roles-clinics--data-isolation)
- [Security & data isolation](#security--data-isolation)
- [Synchronization & conflicts](#synchronization--conflicts)
- [Sync status in the app](#sync-status-in-the-app)
- [Device privacy & signing out](#device-privacy--signing-out)
- [Supervisor PIN reset](#supervisor-pin-reset)
- [Public contact configuration](#public-contact-configuration)
- [Accessibility testing](#accessibility-testing)
- [API surface](#api-surface)
- [Demonstrating offline capability](#demonstrating-offline-capability)
- [Installing Mosi as an app (PWA)](#installing-mosi-as-an-app-pwa)
- [Project structure](#project-structure)
- [MVP status](#mvp-status)
- [Scope and limitations](#scope-and-limitations)

---

## Tech stack

| Layer    | Technology |
|----------|------------|
| Frontend | React 18 + TypeScript + Vite, Tailwind CSS v3, Radix UI primitives, Recharts, Dexie.js (IndexedDB), TanStack Query, React Router |
| Backend  | Node.js 24 + Express 5 + TypeScript, Prisma ORM, PostgreSQL, Zod validation |
| Offline  | Dexie.js/IndexedDB local storage, a custom sync engine with retry/backoff, and a service worker for app-shell caching |
| Tooling  | npm only (no pnpm/yarn), Windows-native — no Unix shell scripts required to run it |

---

## Quick start (Docker — recommended)

This runs the whole stack — database, API, and frontend — with one command.

**Prerequisites:** [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed and running on Windows.

`docker-compose.yml` requires a `JWT_SECRET` and `POSTGRES_PASSWORD` — it
refuses to start without them rather than falling back to a value every
clone of this repo would otherwise share:

```powershell
copy .env.example .env
docker compose up --build
```

That single command will, in order:
1. Start PostgreSQL and wait until it's actually accepting connections.
2. Build and start the backend, which applies database migrations and, only
   if `SEED_ON_START=true` (the `.env.example` default, so the demo stack
   works out of the box), **reseeds the synthetic demo data** — deleting
   whatever patients/visits/sync log entries were already there. Set it to
   `false` for any stack meant to hold data across restarts.
3. Build and start the frontend, served by nginx (not `vite preview`, which
   Vite itself documents as unsuitable for production use).

Once it settles (the backend logs `Mosi API listening on http://localhost:4000`),
open:

```
http://localhost:5173
```

To stop everything:

```powershell
docker compose down
```

(Demo data lives in a Docker volume and survives `docker compose down` —
only `docker compose down -v` clears it, and the next `docker compose up`
would simply reseed it anyway.)

### Ports used

| Service    | Host port | Why |
|------------|-----------|-----|
| Frontend   | 5173      | Same port used during development, so instructions/screenshots stay consistent either way |
| Backend    | 4000      | The API the frontend talks to |
| PostgreSQL | 5433      | **Not 5432** — many Windows machines already run a native PostgreSQL service on 5432; 5433 avoids colliding with it without touching that install |

If any of these ports are already in use on your machine, stop whatever's
using them first, or edit the `ports:` mappings in `docker-compose.yml`
(the frontend's API calls default to `http://localhost:4000/api`, so if you
change the backend's host port you'll also need to rebuild the frontend with
`VITE_API_URL` set to match).

---

## Manual setup (without Docker)

This is how Mosi was actually built and tested step-by-step, and is useful
for active development (hot reload, debugging, etc).

**Prerequisites:** Node.js 24+, npm, and a running PostgreSQL instance.

### 1. Start PostgreSQL

Easiest via Docker (just the database, nothing else containerized):

```powershell
docker compose up -d postgres
```

Or point at a native PostgreSQL install of your own — see the comments in
`backend/.env.example`.

### 2. Backend

```powershell
cd backend
copy .env.example .env
npm install
npm run migrate:dev
npm run db:seed
npm run dev
```

The API starts on `http://localhost:4000`.

### 3. Frontend

In a second terminal:

```powershell
cd web-app
npm install
npm run dev
```

The app opens on `http://localhost:5173`.

---

## Demo accounts

> **Demo only.** These accounts and the shared PIN `1234` come from the
> synthetic demo seed (`backend/prisma/seed.ts`), which runs only when
> `SEED_ON_START=true` (the demo `docker-compose.yml` default). The Login
> screen lists them only in development or when built with
> `VITE_SHOW_DEMO_ACCOUNTS=true` (the demo compose stack does). A pilot
> deployment must set `SEED_ON_START=false`, leave
> `VITE_SHOW_DEMO_ACCOUNTS` unset, and provision real accounts with
> `POST /api/chws`, never these.

Mosi uses pre-configured demo accounts rather than open registration — sign
in with a CHW ID and 4-digit PIN. Supervisors can provision real accounts via
`POST /api/chws` (revoke/reactivate with `POST /api/chws/:chwId/revoke` and
`/reactivate`) - the seed script is no longer the only way in.

| ID      | Name            | Role          | Clinic                          | Status      | PIN  |
|---------|-----------------|---------------|---------------------------------|-------------|------|
| CHW001  | Jane Moyo       | CHW           | Mbare Clinic                    | active      | 1234 |
| CHW002  | John Ncube      | CHW           | Hatcliffe Clinic                | active      | 1234 |
| CHW003  | Tariro Gumbo    | CHW           | Epworth Clinic                  | active      | 1234 |
| CHW004  | Nyasha Chidziva | CHW           | Epworth Clinic                  | **revoked** | 1234 |
| SUP001  | Grace Chikwanha | Administrator | Harare Provincial Health Office | active      | 1234 |
| SUP002  | Farai Mupfumi   | Supervisor    | Mbare Clinic                    | active      | 1234 |

**Roles.** A *supervisor* sees and manages only their own clinic (SUP002 sees
Mbare only). An *administrator* sees every clinic and is the only role that
can create, revoke or delete supervisor accounts ("Manage supervisors") or
create clinics. Nobody can create an administrator through the app.

An existing database from before the administrator role can be brought up
to date without reseeding (which rebuilds all patients and visits):
`npx prisma migrate deploy` then `npx tsx prisma/scripts/promoteAdmin.ts`
(makes SUP001 an administrator and adds SUP002; safe to run twice).

CHW004 is deliberately seeded as revoked, so "a revoked account loses
access immediately" is something you can actually try: with the correct PIN
it gets "This account has been deactivated" - not just something covered by
an automated test.

---

## Roles, clinics & data isolation

Clinics are a first-class entity (`Clinic` in the schema), not a hardcoded
pair of strings - the seed data deliberately includes **three** clinics
(Mbare, Hatcliffe, Epworth) plus a head-office entry for supervisors, so
"multi-clinic" is something the app actually exercises. Every CHW belongs to
exactly one clinic; every patient and visit is scoped to a clinic, assigned
server-side from the authenticated actor at creation time - never from the
request body.

|                       | CHW                  | Supervisor |
|-----------------------|-----------------------|------------|
| Own clinic's patients/visits | read + write    | read + write |
| Other clinics' patients/visits | **denied (403)** | read + write |
| Manage CHW accounts   | denied                | create / activate / deactivate / reassign clinic / reset PIN |
| Dashboard, audit log, sync conflicts | denied  | full access |

This is enforced in the API itself (`backend/src/middleware/authz.ts` +
per-route checks), not by what the frontend does or doesn't render - a CHW
hitting `GET /api/patients/:id` for a patient in another clinic gets a 403
regardless of what UI they're using.

---

## Security & data isolation

- **PIN lockout**: 5 wrong PINs locks a CHW's account for 15 minutes
  (`backend/src/routes/auth.ts`). Login always returns the same generic
  "Invalid CHW ID or PIN" whether the CHW ID doesn't exist, the PIN is
  wrong, or the account is locked/deactivated - nothing about *why* a login
  failed is ever revealed to the client.
- **Deactivation is immediate**: `authenticate` (the middleware every
  protected route runs through) re-checks the CHW's `status`/`locked_until`
  against the database on every request, not just at login - a supervisor
  deactivating a CHW mid-session cuts their access off on their very next
  request, not after their token happens to expire up to 12h later.
- **JWT hardening**: explicit `issuer`/`audience`/`algorithm` (`HS256` only)
  on sign and verify, a required `subject` claim, and no fallback secret -
  the server refuses to start at all without a real `JWT_SECRET`.
- **Anti-spoofing**: a CHW can never write `chw_id`, `clinic_id`, or
  `registered_by_chw_id` via the request body - those always come from the
  authenticated session, both on the direct REST routes and the offline sync
  path, which is a separate write path with its own equivalent checks.
- **Audit trail**: every login (success/failure/lockout), patient/visit
  create/update/archive, CHW create/update/deactivate, and sync
  conflict/resolution is written to an append-only `AuditLog` table
  (`GET /api/audit-logs`, supervisor-only) - never PINs, passwords, JWTs, or
  full health records, just who/what/when.
- **No secrets in logs**: request logs redact the session cookie,
  `Authorization` header and `Set-Cookie` (`backend/src/logger.ts`); PINs are
  never logged (request bodies aren't logged at all).
- **Rate limiting**: 10 login attempts / 15 min per IP+CHW-ID, a generous 30
  sync attempts / min per CHW (field retries shouldn't get throttled), and a
  300 req/min backstop on everything else.
- **Transport/headers**: `helmet` security headers + an explicit
  `ALLOWED_ORIGINS` allowlist on the API; a real `Content-Security-Policy` +
  `X-Frame-Options` on the frontend.

---

## Synchronization & conflicts

Conflict resolution is still last-write-wins by client timestamp, with a
content-hash tiebreak for identical-timestamp retries
(`backend/src/services/conflictResolver.ts`) - unchanged from the original
design, just implemented more robustly now:

- Every patient/visit create/update inside a sync batch runs inside a
  database transaction alongside its `SyncLog` entry, so a write and its own
  audit trail can never end up inconsistent with each other.
- A genuine conflict (same timestamp, different content) now creates a real,
  resolvable `SyncConflict` row - not just a log line - with both the
  incoming and server versions, who/when it was detected, and its
  open/resolved status. `GET /api/conflicts` (supervisor-only) lists them;
  `POST /api/conflicts/:id/resolve` applies `KEEP_SERVER` or
  `APPLY_INCOMING` and permanently records the resolution (it's never
  deleted, only marked resolved).
- A sync batch is capped at 200 patients + 200 visits per request
  (`MAX_SYNC_BATCH_RECORDS`), with a per-record outcome so one bad/conflicted
  record in a batch never blocks the other 399.

---

## Sync status in the app

The server takes a whole sync batch in one request and answers with a
verdict for each record only when the batch is done. So the app reports
what it can actually know, and nothing more:

- **Before / during:** the number of changes sent - "Syncing 3 changes…".
  There is no "3 of 8" progress, because the app can't observe it.
- **After:** the server's real per-record verdicts - e.g. "2 changes synced.
  1 change needs review." or "1 change couldn't sync and is still waiting."
- **No answer** (offline, server unreachable, session ended): "Sync paused.
  N changes are still waiting." Nothing is lost; the records stay on the
  device and are retried (automatically when the connection returns, or
  with "Retry sync").
- "Saved and synced" is only ever shown once the server has accepted a
  record. The same messages are announced to screen readers through a
  single polite live region. All wording lives in
  `web-app/src/utils/syncMessages.ts`.

The supervisor's view of sync activity reads the server's sync log, which
shares the per-user limit of 30 sync requests/minute. Dashboard, CHW
Activity and Sync all read one cached copy (refreshed at most once a
minute while moving between them), 4xx responses are never retried
automatically, and a 429 shows a plain message whose "Try again" waits for
the server's `Retry-After`. The limit itself is unchanged.

---

## Device privacy & signing out

Records are stored in the browser (IndexedDB) so Mosi works offline.

- **One local database per account.** Each CHW ID gets its own database
  (`mosi-chis-user-<CHW ID>`), and the app only opens the signed-in
  person's. Someone else signing in on the same device can't see - or
  accidentally sync - your records through the app.
- **Signing out** removes everything that is already on the server
  (patients, visits, the CHW list, cached server responses in memory).
- **Unsynced changes are never deleted silently.** If any exist, sign-out
  stops and offers: *Sync, then sign out* (when online), *Sign out, keep
  them here* (they stay in your database, hidden from other users, and sync
  the next time you sign in), or *Stay signed in*.
- **"Remove my data from this device"** (Sync screen) deletes everything for
  your account, including unsynced changes - with a clear warning and a
  required "I understand N unsynced changes will be lost" confirmation.
- **Not encrypted.** Data kept on the device is not encrypted; a person with
  the device and browser developer tools could read it. Use devices the
  clinic controls.
- **Upgrading from the old shared database** (`mosi-chis`, used by builds
  before per-user storage): when a CHW signs in, only records whose owner is
  *proven* move to them. An unsynced visit carries `chw_id` (set from the
  session when recorded), so it moves only to that CHW. An unsynced patient
  has no owner field, so it is **never** assigned to whoever signs in: it
  stays in the old database as *unassigned* (not shown, not synced, not
  deleted), together with any visit that depends on it. The Sync screen's
  "This device" section says how many such records the device holds.
  Resolving them needs a supervisor/administrator on that device; there is
  no in-app review screen. IndexedDB is per-origin, so this can only occur
  where an older build was used at the same web address.

---

## Supervisor PIN reset

Supervisors use **More → Reset a PIN** (sidebar on desktop). They choose a
CHW, enter the new 4-digit PIN twice (or generate a random one), and confirm.
It calls the existing `PATCH /api/chws/:chwId` with `{ "pin": "…" }`; the
server enforces supervisor-only access, stores only a bcrypt hash, clears
any sign-in lockout, never returns the PIN or its hash, and records
`pin_reset: true` (never the PIN) in the audit log.

There is **no temporary-PIN concept** in the backend: the new PIN stays the
account's PIN until it's reset again, and the app says so. Nobody's current
PIN can be shown, because only its hash exists. The new PIN is cleared from
the screen as soon as the reset succeeds.

---

## Public contact configuration

The landing page's Contact notice never shows invented details. To show a
real contact, set these at **build time** (see `web-app/.env.example`, or
pass them as Docker build args):

```
VITE_PUBLIC_CONTACT_NAME=Mosi pilot support
VITE_PUBLIC_CONTACT_EMAIL=support@your-organisation.example
```

If they're unset (or the email isn't valid), the notice tells people to
contact their supervisor or system administrator instead
(`web-app/src/config/contact.ts`).

---

## Accessibility testing

Automated accessibility and keyboard testing passed: axe-core (WCAG 2.x A/AA
plus best-practice rules) across every screen at 320-1440px, with no
critical or serious issues. Keyboard-only runs covered sign-in, recording a
visit, menus, dialogs (focus trap, Escape, focus return), conflict
resolution, PIN reset and sign-out. We also reviewed the browser's
accessibility tree. **Testing with specialist screen readers (NVDA, JAWS,
VoiceOver, TalkBack) was not performed in the available environment**, so
Mosi should not be described as fully accessible until that has been done.

One moderate axe best-practice note is expected: an open dropdown menu
(e.g. mobile "More") is rendered in a portal outside the page landmarks.
That follows the WAI-ARIA menu-button pattern (the menu is tied to its
trigger button), so it has been left as is.

These checks are automated in the browser test suites in
[`web-app/e2e/`](web-app/e2e/README.md) (Playwright, against the production
build and the real backend): `cd web-app/e2e && npm install && node run-all.mjs`.

---

## API surface

All routes are under `/api`, JSON in and out, `{success, data}` on success
and `{success: false, message}` on error. Every route except
`POST /api/auth/login` requires `Authorization: Bearer <token>`.

| Route | Notes |
|---|---|
| `POST /api/auth/login` | Rate-limited, generic failure messages, PIN lockout |
| `GET/POST/PUT/DELETE /api/patients[/:id]` | Clinic-scoped; DELETE archives (soft delete), never hard-deletes |
| `GET/POST/PUT/DELETE /api/visits[/:id]` | Clinic-scoped via the patient; DELETE archives |
| `GET/POST/PATCH /api/chws[/:chwId]` | POST/PATCH are supervisor-only (create, activate/deactivate, reassign clinic, reset PIN) |
| `GET/POST /api/clinics` | POST is supervisor-only |
| `POST /api/sync`, `GET /api/sync/log` | Batch sync + the append-only sync event log |
| `GET /api/conflicts`, `POST /api/conflicts/:id/resolve` | Supervisor-only |
| `GET /api/audit-logs` | Supervisor-only |
| `GET /api/dashboard/stats` | Supervisor-only |
| `GET /api/health`, `/api/health/live`, `/api/health/ready` | `/health` is a backward-compatible alias of `/ready` (DB-checked); `/live` never touches the database |

Patients/visits/CHWs/audit-logs/conflicts all support `?page=&limit=` (a
1-2000 hard ceiling) and return a `pagination` object alongside `data` -
omitting `page`/`limit` entirely returns one page covering the whole table
(up to that ceiling), which is what the offline-first frontend's cache
refresh relies on. There's no formal OpenAPI/Swagger spec yet - see
[Known limitations](#known-limitations-for-a-real-non-demo-deployment).

---

## Demonstrating offline capability

Mosi's core claim is that a CHW can keep working with **no connection at
all**. Connectivity in the app is real, not simulated:

- **Automatic detection.** The browser's own online/offline state, plus a
  lightweight `GET /api/health` check (on load, on reconnect, and every 30
  seconds while the tab is visible). A device on a network that can't
  reach the Mosi server shows **Server unreachable**, not "Online".
- **Work Offline.** A deliberate switch on the Sign in page, in the desktop
  header, and in the account menu on phones. While it's on, Mosi makes **no**
  sync, cache-refresh or health-check requests. It's remembered on the
  device until turned off.
- Both feed **one** connectivity state (`web-app/src/services/connectivity.ts`
  + `contexts/NetworkContext.tsx`): the sync engine, the Sync screen, the
  status pill, the save screens and server-backed supervisor screens all read
  it. "Online" means the browser is online **and** the server answered **and**
  Work Offline is off; anything else is treated as offline.

A typical demonstration:

1. Sign in as **CHW001** (signing in needs the server).
2. Turn on **Work Offline** (or genuinely disconnect: switch off Wi-Fi, or
   use browser DevTools -> Network -> Offline).
3. Go to **Add patient**, fill in the form and save. It's saved on the
   device straight away and marked as waiting to sync.
4. Record a visit for that patient the same way.
5. Open **Sync**: both changes are listed as waiting, and the card explains
   why they haven't synced (Working offline / Offline / Server unreachable).
6. Turn **Work Offline** off (or reconnect). Mosi checks the server, then
   syncs the waiting changes automatically.

This works because every write goes straight to the browser's IndexedDB
first (via Dexie.js) - the server is only ever contacted by the separate
sync step, never as a precondition for saving.

---

## Installing Mosi as an app (PWA)

Mosi is installable as a Progressive Web App, so it can run from a home
screen/desktop icon like a native app, and the app shell (not the patient
data — that's IndexedDB's job) still loads with zero network reachable at
all.

**Android (Chrome / Edge)**
1. Open Mosi in Chrome and sign in once.
2. An **Install Mosi** card appears near the bottom of the screen; tap
   **Install**. (Or open the browser menu ⋮ → **Install app** / **Add to
   Home screen**.)
3. Mosi appears on the home screen with the leaf icon and opens full-screen,
   without the browser bar.

**iPhone / iPad (Safari)**
1. Open Mosi in **Safari** (iOS has no install prompt, and older iOS only
   installs from Safari).
2. Tap **Share** → **Add to Home Screen** → **Add**. Mosi's Login and Home
   screens show these steps on iPhone/iPad until you dismiss them, and hide
   them once Mosi is opened from the home screen.

**Desktop (Chrome / Edge)**
Use the install icon at the right of the address bar, or the **Install
Mosi** card in the bottom corner.

What the browser checks before it offers to install (all in place):
`public/manifest.json` with name, `start_url`, `display: standalone`,
192 px and 512 px icons (plus a separate *maskable* 512 px icon whose leaf
sits inside the safe zone, so Android can crop it to any shape) and a
service worker (`public/sw.js`). The page must be served over **HTTPS**
(or `localhost`) - a real deployment needs a TLS certificate. Chrome also
waits until the person has used the page briefly before showing its prompt.
The icons are generated from the in-app leaf logo; iOS uses
`icons/apple-touch-icon.png` (180 px).

Note: the install prompt and offline app-shell caching only activate on a
production build (`docker compose up`, or `npm run build && npm run
preview` in `web-app/`) — not on `npm run dev`, so that the service worker
never interferes with the dev server's hot reload.

---

## Project structure

```
CHIS/
├── docker-compose.yml       # postgres + backend + frontend
├── backend/
│   ├── Dockerfile
│   ├── docker-entrypoint.sh # migrate → seed (opt-in) → start, used by the container
│   ├── prisma/               # schema, migrations, seed script
│   └── src/
│       ├── routes/           # auth, patients, visits, chws, clinics, sync, conflicts, audit-logs, dashboard
│       ├── middleware/        # auth (JWT), authz (clinic/role policies), rate limiting, request ID
│       ├── services/          # sync engine, conflict resolution, validation
│       ├── validation/        # zod schemas
│       └── __tests__/         # integration tests (auth, authz, sync, rate limiting)
└── web-app/
    ├── Dockerfile
    ├── public/                # manifest.json, sw.js, icons
    └── src/
        ├── screens/           # one folder per screen (11 total)
        ├── components/        # shared UI, layouts
        ├── services/          # API client, auth, sync engine
        ├── db/                # Dexie/IndexedDB schema
        └── models/            # shared TypeScript types
```

---

## MVP status

**Pilot-ready, not production-ready.** The backend has real multi-clinic
authorization, account lifecycle, audit logging, a resolvable conflict
model, and the security/deployment baseline (rate limiting, JWT hardening,
non-root Docker images, structured logging, health checks, CI) a small
controlled pilot would need. It has not been through a security audit, load
tested at real-world scale, or formally reviewed for legal/compliance
requirements - see [Known limitations](#known-limitations-for-a-real-non-demo-deployment)
below for exactly what's still missing before a real deployment.

---

## Scope and limitations

Mosi is a working prototype built to demonstrate offline-first CHW
reporting, not a production system. Deliberately **out of scope**:

- No DHIS2, Impilo, HL7, or FHIR integration
- No AI/ML features or clinical decision-making — Mosi records data, it
  never diagnoses
- No CRDT-based conflict resolution — conflicts use last-write-wins by
  timestamp, with a content-hash tiebreaker, and are flagged for a
  supervisor to review rather than resolved automatically
- No WebRTC, SMS, or USSD channels
- No native mobile apps (the PWA is the only mobile delivery mechanism)
- Not intended for real patient data or production clinical use

### Production hardening already in place

Beyond the core offline/sync demo, the backend and deployment config include
real production-oriented hardening, not just prototype defaults - see
[Security & data isolation](#security--data-isolation) above for the
authorization/auth-specific items. Additionally:

- No hardcoded/fallback secrets — the server refuses to start without a real
  `JWT_SECRET`; `docker-compose.yml` requires `JWT_SECRET`/`POSTGRES_PASSWORD`
  from a root `.env` rather than baking in a value.
- Structured JSON logging (`pino`) with request-ID-correlated request
  logging, and `/api/health/live` + `/api/health/ready` for orchestrator
  liveness/readiness checks (the latter verifies real database
  connectivity, not just that the process is up).
- A real compiled production build for the backend (`npm run build` → `node
  dist/src/app.js`, not `tsx` interpreting TypeScript directly), run as a
  non-root user in a Node 24 container; an nginx container (not
  `vite preview`) for the frontend.
- Reseeding demo data is opt-in (`SEED_ON_START`), never automatic — a
  production restart cannot wipe real patients/visits/audit history.
- A CI workflow (`.github/workflows/ci.yml`) running typecheck/test/build for
  both packages on every push/PR.
- Backend integration tests (`backend/src/__tests__/`) covering
  authentication (bad/expired/wrong-issuer tokens, lockout, deactivation),
  clinic-scoped authorization, anti-spoofing, rate limiting, and the health
  checks, on top of the existing unit tests - both migrations
  (fresh-database and existing-populated-database upgrade paths) and the
  full Docker stack have been verified against a real PostgreSQL instance,
  not just mocks.

### Known limitations for a real (non-demo) deployment

- **No formal OpenAPI/Swagger spec** — the [API surface](#api-surface) table
  above and the route source under `backend/src/routes/` are the
  documentation for now.
- **Reporting is limited to CSV exports** of the patient list, visit list
  and CHW activity (supervisor screens) - there is no report builder.
- **Not load-tested at real-world scale** — verified functionally against
  the seeded demo dataset (75 patients / ~190 visits across 3 clinics), not
  against a pilot-realistic volume (thousands of patients). Indexes exist on
  the obvious query patterns (`clinic_id`, `patient_id`, `chw_id`,
  `visit_date`, `deleted_at`, sync/audit/conflict lookup columns), but
  nobody has measured query latency at scale.
- **No incremental/delta sync** — `GET /api/patients` and `GET /api/visits`
  return every record (up to a bounded safety cap, now with real
  `page`/`limit` support too), matching what the offline cache-refresh
  currently expects. That's fine at demo/small-pilot scale; a much larger
  patient population would need cursor-based pull-since-last-sync instead of
  a full pull every refresh.
- **Offline data on the device is not encrypted** - see
  [Device privacy & signing out](#device-privacy--signing-out).
- **Not tested with specialist screen readers** - see
  [Accessibility testing](#accessibility-testing).
- **Sync progress is batch-level** - the API returns one answer per batch,
  so the app reports counts before and after, not per-record progress.
- **No formal backup/restore runbook** — the application itself never runs
  destructive startup behavior against real data (see `SEED_ON_START`
  above), but backup frequency/retention/restore procedure for the
  PostgreSQL database is a deployment-environment decision (e.g. a managed
  Postgres provider's automated backups) that hasn't been documented here
  yet.
- **No legal/compliance sign-off** — see the data-privacy notice at the top
  of this README.
