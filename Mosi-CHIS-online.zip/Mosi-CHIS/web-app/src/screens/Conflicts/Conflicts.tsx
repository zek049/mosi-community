import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLiveQuery } from "dexie-react-hooks";
import { CheckCircle2, User, Stethoscope } from "lucide-react";
import * as api from "../../services/api";
import type { SyncConflict } from "../../services/api";
import { db } from "../../db/indexedDb";
import { usePageTitle } from "../../hooks/usePageTitle";
import { formatDate } from "../../utils/formatDate";
import { PageHeader } from "../../components/ui/PageHeader";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { cn } from "../../lib/utils";

type Resolution = "KEEP_SERVER" | "APPLY_INCOMING";

const DATE_FIELDS = new Set(["date_of_birth", "visit_date"]);

// Human labels, and which fields to show per record type - supervisors
// never have to read raw JSON.
const PATIENT_FIELDS: Array<[string, string]> = [
  ["first_name", "First name"],
  ["last_name", "Last name"],
  ["village", "Village"],
  ["gender", "Gender"],
  ["phone_number", "Phone number"],
  ["date_of_birth", "Date of birth"],
];

const VISIT_FIELDS: Array<[string, string]> = [
  ["visit_type", "Visit type"],
  ["visit_date", "Visit date"],
  ["weight", "Weight (kg)"],
  ["height", "Height (cm)"],
  ["blood_pressure", "Blood pressure"],
  ["notes", "Notes"],
];

function fieldValue(value: unknown, key: string): string {
  if (value === null || value === undefined || value === "") return "-";
  if (key === "gender") return value === "F" ? "Female" : value === "M" ? "Male" : String(value);
  if (DATE_FIELDS.has(key) && typeof value === "string") return formatDate(value);
  return String(value);
}

function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString(undefined, { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" });
}

function useRecordLabel(conflict: SyncConflict): string {
  const incoming = conflict.incoming_version;
  const server = conflict.server_version;
  const patientRef = String(incoming.patient_id ?? server.patient_id ?? "");
  // A visit conflict only carries the patient's internal id - look up their
  // name from this device's cache so the supervisor knows who it's about.
  const visitPatient = useLiveQuery(
    async () => (conflict.record_type === "visit" && patientRef ? await db.patients.get(patientRef) : undefined),
    [conflict.record_type, patientRef],
  );
  if (conflict.record_type === "patient") {
    const name = [server.first_name ?? incoming.first_name, server.last_name ?? incoming.last_name].filter(Boolean).join(" ");
    return name || "Patient record";
  }
  const type = String(server.visit_type ?? incoming.visit_type ?? "");
  const who = visitPatient ? ` for ${visitPatient.first_name} ${visitPatient.last_name}` : "";
  return `${type ? `${type} visit` : "Visit"}${who}`;
}

// A native <dialog> opened with showModal(): the browser supplies the focus
// trap, Escape-to-close and the inert background - no extra dependency.
function ConfirmDialog({
  open,
  title,
  body,
  confirmLabel,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  body: string;
  confirmLabel: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      aria-labelledby="confirm-title"
      aria-describedby="confirm-body"
      onCancel={(e) => {
        e.preventDefault();
        onCancel();
      }}
      className="w-[calc(100%-2rem)] max-w-md rounded-2xl p-0 shadow-xl backdrop:bg-stone-900/50"
    >
      <div className="space-y-4 p-6">
        <h2 id="confirm-title" className="text-lg font-semibold text-stone-900">
          {title}
        </h2>
        <p id="confirm-body" className="text-sm text-stone-700">
          {body}
        </p>
        <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
          <Button type="button" variant="secondary" size="lg" onClick={onCancel} autoFocus>
            Cancel
          </Button>
          <Button type="button" size="lg" onClick={onConfirm}>
            {confirmLabel}
          </Button>
        </div>
      </div>
    </dialog>
  );
}

function VersionColumn({
  heading,
  when,
  fields,
  values,
  compare,
  highlight,
}: {
  heading: string;
  when: string;
  fields: Array<[string, string]>;
  values: Record<string, unknown>;
  compare: Record<string, unknown>;
  highlight: string;
}) {
  return (
    <section aria-label={heading} className={cn("overflow-hidden rounded-lg border", highlight === "amber" ? "border-amber-200" : "border-stone-200")}>
      <div className={cn("border-b px-3 py-2", highlight === "amber" ? "border-amber-200 bg-amber-50" : "border-stone-200 bg-stone-50")}>
        <h3 className="text-sm font-semibold text-stone-900">{heading}</h3>
        <p className="text-xs text-stone-600">Changed {formatDateTime(when)}</p>
      </div>
      <dl className="divide-y divide-stone-100">
        {fields.map(([key, label]) => {
          const value = fieldValue(values[key], key);
          const changed = value !== fieldValue(compare[key], key);
          return (
            <div key={key} className={cn("flex items-start justify-between gap-3 px-3 py-2 text-sm", changed && "bg-amber-50/60")}>
              <dt className="shrink-0 text-stone-600">
                {label}
                {changed && (
                  <span className="ml-1.5 rounded bg-amber-100 px-1 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-amber-900">
                    Changed
                  </span>
                )}
              </dt>
              <dd className={cn("min-w-0 break-words text-right", changed ? "font-semibold text-stone-900" : "text-stone-700")}>{value}</dd>
            </div>
          );
        })}
      </dl>
    </section>
  );
}

function ConflictCard({
  conflict,
  chwName,
  onResolved,
}: {
  conflict: SyncConflict;
  chwName: (id: string | null) => string;
  onResolved: (message: string) => void;
}) {
  const queryClient = useQueryClient();
  const label = useRecordLabel(conflict);
  const [pending, setPending] = useState<Resolution | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);

  const resolveMutation = useMutation({
    mutationFn: (resolution: Resolution) => api.resolveConflict(conflict.id, resolution),
    onSuccess: (_data, resolution) => {
      onResolved(
        resolution === "KEEP_SERVER"
          ? `Conflict resolved. ${label}: the server version was kept.`
          : `Conflict resolved. ${label}: the CHW's change was applied.`,
      );
      void queryClient.invalidateQueries({ queryKey: ["conflicts"] });
      void queryClient.invalidateQueries({ queryKey: ["dashboardStats"] });
    },
    onError: (error) => {
      if (error instanceof api.ApiError && error.status === 409) void queryClient.invalidateQueries({ queryKey: ["conflicts"] });
    },
  });

  const fields = conflict.record_type === "patient" ? PATIENT_FIELDS : VISIT_FIELDS;
  const server = conflict.server_version;
  const incoming = conflict.incoming_version;
  const changedLabels = fields.filter(([key]) => fieldValue(server[key], key) !== fieldValue(incoming[key], key)).map(([, l]) => l);
  const Icon = conflict.record_type === "patient" ? User : Stethoscope;
  const who = chwName(conflict.detected_by);

  function ask(resolution: Resolution, trigger: HTMLButtonElement) {
    triggerRef.current = trigger;
    setPending(resolution);
  }

  function closeDialog() {
    setPending(null);
    // Put focus back where the supervisor was.
    window.setTimeout(() => triggerRef.current?.focus(), 0);
  }

  function confirm() {
    if (!pending) return;
    const resolution = pending;
    setPending(null);
    resolveMutation.mutate(resolution);
  }

  return (
    <Card className="space-y-5 p-5 sm:p-6">
      <div className="flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-100 text-amber-800">
          <Icon className="h-5 w-5" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <h2 className="text-base font-semibold text-stone-900">{label}</h2>
          <p className="mt-0.5 text-sm text-stone-600">
            {who} sent a change on {formatDateTime(conflict.detected_at)}, but the server copy had also changed.
          </p>
          {changedLabels.length > 0 && (
            <p className="mt-1 text-sm text-stone-700">
              <span className="font-medium">Different:</span> {changedLabels.join(", ")}
            </p>
          )}
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <VersionColumn
          heading="On the server now"
          when={conflict.server_timestamp}
          fields={fields}
          values={server}
          compare={incoming}
          highlight="stone"
        />
        <VersionColumn
          heading={`Change from ${who}`}
          when={conflict.incoming_timestamp}
          fields={fields}
          values={incoming}
          compare={server}
          highlight="amber"
        />
      </div>

      {resolveMutation.isError && (
        <p role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
          {resolveMutation.error instanceof api.ApiError && resolveMutation.error.status === 409
            ? "Someone else already resolved this conflict. The list has been refreshed."
            : "Couldn't save your decision. Check your connection and try again."}
        </p>
      )}

      <div className="flex flex-col gap-3 sm:flex-row">
        <Button
          variant="secondary"
          size="lg"
          onClick={(e) => ask("KEEP_SERVER", e.currentTarget)}
          disabled={resolveMutation.isPending}
        >
          {resolveMutation.isPending && resolveMutation.variables === "KEEP_SERVER" ? "Saving…" : "Keep server version"}
        </Button>
        <Button size="lg" onClick={(e) => ask("APPLY_INCOMING", e.currentTarget)} disabled={resolveMutation.isPending}>
          {resolveMutation.isPending && resolveMutation.variables === "APPLY_INCOMING" ? "Saving…" : "Use the CHW's change"}
        </Button>
      </div>

      <ConfirmDialog
        open={pending !== null}
        title={pending === "APPLY_INCOMING" ? "Use the CHW's change?" : "Keep the server version?"}
        body={
          pending === "APPLY_INCOMING"
            ? `The server copy of "${label}" will be replaced with the change from ${who}. The current server values will be overwritten.`
            : `The server copy of "${label}" stays as it is. The change from ${who} will be discarded.`
        }
        confirmLabel={pending === "APPLY_INCOMING" ? "Replace server version" : "Keep server version"}
        onConfirm={confirm}
        onCancel={closeDialog}
      />
    </Card>
  );
}

function Conflicts() {
  usePageTitle("Conflicts");
  const conflictsQuery = useQuery({ queryKey: ["conflicts"], queryFn: () => api.getConflicts("open") });
  const chwsQuery = useQuery({ queryKey: ["chws"], queryFn: api.getChws });
  const [resolvedMessage, setResolvedMessage] = useState<string | null>(null);
  const bannerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (resolvedMessage) bannerRef.current?.focus();
  }, [resolvedMessage]);

  function chwName(id: string | null): string {
    if (!id) return "A CHW";
    return chwsQuery.data?.find((c) => c.chw_id === id)?.full_name ?? "A CHW";
  }

  const conflicts = conflictsQuery.data;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Conflicts"
        description="A record was changed on a CHW's device and on the server at the same time. Choose which version to keep."
      />

      {resolvedMessage && (
        <div
          ref={bannerRef}
          tabIndex={-1}
          role="status"
          className="flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 outline-none focus-visible:ring-2 focus-visible:ring-emerald-700"
        >
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-800" aria-hidden="true" />
          <p className="text-sm text-emerald-900">{resolvedMessage}</p>
        </div>
      )}

      {conflictsQuery.isLoading && <p className="text-sm text-stone-500">Loading…</p>}

      {conflictsQuery.isError && (
        <div role="alert" className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3">
          <p className="text-sm text-red-800">Couldn't load conflicts from the server.</p>
          <Button variant="secondary" onClick={() => void conflictsQuery.refetch()}>
            Try again
          </Button>
        </div>
      )}

      {conflicts && conflicts.length === 0 && (
        <Card className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-800">
              <CheckCircle2 className="h-5 w-5" aria-hidden="true" />
            </span>
            <div>
              <h2 className="text-base font-semibold text-stone-900">All clear</h2>
              <p className="text-sm text-stone-600">No conflicts need your attention.</p>
            </div>
          </div>
          <Button asChild variant="secondary">
            <Link to="/supervisor">Back to dashboard</Link>
          </Button>
        </Card>
      )}

      {conflicts && conflicts.length > 0 && (
        <div className="space-y-5">
          <p className="text-sm text-stone-600">
            {conflicts.length} {conflicts.length === 1 ? "conflict needs" : "conflicts need"} a decision.
          </p>
          {conflicts.map((conflict) => (
            <ConflictCard key={conflict.id} conflict={conflict} chwName={chwName} onResolved={setResolvedMessage} />
          ))}
        </div>
      )}
    </div>
  );
}

export default Conflicts;
