import { Router } from "express";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { requireStringParam } from "../utils/params";
import { parsePageParams, buildPagination } from "../utils/pagination";
import { parseBody, conflictResolutionSchema } from "../validation/schemas";
import { writeAuditLog } from "../utils/audit";
import { canAccessClinic, clinicScope } from "../middleware/authz";
import { conflictIdsInClinic, recordClinic } from "../utils/recordScope";

// Mounted supervisor/admin-only in app.ts. A supervisor sees and resolves
// only conflicts about records in their own clinic (middleware/authz.ts).
const router = Router();

router.get("/", async (req, res) => {
  const { status } = req.query as Record<string, string | undefined>;
  const pageParams = parsePageParams(req);
  const scope = clinicScope(req.user!);
  const where = {
    ...(status ? { status } : {}),
    ...(scope ? { id: { in: await conflictIdsInClinic(scope) } } : {}),
  };

  const [conflicts, total] = await Promise.all([
    prisma.syncConflict.findMany({
      where,
      orderBy: { detected_at: "desc" },
      skip: pageParams.skip,
      take: pageParams.take,
    }),
    prisma.syncConflict.count({ where }),
  ]);

  res.json({ success: true, data: conflicts, pagination: buildPagination(pageParams, total) });
});

function isoToDate(value: unknown): Date | undefined {
  return typeof value === "string" ? new Date(value) : undefined;
}

// Applying "incoming" means writing the conflict's stored incoming_version
// snapshot onto the real patient/visit row - the same content that would
// have been applied at sync time had it not collided with a same-timestamp
// edit already on the server.
async function applyIncomingVersion(conflict: { record_type: string; record_id: string; incoming_version: unknown; incoming_timestamp: Date }) {
  const content = conflict.incoming_version as Record<string, unknown>;

  if (conflict.record_type === "patient") {
    await prisma.patient.update({
      where: { id: conflict.record_id },
      data: {
        first_name: content.first_name as string,
        last_name: content.last_name as string,
        date_of_birth: isoToDate(content.date_of_birth),
        gender: content.gender as "M" | "F",
        village: content.village as string,
        phone_number: (content.phone_number as string | null) ?? null,
        updated_at: conflict.incoming_timestamp,
      },
    });
    return;
  }

  if (conflict.record_type === "visit") {
    await prisma.visit.update({
      where: { id: conflict.record_id },
      data: {
        visit_date: isoToDate(content.visit_date),
        visit_type: content.visit_type as string,
        weight: (content.weight as number | null) ?? null,
        height: (content.height as number | null) ?? null,
        blood_pressure: (content.blood_pressure as string | null) ?? null,
        notes: (content.notes as string | null) ?? null,
        updated_at: conflict.incoming_timestamp,
      },
    });
    return;
  }

  throw new AppError(500, `Unknown conflict record_type "${conflict.record_type}"`);
}

router.post("/:id/resolve", async (req, res) => {
  const idParam = requireStringParam(req, "id");
  const id = Number(idParam);
  if (!Number.isInteger(id)) {
    throw new AppError(400, "id must be an integer");
  }

  const { resolution } = parseBody(conflictResolutionSchema, req.body ?? {});

  const conflict = await prisma.syncConflict.findUnique({ where: { id } });
  // Another clinic's conflict looks the same as a missing one.
  const clinicId = conflict ? await recordClinic(conflict.record_type, conflict.record_id) : null;
  if (!conflict || (clinicScope(req.user!) && (!clinicId || !canAccessClinic(req.user!, clinicId)))) {
    throw new AppError(404, "Conflict not found");
  }
  if (conflict.status !== "open") {
    throw new AppError(409, "This conflict has already been resolved");
  }

  if (resolution === "APPLY_INCOMING") {
    await applyIncomingVersion(conflict);
  }
  // KEEP_SERVER: the record already reflects the server version - nothing
  // to change there, only the conflict's own status.

  const resolved = await prisma.syncConflict.update({
    where: { id },
    data: {
      status: "resolved",
      resolution,
      resolved_by: req.user!.chwId,
      resolved_at: new Date(),
    },
  });

  // The conflict row is never deleted, and this audit entry is a second,
  // independent record of the resolution - "a resolved conflict must never
  // silently disappear from the audit trail" (section 28).
  await writeAuditLog({
    actor: req.user,
    action: "CONFLICT_RESOLVED",
    resourceType: conflict.record_type,
    resourceId: conflict.record_id,
    requestId: req.requestId,
    clinicId,
    metadata: { conflict_id: id, resolution },
  });

  res.json({ success: true, data: resolved });
});

export default router;
