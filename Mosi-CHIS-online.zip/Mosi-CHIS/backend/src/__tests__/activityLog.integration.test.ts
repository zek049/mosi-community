import { beforeEach, describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  process.env.JWT_SECRET = "test-secret-for-integration-tests";
});

const m = vi.hoisted(() => {
  const fns: Record<string, ReturnType<typeof vi.fn>> = {};
  const fn = (name: string) => (fns[name] ??= vi.fn());
  return { fns, fn };
});

vi.mock("../db", () => {
  const delegate = (model: string) => new Proxy({}, { get: (_t, method: string) => m.fn(`${model}.${method}`) });
  return {
    prisma: {
      chw: delegate("chw"),
      patient: delegate("patient"),
      visit: delegate("visit"),
      clinic: delegate("clinic"),
      auditLog: delegate("auditLog"),
      accountRequest: delegate("accountRequest"),
      $queryRaw: m.fn("$queryRaw"),
      $transaction: m.fn("$transaction"),
    },
  };
});

import request from "supertest";
import app from "../app";
import { signSessionToken } from "../middleware/auth";
import { writeAuditLog } from "../utils/audit";
import { loginLimiter } from "../middleware/rateLimit";
import bcrypt from "bcryptjs";

const MBARE = "clinic-mbare";
const HQ = "clinic-hq";
const accounts: Record<string, object> = {
  SUP001: { chw_id: "SUP001", role: "ADMIN", clinic_id: HQ, status: "active", locked_until: null, must_change_pin: false },
  SUP002: { chw_id: "SUP002", role: "SUPERVISOR", clinic_id: MBARE, status: "active", locked_until: null, must_change_pin: false },
  CHW001: { chw_id: "CHW001", role: "CHW", clinic_id: MBARE, status: "active", locked_until: null, must_change_pin: false },
};
const auth = (chwId: string) => ({ Authorization: `Bearer ${signSessionToken({ chwId, role: "SUPERVISOR", fullName: chwId })}` });
const written = () => m.fn("auditLog.create").mock.calls.map((c) => c[0].data);

beforeEach(() => {
  for (const f of Object.values(m.fns)) f.mockReset();
  m.fn("chw.findUnique").mockImplementation(async ({ where }: { where: { chw_id: string } }) => accounts[where.chw_id] ?? null);
  m.fn("chw.findMany").mockResolvedValue([]);
  m.fn("clinic.findMany").mockResolvedValue([]);
  m.fn("auditLog.create").mockResolvedValue({});
  m.fn("auditLog.findMany").mockResolvedValue([]);
  m.fn("auditLog.count").mockResolvedValue(0);
  m.fn("accountRequest.findFirst").mockResolvedValue(null);
});

describe("which clinic an entry belongs to", () => {
  it("explicit clinic, else metadata.clinic_id, else the actor's clinic, else none", async () => {
    await writeAuditLog({ actor: { chwId: "SUP001", role: "ADMIN", clinicId: HQ }, action: "CHW_UPDATED", clinicId: MBARE });
    await writeAuditLog({ actor: { chwId: "SUP001", role: "ADMIN", clinicId: HQ }, action: "RECORD_CONFIRMED", metadata: { clinic_id: MBARE } });
    await writeAuditLog({ actor: { chwId: "CHW001", role: "CHW", clinicId: MBARE }, action: "SYNC_STARTED" });
    await writeAuditLog({ action: "LOGIN_FAILURE", resourceId: "NOPE" });
    expect(written().map((d) => d.clinic_id)).toEqual([MBARE, MBARE, MBARE, null]);
  });

  it("an administrator editing a Mbare patient is Mbare activity", async () => {
    m.fn("patient.findUnique").mockResolvedValueOnce({ id: "p1", clinic_id: MBARE, deleted_at: null, patient_id: "MBR-1" }).mockResolvedValue(null);
    m.fn("patient.update").mockResolvedValue({ id: "p1", clinic_id: MBARE });
    const res = await request(app).put("/api/patients/p1").set(auth("SUP001")).send({ village: "Mbare" });
    expect(res.status).toBe(200);
    expect(written().find((d) => d.action === "PATIENT_UPDATED")).toMatchObject({ actor_id: "SUP001", clinic_id: MBARE });
  });

  it("sign-in: a known account's failure is tagged with its clinic; an unknown ID has none", async () => {
    loginLimiter.resetKey("::ffff:127.0.0.1");
    m.fn("chw.findUnique").mockResolvedValue({ ...accounts.CHW001, pin_hash: bcrypt.hashSync("1234", 4), failed_login_count: 0, full_name: "Jane" });
    m.fn("chw.update").mockResolvedValue({});
    await request(app).post("/api/auth/login").send({ chw_id: "CHW001", pin: "9999" });
    m.fn("chw.findUnique").mockResolvedValue(null);
    await request(app).post("/api/auth/login").send({ chw_id: "NOPE01", pin: "9999" });
    const failures = written().filter((d) => d.action === "LOGIN_FAILURE");
    expect(failures.map((d) => [d.resource_id, d.clinic_id])).toEqual([["CHW001", MBARE], ["NOPE01", null]]);
    expect(JSON.stringify(failures)).not.toContain("9999");
  });
});

describe("GET /api/audit-logs (activity log)", () => {
  it("401 without a session; 403 for a CHW", async () => {
    expect((await request(app).get("/api/audit-logs")).status).toBe(401);
    expect((await request(app).get("/api/audit-logs").set(auth("CHW001"))).status).toBe(403);
  });

  it("supervisor: own clinic's entries, plus older untagged entries by own clinic's accounts", async () => {
    m.fn("chw.findMany").mockResolvedValue([{ chw_id: "SUP002" }, { chw_id: "CHW001" }]);
    await request(app).get("/api/audit-logs").set(auth("SUP002"));
    const where = m.fn("auditLog.findMany").mock.calls[0][0].where;
    expect(where.AND[0]).toEqual({ OR: [{ clinic_id: MBARE }, { clinic_id: null, actor_id: { in: ["SUP002", "CHW001"] } }] });
  });

  it("administrator: no clinic limit", async () => {
    await request(app).get("/api/audit-logs").set(auth("SUP001"));
    expect(m.fn("auditLog.findMany").mock.calls[0][0].where.AND[0]).toEqual({});
  });

  it("filters by date range, several actions and a person; newest first", async () => {
    await request(app).get("/api/audit-logs?from=2026-10-01T00:00:00%2B02:00&to=2026-10-06T23:59:59.999%2B02:00&action=RECORD_CONFIRMED,RECORD_FLAGGED&actor_id=SUP002").set(auth("SUP001"));
    const call = m.fn("auditLog.findMany").mock.calls[0][0];
    expect(call.where.AND).toContainEqual({ created_at: { gte: new Date("2026-09-30T22:00:00.000Z"), lte: new Date("2026-10-06T21:59:59.999Z") } });
    expect(call.where.AND).toContainEqual({ action: { in: ["RECORD_CONFIRMED", "RECORD_FLAGGED"] } });
    expect(call.where.AND).toContainEqual({ actor_id: "SUP002" });
    expect(call.orderBy).toEqual([{ created_at: "desc" }, { id: "desc" }]);
  });

  it.each([["from=yesterday"], ["to=2026-13-45T00:00:00Z"], ["from=2026-10-06T00:00:00Z&to=2026-10-01T00:00:00Z"]])("bad dates -> 400 (%s)", async (q) => {
    expect((await request(app).get(`/api/audit-logs?${q}`).set(auth("SUP001"))).status).toBe(400);
  });

  it("adds the person's and clinic's names; paginates", async () => {
    m.fn("auditLog.findMany").mockResolvedValue([{ id: 1, actor_id: "SUP002", clinic_id: MBARE, action: "RECORD_CONFIRMED", created_at: new Date() }]);
    m.fn("auditLog.count").mockResolvedValue(120);
    m.fn("chw.findMany").mockResolvedValue([{ chw_id: "SUP002", full_name: "Farai Mupfumi" }]);
    m.fn("clinic.findMany").mockResolvedValue([{ id: MBARE, name: "Mbare Clinic" }]);
    const res = await request(app).get("/api/audit-logs?page=2&limit=50").set(auth("SUP001"));
    expect(res.body.data[0]).toMatchObject({ actor_name: "Farai Mupfumi", clinic_name: "Mbare Clinic" });
    expect(res.body.pagination).toMatchObject({ page: 2, limit: 50, total: 120, totalPages: 3 });
    expect(m.fn("auditLog.findMany").mock.calls[0][0]).toMatchObject({ skip: 50, take: 50 });
  });
});
