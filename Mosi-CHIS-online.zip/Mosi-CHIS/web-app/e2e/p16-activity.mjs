// Feature 11 - Activity log (audit_log + clinic). Production build, real backend + database.
import { chromium } from "playwright";
import { readFileSync } from "node:fs";
import { execSync } from "node:child_process";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const WRONG_PIN = "9876";
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
async function axe(page, label) {
  await page.waitForTimeout(400);
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}: ${x.nodes.map((n) => n.target.join(" ")).slice(0, 3).join(" | ")}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
const sql = (q) => execSync(`docker exec mosi-postgres psql -U mosi -d mosi -At -c "${q.replace(/"/g, '\\"')}"`).toString().trim();
function track(page, who, allow = []) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => { if (m.type() === "error" && !/ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(m.text()) && !allow.some((r) => r.test(m.text()))) errors.push(`${who}: ${m.text()}`); });
}
async function login(page, id, pin = "1234") {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => document.body.innerText.includes("Online"));
  await page.fill("#chwId", id); await page.fill("#pin", pin); await page.press("#pin", "Enter");
}
const api = (page, path, init) => page.evaluate(async ([API, path, init]) => { const r = await fetch(`${API}${path}`, { credentials: "include", headers: { "Content-Type": "application/json" }, ...init }); return { status: r.status, body: await r.json().catch(() => null) }; }, [API, path, init]);
const noHScroll = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);
const MBARE = sql("select id from clinics where code='MBR'"), HAT = sql("select id from clinics where code='HTC'");
const before = Number(sql("select count(*) from audit_log where clinic_id is null and created_at < now() - interval '1 minute'"));

const browser = await chromium.launch();

// Activity to look for: a Hatcliffe sign-in, and a failed sign-in for CHW001 (Mbare).
{
  const c = await browser.newContext(); const p = await c.newPage();
  await p.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await p.evaluate(async ([API, pin]) => {
    await fetch(`${API}/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chw_id: "CHW002", pin: "1234" }) });
    await fetch(`${API}/auth/login`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chw_id: "CHW001", pin }) });
  }, [API, WRONG_PIN]);
  await c.close();
}
report("Database: new entries carry a clinic (CHW002 sign-in -> Hatcliffe, CHW001 failed sign-in -> Mbare)",
  sql(`select clinic_id from audit_log where action='LOGIN_SUCCESS' and resource_id='CHW002' order by id desc limit 1`) === HAT &&
  sql(`select clinic_id from audit_log where action='LOGIN_FAILURE' and resource_id='CHW001' order by id desc limit 1`) === MBARE);
sql("update chws set failed_login_count=0 where chw_id='CHW001'");

// ---------- Mbare supervisor ----------
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
  const sp = await ctx.newPage();
  track(sp, "mbare-sup");
  await login(sp, "SUP002");
  await sp.waitForURL("**/supervisor");
  await sp.click('aside a[href="/supervisor/activity"]');
  await sp.waitForSelector("h1:has-text('Activity log')");
  await sp.waitForSelector("ol li", { timeout: 8000 });
  report("Header says it's this clinic's activity", (await sp.locator("main").innerText()).includes("Who did what in Mbare Clinic"));
  const first = await sp.locator("ol li").first().innerText();
  report("Newest first: own sign-in at the top ('Farai Mupfumi (SUP002) · Signed in')", first.includes("Farai Mupfumi (SUP002) · Signed in"), first);
  const all = await api(sp, "/audit-logs?limit=2000");
  const mbareActors = new Set(["SUP002", "CHW001"]);
  const outside = (all.body?.data ?? []).filter((e) => !(e.clinic_id === MBARE || (e.clinic_id === null && mbareActors.has(e.actor_id))));
  report("Every entry is Mbare's (tagged Mbare, or an older untagged entry by a Mbare account)", all.status === 200 && outside.length === 0 && all.body.data.length > 0, { n: all.body?.data?.length, outside: outside.slice(0, 3).map((e) => [e.action, e.actor_id, e.clinic_id]) });
  report("The Hatcliffe sign-in is NOT visible", (all.body?.data ?? []).every((e) => !(e.action === "LOGIN_SUCCESS" && e.resource_id === "CHW002")));
  await axe(sp, "Activity log (supervisor)");

  // Filters
  await sp.click("#activity_action"); await sp.click('[role="option"]:has-text("Sign-ins and PINs")');
  await sp.waitForTimeout(800);
  const rows = await sp.locator("ol li").allInnerTexts();
  report("Filter 'Sign-ins and PINs': only sign-in/PIN entries", rows.length > 0 && rows.every((r) => /Signed in|Sign-in failed|PIN|locked/.test(r)), rows.slice(0, 3));
  const failed = rows.find((r) => r.includes("Sign-in failed") && r.includes("CHW001"));
  report("Failed sign-in shows the reason in words ('Reason: wrong PIN')", !!failed && failed.includes("Reason: wrong PIN"), failed);
  report("The attempted PIN never appears", !(await sp.locator("body").innerText()).includes(WRONG_PIN) && !JSON.stringify(all.body).includes(WRONG_PIN));
  await sp.click("#activity_actor"); await sp.click('[role="option"]:has-text("Farai Mupfumi (SUP002)")');
  await sp.waitForTimeout(800);
  const mine = await sp.locator("ol li").allInnerTexts();
  report("Filter by person: only that person's entries", mine.length > 0 && mine.every((r) => r.includes("(SUP002)")));
  const today = await sp.evaluate(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; });
  const tomorrow = await sp.evaluate(() => { const d = new Date(Date.now() + 86400000); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; });
  await sp.fill("#activity_from", today); await sp.fill("#activity_to", today);
  await sp.waitForTimeout(800);
  report("Date range = today: today's sign-in still listed", (await sp.locator("ol li").count()) > 0);
  await sp.fill("#activity_from", tomorrow); await sp.fill("#activity_to", "");
  await sp.waitForSelector("text=Nothing matches these filters", { timeout: 5000 }).catch(() => {});
  report("From tomorrow: empty state 'Nothing matches these filters'", await sp.isVisible("text=Nothing matches these filters"));
  await sp.fill("#activity_to", today);
  report("Start after end: clear message", await sp.isVisible("text=The start date is after the end date."));
  await axe(sp, "Activity log with filters + date error");
  await sp.click('button:has-text("Clear filters")');
  await sp.waitForTimeout(800);
  report("Clear filters restores the full list", (await sp.locator("ol li").count()) > 1 && !(await sp.isVisible('button:has-text("Clear filters")')));
  await sp.setViewportSize({ width: 360, height: 800 });
  await sp.waitForTimeout(500);
  report("No horizontal scroll at 360px", await noHScroll(sp));
  await ctx.close();
}

// ---------- Administrator ----------
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
  const ap = await ctx.newPage();
  track(ap, "admin");
  await login(ap, "SUP001");
  await ap.waitForURL("**/supervisor");
  await ap.goto(`${BASE}/supervisor/activity`, { waitUntil: "networkidle" });
  await ap.waitForSelector("ol li");
  const text = await ap.locator("main").innerText();
  report("Admin: 'across every clinic'", text.includes("across every clinic"));
  const hatEntry = await api(ap, "/audit-logs?actor_id=CHW002&action=LOGIN_SUCCESS&limit=1");
  report("Admin sees the Hatcliffe sign-in, with its clinic name", hatEntry.body?.data?.[0]?.clinic_name === "Hatcliffe Clinic", hatEntry.body?.data?.[0]);
  report("Admin rows show each entry's clinic", /Mbare Clinic|Harare Provincial Health Office|Hatcliffe Clinic/.test(text));
  const total = Number(text.match(/(\d+) entries/)?.[1] ?? 0);
  report("Admin total > 50 (pagination in play)", total > 50, total);
  const firstPage1 = await ap.locator("ol li").first().innerText();
  await ap.getByRole("button", { name: /next page/i }).click();
  await ap.waitForTimeout(1000);
  const firstPage2 = await ap.locator("ol li").first().innerText();
  report("Next page shows older entries", firstPage1 !== firstPage2 && (await ap.locator("ol li").count()) > 0);
  await axe(ap, "Activity log (admin, page 2)");
  await ctx.close();
}

// ---------- CHW: no access ----------
{
  const ctx = await browser.newContext();
  const cp = await ctx.newPage();
  track(cp, "chw", [/status of 403/]);
  await login(cp, "CHW001");
  await cp.waitForURL("**/chw");
  await cp.goto(`${BASE}/supervisor/activity`, { waitUntil: "networkidle" });
  report("CHW typing /supervisor/activity is sent home", new URL(cp.url()).pathname === "/chw");
  report("CHW calling the API -> 403", (await api(cp, "/audit-logs")).status === 403);
  await ctx.close();
}

report("Older audit entries untouched (no backfill): untagged count not reduced", Number(sql("select count(*) from audit_log where clinic_id is null and created_at < now() - interval '1 minute'")) >= before);
report("No page errors or console errors", errors.length === 0, errors.length ? errors.slice(0, 5) : undefined);
console.log(`\n${pass} passed, ${fail} failed`);
await browser.close();
process.exit(fail ? 1 : 0);
