import type { Response } from "express";

// httpOnly so injected/XSS'd JavaScript can never read the session token,
// even in the origin's own page (the actual risk Phase 5 of the security
// review was about) - localStorage was readable by any script running on
// the page, which is the whole class of attack this closes off.
export const SESSION_COOKIE_NAME = "mosi_session";
const MAX_AGE_MS = 12 * 60 * 60 * 1000; // matches signSessionToken's expiresIn

// Shared between set and clear - a clearCookie() whose attributes don't
// exactly match the cookie it's trying to overwrite is not guaranteed to
// actually clear it (found via adversarial browser testing against the
// production/Secure-cookie build: clearCookie's default options weren't
// specifying `secure`/`sameSite` at all, and the logout response's Set-
// Cookie header ended up not overwriting the original in that case).
function cookieOptions() {
  return {
    httpOnly: true,
    // Secure requires HTTPS, which local/demo HTTP setups don't have -
    // only enforced once NODE_ENV=production (the real deployment target).
    secure: process.env.NODE_ENV === "production",
    // "lax" is the load-bearing CSRF defense here (see routes/auth.ts's
    // comment on the logout route): a cross-site fetch/XHR/form-POST never
    // attaches a Lax cookie, only a real top-level navigation does. "site"
    // is the registrable domain, not the full origin, so this also already
    // covers the local dev setup (localhost:5173 talking to localhost:4000
    // - different ports, same site).
    sameSite: "lax" as const,
    path: "/",
  };
}

export function setSessionCookie(res: Response, token: string): void {
  res.cookie(SESSION_COOKIE_NAME, token, { ...cookieOptions(), maxAge: MAX_AGE_MS });
}

export function clearSessionCookie(res: Response): void {
  res.clearCookie(SESSION_COOKIE_NAME, cookieOptions());
}
