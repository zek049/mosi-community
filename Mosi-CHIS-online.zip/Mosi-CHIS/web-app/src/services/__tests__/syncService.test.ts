import "fake-indexeddb/auto";
import Dexie from "dexie";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const postSync = vi.hoisted(() => vi.fn());
const getPatients = vi.hoisted(() => vi.fn(async () => []));
const getVisits = vi.hoisted(() => vi.fn(async () => []));
vi.mock("../api", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../api")>();
  return { ...actual, postSync, getPatients, getVisits };
});

import * as store from "../../db/indexedDb";
import { runSync } from "../syncService";
import { NetworkError } from "../api";
import { syncResultMessage } from "../../utils/syncMessages";
import { publishConnectivity, SyncNotAllowedError } from "../connectivity";
import { refreshPatientCache, refreshVisitCache } from "../cacheRefresh";

const ONLINE = { status: "online", isOnline: true, workOffline: false } as const;
const WORK_OFFLINE = { status: "work-offline", isOnline: false, workOffline: true } as const;
const DISCONNECTED = { status: "offline", isOnline: false, workOffline: false } as const;
import type { Patient } from "../../models/patient";

const now = new Date().toISOString();
const patient = (id: string): Patient => ({ id, patient_id: id, first_name: "T", last_name: id, date_of_birth: "1990-01-01", gender: "F", village: "V", phone_number: null, created_at: now, updated_at: now, sync_status: "pending" });

beforeEach(async () => {
  postSync.mockReset();
  getPatients.mockClear();
  getVisits.mockClear();
  // These tests model a connected device unless they say otherwise.
  publishConnectivity({ ...ONLINE });
  store.switchDatabaseTo(null);
  for (const name of await Dexie.getDatabaseNames()) await Dexie.delete(name);
  store.switchDatabaseTo("CHW001");
});
afterEach(() => vi.useRealTimers());

describe("runSync", () => {
  it("zero pending: never contacts the server", async () => {
    const outcome = await runSync();
    expect(outcome.attempted).toBe(0);
    expect(postSync).not.toHaveBeenCalled();
  });

  it("one pending change synced", async () => {
    await store.db.patients.put(patient("p1"));
    postSync.mockResolvedValue({ patients: [{ id: "p1", status: "synced" }], visits: [] });
    const outcome = await runSync();
    expect(outcome).toEqual({ attempted: 1, synced: 1, conflicts: 0, failed: 0 });
    expect((await store.db.patients.get("p1"))?.sync_status).toBe("synced");
    expect(syncResultMessage(outcome)).toBe("1 change synced.");
  });

  it("partial failure: reports the server's per-record verdicts, keeps the rejected one waiting", async () => {
    await store.db.patients.bulkPut([patient("ok"), patient("review"), patient("bad")]);
    postSync.mockResolvedValue({
      patients: [
        { id: "ok", status: "synced" },
        { id: "review", status: "conflict", message: "edited elsewhere" },
        { id: "bad", status: "failed", message: "invalid" },
      ],
      visits: [],
    });
    const outcome = await runSync();
    expect(outcome).toEqual({ attempted: 3, synced: 1, conflicts: 1, failed: 1 });
    expect(syncResultMessage(outcome)).toBe("1 change synced. 1 change needs review. 1 change couldn't sync and is still waiting.");
    expect((await store.db.patients.get("bad"))?.sync_status).toBe("pending");
    expect((await store.db.syncAttempts.get("bad"))?.status).toBe("failed");
    expect((await store.db.syncAttempts.get("review"))?.status).toBe("conflict");
    expect(await store.countPending()).toBe(1);
  });

  it("retry: a previously rejected change is sent again and its failure marker cleared once accepted", async () => {
    await store.db.patients.put(patient("bad"));
    postSync.mockResolvedValueOnce({ patients: [{ id: "bad", status: "failed" }], visits: [] });
    await runSync();
    postSync.mockResolvedValueOnce({ patients: [{ id: "bad", status: "synced" }], visits: [] });
    const second = await runSync();
    expect(postSync.mock.calls[1][0].patients.map((p: Patient) => p.id)).toEqual(["bad"]);
    expect(second.synced).toBe(1);
    expect(await store.db.syncAttempts.get("bad")).toBeUndefined();
  });

  it("a dropped connection is retried with backoff and then succeeds", async () => {
    await store.db.patients.put(patient("p1"));
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout"] });
    postSync.mockRejectedValueOnce(new NetworkError()).mockResolvedValueOnce({ patients: [{ id: "p1", status: "synced" }], visits: [] });
    const pending = runSync();
    await vi.advanceTimersByTimeAsync(5000);
    expect((await pending).synced).toBe(1);
    expect(postSync).toHaveBeenCalledTimes(2);
  });

  it("offline interruption: after all retries it gives up and every record stays safely pending", async () => {
    await store.db.patients.bulkPut([patient("p1"), patient("p2")]);
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout"] });
    postSync.mockRejectedValue(new NetworkError());
    const pending = runSync().catch((e: unknown) => e);
    await vi.advanceTimersByTimeAsync(5000 + 10000 + 20000);
    expect(await pending).toBeInstanceOf(NetworkError);
    expect(postSync).toHaveBeenCalledTimes(4);
    expect(await store.countPending()).toBe(2);
  });
});

describe("sync under forced offline (one connectivity source of truth)", () => {
  it("Work Offline on: runSync never contacts the server and the records stay pending", async () => {
    await store.db.patients.bulkPut([patient("p1"), patient("p2")]);
    publishConnectivity({ ...WORK_OFFLINE });
    await expect(runSync()).rejects.toBeInstanceOf(SyncNotAllowedError);
    expect(postSync).not.toHaveBeenCalled();
    expect(await store.countPending()).toBe(2);
  });

  it("automatically detected offline: same - no server contact", async () => {
    await store.db.patients.put(patient("p1"));
    publishConnectivity({ ...DISCONNECTED });
    await expect(runSync()).rejects.toBeInstanceOf(SyncNotAllowedError);
    expect(postSync).not.toHaveBeenCalled();
  });

  it("Work Offline off again: the same records sync normally", async () => {
    await store.db.patients.put(patient("p1"));
    publishConnectivity({ ...WORK_OFFLINE });
    await expect(runSync()).rejects.toBeInstanceOf(SyncNotAllowedError);
    publishConnectivity({ ...ONLINE });
    postSync.mockResolvedValue({ patients: [{ id: "p1", status: "synced" }], visits: [] });
    expect((await runSync()).synced).toBe(1);
  });

  it("turning Work Offline on during network retries stops further attempts", async () => {
    await store.db.patients.put(patient("p1"));
    vi.useFakeTimers({ toFake: ["setTimeout", "clearTimeout"] });
    postSync.mockRejectedValue(new NetworkError());
    const pending = runSync().catch((e: unknown) => e);
    await vi.advanceTimersByTimeAsync(0);
    expect(postSync).toHaveBeenCalledTimes(1);
    publishConnectivity({ ...WORK_OFFLINE });
    await vi.advanceTimersByTimeAsync(5000);
    expect(await pending).toBeInstanceOf(SyncNotAllowedError);
    expect(postSync).toHaveBeenCalledTimes(1);
    expect(await store.countPending()).toBe(1);
  });

  it("cache refresh makes no requests while not online", async () => {
    publishConnectivity({ ...WORK_OFFLINE });
    await refreshPatientCache();
    await refreshVisitCache();
    expect(getPatients).not.toHaveBeenCalled();
    expect(getVisits).not.toHaveBeenCalled();
    publishConnectivity({ ...ONLINE });
    await refreshPatientCache();
    expect(getPatients).toHaveBeenCalledTimes(1);
  });
});

describe("households in sync", () => {
  it("sends pending households with the batch and applies their results", async () => {
    await store.db.households.put({ id: "h1", household_code: "MBA-7Q2K", village: "Mbare", created_at: now, sync_status: "pending" });
    await store.db.patients.put({ ...patient("p1"), household_id: "h1" });
    postSync.mockResolvedValue({ households: [{ id: "h1", status: "synced" }], patients: [{ id: "p1", status: "synced" }], visits: [] });
    const outcome = await runSync();
    expect(postSync.mock.calls[0][0].households.map((h: { id: string }) => h.id)).toEqual(["h1"]);
    expect(outcome).toMatchObject({ attempted: 2, synced: 2 });
    expect((await store.db.households.get("h1"))?.sync_status).toBe("synced");
  });

  it("omits the households field when there are none (older servers keep working)", async () => {
    await store.db.patients.put(patient("p1"));
    postSync.mockResolvedValue({ patients: [{ id: "p1", status: "synced" }], visits: [] });
    await runSync();
    expect("households" in postSync.mock.calls[0][0]).toBe(false);
  });

  it("a rejected household (e.g. code clash) stays pending with a 'couldn't sync' marker", async () => {
    await store.db.households.put({ id: "h1", household_code: "MBA-7Q2K", village: "Mbare", created_at: now, sync_status: "pending" });
    postSync.mockResolvedValue({ households: [{ id: "h1", status: "failed", message: "code used" }], patients: [], visits: [] });
    await runSync();
    expect((await store.db.households.get("h1"))?.sync_status).toBe("pending");
    expect((await store.db.syncAttempts.get("h1"))?.record_type).toBe("household");
  });
});

describe("household code clash recovery", () => {
  it("a household rejected for a used code gets a new code on the device and stays pending", async () => {
    await store.db.households.put({ id: "h1", household_code: "MBA-7Q2K9X", village: "Mbare", created_at: now, sync_status: "pending" });
    postSync.mockResolvedValue({ households: [{ id: "h1", status: "failed", message: 'Household code "MBA-7Q2K9X" is already used' }], patients: [], visits: [] });
    await runSync();
    const h = await store.db.households.get("h1");
    expect(h?.sync_status).toBe("pending");
    expect(h?.household_code).not.toBe("MBA-7Q2K9X");
    expect(h?.household_code).toMatch(/^MBA-[A-Z0-9]{6}$/);
  });
});

describe("review status from the server", () => {
  it("a synced record stores the server's review_status (awaiting_review), never assumed confirmed", async () => {
    await store.db.patients.put(patient("p1"));
    postSync.mockResolvedValue({ patients: [{ id: "p1", status: "synced", review_status: "awaiting_review" }], visits: [] });
    await runSync();
    const p = await store.db.patients.get("p1");
    expect(p).toMatchObject({ sync_status: "synced", review_status: "awaiting_review" });
  });

  it("an older server that doesn't send review_status leaves it unknown (not confirmed)", async () => {
    await store.db.patients.put(patient("p1"));
    postSync.mockResolvedValue({ patients: [{ id: "p1", status: "synced" }], visits: [] });
    await runSync();
    expect((await store.db.patients.get("p1"))?.review_status).toBeUndefined();
  });
});
