// Mosi app icons from the in-app leaf mark (components/Logo.tsx: lucide
// "leaf", white stroke on forest-800). Writes into web-app/public/icons.
// Run from web-app/e2e: node generate-icons.mjs
import { chromium } from "playwright";
import { mkdirSync, writeFileSync } from "node:fs";

import { fileURLToPath } from "node:url";
const OUT = fileURLToPath(new URL("../public/icons", import.meta.url));
const FOREST = "#0F3D34";
const LEAF = [
  "M11 20a10 10 0 0010-10 25.9 25.9 0 00-1.04-7.281 1 1 0 00-1.755-.325C15.833 5.5 13 5.5 9.8 6.1A7 7 0 0011 20",
  "M2 21a5 5 0 012.911-4.544C7.613 15.212 8.351 15.24 11 13",
];

// leafFraction: leaf box (24 units) as a share of the canvas.
function svg({ size, shape, leafFraction }) {
  const leaf = size * leafFraction;
  const scale = leaf / 24;
  const offset = (size - leaf) / 2;
  const bg =
    shape === "circle"
      ? `<circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="${FOREST}"/>`
      : `<rect width="${size}" height="${size}" fill="${FOREST}"/>`;
  const paths = LEAF.map((d) => `<path d="${d}"/>`).join("");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${bg}<g transform="translate(${offset} ${offset}) scale(${scale})" fill="none" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths}</g></svg>`;
}

const ICONS = [
  // "any": the round badge, like the app's own logo.
  { file: "icon-192.png", size: 192, shape: "circle", leafFraction: 0.56 },
  { file: "icon-512.png", size: 512, shape: "circle", leafFraction: 0.56 },
  // maskable: full-bleed; the leaf (radius ~0.5*0.44*sqrt2 = 31% of the
  // canvas) sits well inside the 40%-radius safe zone, so any mask shape works.
  { file: "icon-maskable-512.png", size: 512, shape: "square", leafFraction: 0.44 },
  // iOS draws its own rounded corners and ignores transparency.
  { file: "apple-touch-icon.png", size: 180, shape: "square", leafFraction: 0.56 },
];

mkdirSync(OUT, { recursive: true });
// Rendered by Chromium at exact pixel size; transparent where the SVG is.
const browser = await chromium.launch();
for (const icon of ICONS) {
  const page = await browser.newPage({ viewport: { width: icon.size, height: icon.size }, deviceScaleFactor: 1 });
  await page.setContent(`<html><body style="margin:0;background:transparent">${svg(icon)}</body></html>`);
  await page.screenshot({ path: `${OUT}/${icon.file}`, omitBackground: true, clip: { x: 0, y: 0, width: icon.size, height: icon.size } });
  await page.close();
  console.log("wrote", icon.file);
}
await browser.close();
// Crisp at any size in browser tabs.
writeFileSync(`${OUT}/favicon.svg`, svg({ size: 64, shape: "circle", leafFraction: 0.6 }));
console.log("wrote favicon.svg");
