// Keyboard-only + focus-management + dialog + live-region checks on the
// production build. Uses only the keyboard for the interactions under test.
import { chromium } from "playwright";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const TEST_PATIENT_CODE = process.argv[2]; // P3-<stamp> from p3-offline.mjs
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
const active = (page) => page.evaluate(() => {
  const el = document.activeElement;
  return { tag: el?.tagName, text: (el?.getAttribute("aria-label") || el?.textContent || "").trim().slice(0, 50), id: el?.id, name: el?.getAttribute("name"), value: el?.getAttribute("value"), role: el?.getAttribute("role") };
});
async function tabUntil(page, predicate, max = 40) {
  for (let i = 0; i < max; i++) {
    await page.keyboard.press("Tab");
    const a = await active(page);
    if (predicate(a)) return a;
  }
  return null;
}
const liveText = (page) => page.evaluate(() => document.querySelector('[role="status"][aria-live="polite"].sr-only')?.textContent ?? "");

const browser = await chromium.launch();

// ---------- Landing: footer notice dialog ----------
{
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto(`${BASE}/`, { waitUntil: "networkidle" });
  const opener = await tabUntil(page, (a) => a.text === "Privacy", 80);
  report("Landing: footer Privacy reachable by Tab", !!opener);
  await page.keyboard.press("Enter");
  await page.waitForTimeout(200);
  const dialogOpen = await page.evaluate(() => document.querySelector("dialog[open]") !== null);
  const inDialog = await page.evaluate(() => !!document.activeElement?.closest("dialog[open]"));
  report("Landing: Enter opens Privacy dialog with focus inside it", dialogOpen && inDialog);
  const bodyText = await page.locator("dialog[open]").innerText();
  report("Landing: Privacy notice is honest (synthetic data, no invented contacts)", /synthetic data/.test(bodyText) && !/@|\+263|\bwww\./.test(bodyText));
  // Tab several times - focus must stay in the dialog (page behind is inert)
  let escaped = false;
  for (let i = 0; i < 6; i++) { await page.keyboard.press("Tab"); const inside = await page.evaluate(() => !!document.activeElement?.closest("dialog[open]") || document.activeElement === document.body); if (!inside) escaped = true; }
  report("Landing: Tab does not reach the page behind the dialog", !escaped);
  await page.keyboard.press("Escape");
  await page.waitForTimeout(200);
  const back = await active(page);
  report("Landing: Escape closes dialog and focus returns to 'Privacy'", back.text === "Privacy" && !(await page.evaluate(() => document.querySelector("dialog[open]"))), back);
  await ctx.close();
}

// ---------- Login by keyboard ----------
const ctx = await browser.newContext({ viewport: { width: 375, height: 812 } });
const page = await ctx.newPage();
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => { if (m.type() === "error" && !/ERR_INTERNET_DISCONNECTED|Failed to load resource/.test(m.text())) errors.push(m.text()); });
await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
report("Login: CHW ID field has focus on load", (await active(page)).id === "chwId");
await page.keyboard.press("Enter");
await page.waitForTimeout(150);
const loginErr = await page.locator("main").innerText();
report("Login: empty submit gives specific messages", /Enter your CHW ID/.test(loginErr) && /Enter your 4-digit PIN/.test(loginErr));
await page.keyboard.type("CHW001");
await page.keyboard.press("Tab");
report("Login: Tab moves to PIN", (await active(page)).id === "pin");
await page.keyboard.type("1234");
await page.keyboard.press("Enter");
await page.waitForURL("**/chw", { timeout: 10000 });
report("Login: Enter in PIN signs in", true);
await page.waitForTimeout(1500);

// ---------- Skip link ----------
await page.keyboard.press("Tab");
const skip = await active(page);
const skipVisible = await page.evaluate(() => { const r = document.activeElement.getBoundingClientRect(); return r.width > 20 && r.height > 10; });
report("Shell: first Tab reaches a visible 'Skip to main content'", skip.text === "Skip to main content" && skipVisible);
await page.keyboard.press("Enter");
report("Shell: skip link moves focus to main", (await active(page)).id === "main-content");

// ---------- Record a visit using only the keyboard (offline, so nothing reaches the server) ----------
await page.goto(`${BASE}/chw/visits/new`, { waitUntil: "networkidle" });
await page.waitForSelector("#patient-search");
await ctx.setOffline(true);
await page.waitForTimeout(300);
const toSearch = await tabUntil(page, (a) => a.id === "patient-search");
report("Visit(kb): Tab reaches patient search", !!toSearch);
await page.keyboard.type("Mbare");
await page.waitForTimeout(200);
await page.keyboard.press("Tab");
let a = await active(page);
report("Visit(kb): Tab moves into the patient radio group", a.name === "patient", a);
const first = a.value;
await page.keyboard.press("Space");
await page.keyboard.press("ArrowDown");
a = await active(page);
const stillList = await page.locator('input[name="patient"]').count();
report("Visit(kb): ArrowDown moves to next patient and list stays open", a.name === "patient" && a.value !== first && stillList > 1, { stillList });
await page.keyboard.press("ArrowUp");
await page.keyboard.press("Tab");
a = await active(page);
report("Visit(kb): Tab leaves the group to visit date", a.id === "visit_date", a);
a = await tabUntil(page, (x) => x.name === "visit_type", 6);
report("Visit(kb): Tab reaches visit type radios (after the date's own day/month/year stops)", a?.name === "visit_type", a);
await page.keyboard.press("ArrowDown");
await page.keyboard.press("ArrowDown");
const chosenType = await page.evaluate(() => document.querySelector('input[name="visit_type"]:checked')?.value);
report("Visit(kb): arrow keys choose a visit type", !!chosenType, chosenType);
const cont = await tabUntil(page, (x) => x.text === "Continue");
await page.keyboard.press("Enter");
await page.waitForTimeout(200);
a = await active(page);
report("Visit(kb): Continue -> focus on step 2 heading", a.tag === "H2" && /Measurements/.test(a.text), a);
await tabUntil(page, (x) => x.id === "weight");
await page.keyboard.type("14.2");
await tabUntil(page, (x) => x.text === "Continue");
await page.keyboard.press("Enter");
await page.waitForTimeout(200);
a = await active(page);
report("Visit(kb): Continue -> focus on review heading", a.tag === "H2" && /Review/.test(a.text), a);
await tabUntil(page, (x) => x.text === "Save visit");
await page.keyboard.press("Enter");
await page.waitForSelector("text=Visit recorded");
a = await active(page);
report("Visit(kb): after save, focus moves to 'Visit recorded'", a.tag === "H1" && /Visit recorded/.test(a.text), a);
await page.waitForTimeout(400);
report("Visit(kb): screen-reader announcement for offline save", /Visit saved on this device\. It will sync when you're connected\./.test(await liveText(page)), await liveText(page));
// Error path focus: go to add visit, press Continue with nothing chosen
await page.goto(`${BASE}/chw/visits/new`, { waitUntil: "domcontentloaded" });
await page.waitForSelector("#patient-search");
await tabUntil(page, (x) => x.text === "Continue");
await page.keyboard.press("Enter");
await page.waitForTimeout(200);
a = await active(page);
report("Visit(kb): validation moves focus to the error summary (role=alert)", a.role === "alert", a);
await ctx.setOffline(false);
await page.waitForTimeout(3000); // let the queued keyboard visit auto-sync? (It will - see cleanup.)

// ---------- Mobile top bar height vs sticky sync strip ----------
const heights = await page.evaluate(() => ({ header: document.querySelector("header.sticky")?.getBoundingClientRect().height }));
report("Shell: mobile top bar height matches strip offset (57px)", Math.round(heights.header) === 57, heights);
await ctx.close();

// ---------- Supervisor: More menu + conflict dialog ----------
const sctx = await browser.newContext({ viewport: { width: 375, height: 812 } });
const sp = await sctx.newPage();
sp.on("pageerror", (e) => errors.push(String(e)));
// Create a genuine conflict on the throwaway test patient via the real sync endpoint.
if (TEST_PATIENT_CODE) {
  const cctx = await browser.newContext();
  const cp = await cctx.newPage();
  await cp.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await cp.fill("#chwId", "CHW001"); await cp.fill("#pin", "1234"); await cp.press("#pin", "Enter");
  await cp.waitForURL("**/chw");
  const made = await cp.evaluate(async ({ API, code }) => {
    const r = await fetch(`${API}/patients?search=${code}`, { credentials: "include" });
    const body = await r.json();
    const list = Array.isArray(body.data) ? body.data : body.data?.items ?? [];
    const p = list.find((x) => x.patient_id === code);
    if (!p) return { ok: false };
    const edited = { ...p, village: "Epworth", sync_status: "pending" };
    const s = await fetch(`${API}/sync`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ patients: [edited], visits: [] }) });
    const sb = await s.json();
    return { ok: true, result: sb.data?.patients?.[0]?.status };
  }, { API, code: TEST_PATIENT_CODE });
  report("Setup: same-timestamp edit on test patient flagged as conflict by server", made.result === "conflict", made);
  await cctx.close();
}
await sp.goto(`${BASE}/login`, { waitUntil: "networkidle" });
await sp.fill("#chwId", "SUP001"); await sp.fill("#pin", "1234"); await sp.press("#pin", "Enter");
await sp.waitForURL("**/supervisor");
await sp.waitForTimeout(1500);
const more = await tabUntil(sp, (x) => /^More/.test(x.text), 60);
report("Supervisor mobile: 'More' reachable by Tab (announces attention count)", !!more, more);
await sp.keyboard.press("Enter");
await sp.waitForTimeout(250);
a = await active(sp);
report("Supervisor mobile: Enter opens More menu with focus on first item", a.role === "menuitem", a);
await sp.keyboard.press("ArrowDown");
await sp.waitForTimeout(60); // a person can't press keys 0ms apart; Radix moves focus on the next frame
a = await active(sp);
report("Supervisor mobile: ArrowDown moves to the next item", a.role === "menuitem" && a.text !== "CHW Activity", a);
for (let i = 0; i < 8 && !/Conflicts/.test(a.text); i++) { await sp.keyboard.press("ArrowDown"); await sp.waitForTimeout(60); a = await active(sp); }
report("Supervisor mobile: arrow keys reach Conflicts", /Conflicts/.test(a.text), a);
await sp.keyboard.press("Escape");
await sp.waitForTimeout(200);
a = await active(sp);
report("Supervisor mobile: Escape closes menu, focus back on More", /^More/.test(a.text), a);
await sp.keyboard.press("Enter");
await sp.waitForTimeout(200);
for (let i = 0; i < 8; i++) { a = await active(sp); if (/Conflicts/.test(a.text)) break; await sp.keyboard.press("ArrowDown"); await sp.waitForTimeout(60); }
await sp.keyboard.press("Enter");
await sp.waitForURL("**/supervisor/conflicts");
await sp.waitForSelector("text=Keep server version", { timeout: 10000 });
const conflictText = await sp.locator("main").innerText();
report("Conflicts: card names the patient, shows what differs, no raw JSON", /Tariro Offlinetest/.test(conflictText) && /Different: Village/.test(conflictText) && !/[{}]|"id"/.test(conflictText), conflictText.slice(0, 300));
report("Conflicts: 'Changed' marked in text, not colour alone", (await sp.locator("text=Changed").count()) >= 2);
const card = sp.locator("h2", { hasText: "Tariro Offlinetest" }).locator("xpath=ancestor::div[contains(@class,'space-y-5')][1]");
const keepBtn = card.getByRole("button", { name: "Keep server version" }).first();
await keepBtn.focus();
await sp.keyboard.press("Enter");
await sp.waitForTimeout(250);
const dlg = await sp.evaluate(() => { const d = document.querySelector("dialog[open]"); return d ? { text: d.innerText, focusInside: d.contains(document.activeElement), focused: document.activeElement.textContent } : null; });
report("Conflicts: confirmation dialog opens, focus inside on Cancel", dlg && dlg.focusInside && /Cancel/.test(dlg.focused), dlg && dlg.focused);
report("Conflicts: dialog explains the consequence", dlg && /will be discarded/.test(dlg.text));
await sp.keyboard.press("Escape");
await sp.waitForTimeout(200);
a = await active(sp);
report("Conflicts: Escape cancels and focus returns to the button", /Keep server version/.test(a.text), a);
await keepBtn.focus();
await sp.keyboard.press("Enter");
await sp.waitForTimeout(200);
await sp.keyboard.press("Tab"); // Cancel -> confirm
await sp.keyboard.press("Enter");
await sp.waitForSelector("text=Conflict resolved", { timeout: 10000 });
a = await active(sp);
report("Conflicts: after resolving, focus moves to 'Conflict resolved' message", a.role === "status" && /Conflict resolved/.test(a.text), a);
await sctx.close();

await browser.close();
console.log(`\nPage errors: ${errors.length}`); errors.forEach((e) => console.log("  ", e));
console.log(`${pass} passed, ${fail} failed`);
