import { randomUUID } from "node:crypto";
import type { NextFunction, Request, Response } from "express";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      requestId: string;
    }
  }
}

// Every log line and audit entry for a request can be correlated by this id
// (section 39). Accepts an inbound X-Request-Id from a reverse proxy/load
// balancer if present, so a request can be traced end-to-end across hops;
// generates one otherwise.
export function requestId(req: Request, res: Response, next: NextFunction) {
  const inbound = req.headers["x-request-id"];
  const id = typeof inbound === "string" && inbound.trim() ? inbound.trim() : randomUUID();
  req.requestId = id;
  res.setHeader("X-Request-Id", id);
  next();
}
