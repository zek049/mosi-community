// ---------------------------------------------------------------------------
// Connectivity: ONE source of truth for "may Mosi talk to the server now?"
//
// Three real inputs feed it:
//   1. browserOnline   - navigator.onLine + its online/offline events
//   2. serverReachable - a lightweight GET /api/health check (every 30s while
//                        it matters, and immediately on reconnect). true /
//                        false / null = not checked yet
//   3. workOffline     - the user's deliberate "Work Offline" choice,
//                        remembered on this device. Not a simulation: while
//                        it's on, Mosi makes no sync, cache-refresh or health
//                        requests at all.
//
// Truth table (the brief's four cases):
//   connected    + Work Offline off -> online
//   disconnected + Work Offline off -> offline
//   connected    + Work Offline on  -> offline ("work-offline")
//   disconnected + Work Offline on  -> offline ("work-offline")
//
// NetworkContext (React) owns the state and publishes it into the small
// store below, so non-React code - the sync engine and cache refresh - obeys
// exactly the same decision instead of keeping its own flag.
// ---------------------------------------------------------------------------

export type ConnectivityStatus =
  /** Browser online and the server answered the last health check. */
  | "online"
  /** Browser online, first health check still running. */
  | "checking"
  /** The browser reports no network. */
  | "offline"
  /** Network present, but the Mosi server didn't answer (or answered unhealthy). */
  | "server-unreachable"
  /** The user turned on Work Offline. */
  | "work-offline";

export type ConnectivityInputs = {
  browserOnline: boolean;
  serverReachable: boolean | null;
  workOffline: boolean;
};

export type Connectivity = {
  status: ConnectivityStatus;
  /** True only when the app may contact the server (sync, refresh, API). */
  isOnline: boolean;
};

export function deriveConnectivity({ browserOnline, serverReachable, workOffline }: ConnectivityInputs): Connectivity {
  if (workOffline) return { status: "work-offline", isOnline: false };
  if (!browserOnline) return { status: "offline", isOnline: false };
  if (serverReachable === false) return { status: "server-unreachable", isOnline: false };
  if (serverReachable === null) return { status: "checking", isOnline: false };
  return { status: "online", isOnline: true };
}

/** Plain-language label for indicators. */
export function connectivityLabel(status: ConnectivityStatus): string {
  switch (status) {
    case "online":
      return "Online";
    case "checking":
      return "Checking connection…";
    case "offline":
      return "Offline";
    case "server-unreachable":
      return "Server unreachable";
    case "work-offline":
      return "Working offline";
  }
}

/** Why records saved now won't sync yet - shown on save screens. */
export function syncLaterHint(status: ConnectivityStatus): string {
  if (status === "work-offline") return "It will sync when you turn off Work Offline.";
  if (status === "server-unreachable") return "It will sync once the Mosi server can be reached.";
  return "It will sync when you're connected.";
}

/** Footer note on Add patient / Add visit when the record can't sync yet. */
export function offlineSaveExplanation(status: ConnectivityStatus, noun: "patient" | "visit"): string {
  if (status === "work-offline") return `Work Offline is on. The ${noun} will be saved on this device and synced after you turn it off.`;
  if (status === "server-unreachable") return `The Mosi server isn't answering. The ${noun} will be saved on this device and synced once it can be reached.`;
  if (status === "checking") return `Checking the connection. The ${noun} will be saved on this device either way.`;
  return `You're offline. The ${noun} will be saved on this device and synced when you're connected.`;
}

// --- Health check ----------------------------------------------------------

export const HEALTH_CHECK_INTERVAL_MS = 30_000;
const HEALTH_CHECK_TIMEOUT_MS = 5_000;

/**
 * GET {apiBase}/health - the server's readiness check (it also confirms the
 * database answers). Any non-2xx, network error or timeout = unreachable.
 * No credentials are sent: it's a public endpoint.
 */
export async function checkServerHealth(
  apiBase: string,
  fetchImpl: typeof fetch = fetch,
  timeoutMs = HEALTH_CHECK_TIMEOUT_MS,
): Promise<boolean> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetchImpl(`${apiBase}/health`, { cache: "no-store", signal: controller.signal });
    // Only the status matters, but read the (tiny) body so the request
    // completes and its connection is freed - an unread body stays open.
    await response.text().catch(() => "");
    return response.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

// --- Work Offline preference -------------------------------------------------

const WORK_OFFLINE_KEY = "mosi.workOffline";
// The removed "Demo network" switch's key: a simulation flag with different
// meaning, so it's discarded rather than carried over.
const LEGACY_DEMO_KEY = "mosi.demoNetwork";

export function readWorkOffline(storage: Pick<Storage, "getItem" | "removeItem"> | undefined = safeLocalStorage()): boolean {
  try {
    storage?.removeItem(LEGACY_DEMO_KEY);
    return storage?.getItem(WORK_OFFLINE_KEY) === "true";
  } catch {
    return false;
  }
}

export function writeWorkOffline(value: boolean, storage: Pick<Storage, "setItem" | "removeItem"> | undefined = safeLocalStorage()): void {
  try {
    if (value) storage?.setItem(WORK_OFFLINE_KEY, "true");
    else storage?.removeItem(WORK_OFFLINE_KEY);
  } catch {
    // Non-fatal: the choice still applies until the page is reloaded.
  }
}

function safeLocalStorage(): Storage | undefined {
  try {
    return typeof localStorage === "undefined" ? undefined : localStorage;
  } catch {
    return undefined;
  }
}

// --- Store read by non-React code (sync engine, cache refresh) ---------------

let current: Connectivity & { workOffline: boolean } = { status: "checking", isOnline: false, workOffline: false };
const listeners = new Set<() => void>();

export function publishConnectivity(next: Connectivity & { workOffline: boolean }): void {
  if (current.status === next.status && current.isOnline === next.isOnline && current.workOffline === next.workOffline) return;
  current = next;
  listeners.forEach((listener) => listener());
}

export function getConnectivity(): Connectivity & { workOffline: boolean } {
  return current;
}

export function subscribeConnectivity(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/** Thrown by the sync engine instead of contacting the server while not online. */
export class SyncNotAllowedError extends Error {
  status: ConnectivityStatus;
  constructor(status: ConnectivityStatus) {
    super(status === "work-offline" ? "Work Offline is on - sync is paused" : "Not connected to the Mosi server");
    this.name = "SyncNotAllowedError";
    this.status = status;
  }
}

export function assertCanContactServer(): void {
  if (!current.isOnline) throw new SyncNotAllowedError(current.status);
}
