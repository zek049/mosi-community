import { afterEach, describe, expect, it, vi } from "vitest";
import {
  SyncNotAllowedError,
  assertCanContactServer,
  checkServerHealth,
  connectivityLabel,
  deriveConnectivity,
  getConnectivity,
  offlineSaveExplanation,
  publishConnectivity,
  readWorkOffline,
  subscribeConnectivity,
  syncLaterHint,
  writeWorkOffline,
} from "../connectivity";

describe("deriveConnectivity - one state from three real inputs", () => {
  it("connected + Work Offline off = online", () => {
    expect(deriveConnectivity({ browserOnline: true, serverReachable: true, workOffline: false })).toEqual({ status: "online", isOnline: true });
  });
  it("disconnected + Work Offline off = offline (automatic detection)", () => {
    expect(deriveConnectivity({ browserOnline: false, serverReachable: true, workOffline: false })).toEqual({ status: "offline", isOnline: false });
    // a stale "reachable" from before the drop doesn't keep it online
    expect(deriveConnectivity({ browserOnline: false, serverReachable: null, workOffline: false }).isOnline).toBe(false);
  });
  it("connected + Work Offline on = offline", () => {
    expect(deriveConnectivity({ browserOnline: true, serverReachable: true, workOffline: true })).toEqual({ status: "work-offline", isOnline: false });
  });
  it("disconnected + Work Offline on = offline", () => {
    expect(deriveConnectivity({ browserOnline: false, serverReachable: false, workOffline: true })).toEqual({ status: "work-offline", isOnline: false });
  });
  it("browser online but the health check failed = not online (server unreachable)", () => {
    expect(deriveConnectivity({ browserOnline: true, serverReachable: false, workOffline: false })).toEqual({ status: "server-unreachable", isOnline: false });
  });
  it("browser online, first health check not back yet = not online yet (checking)", () => {
    expect(deriveConnectivity({ browserOnline: true, serverReachable: null, workOffline: false })).toEqual({ status: "checking", isOnline: false });
  });
});

describe("checkServerHealth", () => {
  afterEach(() => vi.useRealTimers());

  it("is reachable when GET /health answers 2xx (no credentials sent)", async () => {
    const fetchImpl = vi.fn(async () => new Response("{}", { status: 200 }));
    expect(await checkServerHealth("http://api.test/api", fetchImpl as unknown as typeof fetch)).toBe(true);
    const [url, init] = fetchImpl.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe("http://api.test/api/health");
    expect(init.credentials).toBeUndefined();
  });

  it("is unreachable when the server answers unhealthy (e.g. 503 database down)", async () => {
    const fetchImpl = vi.fn(async () => new Response("{}", { status: 503 }));
    expect(await checkServerHealth("http://api.test/api", fetchImpl as unknown as typeof fetch)).toBe(false);
  });

  it("is unreachable when the request fails (no route to server)", async () => {
    const fetchImpl = vi.fn(async () => {
      throw new TypeError("Failed to fetch");
    });
    expect(await checkServerHealth("http://api.test/api", fetchImpl as unknown as typeof fetch)).toBe(false);
  });

  it("is unreachable when the server doesn't answer in time", async () => {
    vi.useFakeTimers();
    const fetchImpl = vi.fn(
      (_url: string, init: RequestInit) =>
        new Promise<Response>((_resolve, reject) => init.signal?.addEventListener("abort", () => reject(new DOMException("aborted", "AbortError")))),
    );
    const result = checkServerHealth("http://api.test/api", fetchImpl as unknown as typeof fetch, 5000);
    await vi.advanceTimersByTimeAsync(5000);
    expect(await result).toBe(false);
  });
});

describe("Work Offline preference", () => {
  function memory(initial: Record<string, string> = {}) {
    const m = new Map(Object.entries(initial));
    return {
      getItem: (k: string) => m.get(k) ?? null,
      setItem: (k: string, v: string) => void m.set(k, v),
      removeItem: (k: string) => void m.delete(k),
      has: (k: string) => m.has(k),
    };
  }

  it("is off by default and remembered when turned on, cleared when turned off", () => {
    const store = memory();
    expect(readWorkOffline(store)).toBe(false);
    writeWorkOffline(true, store);
    expect(readWorkOffline(store)).toBe(true);
    writeWorkOffline(false, store);
    expect(readWorkOffline(store)).toBe(false);
  });

  it("discards the old demo-network simulation flag instead of treating it as Work Offline", () => {
    const store = memory({ "mosi.demoNetwork": "offline" });
    expect(readWorkOffline(store)).toBe(false);
    expect(store.has("mosi.demoNetwork")).toBe(false);
  });
});

describe("shared connectivity store (used by the sync engine)", () => {
  it("refuses server contact while Work Offline is on or not connected, allows it when online", () => {
    publishConnectivity({ status: "work-offline", isOnline: false, workOffline: true });
    expect(() => assertCanContactServer()).toThrow(SyncNotAllowedError);
    publishConnectivity({ status: "offline", isOnline: false, workOffline: false });
    expect(() => assertCanContactServer()).toThrow(SyncNotAllowedError);
    publishConnectivity({ status: "server-unreachable", isOnline: false, workOffline: false });
    expect(() => assertCanContactServer()).toThrow(SyncNotAllowedError);
    publishConnectivity({ status: "online", isOnline: true, workOffline: false });
    expect(() => assertCanContactServer()).not.toThrow();
  });

  it("notifies subscribers only when the state actually changes", () => {
    publishConnectivity({ status: "online", isOnline: true, workOffline: false });
    const listener = vi.fn();
    const unsubscribe = subscribeConnectivity(listener);
    publishConnectivity({ status: "online", isOnline: true, workOffline: false });
    expect(listener).not.toHaveBeenCalled();
    publishConnectivity({ status: "work-offline", isOnline: false, workOffline: true });
    expect(listener).toHaveBeenCalledTimes(1);
    expect(getConnectivity().status).toBe("work-offline");
    unsubscribe();
  });
});

describe("wording", () => {
  it("names the real reason", () => {
    expect(connectivityLabel("work-offline")).toBe("Working offline");
    expect(connectivityLabel("server-unreachable")).toBe("Server unreachable");
    expect(syncLaterHint("work-offline")).toMatch(/turn off Work Offline/);
    expect(syncLaterHint("offline")).toMatch(/when you're connected/);
    expect(offlineSaveExplanation("work-offline", "visit")).toMatch(/^Work Offline is on\. The visit/);
  });
});
