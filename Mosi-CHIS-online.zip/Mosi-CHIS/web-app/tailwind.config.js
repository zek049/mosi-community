/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    screens: {
      // Between "phone" and Tailwind's default sm (640px) - just wide
      // enough for a 3-up compact stat row (see CHW Home) to stop cramping
      // on a typical ~390px phone without waiting for tablet width.
      xs: "480px",
      sm: "640px",
      md: "768px",
      lg: "1024px",
      xl: "1280px",
      "2xl": "1536px",
    },
    extend: {
      colors: {
        // Phase 2 design system refresh: warm ivory background, deep forest
        // green primary, muted sage secondary, a small warm-gold accent
        // (used sparingly - underlines, one of three step numbers, never as
        // a primary button color). Semantic tokens, not ad-hoc green values
        // scattered per-screen - every screen should pull from this set.
        cream: "#FAF8F2",
        forest: {
          50: "#EAF1EE",
          100: "#D3E3DC",
          600: "#1C5245",
          700: "#154A3F",
          800: "#0F3D34",
          900: "#0A2B24",
        },
        sage: {
          50: "#F1F5EE",
          100: "#E1EAD9",
          400: "#9CB88C",
          500: "#7FA06E",
          600: "#65855A",
        },
        gold: {
          400: "#E0B15C",
          500: "#C9974A",
          600: "#A97B37",
          // The only gold that passes WCAG AA for small text (5.33:1 on
          // cream, 4.75:1 on the gold-400/20 badge pill) - use this for any
          // gold *text*; 400-600 are for decorative fills/underlines only.
          700: "#86601F",
        },
        // Kept as an alias of forest.800/700 - the sidebar/topbar already
        // reference this token throughout; redefining forest separately (as
        // opposed to just renaming this) avoids a mass find-and-replace
        // across every screen for a purely cosmetic-naming change.
        sidebar: {
          DEFAULT: "#0F3D34",
          hover: "#154A3F",
        },
      },
    },
  },
  plugins: [],
};
