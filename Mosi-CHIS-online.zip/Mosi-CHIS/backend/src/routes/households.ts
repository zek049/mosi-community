import { Router } from "express";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { clinicScope, canAccessClinic } from "../middleware/authz";
import { requireStringParam } from "../utils/params";
import { parseBody, householdCreateSchema } from "../validation/schemas";

// Households. CHWs normally create them on their device and they arrive via
// POST /api/sync (offline-first); these endpoints serve online creation, the
// device cache refresh, and member lookups. Every query is clinic-scoped.
const router = Router();

router.get("/", async (req, res) => {
  const scope = clinicScope(req.user!);
  const households = await prisma.household.findMany({
    where: scope ? { clinic_id: scope } : {},
    select: { id: true, household_code: true, village: true, clinic_id: true, created_at: true, _count: { select: { patients: true } } },
    orderBy: { household_code: "asc" },
    take: 2000,
  });
  res.json({
    success: true,
    data: households.map(({ _count, ...h }) => ({ ...h, member_count: _count.patients })),
  });
});

router.post("/", async (req, res) => {
  const body = parseBody(householdCreateSchema, req.body ?? {});
  const [byId, byCode] = await Promise.all([
    prisma.household.findUnique({ where: { id: body.id }, select: { id: true } }),
    prisma.household.findUnique({ where: { household_code: body.household_code }, select: { id: true } }),
  ]);
  if (byId || byCode) throw new AppError(409, "That household already exists or its code is already used", "HOUSEHOLD_EXISTS");
  const household = await prisma.household.create({
    data: {
      id: body.id,
      household_code: body.household_code,
      village: body.village,
      created_at: body.created_at ? new Date(body.created_at) : new Date(),
      clinic_id: req.user!.clinicId,
      created_by_chw_id: req.user!.chwId,
    },
  });
  res.status(201).json({ success: true, data: household });
});

router.get("/:id/patients", async (req, res) => {
  const id = requireStringParam(req, "id");
  const household = await prisma.household.findUnique({ where: { id } });
  // Out of scope looks like missing.
  if (!household || !canAccessClinic(req.user!, household.clinic_id)) throw new AppError(404, "Household not found");
  const patients = await prisma.patient.findMany({
    where: { household_id: id, deleted_at: null },
    select: { id: true, patient_id: true, first_name: true, last_name: true, gender: true, date_of_birth: true, village: true },
    orderBy: [{ last_name: "asc" }, { first_name: "asc" }],
  });
  res.json({ success: true, data: { household, patients } });
});

export default router;
