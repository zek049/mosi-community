// Possible-duplicate patient matching. Mirrors
// web-app/src/utils/findPossibleDuplicates.ts (no shared package between the
// two apps - same convention as the mirrored validators); both have the same
// test table. A match is a WARNING to the CHW, never a block.

/** Trim, collapse inner whitespace, lowercase, and drop accents ("Mütasa" = "mutasa"). */
export function normalizeForMatch(value: string | null | undefined): string {
  return (value ?? "")
    .normalize("NFKD")
    .replace(/\p{M}/gu, "")
    .trim()
    .replace(/\s+/g, " ")
    .toLowerCase();
}

/** The calendar day of a date-of-birth, whether given as "YYYY-MM-DD" or a timestamp. */
export function dayOf(value: string | Date): string {
  return (value instanceof Date ? value.toISOString() : value).slice(0, 10);
}

export type DuplicateCandidate = { first_name: string; last_name: string; village: string; date_of_birth: string | Date };

export function isPossibleDuplicate(a: DuplicateCandidate, b: DuplicateCandidate): boolean {
  return (
    normalizeForMatch(a.first_name) === normalizeForMatch(b.first_name) &&
    normalizeForMatch(a.last_name) === normalizeForMatch(b.last_name) &&
    normalizeForMatch(a.village) === normalizeForMatch(b.village) &&
    dayOf(a.date_of_birth) === dayOf(b.date_of_birth)
  );
}
