import type { LucideIcon } from "lucide-react";
import { cn } from "../../lib/utils";
import { Card } from "./Card";

const ICON_TONES = {
  teal: "bg-sage-50 text-forest-700",
  blue: "bg-forest-50 text-forest-800",
  amber: "bg-amber-50 text-amber-700",
  violet: "bg-gold-400/20 text-gold-700",
} as const;

type StatCardProps = {
  label: string;
  value: number | string | undefined;
  suffix?: string;
  icon: LucideIcon;
  tone?: keyof typeof ICON_TONES;
};

// Shared by CHW Home and Supervisor Dashboard so both screens' stats look
// identical rather than each rolling their own. The icon's tone is purely
// to help four cards read as distinct at a glance (section 4: colour
// communicates state, not decoration) - it doesn't encode anything itself.
export function StatCard({ label, value, suffix = "", icon: Icon, tone = "teal" }: StatCardProps) {
  return (
    <Card className="flex items-center gap-3 p-4 sm:p-5">
      <span className={cn("flex h-10 w-10 shrink-0 items-center justify-center rounded-full", ICON_TONES[tone])}>
        <Icon className="h-5 w-5" aria-hidden="true" />
      </span>
      <div className="min-w-0">
        <p className="text-xl font-semibold text-stone-900 leading-tight">
          {value ?? "…"}
          {value !== undefined && suffix}
        </p>
        <p className="text-xs text-stone-500 truncate">{label}</p>
      </div>
    </Card>
  );
}
