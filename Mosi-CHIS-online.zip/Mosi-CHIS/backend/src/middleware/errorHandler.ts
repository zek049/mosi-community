import type { NextFunction, Request, Response } from "express";
import { Prisma } from "@prisma/client";
import { AppError } from "../utils/AppError";
import { logger } from "../logger";

export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({ success: false, message: `Not found: ${req.method} ${req.originalUrl}` });
}

// Express 5 forwards a rejected promise from any async route handler here
// automatically, so this is the single place that turns any failure -
// expected (AppError) or not - into the {success:false, message} JSON shape
// required by the spec, without ever leaking a stack trace, Prisma error
// detail, or database connection string to the client.
export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof AppError) {
    res.status(err.statusCode).json({ success: false, message: err.message, ...(err.code ? { code: err.code } : {}) });
    return;
  }

  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    // P1xxx codes are connection/database-server-level failures (P1001
    // "can't reach database server", P1002 timeout, P1008 operation
    // timeout, P1017 server closed the connection) - a real, client-facing
    // 503, never a 409. Found via adversarial DB-outage testing: these were
    // previously misclassified as "conflicts with existing data", which is
    // actively misleading (the client would have no reason to think the
    // problem was on the server's side, let alone that retrying later would
    // help). P2xxx codes are query-engine/constraint errors (P2002 unique
    // constraint, P2025 record not found, etc.) - those really are 409s.
    const isConnectionFailure = err.code.startsWith("P1");
    logger.error({ code: err.code, message: err.message }, isConnectionFailure ? "Database unreachable" : "Database error");
    if (isConnectionFailure) {
      res.status(503).json({ success: false, message: "Database unreachable - please try again shortly" });
      return;
    }
    res.status(409).json({ success: false, message: "The request conflicts with existing data" });
    return;
  }

  // Defense-in-depth: every other Prisma error class (Unknown/Validation/
  // RustPanic/Initialization) means the query itself was rejected by the
  // database or the client library - found via adversarial testing when an
  // oversized field value passed application validation but blew a
  // Postgres index-row-size limit at the database layer. Initialization
  // errors specifically are also connection-level failures (thrown when the
  // client can't even establish a connection, distinct from
  // PrismaClientKnownRequestError's P1xxx which is a failure mid-query), so
  // those get the same 503 as above rather than the 400 the others get.
  if (err instanceof Prisma.PrismaClientInitializationError) {
    logger.error({ err }, "Database unreachable at connection init");
    res.status(503).json({ success: false, message: "Database unreachable - please try again shortly" });
    return;
  }

  if (err instanceof Prisma.PrismaClientUnknownRequestError || err instanceof Prisma.PrismaClientValidationError) {
    logger.error({ err }, "Database rejected the query");
    res.status(400).json({ success: false, message: "The request could not be processed" });
    return;
  }

  logger.error({ err }, "Unexpected error");
  res.status(500).json({ success: false, message: "Internal server error" });
}
