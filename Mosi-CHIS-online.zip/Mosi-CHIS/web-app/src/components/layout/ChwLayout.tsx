import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import { Home, Users, Stethoscope, RefreshCw } from "lucide-react";
import * as authService from "../../services/authService";
import { useNetwork } from "../../contexts/NetworkContext";
import { refreshHouseholdCache, refreshPatientCache, refreshVisitCache } from "../../services/cacheRefresh";
import { AppShell } from "./AppShell";
import type { NavItem } from "./Sidebar";

const NAV_ITEMS: NavItem[] = [
  { to: "/chw", label: "Home", icon: Home, end: true },
  { to: "/patients", label: "Patients", icon: Users },
  { to: "/visits", label: "Visits", icon: Stethoscope },
  { to: "/sync", label: "Sync", icon: RefreshCw },
];

// Shared shell for every CHW-facing screen - one Sidebar/MobileTopBar/
// MobileBottomNav and cache-refresh so they stay consistent across screens,
// instead of each screen reimplementing them. Rendered as a layout route
// (see App.tsx) so it mounts once and persists via <Outlet /> across CHW
// screen navigation, rather than remounting on every page.
function ChwLayout() {
  const session = authService.getSession();
  const { isOnline } = useNetwork();

  // Login already refreshes the cache once (see authService.login); this
  // covers connectivity returning while already in the app - e.g. the demo
  // network toggle flipping back to Online - extended to cached read data
  // too, not just pushing pending edits.
  useEffect(() => {
    if (isOnline) {
      void refreshHouseholdCache();
      void refreshPatientCache();
      void refreshVisitCache();
    }
  }, [isOnline]);

  return (
    <AppShell
      navItems={NAV_ITEMS}
      mobileNavItems={NAV_ITEMS}
      userName={session?.chw.full_name ?? ""}
      userSubtitle={session?.chw.clinic ?? ""}
    >
      <Outlet />
    </AppShell>
  );
}

export default ChwLayout;
