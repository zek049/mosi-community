// Household codes are made on the device (so households work offline):
// a 3-letter village prefix + 6 random characters, e.g. "MBA-7Q2K9X".
// The alphabet leaves out look-alikes (0/O, 1/I/L) so codes can be read out
// and written down reliably. 31^6 (~887 million) combinations per prefix:
// even 10,000 households sharing a prefix have a ~5% chance of ANY clash
// (birthday bound n^2/2N). 4 characters (~0.9 million) was too few - 2,000
// codes already clash about twice. The server enforces uniqueness; on the
// rare clash the device picks a new code and retries (syncService.ts), so
// nothing is lost.
const ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ";

export const HOUSEHOLD_CODE_PATTERN = /^[A-Za-z0-9-]{3,40}$/;

export function villagePrefix(village: string): string {
  const letters = village
    .normalize("NFKD")
    .replace(/\p{M}/gu, "")
    .replace(/[^A-Za-z]/g, "")
    .toUpperCase();
  return (letters + "XXX").slice(0, 3);
}

export function generateHouseholdCode(
  village: string,
  random: (buffer: Uint32Array) => Uint32Array = (b) => crypto.getRandomValues(b),
): string {
  const values = random(new Uint32Array(6));
  const suffix = Array.from(values, (v) => ALPHABET[v % ALPHABET.length]).join("");
  return `${villagePrefix(village)}-${suffix}`;
}
