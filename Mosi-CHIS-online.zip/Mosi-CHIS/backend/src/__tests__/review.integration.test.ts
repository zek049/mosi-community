import { beforeEach, describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  process.env.JWT_SECRET = "test-secret-for-integration-tests";
});

const m = vi.hoisted(() => ({
  scope: { value: undefined as string | undefined },
  chwFindUnique: vi.fn(),
  chwFindMany: vi.fn(),
  patientFindUnique: vi.fn(),
  patientFindMany: vi.fn(),
  patientCreate: vi.fn(),
  patientUpdate: vi.fn(),
  patientUpdateMany: vi.fn(),
  patientCount: vi.fn(),
  patientGroupBy: vi.fn(),
  visitFindUnique: vi.fn(),
  visitFindMany: vi.fn(),
  visitCreate: vi.fn(),
  visitUpdate: vi.fn(),
  visitUpdateMany: vi.fn(),
  visitCount: vi.fn(),
  auditLogCreate: vi.fn(),
  auditLogCreateMany: vi.fn(),
  auditLogFindMany: vi.fn(),
  syncLogCreate: vi.fn(),
  syncLogGroupBy: vi.fn(),
  syncConflictCount: vi.fn(),
  clinicFindMany: vi.fn(),
  transaction: vi.fn(),
}));

vi.mock("../db", () => ({
  prisma: {
    chw: { findUnique: m.chwFindUnique, findMany: m.chwFindMany, count: vi.fn().mockResolvedValue(3) },
    patient: { findUnique: m.patientFindUnique, findMany: m.patientFindMany, create: m.patientCreate, update: m.patientUpdate, updateMany: m.patientUpdateMany, count: m.patientCount, groupBy: m.patientGroupBy },
    visit: { findUnique: m.visitFindUnique, findMany: m.visitFindMany, create: m.visitCreate, update: m.visitUpdate, updateMany: m.visitUpdateMany, count: m.visitCount },
    auditLog: { create: m.auditLogCreate, createMany: m.auditLogCreateMany, findMany: m.auditLogFindMany },
    syncLog: { create: m.syncLogCreate, groupBy: m.syncLogGroupBy },
    syncConflict: { count: m.syncConflictCount },
    clinic: { findMany: m.clinicFindMany },
    household: { findUnique: vi.fn().mockResolvedValue(null) },
    $transaction: m.transaction,
  },
}));

// Supervisors are organisation-wide until the admin-role feature scopes
// them; these tests drive clinicScope() directly to prove the review routes
// honour whatever scope it returns.
vi.mock("../middleware/authz", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../middleware/authz")>();
  return { ...actual, clinicScope: (actor: { role: string; clinicId: string }) => (actor.role === "SUPERVISOR" ? m.scope.value : actor.clinicId) };
});

import request from "supertest";
import app from "../app";
import { signSessionToken } from "../middleware/auth";

const supAuth = { Authorization: `Bearer ${signSessionToken({ chwId: "SUP001", role: "SUPERVISOR", fullName: "Grace" })}` };
const chwAuth = { Authorization: `Bearer ${signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Jane" })}` };
const P = "11111111-1111-4111-8111-111111111111";
const V = "22222222-2222-4222-8222-222222222222";
const t = (s: string) => new Date(s);

const basePatient = {
  id: P,
  patient_id: "MBR-9001",
  first_name: "Rudo",
  last_name: "Moyo",
  date_of_birth: t("1990-01-01T00:00:00Z"),
  gender: "F",
  village: "Mbare",
  phone_number: null,
  clinic_id: "clinic-a",
  registered_by_chw_id: "CHW001",
  created_at: t("2026-10-05T08:00:00Z"),
  updated_at: t("2026-10-05T08:00:00Z"),
  deleted_at: null,
  household_id: null,
  review_status: "awaiting_review",
  review_flag_reason: null,
  reviewed_at: null,
  reviewed_by: null,
};

beforeEach(() => {
  vi.clearAllMocks();
  m.scope.value = undefined;
  m.chwFindUnique.mockImplementation(async ({ where }: { where: { chw_id: string } }) => ({
    chw_id: where.chw_id,
    role: where.chw_id.startsWith("SUP") ? "SUPERVISOR" : "CHW",
    status: "active",
    locked_until: null,
    clinic_id: "clinic-a",
    must_change_pin: false,
  }));
  m.chwFindMany.mockResolvedValue([{ chw_id: "CHW001", full_name: "Jane Moyo" }, { chw_id: "SUP001", full_name: "Grace" }]);
  m.auditLogCreate.mockResolvedValue({});
  m.auditLogCreateMany.mockResolvedValue({ count: 0 });
  m.auditLogFindMany.mockResolvedValue([]);
  m.syncLogCreate.mockResolvedValue({});
  m.transaction.mockImplementation(async (ops: unknown[]) => Promise.all(ops));
  m.patientUpdateMany.mockResolvedValue({ count: 1 });
  m.visitUpdateMany.mockResolvedValue({ count: 1 });
  m.patientCreate.mockImplementation(async ({ data }: { data: unknown }) => data);
  m.patientUpdate.mockImplementation(async ({ data }: { data: unknown }) => data);
  m.visitCreate.mockImplementation(async ({ data }: { data: unknown }) => data);
  m.visitUpdate.mockImplementation(async ({ data }: { data: unknown }) => data);
});

describe("access", () => {
  it("401 without a session; 403 for a CHW on every review endpoint", async () => {
    expect((await request(app).get("/api/review/pending")).status).toBe(401);
    for (const [method, path] of [
      ["get", "/api/review/pending"],
      ["get", "/api/review/flagged"],
      ["post", `/api/review/patients/${P}/confirm`],
      ["post", `/api/review/patients/${P}/flag`],
      ["post", `/api/review/visits/${V}/confirm`],
      ["post", `/api/review/visits/${V}/flag`],
    ] as const) {
      const res = await request(app)[method](path).set(chwAuth).send({ reason: "x x x" });
      expect(res.status, path).toBe(403);
    }
    expect(m.patientUpdateMany).not.toHaveBeenCalled();
  });
});

describe("what new and edited records become", () => {
  it("a CHW's new patient via sync is awaiting_review (and the result says so)", async () => {
    m.patientFindUnique.mockResolvedValue(null);
    const now = new Date().toISOString();
    const res = await request(app).post("/api/sync").set(chwAuth).send({ patients: [{ id: P, patient_id: "MBR-9001", first_name: "Rudo", last_name: "Moyo", date_of_birth: "1990-01-01", gender: "F", village: "Mbare", created_at: now, updated_at: now }], visits: [] });
    expect(res.body.data.patients[0]).toMatchObject({ status: "synced", reason: "created", review_status: "awaiting_review" });
    expect(m.patientCreate.mock.calls[0][0].data.review_status).toBe("awaiting_review");
  });

  it("a CHW can't confirm its own record by putting review fields in the sync payload", async () => {
    m.patientFindUnique.mockResolvedValue(null);
    const now = new Date().toISOString();
    const res = await request(app).post("/api/sync").set(chwAuth).send({ patients: [{ id: P, patient_id: "MBR-9001", first_name: "Rudo", last_name: "Moyo", date_of_birth: "1990-01-01", gender: "F", village: "Mbare", created_at: now, updated_at: now, review_status: "confirmed", reviewed_by: "SUP001", reviewed_at: now }], visits: [] });
    expect(res.body.data.patients[0].review_status).toBe("awaiting_review");
    const data = m.patientCreate.mock.calls[0][0].data;
    expect(data.review_status).toBe("awaiting_review");
    expect(data).not.toHaveProperty("reviewed_by");
  });

  it("a supervisor's new visit (online) is confirmed", async () => {
    m.patientFindUnique.mockResolvedValue(basePatient);
    m.chwFindUnique.mockImplementation(async ({ where }: { where: { chw_id: string } }) => ({ chw_id: where.chw_id, role: where.chw_id.startsWith("SUP") ? "SUPERVISOR" : "CHW", status: "active", locked_until: null, clinic_id: "clinic-a", must_change_pin: false }));
    const res = await request(app).post("/api/visits").set(supAuth).send({ id: V, patient_id: P, chw_id: "CHW001", visit_date: "2026-10-05", visit_type: "Antenatal" });
    expect(res.status).toBe(201);
    expect(m.visitCreate.mock.calls[0][0].data).toMatchObject({ review_status: "confirmed", reviewed_by: "SUP001" });
  });

  it("each record a sync creates is audited with the CHW and the sync's request id (submitted by / batch)", async () => {
    m.patientFindUnique.mockResolvedValue(null);
    const now = new Date().toISOString();
    await request(app).post("/api/sync").set(chwAuth).send({ patients: [{ id: P, patient_id: "MBR-9001", first_name: "Rudo", last_name: "Moyo", date_of_birth: "1990-01-01", gender: "F", village: "Mbare", created_at: now, updated_at: now }], visits: [] });
    const entries = m.auditLogCreateMany.mock.calls[0][0].data;
    expect(entries).toEqual([expect.objectContaining({ actor_id: "CHW001", action: "PATIENT_CREATED", resource_type: "patient", resource_id: P, request_id: expect.any(String) })]);
    const started = m.auditLogCreate.mock.calls.map((c) => c[0].data).find((d) => d.action === "SYNC_STARTED");
    expect(started.request_id).toBe(entries[0].request_id);
  });

  it("a supervisor's new patient is confirmed, stamped with the supervisor", async () => {
    m.patientFindUnique.mockResolvedValue(null);
    const res = await request(app).post("/api/patients").set(supAuth).send({ id: P, patient_id: "MBR-9001", first_name: "Rudo", last_name: "Moyo", date_of_birth: "1990-01-01", gender: "F", village: "Mbare" });
    expect(res.status).toBe(201);
    expect(m.patientCreate.mock.calls[0][0].data).toMatchObject({ review_status: "confirmed", reviewed_by: "SUP001" });
  });

  it("a CHW's new patient via the online route is awaiting_review", async () => {
    m.patientFindUnique.mockResolvedValue(null);
    await request(app).post("/api/patients").set(chwAuth).send({ id: P, patient_id: "MBR-9001", first_name: "Rudo", last_name: "Moyo", date_of_birth: "1990-01-01", gender: "F", village: "Mbare" });
    expect(m.patientCreate.mock.calls[0][0].data.review_status).toBe("awaiting_review");
  });

  it.each(["confirmed", "flagged"])("editing a %s patient (sync) sends it back to awaiting_review and keeps the flag reason + reviewer", async (status) => {
    m.patientFindUnique.mockResolvedValue({ ...basePatient, review_status: status, review_flag_reason: status === "flagged" ? "Wrong DOB" : null, reviewed_at: t("2026-10-04T10:00:00Z"), reviewed_by: "SUP001" });
    const later = new Date().toISOString();
    const res = await request(app).post("/api/sync").set(chwAuth).send({ patients: [{ ...basePatient, date_of_birth: "1991-01-01", created_at: basePatient.created_at.toISOString(), updated_at: later }], visits: [] });
    expect(res.body.data.patients[0]).toMatchObject({ reason: "updated", review_status: "awaiting_review" });
    const data = m.patientUpdate.mock.calls[0][0].data;
    expect(data.review_status).toBe("awaiting_review");
    // History isn't wiped: these aren't in the update at all.
    expect(data).not.toHaveProperty("review_flag_reason");
    expect(data).not.toHaveProperty("reviewed_at");
    expect(data).not.toHaveProperty("reviewed_by");
  });

  it("editing a confirmed visit (online PUT) sends it back to awaiting_review", async () => {
    m.visitFindUnique.mockResolvedValue({ id: V, patient_id: P, chw_id: "CHW001", clinic_id: "clinic-a", deleted_at: null, review_status: "confirmed" });
    m.patientFindUnique.mockResolvedValue(basePatient);
    await request(app).put(`/api/visits/${V}`).set(chwAuth).send({ notes: "Corrected" });
    expect(m.visitUpdate.mock.calls[0][0].data.review_status).toBe("awaiting_review");
    expect(m.visitUpdate.mock.calls[0][0].data).not.toHaveProperty("review_flag_reason");
  });

  it("re-sending identical content changes nothing - a confirmed record stays confirmed", async () => {
    m.patientFindUnique.mockResolvedValue({ ...basePatient, review_status: "confirmed" });
    const res = await request(app).post("/api/sync").set(chwAuth).send({ patients: [{ ...basePatient, date_of_birth: "1990-01-01", created_at: basePatient.created_at.toISOString(), updated_at: basePatient.updated_at.toISOString() }], visits: [] });
    expect(res.body.data.patients[0]).toMatchObject({ status: "synced", reason: "identical", review_status: "confirmed" });
    expect(m.patientUpdate).not.toHaveBeenCalled();
    expect(m.auditLogCreateMany).not.toHaveBeenCalled();
  });
});

describe("GET /api/review/pending", () => {
  it("returns awaiting records grouped by CHW, then by sync batch, with submitter, time and details", async () => {
    m.patientFindMany.mockResolvedValue([basePatient]);
    m.visitFindMany.mockResolvedValue([
      { id: V, patient_id: P, chw_id: "CHW001", visit_date: t("2026-10-05T00:00:00Z"), visit_type: "Antenatal", weight: 61, height: null, blood_pressure: "118/76", notes: null, clinic_id: "clinic-a", created_at: t("2026-10-05T08:05:00Z"), updated_at: t("2026-10-05T08:05:00Z"), review_status: "awaiting_review", review_flag_reason: "Missing weight", reviewed_at: t("2026-10-04T09:00:00Z"), reviewed_by: "SUP001", patient: { id: P, patient_id: "MBR-9001", first_name: "Rudo", last_name: "Moyo", village: "Mbare" } },
    ]);
    m.auditLogFindMany.mockImplementation(async ({ where }: { where: { action: unknown } }) =>
      where.action === "SYNC_STARTED"
        ? [{ request_id: "req-1", created_at: t("2026-10-05T09:00:00Z"), metadata: { batch_id: "device-batch-7" } }]
        : [
            { resource_id: P, actor_id: "CHW001", created_at: t("2026-10-05T09:00:01Z"), action: "PATIENT_CREATED", request_id: "req-1" },
            { resource_id: V, actor_id: "CHW001", created_at: t("2026-10-05T09:00:02Z"), action: "VISIT_UPDATED", request_id: "req-1" },
          ],
    );
    const res = await request(app).get("/api/review/pending").set(supAuth);
    expect(res.status).toBe(200);
    const d = res.body.data;
    expect(d).toMatchObject({ total: 2, counts: { patients: 1, visits: 1 } });
    expect(d.groups).toHaveLength(1);
    expect(d.groups[0].chw).toEqual({ chw_id: "CHW001", full_name: "Jane Moyo" });
    expect(d.groups[0].batches).toHaveLength(1);
    const batch = d.groups[0].batches[0];
    expect(batch).toMatchObject({ via: "sync", device_batch_id: "device-batch-7", sent_at: "2026-10-05T09:00:00.000Z" });
    expect(batch.items.map((i: { record_type: string; submission: string }) => [i.record_type, i.submission])).toEqual([["patient", "new"], ["visit", "edit"]]);
    expect(batch.items[1].visit).toMatchObject({ visit_type: "Antenatal", blood_pressure: "118/76" });
    expect(batch.items[1].patient).toMatchObject({ first_name: "Rudo" });
    expect(batch.items[1].previous_review).toEqual({ flag_reason: "Missing weight", reviewed_at: "2026-10-04T09:00:00.000Z" });
  });

  it("asks only for live awaiting_review rows, limited to the reviewer's clinic scope", async () => {
    m.scope.value = "clinic-a";
    m.patientFindMany.mockResolvedValue([]);
    m.visitFindMany.mockResolvedValue([]);
    await request(app).get("/api/review/pending").set(supAuth);
    for (const call of [m.patientFindMany.mock.calls[0][0], m.visitFindMany.mock.calls[0][0]]) {
      expect(call.where).toEqual({ deleted_at: null, review_status: "awaiting_review", clinic_id: "clinic-a" });
    }
  });

  it("records entered online (no sync request) are their own batch, marked online", async () => {
    m.patientFindMany.mockResolvedValue([basePatient]);
    m.visitFindMany.mockResolvedValue([]);
    const res = await request(app).get("/api/review/pending").set(supAuth);
    expect(res.body.data.groups[0].batches[0]).toMatchObject({ via: "online", device_batch_id: null });
  });
});

describe("confirm / flag", () => {
  it("confirm: awaiting -> confirmed, stamps reviewer + time, keeps flag reason, never touches updated_at, audited", async () => {
    m.patientFindUnique.mockResolvedValue({ clinic_id: "clinic-a", review_status: "awaiting_review", deleted_at: null });
    const res = await request(app).post(`/api/review/patients/${P}/confirm`).set(supAuth).send({});
    expect(res.status).toBe(200);
    expect(res.body.data).toMatchObject({ review_status: "confirmed", reviewed_by: "SUP001" });
    const call = m.patientUpdateMany.mock.calls[0][0];
    expect(call.where).toEqual({ id: P, review_status: "awaiting_review", deleted_at: null });
    expect(call.data).toEqual({ review_status: "confirmed", reviewed_at: expect.any(Date), reviewed_by: "SUP001" });
    expect(call.data).not.toHaveProperty("updated_at");
    const audit = m.auditLogCreate.mock.calls.map((c) => c[0].data).find((d) => d.action === "RECORD_CONFIRMED");
    expect(audit).toMatchObject({ actor_id: "SUP001", resource_type: "patient", resource_id: P, metadata: { from: "awaiting_review", clinic_id: "clinic-a" } });
  });

  it("flag a visit with a reason: stored with reviewer + time, audited", async () => {
    m.visitFindUnique.mockResolvedValue({ clinic_id: "clinic-a", review_status: "awaiting_review", deleted_at: null });
    const res = await request(app).post(`/api/review/visits/${V}/flag`).set(supAuth).send({ reason: "  Weight looks wrong - recheck  " });
    expect(res.status).toBe(200);
    expect(m.visitUpdateMany.mock.calls[0][0].data).toEqual({ review_status: "flagged", review_flag_reason: "Weight looks wrong - recheck", reviewed_at: expect.any(Date), reviewed_by: "SUP001" });
    expect(m.auditLogCreate.mock.calls.map((c) => c[0].data.action)).toContain("RECORD_FLAGGED");
  });

  it.each([[{}], [{ reason: "" }], [{ reason: "  " }], [{ reason: "ok" }], [{ reason: "x".repeat(501) }], [{ reason: 5 }], [{ reason: "fine reason", extra: 1 }]])("flag without a usable reason -> 400, nothing changed (%j)", async (body) => {
    m.patientFindUnique.mockResolvedValue({ clinic_id: "clinic-a", review_status: "awaiting_review", deleted_at: null });
    const res = await request(app).post(`/api/review/patients/${P}/flag`).set(supAuth).send(body);
    expect(res.status).toBe(400);
    expect(m.patientUpdateMany).not.toHaveBeenCalled();
  });

  it("a flagged record can be confirmed after follow-up (reason kept)", async () => {
    m.patientFindUnique.mockResolvedValue({ clinic_id: "clinic-a", review_status: "flagged", deleted_at: null });
    const res = await request(app).post(`/api/review/patients/${P}/confirm`).set(supAuth).send({});
    expect(res.status).toBe(200);
    expect(m.patientUpdateMany.mock.calls[0][0].data).not.toHaveProperty("review_flag_reason");
  });

  it.each([
    ["confirm", "confirmed", "already confirmed"],
    ["flag", "flagged", "already flagged"],
  ])("invalid transition: %s a record that is %s -> 409, nothing changed", async (action, status, text) => {
    m.patientFindUnique.mockResolvedValue({ clinic_id: "clinic-a", review_status: status, deleted_at: null });
    const res = await request(app).post(`/api/review/patients/${P}/${action}`).set(supAuth).send(action === "flag" ? { reason: "Wrong village" } : {});
    expect(res.status).toBe(409);
    expect(res.body.code).toBe("INVALID_REVIEW_TRANSITION");
    expect(res.body.message).toContain(text);
    expect(m.patientUpdateMany).not.toHaveBeenCalled();
  });

  it("someone else decided first (status changed between read and write) -> 409, not a silent overwrite", async () => {
    m.patientFindUnique.mockResolvedValue({ clinic_id: "clinic-a", review_status: "awaiting_review", deleted_at: null });
    m.patientUpdateMany.mockResolvedValue({ count: 0 });
    const res = await request(app).post(`/api/review/patients/${P}/confirm`).set(supAuth).send({});
    expect(res.status).toBe(409);
    expect(res.body.code).toBe("REVIEW_STALE");
    expect(m.auditLogCreate.mock.calls.map((c) => c[0].data.action)).not.toContain("RECORD_CONFIRMED");
  });

  it("unknown, archived, or another clinic's record -> 404 (scope can't be probed)", async () => {
    m.scope.value = "clinic-a";
    for (const record of [null, { clinic_id: "clinic-a", review_status: "awaiting_review", deleted_at: new Date() }, { clinic_id: "clinic-b", review_status: "awaiting_review", deleted_at: null }]) {
      m.visitFindUnique.mockResolvedValue(record);
      const res = await request(app).post(`/api/review/visits/${V}/confirm`).set(supAuth).send({});
      expect(res.status).toBe(404);
    }
    expect(m.visitUpdateMany).not.toHaveBeenCalled();
  });

  it("confirm accepts no body fields (strict)", async () => {
    m.patientFindUnique.mockResolvedValue({ clinic_id: "clinic-a", review_status: "awaiting_review", deleted_at: null });
    expect((await request(app).post(`/api/review/patients/${P}/confirm`).set(supAuth).send({ review_status: "confirmed" })).status).toBe(400);
  });
});

describe("GET /api/review/flagged", () => {
  it("lists flagged records with reason, who flagged and when, and the submitting CHW", async () => {
    m.patientFindMany.mockResolvedValue([{ ...basePatient, review_status: "flagged", review_flag_reason: "Wrong DOB", reviewed_at: t("2026-10-05T10:00:00Z"), reviewed_by: "SUP001" }]);
    m.visitFindMany.mockResolvedValue([]);
    const res = await request(app).get("/api/review/flagged").set(supAuth);
    expect(res.body.data.items[0]).toMatchObject({ record_type: "patient", flag_reason: "Wrong DOB", flagged_by_name: "Grace", chw_name: "Jane Moyo" });
    expect(m.patientFindMany.mock.calls[0][0].where).toMatchObject({ review_status: "flagged", deleted_at: null });
  });
});

describe("dashboard statistics", () => {
  it("headline numbers count confirmed records only; awaiting review and flagged reported separately", async () => {
    m.patientCount.mockImplementation(async ({ where }: { where: { review_status?: string } }) => ({ confirmed: 75, awaiting_review: 2, flagged: 1 })[where.review_status ?? ""] ?? 0);
    m.visitCount.mockImplementation(async ({ where }: { where: { review_status?: string } }) => ({ confirmed: 184, awaiting_review: 5, flagged: 0 })[where.review_status ?? ""] ?? 0);
    m.patientGroupBy.mockResolvedValue([]);
    m.clinicFindMany.mockResolvedValue([]);
    m.visitFindMany.mockResolvedValue([]);
    m.syncLogGroupBy.mockResolvedValue([]);
    m.syncConflictCount.mockResolvedValue(0);
    const res = await request(app).get("/api/dashboard/stats").set(supAuth);
    expect(res.status).toBe(200);
    expect(res.body.data).toMatchObject({ patients: 75, visits: 184, awaitingReview: { patients: 2, visits: 5 }, flagged: { patients: 1, visits: 0 } });
    // Every patient/visit query on the dashboard states its review filter.
    for (const call of [...m.patientCount.mock.calls, ...m.visitCount.mock.calls, ...m.patientGroupBy.mock.calls, ...m.visitFindMany.mock.calls]) {
      expect(call[0].where.review_status, JSON.stringify(call[0].where)).toBeDefined();
    }
  });
});
