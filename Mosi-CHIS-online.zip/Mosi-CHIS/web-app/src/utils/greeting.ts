// Shared by CHW Home and Supervisor Dashboard (section 21's "Good morning,
// [name]" example applies to both).
export function getGreeting(date: Date = new Date()): string {
  const hour = date.getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}
