import type { LucideIcon } from "lucide-react";
import { Card } from "./Card";

type EmptyStateProps = {
  icon: LucideIcon;
  title: string;
  description?: string;
};

// One consistent "nothing here" treatment (no patients match your filters,
// no visits yet, no CHW accounts...) instead of every list screen writing
// its own short paragraph.
export function EmptyState({ icon: Icon, title, description }: EmptyStateProps) {
  return (
    <Card className="flex flex-col items-center gap-2 py-12 text-center">
      <span className="flex h-11 w-11 items-center justify-center rounded-full bg-stone-100 text-stone-400">
        <Icon className="h-5 w-5" aria-hidden="true" />
      </span>
      <p className="text-sm font-medium text-stone-700">{title}</p>
      {description && <p className="text-sm text-stone-500 max-w-xs">{description}</p>}
    </Card>
  );
}
