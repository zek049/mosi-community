-- Feature 10 - administrator role. Additive: existing CHW/SUPERVISOR rows
-- are unchanged. Kept as its own migration on purpose: Postgres can't use a
-- newly added enum value inside the transaction that adds it, so any data
-- step that assigns ADMIN must run separately (see prisma/seed.ts and
-- prisma/scripts/promoteAdmin.ts).
ALTER TYPE "Role" ADD VALUE IF NOT EXISTS 'ADMIN';
