import "fake-indexeddb/auto";
import Dexie from "dexie";
import { beforeEach, describe, expect, it, vi } from "vitest";

// Minimal browser globals for authService (it runs in the browser normally).
function memoryStorage() {
  const m = new Map<string, string>();
  return {
    getItem: (k: string) => m.get(k) ?? null,
    setItem: (k: string, v: string) => void m.set(k, String(v)),
    removeItem: (k: string) => void m.delete(k),
    clear: () => m.clear(),
    key: (i: number) => [...m.keys()][i] ?? null,
    get length() { return m.size; },
    keys: () => [...m.keys()],
  };
}
const local = memoryStorage();
const session = memoryStorage();
vi.stubGlobal("localStorage", local);
vi.stubGlobal("sessionStorage", session);
vi.stubGlobal("window", { dispatchEvent: () => true, addEventListener: () => {}, removeEventListener: () => {} });

const apiLogout = vi.hoisted(() => vi.fn(async () => undefined));
vi.mock("../api", async (orig) => ({ ...(await orig<typeof import("../api")>()), logout: apiLogout }));

import * as store from "../../db/indexedDb";
import * as authService from "../authService";
import { queryClient } from "../../lib/queryClient";

const now = new Date().toISOString();
function signInAs(chwId: string) {
  local.setItem("mosi.session", JSON.stringify({ chw: { chw_id: chwId, full_name: chwId, clinic: "C", role: "CHW" } }));
  local.setItem(`mosi.lastSyncAt.${chwId}`, now);
  store.switchDatabaseTo(chwId);
}

beforeEach(async () => {
  local.clear();
  session.clear();
  queryClient.clear();
  store.switchDatabaseTo(null);
  for (const name of await Dexie.getDatabaseNames()) await Dexie.delete(name);
});

describe("signOut", () => {
  it("clears the local session, per-user sync time, and all cached server data", async () => {
    signInAs("SUP001");
    queryClient.setQueryData(["dashboardStats"], { patients: 75 });
    queryClient.setQueryData(["chws"], [{ chw_id: "CHW001" }]);
    await authService.signOut();
    expect(authService.getSession()).toBeNull();
    expect(local.getItem("mosi.lastSyncAt.SUP001")).toBeNull();
    expect(queryClient.getQueryCache().getAll()).toHaveLength(0);
    expect(apiLogout).toHaveBeenCalled();
  });

  it("keeps unsynced records by default and reports how many", async () => {
    signInAs("CHW001");
    await store.db.patients.put({ id: "p", patient_id: "P", first_name: "A", last_name: "B", date_of_birth: "1990-01-01", gender: "F", village: "V", phone_number: null, created_at: now, updated_at: now, sync_status: "pending" });
    expect(await authService.signOut()).toEqual({ keptUnsynced: 1 });
    expect(authService.readSignOutNotice()).toEqual({ keptUnsynced: 1 });
    expect(await Dexie.exists(store.dbNameFor("CHW001"))).toBe(true);
  });

  it("'wipe' removes the account's whole local database, unsynced records included", async () => {
    signInAs("CHW001");
    await store.db.patients.put({ id: "p", patient_id: "P", first_name: "A", last_name: "B", date_of_birth: "1990-01-01", gender: "F", village: "V", phone_number: null, created_at: now, updated_at: now, sync_status: "pending" });
    await authService.signOut("wipe");
    expect(await Dexie.exists(store.dbNameFor("CHW001"))).toBe(false);
    expect(authService.getSession()).toBeNull();
    // Only non-personal preferences may remain in localStorage.
    expect(local.keys().filter((k) => !["mosi.demoNetwork", "mosi.installBannerDismissed"].includes(k))).toEqual([]);
  });

  it("after sign-out the app no longer points at the previous user's database", async () => {
    signInAs("CHW001");
    await authService.signOut();
    expect(store.db.name).not.toBe(store.dbNameFor("CHW001"));
  });
});
