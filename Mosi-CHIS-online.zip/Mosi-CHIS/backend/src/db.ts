import { PrismaClient } from "@prisma/client";

// Load backend/.env if present. Safe to skip if it's missing (e.g. the
// process was started with environment variables already set some other
// way) - fall back to the default DATABASE_URL below instead.
try {
  process.loadEnvFile();
} catch {
  // No .env file found; continue with whatever is already in process.env.
}

// Matches the postgres service in the root docker-compose.yml, so the API
// can start with zero configuration once that container is running. Port
// 5433 (not 5432) avoids clashing with a native PostgreSQL install, if one
// happens to be running locally.
process.env.DATABASE_URL ??= "postgresql://mosi:mosi@localhost:5433/mosi";

declare global {
  // eslint-disable-next-line no-var
  var __mosiPrisma: PrismaClient | undefined;
}

// Reuse a single PrismaClient across ts-node/tsx hot reloads in development
// so repeated file saves don't open a new pool of database connections.
export const prisma = globalThis.__mosiPrisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  globalThis.__mosiPrisma = prisma;
}
