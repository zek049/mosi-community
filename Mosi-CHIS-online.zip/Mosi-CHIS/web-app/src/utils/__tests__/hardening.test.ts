import { describe, expect, it } from "vitest";
import { syncingLabel, syncPausedMessage, syncResultMessage, syncStartAnnouncement } from "../syncMessages";
import { generatePin, validatePinReset } from "../validators";
import { readPublicContact } from "../../config/contact";
import { ApiError, parseRetryAfter } from "../../services/api";

const outcome = (synced: number, conflicts = 0, failed = 0) => ({ attempted: synced + conflicts + failed, synced, conflicts, failed });

describe("sync status messages (batch-level only - no invented progress)", () => {
  it("zero pending: nothing to send", () => {
    expect(syncStartAnnouncement(0)).toBeNull();
    expect(syncingLabel(0)).toBe("Checking with the server…");
    expect(syncResultMessage(outcome(0))).toBe("Everything is up to date.");
  });
  it("one pending change", () => {
    expect(syncingLabel(1)).toBe("Syncing 1 change…");
    expect(syncStartAnnouncement(1)).toBe("Syncing 1 change.");
    expect(syncResultMessage(outcome(1))).toBe("1 change synced.");
  });
  it("several pending changes", () => {
    expect(syncingLabel(3)).toBe("Syncing 3 changes…");
    expect(syncResultMessage(outcome(3))).toBe("3 changes synced.");
  });
  it("never shows 'N of M' progress", () => {
    for (const n of [1, 2, 12]) expect(syncingLabel(n)).not.toMatch(/\bof\b|%/);
  });
  it("partial results report the server's real counts", () => {
    expect(syncResultMessage(outcome(2, 1))).toBe("2 changes synced. 1 change needs review.");
    expect(syncResultMessage(outcome(2, 0, 1))).toBe("2 changes synced. 1 change couldn't sync and is still waiting.");
    expect(syncResultMessage(outcome(0, 0, 2))).toBe("2 changes couldn't sync and are still waiting.");
    expect(syncResultMessage(outcome(0, 2))).toBe("2 changes need review.");
  });
  it("offline interruption / no answer: paused, with what's still waiting", () => {
    expect(syncPausedMessage(1)).toBe("Sync paused. 1 change is still waiting.");
    expect(syncPausedMessage(4)).toBe("Sync paused. 4 changes are still waiting.");
    expect(syncPausedMessage(0)).toBe("Sync paused.");
  });
});

describe("PIN reset validation", () => {
  it("requires exactly 4 digits", () => {
    expect(validatePinReset("", "").pin).toBeDefined();
    expect(validatePinReset("123", "123").pin).toBeDefined();
    expect(validatePinReset("12a4", "12a4").pin).toBeDefined();
    expect(validatePinReset("4821", "4821")).toEqual({});
  });
  it("catches a mistyped confirmation", () => {
    expect(validatePinReset("4821", "4812").confirm).toMatch(/don't match/);
  });
  it("generates 4 digits, keeping leading zeros", () => {
    expect(generatePin((b) => { b[0] = 7; return b; })).toBe("0007");
    expect(generatePin((b) => { b[0] = 123456; return b; })).toBe("3456");
    for (let i = 0; i < 50; i++) expect(generatePin()).toMatch(/^\d{4}$/);
  });
});

describe("public contact configuration", () => {
  it("shows nothing invented when unset or invalid", () => {
    expect(readPublicContact({})).toBeNull();
    expect(readPublicContact({ VITE_PUBLIC_CONTACT_EMAIL: "" })).toBeNull();
    expect(readPublicContact({ VITE_PUBLIC_CONTACT_EMAIL: "not an email" })).toBeNull();
  });
  it("uses the configured address and name", () => {
    expect(readPublicContact({ VITE_PUBLIC_CONTACT_EMAIL: " help@example.org ", VITE_PUBLIC_CONTACT_NAME: "Pilot support" })).toEqual({
      email: "help@example.org",
      name: "Pilot support",
    });
    expect(readPublicContact({ VITE_PUBLIC_CONTACT_EMAIL: "help@example.org" })?.name).toBe("the Mosi team");
  });
});

describe("rate-limit handling", () => {
  it("reads Retry-After in seconds or as a date", () => {
    expect(parseRetryAfter(null)).toBeNull();
    expect(parseRetryAfter("42")).toBe(42);
    const now = Date.parse("2026-09-24T10:00:00Z");
    expect(parseRetryAfter("Thu, 24 Sep 2026 10:00:30 GMT", now)).toBe(30);
    expect(parseRetryAfter("nonsense")).toBeNull();
  });
  it("keeps the wait on the error", () => {
    expect(new ApiError(429, "slow down", 17).retryAfterSeconds).toBe(17);
  });
});

describe("account request form validation (mirrors the server schema)", () => {
  const ok = { full_name: "New Person", chw_id: "CHW555", clinic_id: "c1", phone_number: "", pin: "4821", confirm: "4821" };
  it("accepts a complete request (phone optional)", async () => {
    const { validateAccountRequest } = await import("../validators");
    expect(validateAccountRequest(ok)).toEqual({});
    expect(validateAccountRequest({ ...ok, phone_number: "0771234567" })).toEqual({});
  });
  it("names each problem", async () => {
    const { validateAccountRequest } = await import("../validators");
    const e = validateAccountRequest({ full_name: " ", chw_id: "a b", clinic_id: "", phone_number: "123", pin: "12", confirm: "" });
    expect(Object.keys(e).sort()).toEqual(["chw_id", "clinic_id", "full_name", "phone_number", "pin"]);
    expect(validateAccountRequest({ ...ok, confirm: "4822" }).confirm).toMatch(/don't match/);
    expect(validateAccountRequest({ ...ok, chw_id: "X".repeat(21) }).chw_id).toBeDefined();
  });
});

describe("PIN policy (mirrors backend/src/utils/pinPolicy.ts)", () => {
  it("flags guessable PINs, accepts ordinary ones", async () => {
    const { isWeakPin } = await import("../validators");
    for (const pin of ["1234", "0000", "9999", "0123", "6789", "9876", "4321", "2580", "1212"]) expect(isWeakPin(pin)).toBe(true);
    for (const pin of ["5739", "8264", "4821", "3071"]) expect(isWeakPin(pin)).toBe(false);
  });
  it("change-PIN validation: current required, new must differ, not guessable, confirmed", async () => {
    const { validateChangePin } = await import("../validators");
    expect(validateChangePin("5739", "8264", "8264")).toEqual({});
    expect(validateChangePin("", "8264", "8264").current).toBeDefined();
    expect(validateChangePin("5739", "5739", "5739").pin).toMatch(/different/);
    expect(validateChangePin("5739", "1234", "1234").pin).toMatch(/too easy/);
    expect(validateChangePin("5739", "8264", "8265").confirm).toMatch(/don't match/);
  });
  it("account requests also refuse guessable PINs", async () => {
    const { validateAccountRequest } = await import("../validators");
    expect(validateAccountRequest({ full_name: "A B", chw_id: "CHW555", clinic_id: "c", phone_number: "", pin: "1234", confirm: "1234" }).pin).toMatch(/too easy/);
  });
});
