import { useEffect, useState } from "react";

// Not part of any standard TS lib - Chromium-only event, feature-detected below.
interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

const DISMISSED_KEY = "mosi-install-dismissed";

// Browsers that support install prompting (Chrome/Edge/Android) fire this
// event unprompted once their own installability criteria are met (manifest
// with name + 192/512 icons + start_url + display, a service worker, HTTPS
// or localhost) and the user has engaged with the page a little. Safari/iOS
// never fires it - there, components/InstallHint.tsx shows Safari's own
// "Share -> Add to Home Screen" steps instead.
function InstallPrompt() {
  const [deferredEvent, setDeferredEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [dismissed, setDismissed] = useState(() => {
    try {
      return sessionStorage.getItem(DISMISSED_KEY) === "1";
    } catch {
      return false;
    }
  });

  useEffect(() => {
    function handleBeforeInstallPrompt(event: Event) {
      event.preventDefault();
      setDeferredEvent(event as BeforeInstallPromptEvent);
    }
    // Installed (from this card or the browser's own menu): nothing left to offer.
    function handleInstalled() {
      setDeferredEvent(null);
    }
    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleInstalled);
    };
  }, []);

  if (!deferredEvent || dismissed) return null;

  async function handleInstall() {
    if (!deferredEvent) return;
    await deferredEvent.prompt();
    await deferredEvent.userChoice;
    // Browsers only allow prompting a given deferred event once either way.
    setDeferredEvent(null);
  }

  function handleDismiss() {
    setDismissed(true);
    try {
      sessionStorage.setItem(DISMISSED_KEY, "1");
    } catch {
      // Private-mode/blocked storage - dismissal just won't persist across reloads, harmless.
    }
  }

  return (
    // bottom-20 on phones: clear of the bottom navigation bar.
    <section
      aria-label="Install Mosi"
      className="fixed bottom-20 left-4 right-4 z-50 flex items-start gap-3 rounded-xl border border-stone-200 bg-white p-4 shadow-md sm:bottom-4 sm:left-auto sm:right-4 sm:w-80"
    >
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-stone-900">Install Mosi</p>
        <p className="mt-0.5 text-xs text-stone-600">Add it to your home screen for quick, offline-ready access.</p>
      </div>
      <div className="flex shrink-0 flex-col items-end gap-1.5">
        <button
          type="button"
          onClick={() => void handleInstall()}
          className="min-h-11 rounded-lg bg-forest-800 px-4 text-sm font-medium text-white hover:bg-forest-900"
        >
          Install
        </button>
        <button type="button" onClick={handleDismiss} className="min-h-11 px-2 text-sm font-medium text-stone-700 hover:text-stone-900">
          Not now
        </button>
      </div>
    </section>
  );
}

export default InstallPrompt;
