import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { AlertCircle, CheckCircle2, Cloud, CloudOff, Loader2, PlugZap, RefreshCw, ServerCrash, UploadCloud, type LucideIcon } from "lucide-react";
import { useNetwork } from "../contexts/NetworkContext";
import { useSync } from "../contexts/SyncContext";
import { timeAgo } from "../utils/timeAgo";
import { cn } from "../lib/utils";
import { syncingLabel } from "../utils/syncMessages";

export type SyncDisplayKind = "offline" | "syncing" | "paused" | "waiting" | "synced" | "online";

type SyncDisplay = { kind: SyncDisplayKind; label: string; icon: LucideIcon; tone: string };

// One mapping from real sync state to wording/icon/colour, shared by every
// place that shows it. Always icon + text + colour - never colour alone.
export function useSyncDisplay(): SyncDisplay {
  const { isOnline, status } = useNetwork();
  const { phase, syncingCount, pendingCount, lastSyncAt } = useSync();

  // Keeps "2 minutes ago" from going stale while the screen sits open.
  const [, setTick] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setTick((t) => t + 1), 30_000);
    return () => window.clearInterval(id);
  }, []);

  const waiting = `${pendingCount} waiting`;
  if (!isOnline) {
    // Same reasons, same words as the connectivity indicator.
    const reason =
      status === "work-offline"
        ? { label: "Working offline", icon: PlugZap, tone: "bg-sage-50 text-forest-900 border-sage-100" }
        : status === "server-unreachable"
          ? { label: "Server unreachable", icon: ServerCrash, tone: "bg-amber-50 text-amber-900 border-amber-200" }
          : status === "checking"
            ? { label: "Checking connection…", icon: Loader2, tone: "bg-white text-stone-700 border-stone-200" }
            : { label: "Offline", icon: CloudOff, tone: "bg-amber-50 text-amber-800 border-amber-200" };
    return {
      kind: "offline",
      label: pendingCount > 0 ? `${reason.label.replace("…", "")} · ${waiting}` : reason.label,
      icon: reason.icon,
      tone: reason.tone,
    };
  }
  if (phase === "syncing") {
    return {
      kind: "syncing",
      label: syncingLabel(syncingCount),
      icon: RefreshCw,
      tone: "bg-sage-50 text-forest-800 border-sage-100",
    };
  }
  if (phase === "paused" && pendingCount > 0) {
    return { kind: "paused", label: `Sync paused · ${waiting}`, icon: AlertCircle, tone: "bg-red-50 text-red-700 border-red-200" };
  }
  if (pendingCount > 0) {
    return { kind: "waiting", label: `${pendingCount} waiting to sync`, icon: UploadCloud, tone: "bg-amber-50 text-amber-800 border-amber-200" };
  }
  if (lastSyncAt) {
    return {
      kind: "synced",
      label: `Synced ${timeAgo(lastSyncAt)}`,
      icon: CheckCircle2,
      tone: "bg-emerald-50 text-emerald-800 border-emerald-200",
    };
  }
  return { kind: "online", label: "Online", icon: Cloud, tone: "bg-white text-stone-700 border-stone-200" };
}

// Deliberately not a live region itself - AnnouncerContext speaks state
// *changes* once; this is the always-visible summary you can glance at (or
// tab to, and follow to Sync Status for detail).
export function SyncStatusPill({ className }: { className?: string }) {
  const display = useSyncDisplay();
  const Icon = display.icon;

  return (
    <Link
      to="/sync"
      className={cn(
        "inline-flex min-h-8 items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium transition-colors hover:brightness-95",
        display.tone,
        className,
      )}
    >
      <Icon
        className={cn("h-3.5 w-3.5 shrink-0", display.kind === "syncing" && "animate-spin motion-reduce:animate-none")}
        aria-hidden="true"
      />
      <span>{display.label}</span>
      <span className="sr-only"> - view sync status</span>
    </Link>
  );
}
