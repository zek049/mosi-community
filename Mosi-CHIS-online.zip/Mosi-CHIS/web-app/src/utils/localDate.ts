// Today's date as YYYY-MM-DD in the device's own time zone. Using
// toISOString() here would give the UTC date, which is "yesterday" for a
// CHW in Zimbabwe (UTC+2) recording a visit just after midnight.
export function localIsoDate(date: Date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

// The "YYYY-MM-DD" day of a calendar-date field, whether it's stored as
// "2026-09-24" (created on this device) or "2026-09-24T00:00:00.000Z"
// (as returned by the server). Use this before comparing or sorting
// visit dates so the two forms never disagree.
export function calendarDay(value: string): string {
  return value.slice(0, 10);
}
