import { prisma } from "../db";
import { logger } from "../logger";
import type { AuthenticatedUser } from "../middleware/auth";

// The fixed vocabulary of audit actions (section 20). Kept as a union type
// rather than a free string so a typo here is a compile error, not a silent
// gap in the audit trail.
export type AuditAction =
  | "LOGIN_SUCCESS"
  | "LOGIN_FAILURE"
  | "ACCOUNT_LOCKED"
  | "PATIENT_CREATED"
  | "PATIENT_UPDATED"
  | "PATIENT_ARCHIVED"
  | "VISIT_CREATED"
  | "VISIT_UPDATED"
  | "VISIT_ARCHIVED"
  | "SYNC_STARTED"
  | "SYNC_COMPLETED"
  | "SYNC_CONFLICT"
  | "CONFLICT_RESOLVED"
  | "CHW_CREATED"
  | "CHW_UPDATED"
  | "CHW_DEACTIVATED"
  | "CLINIC_CREATED"
  | "ACCOUNT_REQUESTED"
  | "ACCOUNT_APPROVED"
  | "ACCOUNT_REJECTED"
  | "CHW_REVOKED"
  | "CHW_REACTIVATED"
  | "CHW_DELETED"
  | "PIN_RESET_REQUESTED"
  | "PIN_RESET_COMPLETED"
  | "PIN_CHANGED"
  | "RECORD_CONFIRMED"
  | "RECORD_FLAGGED";

type WriteAuditLogInput = {
  actor?: (Pick<AuthenticatedUser, "chwId" | "role"> & { clinicId?: string }) | null;
  // The clinic the action concerns. Defaults to metadata.clinic_id, then
  // the actor's clinic (see clinicFor). null = no clinic (e.g. a sign-in
  // attempt for an ID that doesn't exist) - visible to administrators only.
  clinicId?: string | null;
  action: AuditAction;
  resourceType?: string;
  resourceId?: string;
  requestId?: string;
  // Never put PIN/password/JWT/authorization-header values or full health
  // records in here (section 20) - just enough context to answer "who did
  // what, to which record, when".
  metadata?: Record<string, unknown>;
};

// The record's/account's clinic when the caller knows it (an administrator
// acting on a Mbare record is Mbare activity), else the actor's own clinic.
function clinicFor(input: WriteAuditLogInput): string | null {
  if (input.clinicId !== undefined) return input.clinicId;
  const fromMetadata = input.metadata?.clinic_id;
  if (typeof fromMetadata === "string") return fromMetadata;
  return input.actor?.clinicId ?? null;
}

// Many entries in one insert (e.g. one per record a sync created/updated).
// Same never-throw rule as writeAuditLog below.
export async function writeAuditLogs(inputs: WriteAuditLogInput[]): Promise<void> {
  if (inputs.length === 0) return;
  try {
    await prisma.auditLog.createMany({
      data: inputs.map((input) => ({
        actor_id: input.actor?.chwId ?? null,
        actor_role: input.actor?.role ?? null,
        action: input.action,
        resource_type: input.resourceType ?? null,
        resource_id: input.resourceId ?? null,
        request_id: input.requestId ?? null,
        metadata: input.metadata ? (input.metadata as object) : undefined,
        clinic_id: clinicFor(input),
      })),
    });
  } catch (error) {
    logger.error({ err: error, count: inputs.length }, "Failed to write audit log entries");
  }
}

// Audit logging must never be why a request fails - a write to AuditLog
// failing (e.g. a transient DB hiccup) is logged and swallowed, not thrown,
// so it can never turn an otherwise-successful patient/visit/login action
// into a 500.
export async function writeAuditLog(input: WriteAuditLogInput): Promise<void> {
  try {
    await prisma.auditLog.create({
      data: {
        actor_id: input.actor?.chwId ?? null,
        actor_role: input.actor?.role ?? null,
        action: input.action,
        resource_type: input.resourceType ?? null,
        resource_id: input.resourceId ?? null,
        request_id: input.requestId ?? null,
        metadata: input.metadata ? (input.metadata as object) : undefined,
        clinic_id: clinicFor(input),
      },
    });
  } catch (error) {
    logger.error({ err: error, action: input.action }, "Failed to write audit log entry");
  }
}
