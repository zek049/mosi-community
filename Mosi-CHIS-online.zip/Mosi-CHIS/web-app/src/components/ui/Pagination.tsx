import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "../../lib/utils";

type PaginationProps = {
  page: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  itemLabel: string;
};

// Page numbers to show: always first and last, the current page and its
// neighbours, with gaps marked - so the control stays a fixed, small width
// however many pages there are.
function pageWindow(page: number, totalPages: number): Array<number | "gap"> {
  const pages = new Set([1, totalPages, page - 1, page, page + 1].filter((n) => n >= 1 && n <= totalPages));
  const sorted = [...pages].sort((a, b) => a - b);
  const result: Array<number | "gap"> = [];
  sorted.forEach((n, i) => {
    if (i > 0 && n - sorted[i - 1] > 1) result.push("gap");
    result.push(n);
  });
  return result;
}

const ARROW_CLASS =
  "flex h-11 w-11 items-center justify-center rounded-lg border border-stone-200 bg-white text-stone-600 hover:bg-stone-50 disabled:opacity-40 disabled:hover:bg-white";

// Client-side pagination over data already on the device (Dexie) or a small
// API list. On phones it's just "Page 2 of 19" with previous/next; wider
// screens also get a short run of page numbers.
export function Pagination({ page, pageSize, totalItems, onPageChange, itemLabel }: PaginationProps) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  if (totalItems === 0) return null;

  const rangeStart = (page - 1) * pageSize + 1;
  const rangeEnd = Math.min(page * pageSize, totalItems);

  return (
    <nav aria-label="Pagination" className="flex flex-wrap items-center justify-between gap-3 pt-1">
      <p className="text-sm text-stone-600">
        {rangeStart}-{rangeEnd} of {totalItems} {itemLabel}
      </p>
      {totalPages > 1 && (
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => onPageChange(Math.max(1, page - 1))}
            disabled={page === 1}
            aria-label="Previous page"
            className={ARROW_CLASS}
          >
            <ChevronLeft className="h-4 w-4" aria-hidden="true" />
          </button>
          <span className="px-2 text-sm text-stone-700 sm:hidden">
            Page {page} of {totalPages}
          </span>
          <span className="hidden items-center gap-1 sm:flex">
            {pageWindow(page, totalPages).map((n, i) =>
              n === "gap" ? (
                <span key={`gap-${i}`} className="px-1 text-stone-500" aria-hidden="true">
                  …
                </span>
              ) : (
                <button
                  key={n}
                  type="button"
                  onClick={() => onPageChange(n)}
                  aria-label={`Page ${n}`}
                  aria-current={n === page ? "page" : undefined}
                  className={cn(
                    "flex h-11 min-w-11 items-center justify-center rounded-lg px-2 text-sm font-medium",
                    n === page ? "bg-forest-800 text-white" : "text-stone-700 hover:bg-stone-100",
                  )}
                >
                  {n}
                </button>
              ),
            )}
          </span>
          <button
            type="button"
            onClick={() => onPageChange(Math.min(totalPages, page + 1))}
            disabled={page === totalPages}
            aria-label="Next page"
            className={ARROW_CLASS}
          >
            <ChevronRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      )}
    </nav>
  );
}
