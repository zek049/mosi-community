import type { Request } from "express";
import { AppError } from "./AppError";

// Express 5's router types req.params values as `string | string[]` (some
// route patterns can capture repeated segments). None of Mosi's routes use
// that, but this keeps every handler honest about it instead of casting.
export function requireStringParam(req: Request, name: string): string {
  const value = req.params[name];
  if (typeof value !== "string" || !value) {
    throw new AppError(400, `${name} parameter is required`);
  }
  return value;
}
