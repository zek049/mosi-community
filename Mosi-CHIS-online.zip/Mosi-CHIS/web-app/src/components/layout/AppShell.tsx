import { Suspense, useEffect, useRef, type ReactNode } from "react";
import { useLocation } from "react-router-dom";
import { ScreenSkeleton } from "../ui/ScreenSkeleton";
import { Sidebar, type NavItem } from "./Sidebar";
import { MobileTopBar } from "./MobileTopBar";
import { MobileBottomNav } from "./MobileBottomNav";
import { SyncStatusPill, useSyncDisplay } from "../SyncStatusPill";
import { useSignOutFlow } from "../SignOutFlow";
import { ConnectivityIndicator, WorkOfflineSwitch } from "../Connectivity";

type AppShellProps = {
  navItems: NavItem[];
  mobileNavItems: NavItem[];
  mobileMoreItems?: NavItem[];
  userName: string;
  userSubtitle: string;
  children: ReactNode;
};

// On phones, sync status only takes vertical space when there's something
// to know (offline, syncing, waiting, paused) - "all synced" stays quiet.
function MobileSyncStrip() {
  const display = useSyncDisplay();
  if (display.kind === "synced" || display.kind === "online") return null;
  return (
    <div role="region" aria-label="Sync status" className="md:hidden sticky top-[57px] z-30 border-b border-stone-200 bg-cream/95 px-4 py-2">
      <SyncStatusPill />
    </div>
  );
}

// The one consistent shell: a dark Sidebar on desktop, a white MobileTopBar
// + bottom MobileBottomNav on mobile. ChwLayout and SupervisorLayout each
// supply their own real nav items and keep their own role-specific effects
// (cache refresh etc.) - this only owns the chrome around <Outlet />.
export function AppShell({
  navItems,
  mobileNavItems,
  mobileMoreItems,
  userName,
  userSubtitle,
  children,
}: AppShellProps) {
  const signOut = useSignOutFlow();
  const onSignOut = () => void signOut.request();
  const { pathname } = useLocation();
  const mainRef = useRef<HTMLElement>(null);
  const firstRender = useRef(true);

  // After an in-app navigation, move focus to the new page's content so
  // keyboard and screen-reader users start at the top of what changed
  // instead of on a nav link that no longer describes where they are.
  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    mainRef.current?.focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }, [pathname]);

  return (
    <div className="min-h-screen bg-cream">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[60] focus:rounded-lg focus:bg-forest-800 focus:px-4 focus:py-2 focus:text-sm focus:font-medium focus:text-white"
      >
        Skip to main content
      </a>
      <Sidebar navItems={navItems} userName={userName} userSubtitle={userSubtitle} onSignOut={onSignOut} />
      <MobileTopBar userName={userName} userSubtitle={userSubtitle} onSignOut={onSignOut} />
      <MobileSyncStrip />
      <div className="md:pl-60">
        <header className="hidden md:flex items-center justify-between gap-4 border-b border-stone-200 bg-white px-6 py-2">
          <SyncStatusPill />
          <div className="flex items-center gap-4">
            <ConnectivityIndicator />
            <WorkOfflineSwitch />
          </div>
        </header>
        <main ref={mainRef} id="main-content" tabIndex={-1} className="mx-auto max-w-6xl px-4 py-6 pb-24 sm:px-6 md:pb-10 outline-none">
          <Suspense fallback={<ScreenSkeleton />}>{children}</Suspense>
        </main>
      </div>
      <MobileBottomNav navItems={mobileNavItems} moreItems={mobileMoreItems} />
      {signOut.dialog}
    </div>
  );
}
