import { beforeEach, describe, expect, it, vi } from "vitest";
import bcrypt from "bcryptjs";

vi.hoisted(() => {
  process.env.JWT_SECRET = "test-secret-for-integration-tests";
});

const m = vi.hoisted(() => ({
  chwFindUnique: vi.fn(),
  chwFindMany: vi.fn(),
  chwUpdate: vi.fn(),
  reqFindFirst: vi.fn(),
  reqFindUnique: vi.fn(),
  reqFindMany: vi.fn(),
  reqCreate: vi.fn(),
  reqUpdate: vi.fn(),
  accountRequestFindFirst: vi.fn(),
  auditLogCreate: vi.fn(),
  transaction: vi.fn(),
}));

vi.mock("../db", () => ({
  prisma: {
    chw: { findUnique: m.chwFindUnique, findMany: m.chwFindMany, update: m.chwUpdate },
    pinResetRequest: { findFirst: m.reqFindFirst, findUnique: m.reqFindUnique, findMany: m.reqFindMany, create: m.reqCreate, update: m.reqUpdate },
    accountRequest: { findFirst: m.accountRequestFindFirst },
    auditLog: { create: m.auditLogCreate },
    $transaction: m.transaction,
  },
}));

import request from "supertest";
import app from "../app";
import { signSessionToken } from "../middleware/auth";
import { pinResetRequestLimiter } from "../middleware/rateLimit";
import { isWeakPin } from "../utils/pinPolicy";

const base = { status: "active", locked_until: null, failed_login_count: 0, must_change_pin: false };
const sup = { ...base, chw_id: "SUP001", role: "SUPERVISOR", clinic_id: "clinic-a" }; // supervisors are clinic-scoped (admin-role feature)
const sup2 = { ...base, chw_id: "SUP002", role: "SUPERVISOR", clinic_id: "clinic-a" };
const chw = { ...base, chw_id: "CHW001", role: "CHW", clinic_id: "clinic-a", full_name: "Jane", clinic: "Clinic A" };
const revoked = { ...chw, chw_id: "CHW004", status: "revoked" };
let rows: Record<string, unknown>[] = [];
const REQ = "11111111-1111-4111-8111-111111111111";
const supAuth = { Authorization: `Bearer ${signSessionToken({ chwId: "SUP001", role: "SUPERVISOR", fullName: "Sup" })}` };
const chwAuth = { Authorization: `Bearer ${signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Jane" })}` };
const MESSAGE = "A supervisor will reset your PIN — check with them for your new temporary PIN.";

beforeEach(async () => {
  for (const key of ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:127.0.0.0/120", "::1/56"]) await pinResetRequestLimiter.resetKey(key);
  vi.clearAllMocks();
  rows = [sup, sup2, { ...chw }, revoked];
  m.chwFindUnique.mockImplementation(async ({ where }: { where: { chw_id: string } }) => rows.find((r) => r.chw_id === where.chw_id) ?? null);
  m.chwUpdate.mockImplementation(async ({ data }: { data: Record<string, unknown> }) => data);
  m.reqFindFirst.mockResolvedValue(null);
  m.reqCreate.mockResolvedValue({ id: REQ });
  m.reqUpdate.mockResolvedValue({});
  m.reqFindUnique.mockResolvedValue({ id: REQ, chw_id: "CHW001", status: "pending", chw: { ...chw } });
  m.accountRequestFindFirst.mockResolvedValue(null);
  m.auditLogCreate.mockResolvedValue({});
  m.transaction.mockImplementation(async (ops: unknown[]) => Promise.all(ops));
});

describe("POST /api/pin-reset-requests (public)", () => {
  it.each([
    ["an active CHW", "CHW001", true],
    ["an unknown ID", "NOPE01", false],
    ["a revoked CHW", "CHW004", false],
    ["a supervisor", "SUP001", false],
  ])("for %s: the same 202 + message; a request recorded only for an active CHW", async (_l, id, recorded) => {
    const res = await request(app).post("/api/pin-reset-requests").send({ chw_id: id });
    expect(res.status).toBe(202);
    expect(res.body).toEqual({ success: true, data: { message: MESSAGE } });
    expect(m.reqCreate).toHaveBeenCalledTimes(recorded ? 1 : 0);
  });

  it("doesn't create a second pending request for the same CHW (same response)", async () => {
    m.reqFindFirst.mockResolvedValue({ id: "existing" });
    const res = await request(app).post("/api/pin-reset-requests").send({ chw_id: "CHW001" });
    expect(res.status).toBe(202);
    expect(m.reqCreate).not.toHaveBeenCalled();
  });

  it("validates input and is rate limited (5/hour)", async () => {
    expect((await request(app).post("/api/pin-reset-requests").send({})).status).toBe(400);
    expect((await request(app).post("/api/pin-reset-requests").send({ chw_id: "X", role: "SUPERVISOR" })).status).toBe(400);
    const codes: number[] = [];
    for (let i = 0; i < 6; i++) codes.push((await request(app).post("/api/pin-reset-requests").send({ chw_id: "NOPE01" })).status);
    expect(codes.filter((c) => c === 429).length).toBeGreaterThan(0);
  });
});

describe("supervisor completion", () => {
  it("401 without a session, 403 for a CHW", async () => {
    expect((await request(app).get("/api/pin-reset-requests")).status).toBe(401);
    expect((await request(app).post(`/api/pin-reset-requests/${REQ}/complete`).send({ new_pin: "5555" })).status).toBe(401);
    expect((await request(app).get("/api/pin-reset-requests").set(chwAuth)).status).toBe(403);
    expect((await request(app).post(`/api/pin-reset-requests/${REQ}/complete`).set(chwAuth).send({ new_pin: "5555" })).status).toBe(403);
    expect(m.chwUpdate).not.toHaveBeenCalled();
  });

  it("completes: hashes the temporary PIN, forces a change, clears lockout, marks done - one transaction, no PIN in response/audit", async () => {
    const res = await request(app).post(`/api/pin-reset-requests/${REQ}/complete`).set(supAuth).send({ new_pin: "5739" });
    expect(res.status).toBe(200);
    const data = m.chwUpdate.mock.calls[0][0].data;
    expect(await bcrypt.compare("5739", data.pin_hash)).toBe(true);
    expect(data).toMatchObject({ must_change_pin: true, failed_login_count: 0, locked_until: null });
    expect(m.reqUpdate.mock.calls[0][0].data).toMatchObject({ status: "completed", reviewed_by: "SUP001" });
    expect(m.transaction).toHaveBeenCalledTimes(1);
    const audit = JSON.stringify(m.auditLogCreate.mock.calls);
    expect(audit).toContain("PIN_RESET_COMPLETED");
    expect(audit).not.toContain("5739");
    expect(JSON.stringify(res.body)).not.toContain("5739");
  });

  it("rejects a malformed PIN, an already-completed request, and requests for accounts outside the supervisor's remit", async () => {
    expect((await request(app).post(`/api/pin-reset-requests/${REQ}/complete`).set(supAuth).send({ new_pin: "12" })).status).toBe(400);
    m.reqFindUnique.mockResolvedValue({ id: REQ, chw_id: "CHW001", status: "completed", chw: { ...chw } });
    expect((await request(app).post(`/api/pin-reset-requests/${REQ}/complete`).set(supAuth).send({ new_pin: "5739" })).status).toBe(409);
    m.reqFindUnique.mockResolvedValue({ id: REQ, chw_id: "SUP002", status: "pending", chw: sup2 });
    expect((await request(app).post(`/api/pin-reset-requests/${REQ}/complete`).set(supAuth).send({ new_pin: "5739" })).status).toBe(404);
    expect(m.chwUpdate).not.toHaveBeenCalled();
  });

  it("the existing direct reset (PATCH /chws/:id) also makes the PIN temporary", async () => {
    const res = await request(app).patch("/api/chws/CHW001").set(supAuth).send({ pin: "5739" });
    expect(res.status).toBe(200);
    expect(m.chwUpdate.mock.calls[0][0].data.must_change_pin).toBe(true);
  });
});

describe("forced PIN change (must_change_pin)", () => {
  const mustChange = () => {
    rows = [sup, { ...chw, must_change_pin: true, pin_hash: bcrypt.hashSync("5739", 4) }];
  };

  it("sign-in tells the app a new PIN is needed", async () => {
    mustChange();
    const res = await request(app).post("/api/auth/login").send({ chw_id: "CHW001", pin: "5739" });
    expect(res.status).toBe(200);
    expect(res.body.data.chw.must_change_pin).toBe(true);
  });

  it("every other API call is refused (403 PIN_CHANGE_REQUIRED) until the PIN is changed", async () => {
    mustChange();
    const res = await request(app).post("/api/sync").set(chwAuth).send({ patients: [], visits: [] });
    expect(res.status).toBe(403);
    expect(res.body.code).toBe("PIN_CHANGE_REQUIRED");
  });

  it("change-pin: wrong current PIN -> 401 and counts towards lockout", async () => {
    mustChange();
    const res = await request(app).post("/api/auth/change-pin").set(chwAuth).send({ current_pin: "0000", new_pin: "8264" });
    expect(res.status).toBe(401);
    expect(m.chwUpdate.mock.calls[0][0].data.failed_login_count).toBe(1);
  });

  it.each([
    ["the same PIN", "5739"],
    ["a guessable PIN", "1234"],
    ["repeated digits", "7777"],
  ])("change-pin: refuses %s", async (_l, newPin) => {
    mustChange();
    const res = await request(app).post("/api/auth/change-pin").set(chwAuth).send({ current_pin: "5739", new_pin: newPin });
    expect(res.status).toBe(400);
  });

  it("change-pin: success stores a new hash and clears the flag, audited without the PIN", async () => {
    mustChange();
    const res = await request(app).post("/api/auth/change-pin").set(chwAuth).send({ current_pin: "5739", new_pin: "8264" });
    expect(res.status).toBe(200);
    const data = m.chwUpdate.mock.calls[0][0].data;
    expect(await bcrypt.compare("8264", data.pin_hash)).toBe(true);
    expect(data.must_change_pin).toBe(false);
    const audit = JSON.stringify(m.auditLogCreate.mock.calls);
    expect(audit).toContain("PIN_CHANGED");
    expect(audit).not.toContain("8264");
  });

  it("change-pin needs a session", async () => {
    expect((await request(app).post("/api/auth/change-pin").send({ current_pin: "5739", new_pin: "8264" })).status).toBe(401);
  });
});

describe("PIN policy", () => {
  it.each(["1234", "0000", "9999", "0123", "6789", "9876", "4321", "2580", "1212"])("%s is too guessable", (pin) => expect(isWeakPin(pin)).toBe(true));
  it.each(["5739", "8264", "4821", "3071"])("%s is acceptable", (pin) => expect(isWeakPin(pin)).toBe(false));
});
