import { describe, expect, it } from "vitest";
import { generateHouseholdCode, HOUSEHOLD_CODE_PATTERN, villagePrefix } from "../householdCode";

describe("household codes (made on the device, work offline)", () => {
  it("village prefix: first 3 letters, upper-case, accents and non-letters dropped, padded", () => {
    expect(villagePrefix("Mbare")).toBe("MBA");
    expect(villagePrefix("  épworth 2 ")).toBe("EPW");
    expect(villagePrefix("Ox")).toBe("OXX");
    expect(villagePrefix("")).toBe("XXX");
  });
  it("format: PREFIX-XXXX from an alphabet without look-alikes, valid for the server", () => {
    const code = generateHouseholdCode("Mbare");
    expect(code).toMatch(/^MBA-[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{6}$/);
    expect(HOUSEHOLD_CODE_PATTERN.test(code)).toBe(true);
    expect(generateHouseholdCode("Mbare", (b) => b.fill(0))).toBe("MBA-222222");
  });
  it("distinct random draws give distinct codes (31^6 per prefix, no lost entropy)", () => {
    // Deterministic: feed consecutive values and check the mapping is one-to-one.
    // Draw i is i written in base 31 across the 6 slots, so every draw differs.
    let i = 0;
    const counter = (b: Uint32Array) => {
      let n = i++;
      for (let k = 0; k < b.length; k++) {
        b[k] = n % 31;
        n = Math.floor(n / 31);
      }
      return b;
    };
    const codes = new Set(Array.from({ length: 5000 }, () => generateHouseholdCode("Mbare", counter)));
    expect(codes.size).toBe(5000);
  });
});
