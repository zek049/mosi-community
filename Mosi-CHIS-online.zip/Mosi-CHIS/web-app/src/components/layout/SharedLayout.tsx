import { Navigate } from "react-router-dom";
import * as authService from "../../services/authService";
import ChwLayout from "./ChwLayout";
import { isSupervisorRole } from "../../models/chw";
import SupervisorLayout from "./SupervisorLayout";

// For routes both roles use (Patient List, and Patient Detail/Visit List
// coming next): a single path can't be registered under two separate
// ProtectedRoute-guarded branches in one route tree, because React Router
// matches by path alone, before any permission check runs - whichever
// branch is registered would "win" for every visitor regardless of their
// actual role. This picks the role-appropriate header/nav shell at render
// time instead, so one path genuinely serves both roles correctly.
function SharedLayout() {
  const session = authService.getSession();

  if (!session) {
    return <Navigate to="/login" replace />;
  }
  if (session.mustChangePin) {
    return <Navigate to="/change-pin" replace />;
  }

  return isSupervisorRole(session.chw.role) ? <SupervisorLayout /> : <ChwLayout />;
}

export default SharedLayout;
