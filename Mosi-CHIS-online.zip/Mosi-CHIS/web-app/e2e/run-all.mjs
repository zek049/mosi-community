// Runs every browser suite in order against the production preview
// (http://localhost:4173) and the real backend (http://localhost:4000),
// cleaning the test data out of the database between suites.
//
//   node run-all.mjs            # everything
//   node run-all.mjs p14 p15    # only suites whose name starts with these
import { execFileSync, spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";

const SUITES = [
  "p3-offline", // must run right before p3-keyboard (it creates the patient p3-keyboard edits)
  "p3-keyboard",
  "p4-hardening",
  "p5-integrity",
  "p7-connectivity",
  "p8-account-requests",
  "p9-manage-chws",
  "p10-duplicates",
  "p11-pin-reset",
  "p12-households",
  "p13-due",
  "p14-review",
  "p15-admin",
  "p16-activity",
  "p17-pwa",
  "p3-sweep",
];

const only = process.argv.slice(2);
const selected = only.length ? SUITES.filter((s) => only.some((o) => s.startsWith(o))) : SUITES;

// Removes rows the suites create (recognisable by their P<n>-/T<n> markers)
// and puts the demo accounts back to PIN 1234. See cleanup.sql.
function cleanup() {
  execFileSync("docker", ["exec", "-i", "mosi-postgres", "psql", "-q", "-U", "mosi", "-d", "mosi"], { input: readFileSync(new URL("./cleanup.sql", import.meta.url)), stdio: ["pipe", "ignore", "inherit"] });
}

let failed = 0;
let p3Stamp = "";
cleanup();
for (const suite of selected) {
  const args = [`${suite}.mjs`];
  if (suite === "p3-keyboard" && p3Stamp) args.push(p3Stamp);
  const run = spawnSync(process.execPath, args, { cwd: new URL(".", import.meta.url), encoding: "utf8" });
  const out = `${run.stdout}${run.stderr}`;
  const summary = out.match(/\d+ passed, \d+ failed[^\n]*|Layout problems: \d+/g)?.at(-1) ?? "no summary (crashed?)";
  const stamp = out.match(/TEST_STAMP=(P3-\d+)/);
  if (suite === "p3-offline" && stamp) p3Stamp = stamp[1];
  const ok = run.status === 0;
  if (!ok) failed++;
  console.log(`${ok ? "PASS" : "FAIL"} ${suite}: ${summary}`);
  for (const line of out.split("\n").filter((l) => l.startsWith("FAIL")).slice(0, 5)) console.log(`     ${line}`);
  if (suite !== "p3-offline") cleanup();
}
console.log(failed ? `\n${failed} suite(s) failed` : "\nAll suites passed");
process.exit(failed ? 1 : 0);
