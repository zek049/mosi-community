// Responsive + automated-accessibility sweep of every route, both roles,
// at the widths the Phase 3 brief lists. Production build on :4173.
import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const BASE = "http://localhost:4173";
const WIDTHS = [320, 360, 375, 390, 430, 768, 820, 1024, 1280, 1440];
const AXE_WIDTHS = new Set([320, 768, 1280]);
const SHOT_WIDTHS = new Set([320, 1280]);
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");

const problems = [];
const axeFindings = new Map();
const consoleErrors = [];
let checks = 0;

async function login(context, chwId) {
  const page = await context.newPage();
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.fill("#chwId", chwId);
  await page.fill("#pin", "1234");
  await page.click('button[type="submit"]');
  await page.waitForURL((u) => !u.pathname.startsWith("/login"), { timeout: 10000 });
  await page.waitForTimeout(1500); // let cache refresh populate Dexie
  return page;
}

async function audit(page, label, width) {
  checks++;
  const result = await page.evaluate(() => {
    const vw = document.documentElement.clientWidth;
    const pageOverflow = document.documentElement.scrollWidth - vw;
    const offenders = [];
    for (const el of document.querySelectorAll("body *")) {
      const style = getComputedStyle(el);
      if (style.display === "none" || style.visibility === "hidden") continue;
      if (el.closest(".sr-only") || el.closest("dialog:not([open])")) continue;
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      if (r.right > vw + 1 || r.left < -1) {
        // Ignore things clipped by an overflow container (e.g. a scrolling table).
        let clipped = false;
        for (let p = el.parentElement; p; p = p.parentElement) {
          const ps = getComputedStyle(p);
          if (/(auto|scroll|hidden|clip)/.test(ps.overflowX)) { const pr = p.getBoundingClientRect(); if (pr.right <= vw + 1 && pr.left >= -1) { clipped = true; break; } }
        }
        if (!clipped) offenders.push(`${el.tagName.toLowerCase()}.${String(el.className).slice(0, 60)} [${Math.round(r.left)}..${Math.round(r.right)}]`);
      }
    }
    const brokenImages = [...document.images].filter((i) => i.complete && i.naturalWidth === 0).map((i) => i.src);
    // Text clipped by its own box (e.g. button labels cut off)
    const clippedText = [...document.querySelectorAll("button, a")].filter((el) => {
      const s = getComputedStyle(el);
      return !el.classList.contains("sr-only") && s.overflow === "hidden" && el.scrollWidth > el.clientWidth + 1 && !/truncate/.test(el.className);
    }).map((el) => el.textContent.trim().slice(0, 40));
    return { pageOverflow, offenders: offenders.slice(0, 5), brokenImages, clippedText, title: document.title, h1: [...document.querySelectorAll("h1")].map((h) => h.textContent.trim()) };
  });
  if (result.pageOverflow > 1) problems.push(`${label} @${width}: page scrolls horizontally by ${result.pageOverflow}px`);
  if (result.offenders.length) problems.push(`${label} @${width}: elements outside viewport: ${result.offenders.join(" | ")}`);
  if (result.brokenImages.length) problems.push(`${label} @${width}: broken images ${result.brokenImages.join(", ")}`);
  if (result.clippedText.length) problems.push(`${label} @${width}: clipped button/link text: ${result.clippedText.join(", ")}`);
  if (result.h1.length !== 1) problems.push(`${label} @${width}: expected exactly one h1, found ${result.h1.length} (${result.h1.join(" / ")})`);
  if (!/· Mosi$/.test(result.title)) problems.push(`${label}: title missing ("${result.title}")`);

  if (AXE_WIDTHS.has(width)) {
    await page.addScriptTag({ content: axeSource });
    const axe = await page.evaluate(async () => {
      const r = await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa", "wcag22aa", "best-practice"] } });
      return r.violations.map((v) => ({ id: v.id, impact: v.impact, help: v.help, nodes: v.nodes.slice(0, 3).map((n) => n.target.join(" ")) }));
    });
    for (const v of axe) {
      const key = `${v.impact} ${v.id}: ${v.help}`;
      if (!axeFindings.has(key)) axeFindings.set(key, new Set());
      axeFindings.get(key).add(`${label}@${width} ${v.nodes.join(", ")}`);
    }
  }
  return result;
}

// The API allows 300 requests/minute per IP, and every full page load here
// re-runs the app's start-up requests - so pace page loads to stay under it
// (a person navigating inside the app never reloads like this).
const apiRequestTimes = [];
async function paceApi() {
  for (;;) {
    const now = Date.now();
    while (apiRequestTimes.length && now - apiRequestTimes[0] > 60_000) apiRequestTimes.shift();
    if (apiRequestTimes.length < 240) return;
    await new Promise((r) => setTimeout(r, 1000));
  }
}
function countApi(page) {
  page.on("request", (r) => { if (r.url().startsWith("http://localhost:4000/")) apiRequestTimes.push(Date.now()); });
}

async function sweep(page, label, path, prepare) {
  if (!page.__counted) { countApi(page); page.__counted = true; }
  for (const width of WIDTHS) {
    await page.setViewportSize({ width, height: width < 768 ? 800 : 900 });
    await paceApi();
    await page.goto(`${BASE}${path}`, { waitUntil: "networkidle" });
    await page.waitForTimeout(400);
    if (prepare) await prepare(page);
    await audit(page, label, width);
    if (SHOT_WIDTHS.has(width)) await page.screenshot({ path: `p3-${label.replace(/[^a-z0-9]+/gi, "-")}-${width}.png`, fullPage: true });
  }
}

const browser = await chromium.launch();
function track(page, who) {
  page.on("console", (m) => { if (m.type() === "error") consoleErrors.push(`${who}: ${m.text()}`); });
  page.on("pageerror", (e) => consoleErrors.push(`${who}: ${e}`));
  page.on("requestfailed", (r) => { if (!/favicon/.test(r.url())) consoleErrors.push(`${who}: request failed ${r.url()} ${r.failure()?.errorText}`); });
  page.on("response", (r) => { if (r.status() >= 400 && !r.url().includes("/api/auth/login")) consoleErrors.push(`${who}: HTTP ${r.status()} ${r.url()}`); });
}

// Public
const pub = await browser.newContext({ bypassCSP: true });
const pp = await pub.newPage();
track(pp, "public");
await sweep(pp, "landing", "/");
await sweep(pp, "login", "/login");
await sweep(pp, "not-found", "/definitely-not-a-page");
await pub.close();

// CHW
const chwCtx = await browser.newContext({ bypassCSP: true });
const chw = await login(chwCtx, "CHW001");
track(chw, "chw");
const firstPatient = await chw.evaluate(async () => {
  const req = indexedDB.open("mosi-chis-user-CHW001");
  const db = await new Promise((res) => { req.onsuccess = () => res(req.result); });
  return await new Promise((res) => { const g = db.transaction("patients").objectStore("patients").getAll(); g.onsuccess = () => res(g.result.find((p) => p.patient_id === "MBR-0017")?.id ?? g.result[0].id); });
});
await sweep(chw, "chw-home", "/chw");
await sweep(chw, "chw-patients", "/patients");
await sweep(chw, "chw-patient-detail", `/patients/${firstPatient}`);
await sweep(chw, "chw-visits", "/visits");
await sweep(chw, "chw-sync", "/sync");
await sweep(chw, "chw-add-patient", "/chw/patients/new", async (p) => { await p.click('button:has-text("Save patient")'); await p.waitForTimeout(200); });
await sweep(chw, "chw-add-visit-step1", "/chw/visits/new", async (p) => { await p.click('button:has-text("Continue")'); await p.waitForTimeout(200); });
await sweep(chw, "chw-add-visit-review", `/chw/visits/new?patient_id=${firstPatient}`, async (p) => {
  await p.check('input[name="visit_type"][value="Growth Monitoring"]');
  await p.click('button:has-text("Continue")');
  await p.fill("#weight", "12.4"); await p.fill("#bp_systolic", "100"); await p.fill("#bp_diastolic", "70");
  await p.fill("#notes", "A fairly long note to check that the review step wraps text sensibly on very narrow screens without overflowing.");
  await p.click('button:has-text("Continue")');
  await p.waitForSelector('h2:has-text("Review")');
});
await chwCtx.close();

// Supervisor
const supCtx = await browser.newContext({ bypassCSP: true });
const sup = await login(supCtx, "SUP001");
track(sup, "supervisor");
await sweep(sup, "sup-dashboard", "/supervisor");
await sweep(sup, "sup-chw-activity", "/supervisor/chw-activity");
await sweep(sup, "sup-conflicts", "/supervisor/conflicts");
await sweep(sup, "sup-sync", "/sync");
await sweep(sup, "sup-patients", "/patients");
await sweep(sup, "sup-visits", "/visits");
await sweep(sup, "sup-pin-reset", "/supervisor/pin-reset", async (p) => {
  await p.locator('input[name="account"]').first().check();
  await p.fill("#new-pin", "12"); await p.click('button[type="submit"]'); await p.waitForTimeout(150);
});
await sweep(sup, "sup-more-menu-open", "/supervisor", async (p) => {
  const more = p.locator('nav[aria-label="Mobile"] button, nav button:has-text("More")').first();
  if (await more.isVisible().catch(() => false)) { await more.click(); await p.waitForTimeout(250); }
});
await supCtx.close();

await browser.close();

console.log(`Checked ${checks} page/width combinations across ${WIDTHS.join(", ")}px.\n`);
console.log(`Layout problems: ${problems.length}`);
for (const p of [...new Set(problems)]) console.log("  -", p);
console.log(`\naxe violations (unique rules): ${axeFindings.size}`);
for (const [k, where] of axeFindings) console.log(`  - ${k}\n      ${[...where].slice(0, 4).join("\n      ")}`);
console.log(`\nConsole errors / failed requests: ${consoleErrors.length}`);
for (const e of [...new Set(consoleErrors)].slice(0, 30)) console.log("  -", e);
