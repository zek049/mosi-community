import { Router } from "express";
import { prisma } from "../db";
import { clinicScope } from "../middleware/authz";
import { conflictIdsInClinic, syncLogStatusCountsInClinic } from "../utils/recordScope";

const DAY_MS = 24 * 60 * 60 * 1000;
const COVERAGE_WINDOW_DAYS = 90;
const TREND_WINDOW_DAYS = 30;

const router = Router();

// The headline numbers count CONFIRMED records only - what a supervisor has
// checked (review queue). Records awaiting review or flagged are reported
// separately, never mixed in. Spelled out here so every query says so.
router.get("/stats", async (req, res) => {
  // Supervisors: their own clinic only. Administrators: every clinic.
  const scope = clinicScope(req.user!);
  const inClinic = scope ? { clinic_id: scope } : {};
  const CONFIRMED = { deleted_at: null, review_status: "confirmed" as const, ...inClinic };
  const AWAITING_REVIEW = { deleted_at: null, review_status: "awaiting_review" as const, ...inClinic };
  const FLAGGED = { deleted_at: null, review_status: "flagged" as const, ...inClinic };

  const [
    chwCount,
    activeChwCount,
    patientCount,
    visitCount,
    openConflicts,
    clinicBreakdown,
    patientsAwaiting,
    visitsAwaiting,
    patientsFlagged,
    visitsFlagged,
  ] = await Promise.all([
    prisma.chw.count({ where: { role: "CHW", ...inClinic } }),
    prisma.chw.count({ where: { role: "CHW", status: "active", ...inClinic } }),
    prisma.patient.count({ where: CONFIRMED }),
    prisma.visit.count({ where: CONFIRMED }),
    scope
      ? conflictIdsInClinic(scope).then((ids) => prisma.syncConflict.count({ where: { status: "open", id: { in: ids } } }))
      : prisma.syncConflict.count({ where: { status: "open" } }),
    // Efficient aggregation (section 34): one grouped query, not "pull
    // every patient into Node and count them by hand".
    prisma.patient.groupBy({
      by: ["clinic_id"],
      where: CONFIRMED,
      _count: { _all: true },
    }),
    prisma.patient.count({ where: AWAITING_REVIEW }),
    prisma.visit.count({ where: AWAITING_REVIEW }),
    prisma.patient.count({ where: FLAGGED }),
    prisma.visit.count({ where: FLAGGED }),
  ]);

  const clinics = await prisma.clinic.findMany({ where: { id: { in: clinicBreakdown.map((c) => c.clinic_id) } } });
  const clinicNameById = new Map(clinics.map((c) => [c.id, c.name]));
  const patientsByClinic = clinicBreakdown.map((c) => ({
    clinic_id: c.clinic_id,
    clinic_name: clinicNameById.get(c.clinic_id) ?? "Unknown",
    patients: c._count._all,
  }));

  // Coverage = the share of registered patients who have had at least one
  // visit in the last 90 days. Derived from real seeded/synced visit dates,
  // not fabricated - see section 23 of the spec.
  const coverageWindowStart = new Date(Date.now() - COVERAGE_WINDOW_DAYS * DAY_MS);
  const patientsWithRecentVisit = await prisma.patient.count({
    where: { ...CONFIRMED, visits: { some: { ...CONFIRMED, visit_date: { gte: coverageWindowStart } } } },
  });
  const coveragePercent =
    patientCount === 0 ? 0 : Math.round((patientsWithRecentVisit / patientCount) * 1000) / 10;

  const trendWindowStart = new Date(Date.now() - TREND_WINDOW_DAYS * DAY_MS);
  const recentVisits = await prisma.visit.findMany({
    where: { ...CONFIRMED, visit_date: { gte: trendWindowStart } },
    select: { visit_date: true },
  });

  const visitsByDay = new Map<string, number>();
  for (const { visit_date } of recentVisits) {
    const key = visit_date.toISOString().slice(0, 10);
    visitsByDay.set(key, (visitsByDay.get(key) ?? 0) + 1);
  }

  const trend: { date: string; visits: number }[] = [];
  for (let i = TREND_WINDOW_DAYS - 1; i >= 0; i--) {
    const key = new Date(Date.now() - i * DAY_MS).toISOString().slice(0, 10);
    trend.push({ date: key, visits: visitsByDay.get(key) ?? 0 });
  }

  // Sync success rate over the same trend window - a real operational
  // indicator (section 34), computed from SyncLog, not fabricated. There is
  // deliberately no "pending sync" count here: that's a device-local
  // IndexedDB concept the server has no visibility into (see the CHW Home /
  // Sync Status screens, which show it from the device's own perspective
  // instead).
  const recentSyncAttempts = scope
    ? await syncLogStatusCountsInClinic(scope, trendWindowStart)
    : (
        await prisma.syncLog.groupBy({
          by: ["status"],
          where: { synced_at: { gte: trendWindowStart } },
          _count: { _all: true },
        })
      ).map((row) => ({ status: row.status, count: row._count._all }));
  const syncAttemptTotal = recentSyncAttempts.reduce((sum, row) => sum + row.count, 0);
  const syncAttemptSuccess = recentSyncAttempts.find((row) => row.status === "success")?.count ?? 0;
  const syncSuccessRate = syncAttemptTotal === 0 ? null : Math.round((syncAttemptSuccess / syncAttemptTotal) * 1000) / 10;

  res.json({
    success: true,
    data: {
      chws: chwCount,
      activeChws: activeChwCount,
      patients: patientCount,
      visits: visitCount,
      coveragePercent,
      trend,
      openConflicts,
      syncSuccessRate,
      patientsByClinic,
      // Not in the numbers above until a supervisor confirms them.
      awaitingReview: { patients: patientsAwaiting, visits: visitsAwaiting },
      flagged: { patients: patientsFlagged, visits: visitsFlagged },
    },
  });
});

export default router;
