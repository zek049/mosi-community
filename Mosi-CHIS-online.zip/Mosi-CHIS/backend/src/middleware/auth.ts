import type { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { AppError } from "../utils/AppError";
import { prisma } from "../db";
import { SESSION_COOKIE_NAME } from "../utils/sessionCookie";

export type Role = "CHW" | "SUPERVISOR" | "ADMIN";

export type AuthenticatedUser = {
  chwId: string;
  role: Role;
  fullName: string;
  // Always the CHW row's CURRENT clinic_id, fetched fresh on every request
  // (see authenticate() below) - never trusted from the JWT payload, so a
  // supervisor reassigning someone to a different clinic takes effect on
  // that user's very next request, not just their next login.
  clinicId: string;
};

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthenticatedUser;
    }
  }
}

const ISSUER = "mosi-api";
const AUDIENCE = "mosi-app";

// Read lazily (not cached at module load) so this module never depends on
// import order relative to db.ts, which is what actually loads backend/.env.
// No fallback string - app.ts's assertRequiredEnv() refuses to let the
// server start at all without a real JWT_SECRET, so by the time any request
// reaches this function it is guaranteed to be set.
function getJwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    throw new Error("JWT_SECRET is not set");
  }
  return secret;
}

// sub (the JWT subject) is the chw_id - explicit per section 10's "missing
// subject" rejection requirement, distinct from the chwId claim below only
// in that it's the standard JWT field a generic verifier checks for.
export function signSessionToken(user: { chwId: string; role: Role; fullName: string }): string {
  return jwt.sign({ chwId: user.chwId, role: user.role, fullName: user.fullName }, getJwtSecret(), {
    subject: user.chwId,
    issuer: ISSUER,
    audience: AUDIENCE,
    algorithm: "HS256",
    expiresIn: "12h",
  });
}

type SessionTokenPayload = { chwId: string; role: Role; fullName: string; sub?: string };

export const authenticate = authenticateWith({ allowPinChange: false });

// Only for POST /api/auth/change-pin: a session whose account must choose a
// new PIN may reach that endpoint (and nothing else).
export const authenticateForPinChange = authenticateWith({ allowPinChange: true });

function authenticateWith({ allowPinChange }: { allowPinChange: boolean }) {
  return async function authenticateRequest(req: Request, _res: Response, next: NextFunction) {
  // The browser frontend authenticates via the httpOnly cookie set at login
  // (see routes/auth.ts) - JavaScript can never read or exfiltrate it, which
  // is the whole point (see the Security & data isolation section of the
  // README for the full rationale). The Authorization header is kept as a
  // fallback for non-browser API clients/tests, not as the primary path.
  const cookieToken = req.cookies?.[SESSION_COOKIE_NAME] as string | undefined;
  const header = req.headers.authorization;
  const headerToken = header?.startsWith("Bearer ") ? header.slice("Bearer ".length) : undefined;
  const token = cookieToken || headerToken;

  if (!token) {
    next(new AppError(401, "Authentication required"));
    return;
  }

  let payload: SessionTokenPayload;
  try {
    // Explicit algorithms allowlist (never trust an alg the token itself
    // claims to use - that's what makes algorithm-confusion attacks
    // possible), explicit issuer/audience, and jsonwebtoken already rejects
    // expired/malformed tokens and requires `sub` to be present when
    // `subject` was set at sign time.
    const decoded = jwt.verify(token, getJwtSecret(), {
      algorithms: ["HS256"],
      issuer: ISSUER,
      audience: AUDIENCE,
    });
    if (typeof decoded !== "object" || decoded === null || !decoded.sub) {
      throw new Error("Token missing subject claim");
    }
    payload = decoded as SessionTokenPayload;
  } catch {
    next(new AppError(401, "Invalid or expired session"));
    return;
  }

  // The server, not the token, is authoritative for whether this account can
  // still act at all (section 6/12): a deactivated or locked CHW must lose
  // access immediately, not just at their next login up to 12h later.
  const chw = await prisma.chw.findUnique({
    where: { chw_id: payload.chwId },
    select: { status: true, locked_until: true, clinic_id: true, must_change_pin: true, role: true },
  });

  if (!chw) {
    next(new AppError(401, "Invalid or expired session"));
    return;
  }
  if (chw.status !== "active") {
    next(new AppError(403, "This account has been deactivated", "ACCOUNT_REVOKED"));
    return;
  }
  if (chw.locked_until && chw.locked_until.getTime() > Date.now()) {
    next(new AppError(403, "This account is temporarily locked"));
    return;
  }

  // A supervisor-set (temporary) PIN must be replaced before anything else.
  if (chw.must_change_pin && !allowPinChange) {
    next(new AppError(403, "Choose a new PIN before continuing.", "PIN_CHANGE_REQUIRED"));
    return;
  }

  // Role, like clinic, comes from the database on every request - never the
  // token - so promoting/demoting an account takes effect immediately.
  req.user = { chwId: payload.chwId, role: chw.role, fullName: payload.fullName, clinicId: chw.clinic_id };
  next();
  };
}

// An administrator can do everything a supervisor can (across all clinics),
// so ADMIN passes any SUPERVISOR check. requireRole("ADMIN") stays
// admin-only. Which clinic's data they then see is decided by
// clinicScope()/canAccessClinic() in middleware/authz.ts.
export function hasRole(role: Role, roles: readonly Role[]): boolean {
  return roles.includes(role) || (role === "ADMIN" && roles.includes("SUPERVISOR"));
}

export function requireRole(...roles: Role[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user || !hasRole(req.user.role, roles)) {
      next(new AppError(403, "You do not have permission to perform this action"));
      return;
    }
    next();
  };
}
