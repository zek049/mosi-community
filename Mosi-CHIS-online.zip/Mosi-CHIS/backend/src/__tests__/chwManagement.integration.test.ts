import { beforeEach, describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  process.env.JWT_SECRET = "test-secret-for-integration-tests";
});

const m = vi.hoisted(() => ({
  chwFindUnique: vi.fn(),
  chwFindMany: vi.fn(),
  chwCreate: vi.fn(),
  chwUpdate: vi.fn(),
  chwDelete: vi.fn(),
  visitCount: vi.fn(),
  patientCount: vi.fn(),
  clinicFindUnique: vi.fn(),
  auditLogCreate: vi.fn(),
}));

vi.mock("../db", () => ({
  prisma: {
    chw: { findUnique: m.chwFindUnique, findMany: m.chwFindMany, create: m.chwCreate, update: m.chwUpdate, delete: m.chwDelete },
    visit: { count: m.visitCount },
    patient: { count: m.patientCount },
    clinic: { findUnique: m.clinicFindUnique },
    auditLog: { create: m.auditLogCreate },
  },
}));

import request from "supertest";
import app from "../app";
import { signSessionToken } from "../middleware/auth";

const base = { status: "active", locked_until: null };
const sup = { ...base, chw_id: "SUP001", role: "SUPERVISOR", clinic_id: "clinic-a" }; // supervisors are clinic-scoped (admin-role feature)
const sup2 = { ...base, chw_id: "SUP002", role: "SUPERVISOR", clinic_id: "clinic-a" };
const chwA = { ...base, chw_id: "CHW001", role: "CHW", clinic_id: "clinic-a", full_name: "Jane" };
const fresh = { ...base, chw_id: "CHW009", role: "CHW", clinic_id: "clinic-a", full_name: "New" };
const revoked = { ...chwA, chw_id: "CHW004", status: "revoked" };
const supAuth = { Authorization: `Bearer ${signSessionToken({ chwId: "SUP001", role: "SUPERVISOR", fullName: "Sup" })}` };
const chwAuth = { Authorization: `Bearer ${signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Jane" })}` };

beforeEach(() => {
  vi.clearAllMocks();
  const rows = [sup, sup2, chwA, fresh, revoked];
  m.chwFindUnique.mockImplementation(async ({ where }: { where: { chw_id: string } }) => rows.find((r) => r.chw_id === where.chw_id) ?? null);
  m.chwUpdate.mockImplementation(async ({ where, data }: { where: { chw_id: string }; data: Record<string, unknown> }) => ({ chw_id: where.chw_id, clinic_id: "clinic-a", ...data }));
  m.chwCreate.mockImplementation(async ({ data }: { data: Record<string, unknown> }) => ({ chw_id: data.chw_id, role: data.role, clinic_id: data.clinic_id }));
  m.chwDelete.mockResolvedValue({});
  m.visitCount.mockResolvedValue(0);
  m.patientCount.mockResolvedValue(0);
  m.clinicFindUnique.mockResolvedValue({ id: "clinic-a", name: "Clinic A", active: true });
  m.auditLogCreate.mockResolvedValue({});
});

const audit = () => JSON.stringify(m.auditLogCreate.mock.calls);

describe("authorization", () => {
  it("unauthenticated -> 401 on every management endpoint", async () => {
    expect((await request(app).get("/api/chws/manage")).status).toBe(401);
    expect((await request(app).post("/api/chws/CHW001/revoke")).status).toBe(401);
    expect((await request(app).post("/api/chws/CHW001/reactivate")).status).toBe(401);
    expect((await request(app).delete("/api/chws/CHW009")).status).toBe(401);
    expect((await request(app).post("/api/chws").send({})).status).toBe(401);
  });

  it("a CHW -> 403 on every management endpoint, nothing changes", async () => {
    expect((await request(app).get("/api/chws/manage").set(chwAuth)).status).toBe(403);
    expect((await request(app).post("/api/chws/CHW004/reactivate").set(chwAuth)).status).toBe(403);
    expect((await request(app).post("/api/chws/CHW001/revoke").set(chwAuth)).status).toBe(403);
    expect((await request(app).delete("/api/chws/CHW009").set(chwAuth)).status).toBe(403);
    expect(m.chwUpdate).not.toHaveBeenCalled();
    expect(m.chwDelete).not.toHaveBeenCalled();
  });

  it("a supervisor can't create, edit, revoke or delete SUPERVISOR accounts (looks like not found)", async () => {
    const create = await request(app).post("/api/chws").set(supAuth).send({ chw_id: "SUP009", full_name: "X", clinic_id: "clinic-a", role: "SUPERVISOR", pin: "1234" });
    expect(create.status).toBe(403);
    expect((await request(app).post("/api/chws/SUP002/revoke").set(supAuth)).status).toBe(404);
    expect((await request(app).patch("/api/chws/SUP002").set(supAuth).send({ pin: "9999" })).status).toBe(404);
    expect((await request(app).delete("/api/chws/SUP002").set(supAuth)).status).toBe(404);
    expect(m.chwCreate).not.toHaveBeenCalled();
    expect(m.chwUpdate).not.toHaveBeenCalled();
  });

  it("the generic edit can no longer change role or status (privilege escalation closed)", async () => {
    expect((await request(app).patch("/api/chws/CHW001").set(supAuth).send({ role: "SUPERVISOR" })).status).toBe(400);
    expect((await request(app).patch("/api/chws/CHW001").set(supAuth).send({ status: "active" })).status).toBe(400);
    expect(m.chwUpdate).not.toHaveBeenCalled();
  });
});

describe("revoke / reactivate", () => {
  it("revoke: status -> revoked, history untouched (no deletes), audited", async () => {
    const res = await request(app).post("/api/chws/CHW001/revoke").set(supAuth);
    expect(res.status).toBe(200);
    expect(m.chwUpdate.mock.calls[0][0].data).toEqual({ status: "revoked" });
    expect(m.chwDelete).not.toHaveBeenCalled();
    expect(audit()).toContain("CHW_REVOKED");
  });

  it("revoke twice -> 409", async () => {
    expect((await request(app).post("/api/chws/CHW004/revoke").set(supAuth)).status).toBe(409);
  });

  it("reactivate: status -> active and any lockout cleared, audited", async () => {
    const res = await request(app).post("/api/chws/CHW004/reactivate").set(supAuth);
    expect(res.status).toBe(200);
    expect(m.chwUpdate.mock.calls[0][0].data).toEqual({ status: "active", failed_login_count: 0, locked_until: null });
    expect(audit()).toContain("CHW_REACTIVATED");
  });

  it("a revoked CHW's still-valid session is refused on the next request", async () => {
    const token = signSessionToken({ chwId: "CHW004", role: "CHW", fullName: "Nyasha" });
    const res = await request(app).get("/api/chws/manage").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(403);
    expect(res.body.message).toBe("This account has been deactivated");
  });
});

describe("delete", () => {
  it("deletes an account with no history, audited", async () => {
    const res = await request(app).delete("/api/chws/CHW009").set(supAuth);
    expect(res.status).toBe(200);
    expect(m.chwDelete).toHaveBeenCalledWith({ where: { chw_id: "CHW009" } });
    expect(audit()).toContain("CHW_DELETED");
  });

  it.each([
    ["visits", 3, 0],
    ["registered patients", 0, 2],
  ])("refuses (409 HAS_HISTORY) when the CHW has %s - clinical data is never deleted", async (_what, visits, patients) => {
    m.visitCount.mockResolvedValue(visits);
    m.patientCount.mockResolvedValue(patients);
    const res = await request(app).delete("/api/chws/CHW001").set(supAuth);
    expect(res.status).toBe(409);
    expect(res.body.code).toBe("HAS_HISTORY");
    expect(m.chwDelete).not.toHaveBeenCalled();
  });

  it("unknown account -> 404", async () => {
    expect((await request(app).delete("/api/chws/NOPE01").set(supAuth)).status).toBe(404);
  });
});

describe("create + management list", () => {
  it("supervisor creates a CHW account (hashed PIN, must change it at first sign-in), audited", async () => {
    const res = await request(app).post("/api/chws").set(supAuth).send({ chw_id: "CHW010", full_name: "Added", clinic_id: "clinic-a", pin: "4829" });
    expect(res.status).toBe(201);
    const data = m.chwCreate.mock.calls[0][0].data;
    expect(data.role).toBe("CHW");
    expect(data.pin_hash).not.toBe("4829");
    expect(data.must_change_pin).toBe(true);
    expect(audit()).toContain("CHW_CREATED");
  });

  it("a guessable starting PIN is refused (same rule as the form)", async () => {
    const res = await request(app).post("/api/chws").set(supAuth).send({ chw_id: "CHW010", full_name: "Added", clinic_id: "clinic-a", pin: "4321" });
    expect(res.status).toBe(400);
    expect(res.body.code).toBe("WEAK_PIN");
    expect(m.chwCreate).not.toHaveBeenCalled();
  });

  it("management list: CHW accounts only, with visit counts and whether deletion is allowed, no PIN hashes", async () => {
    m.chwFindMany.mockResolvedValue([
      { chw_id: "CHW001", role: "CHW", status: "active", _count: { visitsRecorded: 5, patientsRegistered: 1 } },
      { chw_id: "CHW009", role: "CHW", status: "active", _count: { visitsRecorded: 0, patientsRegistered: 0 } },
    ]);
    const res = await request(app).get("/api/chws/manage").set(supAuth);
    expect(res.status).toBe(200);
    expect(m.chwFindMany.mock.calls[0][0].where.role).toBe("CHW");
    expect(m.chwFindMany.mock.calls[0][0].select.pin_hash).toBeUndefined();
    expect(res.body.data).toEqual([
      expect.objectContaining({ chw_id: "CHW001", visit_count: 5, can_delete: false }),
      expect.objectContaining({ chw_id: "CHW009", visit_count: 0, can_delete: true }),
    ]);
  });
});
