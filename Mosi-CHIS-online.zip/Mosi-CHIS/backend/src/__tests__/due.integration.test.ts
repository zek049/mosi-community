import { beforeEach, describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  process.env.JWT_SECRET = "test-secret-for-integration-tests";
});

const m = vi.hoisted(() => ({
  chwFindUnique: vi.fn(),
  visitGroupBy: vi.fn(),
  patientFindMany: vi.fn(),
}));

vi.mock("../db", () => ({
  prisma: {
    chw: { findUnique: m.chwFindUnique },
    visit: { groupBy: m.visitGroupBy },
    patient: { findMany: m.patientFindMany },
  },
}));

import request from "supertest";
import app from "../app";
import { signSessionToken } from "../middleware/auth";

const supAuth = { Authorization: `Bearer ${signSessionToken({ chwId: "SUP001", role: "SUPERVISOR", fullName: "Sue" })}` };
const chwAuth = { Authorization: `Bearer ${signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Jane" })}` };
const day = (d: string) => new Date(`${d}T00:00:00.000Z`);

beforeEach(() => {
  vi.clearAllMocks();
  m.chwFindUnique.mockImplementation(async ({ where }: { where: { chw_id: string } }) => ({
    chw_id: where.chw_id,
    role: where.chw_id.startsWith("SUP") ? "SUPERVISOR" : "CHW",
    status: "active",
    locked_until: null,
    clinic_id: "clinic-a",
    must_change_pin: false,
  }));
  m.visitGroupBy.mockResolvedValue([
    { patient_id: "p1", visit_type: "Antenatal", _max: { visit_date: day("2026-08-01") } }, // 35 days overdue
    { patient_id: "p2", visit_type: "Immunization", _max: { visit_date: day("2026-07-08") } }, // due in 1 day
    { patient_id: "p3", visit_type: "HIV/TB Support", _max: { visit_date: day("2026-10-01") } }, // not due
  ]);
  m.patientFindMany.mockResolvedValue([
    { id: "p1", patient_id: "MBR-0001", first_name: "A", last_name: "One", village: "Mbare" },
    { id: "p2", patient_id: "MBR-0002", first_name: "B", last_name: "Two", village: "Mbare" },
  ]);
});

describe("GET /api/patients/due", () => {
  it("401 without a session, 403 for a CHW (CHWs compute it on their device)", async () => {
    expect((await request(app).get("/api/patients/due")).status).toBe(401);
    expect((await request(app).get("/api/patients/due").set(chwAuth)).status).toBe(403);
  });

  it("returns what's due this week and overdue, most overdue first, with patient names", async () => {
    const res = await request(app).get("/api/patients/due?today=2026-10-05").set(supAuth);
    expect(res.status).toBe(200);
    expect(res.body.data).toMatchObject({ today: "2026-10-05", total: 2, overdue: 1, by_type: { Antenatal: 1, Immunization: 1, "Growth Monitoring": 0, "HIV/TB Support": 0 } });
    expect(res.body.data.items.map((i: { patient: { patient_id: string }; days_overdue: number }) => [i.patient.patient_id, i.days_overdue])).toEqual([
      ["MBR-0001", 35],
      ["MBR-0002", -1],
    ]);
  });

  it("asks the database only for tracked types, live visits and live patients", async () => {
    await request(app).get("/api/patients/due?today=2026-10-05").set(supAuth);
    const where = m.visitGroupBy.mock.calls[0][0].where;
    expect(where).toMatchObject({ deleted_at: null, patient: { deleted_at: null } });
    expect([...where.visit_type.in].sort()).toEqual(["Antenatal", "Growth Monitoring", "HIV/TB Support", "Immunization"]);
  });

  it("rejects a malformed today", async () => {
    for (const bad of ["2026-13-45", "2026-02-30", "yesterday", "2026-1-5"]) {
      expect((await request(app).get(`/api/patients/due?today=${bad}`).set(supAuth)).status).toBe(400);
    }
  });
});
