// A thrown AppError carries the HTTP status code its message should be
// returned with. Route handlers just `throw new AppError(...)` and
// middleware/errorHandler.ts turns it into the {success:false, message} JSON
// shape required by the spec - nothing else needs to know about status codes.
export class AppError extends Error {
  statusCode: number;
  /** Optional machine-readable reason (additive to the {success,message} shape). */
  code?: string;

  constructor(statusCode: number, message: string, code?: string) {
    super(message);
    this.name = "AppError";
    this.statusCode = statusCode;
    this.code = code;
  }
}
