// Feature 1 - genuine connectivity + Work Offline. Production build (:4173),
// real backend (:4000). Real offline = Playwright context.setOffline; a server
// outage is simulated by aborting requests to the API host only.
import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const STAMP = `P7-${Date.now()}`;
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
function track(page, who) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => {
    if (m.type() !== "error") return;
    const t = m.text();
    if (/ERR_INTERNET_DISCONNECTED|ERR_FAILED|Failed to fetch|Failed to load resource/.test(t)) return; // deliberate outages
    errors.push(`${who}: ${t}`);
  });
}
const indicator = (page) => page.locator('span:has(> span > .sr-only:text("Connection:"))').first().innerText().catch(() => "");
async function indicatorText(page) {
  return page.evaluate(() => {
    const el = [...document.querySelectorAll("span.sr-only")].find((s) => s.textContent === "Connection: " && s.offsetParent !== null);
    return el ? el.parentElement.textContent.replace("Connection: ", "").trim() : null;
  });
}
const live = (page) => page.evaluate(() => document.querySelector('[role="status"][aria-live="polite"].sr-only')?.textContent ?? "");
async function axe(page, label) {
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
function countRequests(page, pattern) {
  const hits = [];
  page.on("request", (r) => { if (pattern.test(r.url())) hits.push(`${r.method()} ${new URL(r.url()).pathname}`); });
  return hits;
}

const browser = await chromium.launch();

// ---------------------------------------------------------------- LOGIN PAGE
{
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "login");
  const health = countRequests(page, /\/api\/health/);
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => document.body.innerText.includes("Online"), null, { timeout: 8000 });
  report("Login: automatic detection -> 'Online' after a real health check", (await indicatorText(page)) === "Online" && health.length >= 1, { indicator: await indicatorText(page), health });
  report("Login: Sign in enabled when online", !(await page.isDisabled('button[type="submit"]')));
  report("Login: Work Offline switch present (role=switch, off)", (await page.getAttribute('[role="switch"]', "aria-checked")) === "false");
  await axe(page, "Login online");

  // Real network loss
  await ctx.setOffline(true);
  await page.waitForTimeout(300);
  report("Login: automatic offline detection -> 'Offline', sign in disabled", (await indicatorText(page)) === "Offline" && (await page.isDisabled('button[type="submit"]')) && (await page.isVisible("text=You're offline. Signing in needs a connection")));
  await ctx.setOffline(false);
  await page.waitForFunction(() => document.body.innerText.includes("Online") && !document.body.innerText.includes("You're offline"), null, { timeout: 8000 });
  report("Login: network back -> re-checks the server and returns to 'Online'", (await indicatorText(page)) === "Online");

  // Server down while the network is fine
  await page.route(`${API}/health`, (r) => r.abort("connectionrefused"));
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForSelector("text=Server unreachable", { timeout: 10000 });
  report("Login: health check fails -> 'Server unreachable' (not 'Online'), sign in disabled", (await indicatorText(page)) === "Server unreachable" && (await page.isDisabled('button[type="submit"]')));
  report("Login: offers 'Check again'", await page.isVisible('button:has-text("Check again")'));
  await axe(page, "Login server unreachable");
  await page.unroute(`${API}/health`);
  await page.click('button:has-text("Check again")');
  await page.waitForFunction(() => !document.body.innerText.includes("Server unreachable"), null, { timeout: 8000 });
  report("Login: 'Check again' after the server recovers -> 'Online'", (await indicatorText(page)) === "Online");

  // Work Offline from the Sign in page (keyboard: Tab to the switch, Space)
  await page.focus('[role="switch"]');
  await page.keyboard.press("Space");
  await page.waitForTimeout(200);
  report("Login: Space toggles Work Offline on (keyboard)", (await page.getAttribute('[role="switch"]', "aria-checked")) === "true");
  report("Login: Work Offline -> 'Working offline', sign in disabled with explanation", (await indicatorText(page)) === "Working offline" && (await page.isDisabled('button[type="submit"]')) && (await page.isVisible("text=Work Offline is on. Signing in needs the Mosi server")));
  await axe(page, "Login working offline");
  const before = health.length;
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForTimeout(1500);
  report("Login: Work Offline remembered after reload", (await page.getAttribute('[role="switch"]', "aria-checked")) === "true" && (await indicatorText(page)) === "Working offline");
  report("Login: no health-check requests while Work Offline is on", health.length === before, { before, after: health.length });
  await page.click('[role="switch"]');
  await page.waitForFunction(() => document.body.innerText.includes("Online"), null, { timeout: 8000 });
  report("Login: Work Offline off -> checks the server, back to 'Online'", (await indicatorText(page)) === "Online" && !(await page.isDisabled('button[type="submit"]')));
  await ctx.close();
}

// ------------------------------------------------- IN THE APP (CHW, desktop)
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "app");
  const serverCalls = countRequests(page, /localhost:4000\/api\/(?!health)/);
  const healthCalls = countRequests(page, /\/api\/health/);
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => document.body.innerText.includes("Online"));
  await page.fill("#chwId", "CHW001"); await page.fill("#pin", "1234"); await page.press("#pin", "Enter");
  await page.waitForURL("**/chw");
  await page.waitForTimeout(1500);
  report("App: header shows indicator 'Online' and a Work Offline switch", (await indicatorText(page)) === "Online" && (await page.isVisible('header [role="switch"]')));

  // Turn Work Offline on from the app header
  await page.click('header [role="switch"]');
  await page.waitForTimeout(300);
  const pillText = await page.locator("header a[href='/sync']").innerText();
  report("App: header switch -> 'Working offline' everywhere (indicator + sync pill)", (await indicatorText(page)) === "Working offline" && /Working offline/.test(pillText), { indicator: await indicatorText(page), pillText });
  report("App: announced to screen readers", /Working offline\. Changes are saved on this device/.test(await live(page)), await live(page));
  const callsBefore = serverCalls.length;
  const healthBefore = healthCalls.length;
  // Record a patient while working offline
  await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector("h1:has-text('Add patient')");
  report("App: Add patient explains Work Offline", await page.isVisible("text=Work Offline is on. The patient will be saved on this device"));
  await page.fill("#patient_id", `${STAMP}-A`); await page.fill("#first_name", "Workoff"); await page.fill("#last_name", "Line");
  await page.fill("#date_of_birth", "1990-02-02"); await page.check('input[name="gender"][value="F"]'); await page.fill("#village", "Mbare");
  await page.click('button:has-text("Save patient")');
  await page.waitForSelector("text=Patient registered");
  await page.waitForTimeout(1500);
  report("App: saved status says it waits for Work Offline", await page.isVisible("text=Will sync when you turn off Work Offline."));
  await page.goto(`${BASE}/sync`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector("h2:has-text('Working offline')");
  report("App: Sync screen shows 'Working offline' with 1 waiting and a 'Turn off Work Offline' action", (await page.isVisible("text=1 change is saved on this device")) && (await page.isVisible('button:has-text("Turn off Work Offline")')));
  await page.waitForTimeout(31000); // longer than one health-check interval
  report("App: NO server requests at all while Work Offline is on (sync, refresh, health) over 30s+", serverCalls.length === callsBefore && healthCalls.length === healthBefore, { api: serverCalls.slice(callsBefore), health: healthCalls.length - healthBefore });
  await axe(page, "Sync screen working offline");

  // Turn it off from the Sync screen action -> health check -> automatic sync
  await page.click('button:has-text("Turn off Work Offline")');
  await page.waitForSelector("text=Everything is up to date", { timeout: 20000 });
  report("App: Work Offline off -> online -> queued patient syncs automatically", serverCalls.slice(callsBefore).some((c) => c === "POST /api/sync"), serverCalls.slice(callsBefore));
  const onServer = await page.evaluate(async ({ API, id }) => { const r = await fetch(`${API}/patients?search=${id}`, { credentials: "include" }); return ((await r.json()).data ?? []).length; }, { API, id: `${STAMP}-A` });
  report("App: the patient reached the server", onServer === 1);

  // Server outage while signed in (network fine): health + API aborted
  await page.route("http://localhost:4000/api/**", (r) => r.abort("connectionrefused"));
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.waitForSelector("text=Can't reach the Mosi server", { timeout: 10000 });
  report("App: server outage -> 'Server unreachable' state with 'Check again'", (await indicatorText(page)) === "Server unreachable" && (await page.isVisible('button:has-text("Check again")')));
  await page.unroute("http://localhost:4000/api/**");
  await page.click('button:has-text("Check again")');
  await page.waitForSelector("text=Everything is up to date", { timeout: 10000 });
  report("App: 'Check again' after recovery -> online", (await indicatorText(page)) === "Online");
  await ctx.close();
}

// ------------------------------------- MOBILE: Work Offline in the account menu
{
  const ctx = await browser.newContext({ viewport: { width: 360, height: 780 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "mobile");
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => document.body.innerText.includes("Online"));
  await page.fill("#chwId", "CHW001"); await page.fill("#pin", "1234"); await page.press("#pin", "Enter");
  await page.waitForURL("**/chw");
  await page.waitForTimeout(1200);
  report("Mobile: top bar shows the connection indicator", (await indicatorText(page)) === "Online");
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  report("Mobile 360px: top bar fits (no horizontal scroll)", overflow <= 0, overflow);
  await page.click('button[aria-label^="Account menu"]');
  const item = page.locator('[role="menuitemcheckbox"]:has-text("Work offline")');
  report("Mobile: account menu has a 'Work offline' checkbox item (unchecked)", (await item.getAttribute("aria-checked")) === "false");
  await item.focus();
  await page.keyboard.press("Enter");
  await page.waitForTimeout(300);
  report("Mobile: Enter toggles it; menu stays open showing it checked", (await item.getAttribute("aria-checked")) === "true");
  await page.keyboard.press("Escape");
  await page.waitForTimeout(200);
  report("Mobile: top bar now 'Working offline'", (await indicatorText(page)) === "Working offline");
  const top = await page.evaluate(() => document.querySelector("header.sticky")?.getBoundingClientRect().height);
  report("Mobile: sticky sync strip offset still matches top bar height (57px)", Math.round(top) === 57, top);
  await axe(page, "Mobile home working offline");
  await page.click('button[aria-label^="Account menu"]');
  await page.click('[role="menuitemcheckbox"]:has-text("Work offline")');
  await page.keyboard.press("Escape");
  await ctx.close();
}

// ------------------------------------------ SUPERVISOR with Work Offline on
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await ctx.newPage();
  track(page, "supervisor");
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => document.body.innerText.includes("Online"));
  await page.fill("#chwId", "SUP001"); await page.fill("#pin", "1234"); await page.press("#pin", "Enter");
  await page.waitForURL("**/supervisor");
  await page.waitForTimeout(1200);
  await page.click('header [role="switch"]');
  await page.click('aside a[href="/supervisor/chw-activity"]');
  await page.waitForTimeout(500);
  report("Supervisor: Work Offline -> clear notice instead of an endless spinner", await page.isVisible("text=Server data on these screens loads once Mosi can reach the server"));
  await page.click('[role="status"] button:has-text("Turn off Work Offline")');
  await page.waitForSelector("text=Nyasha Chidziva", { timeout: 10000 });
  report("Supervisor: turning it off resumes the paused server data", true);
  await ctx.close();
}

await browser.close();
console.log(`\nConsole/page errors: ${errors.length}`); errors.forEach((e) => console.log("  ", e));
console.log(`${pass} passed, ${fail} failed. TEST_STAMP=${STAMP}`);
