import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { onlineManager } from "@tanstack/react-query";
import { API_BASE_URL } from "../services/api";
import {
  HEALTH_CHECK_INTERVAL_MS,
  checkServerHealth,
  deriveConnectivity,
  publishConnectivity,
  readWorkOffline,
  writeWorkOffline,
  type ConnectivityStatus,
} from "../services/connectivity";

// The single connectivity state for the whole app - see
// services/connectivity.ts for the rules. Everything that cares (sync,
// cache refresh, status pill, Sync screen, save screens, Sign in page, and
// TanStack Query's server requests) reads THIS, never navigator.onLine
// directly, so they can't disagree.
type NetworkContextValue = {
  /** True only when Mosi may contact the server. */
  isOnline: boolean;
  status: ConnectivityStatus;
  browserOnline: boolean;
  serverReachable: boolean | null;
  workOffline: boolean;
  setWorkOffline: (value: boolean) => void;
  lastCheckedAt: number | null;
  /** Run a health check now (e.g. "Check again"). No-op while Work Offline is on. */
  recheck: () => Promise<void>;
  /** A real request just failed to reach the server - mark it unreachable and re-check soon. */
  reportServerUnreachable: () => void;
};

const NetworkContext = createContext<NetworkContextValue | undefined>(undefined);

export function NetworkProvider({ children }: { children: ReactNode }) {
  const [browserOnline, setBrowserOnline] = useState(navigator.onLine);
  const [serverReachable, setServerReachable] = useState<boolean | null>(null);
  const [workOffline, setWorkOfflineState] = useState(readWorkOffline);
  const [lastCheckedAt, setLastCheckedAt] = useState<number | null>(null);
  const checking = useRef(false);

  const runCheck = useCallback(async () => {
    if (checking.current || workOffline || !navigator.onLine) return;
    checking.current = true;
    try {
      const ok = await checkServerHealth(API_BASE_URL);
      setServerReachable(ok);
      setLastCheckedAt(Date.now());
    } finally {
      checking.current = false;
    }
  }, [workOffline]);

  // Browser network events.
  useEffect(() => {
    const handleOnline = () => {
      setBrowserOnline(true);
      void runCheck();
    };
    const handleOffline = () => setBrowserOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, [runCheck]);

  // Periodic health check - only while it could change anything: browser
  // online, Work Offline off, and the tab visible (a hidden tab re-checks
  // the moment it's shown again).
  useEffect(() => {
    if (!browserOnline || workOffline) return;
    void runCheck();
    const timer = window.setInterval(() => {
      if (document.visibilityState === "visible") void runCheck();
    }, HEALTH_CHECK_INTERVAL_MS);
    const onVisible = () => {
      if (document.visibilityState === "visible") void runCheck();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [browserOnline, workOffline, runCheck]);

  const setWorkOffline = useCallback((value: boolean) => {
    writeWorkOffline(value);
    setWorkOfflineState(value);
    // Turning it off: don't trust a stale result - check before going online.
    if (!value) setServerReachable(null);
  }, []);

  const reportServerUnreachable = useCallback(() => {
    setServerReachable(false);
    setLastCheckedAt(Date.now());
  }, []);

  const { status, isOnline } = deriveConnectivity({ browserOnline, serverReachable, workOffline });

  // Publish to non-React code during render, not in an effect: child
  // effects (e.g. SyncContext reacting to "back online") run before this
  // provider's effects, and must already see the new state. It's a plain,
  // idempotent assignment.
  publishConnectivity({ status, isOnline, workOffline });

  // TanStack Query: while not online, server queries/mutations pause
  // instead of firing, and resume when connectivity returns.
  useEffect(() => {
    onlineManager.setOnline(isOnline);
  }, [isOnline]);

  const value = useMemo<NetworkContextValue>(
    () => ({
      isOnline,
      status,
      browserOnline,
      serverReachable,
      workOffline,
      setWorkOffline,
      lastCheckedAt,
      recheck: runCheck,
      reportServerUnreachable,
    }),
    [isOnline, status, browserOnline, serverReachable, workOffline, setWorkOffline, lastCheckedAt, runCheck, reportServerUnreachable],
  );

  return <NetworkContext.Provider value={value}>{children}</NetworkContext.Provider>;
}

export function useNetwork(): NetworkContextValue {
  const context = useContext(NetworkContext);
  if (!context) {
    throw new Error("useNetwork must be used within a NetworkProvider");
  }
  return context;
}
