import { Leaf } from "lucide-react";
import { cn } from "../lib/utils";

type LogoProps = {
  tagline?: boolean;
  onDark?: boolean;
  size?: "sm" | "md" | "lg";
  className?: string;
};

const MARK_SIZE = { sm: "h-6 w-6", md: "h-8 w-8", lg: "h-10 w-10" } as const;
const TEXT_SIZE = { sm: "text-sm", md: "text-lg", lg: "text-2xl" } as const;

// One brand mark (leaf badge + wordmark, with an optional tagline) shared
// by Landing, Login, the desktop sidebar, and the mobile top bar - so the
// same identity reads consistently everywhere rather than each screen
// hand-rolling its own "Mosi" text.
export function Logo({ tagline = false, onDark = false, size = "md", className }: LogoProps) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <span
        className={cn(
          "flex shrink-0 items-center justify-center rounded-full",
          onDark ? "bg-white/15 text-white" : "bg-forest-800 text-white",
          MARK_SIZE[size],
        )}
      >
        <Leaf className={size === "sm" ? "h-3.5 w-3.5" : "h-5 w-5"} aria-hidden="true" />
      </span>
      <span className="leading-tight">
        <span className={cn("block font-semibold tracking-tight", TEXT_SIZE[size], onDark ? "text-white" : "text-forest-900")}>
          Mosi
        </span>
        {tagline && (
          <span className={cn("block text-[11px] font-medium", onDark ? "text-white/60" : "text-stone-500")}>
            Community health in motion
          </span>
        )}
      </span>
    </div>
  );
}
