// Final hardening pass - browser checks on the PRODUCTION build (:4173):
// PIN reset, sign-out privacy, sync status states, sync-log request
// discipline + 429 handling, and axe on every new screen/dialog.
import { chromium } from "playwright";
import { readFileSync, writeFileSync } from "node:fs";
import { execSync } from "node:child_process";

// Test-only: put a demo account back to PIN 1234 with no temporary-PIN flag
// (a supervisor-set PIN is now temporary by design).
function restoreDemoPin(chwId) {
  const hash = readFileSync(new URL("./demo-pin-hash.txt", import.meta.url), "utf8").trim();
  const sql = `update chws set pin_hash='${hash}', must_change_pin=false, failed_login_count=0, locked_until=null where chw_id='${chwId}';`;
  writeFileSync(new URL("./restore.sql", import.meta.url), sql);
  execSync(`docker cp "${new URL("./restore.sql", import.meta.url).pathname.replace(/^\//, "")}" mosi-postgres:/tmp/restore.sql`);
  execSync(`docker exec mosi-postgres sh -c "psql -q -U \$POSTGRES_USER -d \$POSTGRES_DB -f /tmp/restore.sql"`, { env: { ...process.env, MSYS_NO_PATHCONV: "1" } });
}

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const STAMP = `P4-${Date.now()}`;
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
const axeProblems = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
function track(page, who, allow = []) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => {
    if (m.type() === "warning" && /blocked/.test(m.text())) errors.push(`${who}: ${m.text()}`);
    if (m.type() !== "error") return;
    const t = m.text();
    if (/ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(t)) return; // genuinely offline moments
    if (allow.some((re) => re.test(t))) return;
    errors.push(`${who}: ${t}`);
  });
}
const active = (page) => page.evaluate(() => {
  const el = document.activeElement;
  return { tag: el?.tagName, text: (el?.getAttribute("aria-label") || el?.textContent || "").trim().slice(0, 60), id: el?.id, role: el?.getAttribute("role"), name: el?.getAttribute("name") };
});
const live = (page) => page.evaluate(() => document.querySelector('[role="status"][aria-live="polite"].sr-only')?.textContent ?? "");
const dbNames = (page) => page.evaluate(async () => (await indexedDB.databases()).map((d) => d.name).sort());
async function axe(page, label) {
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa", "best-practice"] } })).violations.map((x) => `${x.impact} ${x.id} (${x.nodes.length})`));
  const serious = v.filter((x) => /^(critical|serious)/.test(x));
  if (v.length) axeProblems.push(`${label}: ${v.join(", ")}`);
  report(`axe: no critical/serious issues - ${label}`, serious.length === 0, v.length ? v : undefined);
}
async function login(page, id, pin = "1234") {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.fill("#chwId", id);
  await page.fill("#pin", pin);
  await page.press("#pin", "Enter");
  await page.waitForURL((u) => !u.pathname.startsWith("/login"), { timeout: 10000 });
  await page.waitForTimeout(1200);
}
async function signOutViaMenu(page) {
  // Mobile account menu (375px viewport)
  await page.click('button[aria-label^="Account menu"]');
  await page.click('[role="menuitem"]:has-text("Sign out")');
}

const browser = await chromium.launch();

// =====================================================================
// 1. PIN RESET
// =====================================================================
{
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "pin", [/status of 500/]);
  let patchCount = 0;
  page.on("request", (r) => { if (r.method() === "PATCH" && r.url().includes("/api/chws/")) patchCount++; });
  await login(page, "SUP001");

  await page.click('nav button:has-text("More")');
  report("PIN: 'Reset a PIN' is in the supervisor's More menu", await page.isVisible('[role="menuitem"]:has-text("Reset a PIN")'));
  await page.click('[role="menuitem"]:has-text("Reset a PIN")');
  await page.waitForURL("**/supervisor/pin-reset");
  await page.waitForSelector('input[name="account"]');
  const listText = await page.locator("main").innerText();
  report("PIN: account list shows names + CHW IDs, never a PIN or hash", /John Ncube/.test(listText) && /CHW002/.test(listText) && !/pin_hash|\$2[aby]\$/.test(listText));
  await axe(page, "PIN reset - account list (375px)");

  // Keyboard: search, pick with Space, type both PINs, Enter to submit.
  await page.focus('input[type="search"]');
  await page.keyboard.type("CHW002");
  await page.keyboard.press("Tab");
  await page.keyboard.press("Space");
  await page.waitForSelector("#new-pin");
  report("PIN: form names the chosen account", await page.isVisible("text=New PIN for John Ncube (CHW002)"));
  await page.focus("#new-pin");
  await page.keyboard.type("5822");
  await page.keyboard.press("Tab");
  await page.keyboard.type("5823");
  await page.keyboard.press("Enter");
  await page.waitForTimeout(150);
  let a = await active(page);
  report("PIN: mismatched confirmation blocked, focus on the field with the error", a.id === "confirm-pin" && (await page.isVisible("text=The two PINs don't match")), a);
  report("PIN: no request sent for invalid input", patchCount === 0);
  await axe(page, "PIN reset - validation error");

  await page.fill("#confirm-pin", "5822");
  await page.keyboard.press("Enter");
  await page.waitForTimeout(200);
  let dlg = await page.evaluate(() => { const d = document.querySelector("dialog[open]"); return d ? { text: d.innerText, focus: document.activeElement.textContent } : null; });
  report("PIN: confirmation dialog names the account; focus starts on Cancel", dlg && /John Ncube \(CHW002\)/.test(dlg.text) && dlg.focus === "Cancel", dlg);
  await axe(page, "PIN reset - confirmation dialog open");
  await page.keyboard.press("Escape");
  await page.waitForTimeout(200);
  a = await active(page);
  report("PIN: Escape cancels - no request, focus back where the supervisor submitted from", patchCount === 0 && a.id === "confirm-pin", a);

  // Failed reset (server error simulated by intercepting this one request).
  await page.route("**/api/chws/CHW002", (route) => route.request().method() === "PATCH"
    ? route.fulfill({ status: 500, contentType: "application/json", headers: { "access-control-allow-origin": BASE, "access-control-allow-credentials": "true" }, body: JSON.stringify({ success: false, message: "boom" }) })
    : route.continue());
  await page.keyboard.press("Enter");
  await page.waitForTimeout(200);
  await page.keyboard.press("Tab");
  await page.keyboard.press("Enter"); // confirm
  await page.waitForSelector('[role="alert"]:has-text("PIN was not changed")', { timeout: 5000 });
  a = await active(page);
  report("PIN: failed reset explains the PIN was NOT changed, focus on the message", a.role === "alert" && /not changed/.test(a.text), a);
  await page.unroute("**/api/chws/CHW002");

  // Successful reset.
  await page.click('button[type="submit"]:has-text("Reset PIN")');
  await page.click('dialog[open] button:has-text("Reset PIN")');
  await page.waitForSelector("text=PIN reset for John Ncube (CHW002)", { timeout: 8000 });
  a = await active(page);
  const bodyText = await page.locator("body").innerText();
  const inputs = await page.evaluate(() => [...document.querySelectorAll("input")].map((i) => i.value));
  report("PIN: success message focused, says it's temporary (they choose their own at sign-in)", a.role === "status" && /temporary PIN/.test(bodyText) && /choose their own PIN/.test(bodyText), a);
  report("PIN: new PIN not left on screen, in inputs, or in the live region", !bodyText.includes("5822") && !inputs.includes("5822") && !(await live(page)).includes("5822"));
  await ctx.close();

  // The reset really took effect on the server.
  const c2 = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const p2 = await c2.newPage();
  track(p2, "pin-verify", [/status of 401/]);
  await p2.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await p2.fill("#chwId", "CHW002"); await p2.fill("#pin", "1234"); await p2.press("#pin", "Enter");
  report("PIN: old PIN no longer works", await p2.waitForSelector("text=Invalid CHW ID or PIN", { timeout: 6000 }).then(() => true).catch(() => false));
  await p2.fill("#pin", "5822"); await p2.press("#pin", "Enter");
  report("PIN: new (temporary) PIN works and leads to 'Choose a new PIN'", await p2.waitForURL("**/change-pin", { timeout: 8000 }).then(() => true).catch(() => false));
  await c2.close();

  // Restore the seed PIN (back to 1234) through the same UI.
  const c3 = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
  const p3 = await c3.newPage();
  track(p3, "pin-restore");
  await login(p3, "SUP001");
  await p3.click('aside a:has-text("Reset a PIN")');
  await p3.waitForSelector('input[name="account"]');
  await axe(p3, "PIN reset - desktop (1280px)");
  await p3.check('input[name="account"][value="CHW002"]');
  await p3.fill("#new-pin", "1234"); await p3.fill("#confirm-pin", "1234");
  await p3.click('button[type="submit"]:has-text("Reset PIN")');
  await p3.click('dialog[open] button:has-text("Reset PIN")');
  report("PIN: reset to 1234 through the UI (cleanup clears the temporary flag)", await p3.waitForSelector("text=PIN reset for John Ncube", { timeout: 8000 }).then(() => true).catch(() => false));
  await c3.close();

  // Unauthorized: a CHW can't reach the screen, and the server refuses anyway.
  const c4 = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const p4 = await c4.newPage();
  track(p4, "pin-chw", [/status of 403/]);
  await login(p4, "CHW001");
  await p4.goto(`${BASE}/supervisor/pin-reset`, { waitUntil: "networkidle" });
  report("PIN: CHW is redirected away from /supervisor/pin-reset", new URL(p4.url()).pathname === "/chw", p4.url());
  report("PIN: CHW navigation has no PIN reset link", (await p4.locator("text=Reset a PIN").count()) === 0);
  const direct = await p4.evaluate(async (API) => (await fetch(`${API}/chws/CHW002`, { method: "PATCH", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pin: "0000" }) })).status, API);
  report("PIN: server refuses a CHW's direct reset request (403)", direct === 403, direct);
  await c4.close();
}

restoreDemoPin("CHW002");

// =====================================================================
// 2. SIGN-OUT PRIVACY
// =====================================================================
{
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "privacy", [/status of 503/]);
  await login(page, "CHW001");
  const namesSignedIn = await dbNames(page);
  report("Privacy: signed-in CHW001 uses its own database", namesSignedIn.some((n) => /user-CHW001/.test(n)), namesSignedIn);

  // (a) nothing pending -> immediate sign-out, data removed
  await signOutViaMenu(page);
  await page.waitForURL("**/login");
  report("Privacy: no pending -> signs out immediately with a clear notice", await page.waitForSelector("text=Your records were removed from this device", { timeout: 5000 }).then(() => true).catch(() => false));
  await axe(page, "Login - signed-out notice");
  report("Privacy: CHW001's database is gone after sign-out", !(await dbNames(page)).some((n) => /user-CHW001/.test(n)), await dbNames(page));
  for (const path of ["/chw", "/patients", "/sync", "/supervisor"]) {
    await page.goto(`${BASE}${path}`, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(500);
    report(`Privacy: reopening ${path} after sign-out goes to /login`, new URL(page.url()).pathname === "/login");
  }

  // (b) pending offline change -> warned, kept for the owner only
  await login(page, "CHW001");
  await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "networkidle" });
  await ctx.setOffline(true);
  await page.fill("#patient_id", `${STAMP}-A`);
  await page.fill("#first_name", "Private");
  await page.fill("#last_name", "Pending");
  await page.fill("#date_of_birth", "1991-02-03");
  await page.check('input[name="gender"][value="F"]');
  await page.fill("#village", "Mbare");
  await page.click('button:has-text("Save patient")');
  await page.waitForSelector("text=Patient registered");
  await signOutViaMenu(page);
  await page.waitForSelector("dialog[open]");
  let dlg = await page.locator("dialog[open]").innerText();
  report("Privacy: pending change -> sign-out stops and warns", /1 change hasn't synced yet/.test(dlg), dlg.slice(0, 120));
  report("Privacy: offline -> no 'sync' option offered, says why", !/Sync, then sign out/.test(dlg) && /You're offline/.test(dlg));
  report("Privacy: focus starts on the safe choice ('Stay signed in')", (await active(page)).text === "Stay signed in");
  await axe(page, "Sign-out dialog (pending, offline)");
  await page.keyboard.press("Escape");
  await page.waitForTimeout(200);
  report("Privacy: Escape = stay signed in, nothing removed", new URL(page.url()).pathname !== "/login" && !(await page.isVisible("dialog[open]")));
  await signOutViaMenu(page);
  await page.click('dialog[open] button:has-text("Sign out, keep them here")');
  await page.waitForURL("**/login");
  report("Privacy: login notice says the unsynced change was kept", await page.waitForSelector("text=1 unsynced change is kept on this device", { timeout: 5000 }).then(() => true).catch(() => false));
  const kept = await page.evaluate(async () => {
    const name = (await indexedDB.databases()).map((d) => d.name).find((n) => /user-CHW001/.test(n));
    if (!name) return null;
    const db = await new Promise((res) => { const r = indexedDB.open(name); r.onsuccess = () => res(r.result); });
    const all = await new Promise((res) => { const g = db.transaction("patients").objectStore("patients").getAll(); g.onsuccess = () => res(g.result); });
    db.close();
    return all.map((p) => `${p.first_name} ${p.last_name}:${p.sync_status}`);
  });
  report("Privacy: only the unsynced record remains in CHW001's database", JSON.stringify(kept) === JSON.stringify(["Private Pending:pending"]), kept);

  // (c) user B on the same device can't see it
  await ctx.setOffline(false);
  await login(page, "CHW002");
  await page.goto(`${BASE}/patients`, { waitUntil: "networkidle" });
  await page.fill('input[type="search"]', "Private");
  await page.waitForTimeout(400);
  report("Privacy: CHW002 cannot see CHW001's unsynced patient", (await page.locator("main").innerText()).includes("No patients match"));
  await page.goto(`${BASE}/sync`, { waitUntil: "networkidle" });
  report("Privacy: CHW002 has nothing waiting (A's change isn't in B's queue)", /Waiting \(0\)/.test(await page.locator("main").innerText()));
  await signOutViaMenu(page);
  await page.waitForURL("**/login");

  // (d) owner signs back in -> it syncs
  await login(page, "CHW001");
  await page.goto(`${BASE}/sync`, { waitUntil: "networkidle" });
  const synced = await page.waitForSelector("text=Everything is up to date", { timeout: 20000 }).then(() => true).catch(() => false);
  const onServer = await page.evaluate(async ({ API, id }) => {
    const b = await (await fetch(`${API}/patients?search=${id}`, { credentials: "include" })).json();
    return (Array.isArray(b.data) ? b.data : []).some((p) => p.patient_id === id);
  }, { API, id: `${STAMP}-A` });
  report("Privacy: kept change syncs when its owner signs back in, and reaches the server", synced && onServer, { synced, onServer });

  // (e) "Sync, then sign out" (first sync attempt forced to fail so the change stays pending)
  await page.route("**/api/sync", (r) => r.request().method() === "POST"
    ? r.fulfill({ status: 503, contentType: "application/json", headers: { "access-control-allow-origin": BASE, "access-control-allow-credentials": "true" }, body: JSON.stringify({ success: false, message: "down" }) })
    : r.continue());
  await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "networkidle" });
  await page.fill("#patient_id", `${STAMP}-B`);
  await page.fill("#first_name", "Sync");
  await page.fill("#last_name", "Beforesignout");
  await page.fill("#date_of_birth", "1991-02-03");
  await page.check('input[name="gender"][value="M"]');
  await page.fill("#village", "Mbare");
  await page.click('button:has-text("Save patient")');
  await page.waitForSelector("text=Patient registered");
  await page.waitForTimeout(1500);
  await page.unroute("**/api/sync");
  await signOutViaMenu(page);
  await page.waitForSelector("dialog[open]");
  report("Privacy: online -> 'Sync, then sign out' is offered", await page.isVisible('dialog[open] button:has-text("Sync, then sign out")'));
  await page.click('dialog[open] button:has-text("Sync, then sign out")');
  await page.waitForURL("**/login", { timeout: 20000 });
  report("Privacy: synced first, then signed out with everything removed", await page.waitForSelector("text=Your records were removed from this device", { timeout: 5000 }).then(() => true).catch(() => false));

  // (f) "Remove my data from this device" with an unsynced change
  await login(page, "CHW001");
  await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "networkidle" });
  await ctx.setOffline(true);
  await page.fill("#patient_id", `${STAMP}-C`);
  await page.fill("#first_name", "Will");
  await page.fill("#last_name", "Bewiped");
  await page.fill("#date_of_birth", "1991-02-03");
  await page.check('input[name="gender"][value="F"]');
  await page.fill("#village", "Mbare");
  await page.click('button:has-text("Save patient")');
  await page.waitForSelector("text=Patient registered");
  await page.goto(`${BASE}/sync`, { waitUntil: "domcontentloaded" });
  await page.click('button:has-text("Remove my data from this device")');
  await page.waitForSelector("dialog[open]");
  dlg = await page.locator("dialog[open]").innerText();
  const confirmDisabled = await page.isDisabled('dialog[open] button:has-text("Remove and sign out")');
  report("Privacy: wipe warns that the unsynced change will be lost; confirm disabled until acknowledged", /1 change has not reached the server/.test(dlg) && confirmDisabled);
  await axe(page, "Remove-my-data dialog (pending)");
  await page.keyboard.press("Escape");
  report("Privacy: cancelling the wipe removes nothing", (await dbNames(page)).some((n) => /user-CHW001/.test(n)));
  await page.click('button:has-text("Remove my data from this device")');
  await page.check('dialog[open] input[type="checkbox"]');
  await page.click('dialog[open] button:has-text("Remove and sign out")');
  await page.waitForURL("**/login");
  report("Privacy: after explicit confirmation, the account's data is removed and user signed out", !(await dbNames(page)).some((n) => /user-CHW001/.test(n)));
  await ctx.setOffline(false);
  await ctx.close();
}

// =====================================================================
// 3. SYNC STATUS STATES (partial result simulated at the network layer)
// =====================================================================
{
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  track(page, "sync-states");
  await login(page, "CHW001");
  await page.goto(`${BASE}/sync`, { waitUntil: "networkidle" });
  await page.click('button:has-text("Sync now")');
  await page.waitForTimeout(1200);
  report("Sync: zero pending -> 'Everything is up to date.' announced", /Everything is up to date\./.test(await live(page)), await live(page));

  // Two offline patients, then a server answer: one accepted, one rejected.
  await ctx.setOffline(true);
  for (const suffix of ["D", "E"]) {
    await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "domcontentloaded" });
    await page.fill("#patient_id", `${STAMP}-${suffix}`);
    await page.fill("#first_name", "Batch");
    await page.fill("#last_name", `Test${suffix}`);
    await page.fill("#date_of_birth", "1990-01-01");
    await page.check('input[name="gender"][value="F"]');
    await page.fill("#village", "Mbare");
    await page.click('button:has-text("Save patient")');
    await page.waitForSelector("text=Patient registered");
  }
  await page.goto(`${BASE}/sync`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector("text=You're offline");
  const offlineCard = await page.locator("main").innerText();
  report("Sync: offline -> '2 changes are saved on this device'", /2 changes are saved on this device/.test(offlineCard));
  let sawSyncing = false;
  await page.route("**/api/sync", async (route) => {
    if (route.request().method() !== "POST") return route.continue();
    const body = JSON.parse(route.request().postData());
    const [first, second] = body.patients;
    await new Promise((r) => setTimeout(r, 1500)); // hold the batch so the in-flight state is observable
    await route.fulfill({
      status: 200, contentType: "application/json",
      headers: { "access-control-allow-origin": BASE, "access-control-allow-credentials": "true" },
      body: JSON.stringify({ success: true, data: { patients: [{ id: first.id, status: "failed", message: "rejected" }, { id: second.id, status: "failed", message: "rejected" }], visits: [] } }),
    });
  });
  await ctx.setOffline(false);
  for (let i = 0; i < 20 && !sawSyncing; i++) { sawSyncing = /Syncing 2 changes…/.test(await page.locator("main").innerText()); if (!sawSyncing) await page.waitForTimeout(100); }
  report("Sync: in flight -> 'Syncing 2 changes…' (a total, no fake per-record progress)", sawSyncing);
  await page.waitForSelector("text=Sync paused", { timeout: 10000 });
  const pausedCard = await page.locator("main").innerText();
  report("Sync: rejected batch -> 'Sync paused' with the real counts", /2 changes couldn't sync and are still waiting/.test(pausedCard) && /Retry sync/.test(pausedCard), pausedCard.slice(0, 260));
  report("Sync: announced with real counts", /2 changes couldn't sync and are still waiting\./.test(await live(page)), await live(page));
  // Retry against the real server - both are accepted.
  await page.unroute("**/api/sync");
  await page.click('button:has-text("Retry sync")');
  await page.waitForSelector("text=Everything is up to date", { timeout: 15000 });
  await page.waitForTimeout(300); // announcer sets its text 50ms after clearing
  const afterRetry = await page.locator("main").innerText();
  report("Sync: Retry sync -> '2 changes synced.'", /2 changes synced\./.test(await live(page)) && /Last sync: 2 changes synced\./.test(afterRetry), { live: await live(page), card: afterRetry.slice(0, 260) });
  await ctx.close();
}

// =====================================================================
// 4. SYNC-LOG REQUESTS + 429 HANDLING (supervisor)
// =====================================================================
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "ratelimit", [/status of 429/]);
  const logRequests = [];
  page.on("request", (r) => { if (r.url().includes("/api/sync/log")) logRequests.push(new URL(r.url()).search); });
  await login(page, "SUP001");
  for (const path of ["/supervisor", "/supervisor/chw-activity", "/sync", "/supervisor", "/supervisor/chw-activity", "/sync"]) {
    await page.click(`aside a[href="${path}"]`);
    await page.waitForTimeout(700);
  }
  report("Rate limit: Dashboard -> CHW Activity -> Sync (twice) makes ONE sync-log request", logRequests.length === 1, logRequests);

  const c2 = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
  const p2 = await c2.newPage();
  track(p2, "ratelimit-429", [/status of 429/]);
  let limited = 0;
  await p2.route("**/api/sync/log**", (route) => {
    limited++;
    return route.fulfill({ status: 429, contentType: "application/json", headers: { "access-control-allow-origin": BASE, "access-control-allow-credentials": "true", "access-control-expose-headers": "Retry-After", "retry-after": "4" }, body: JSON.stringify({ success: false, message: "Too many sync attempts. Please wait a moment and try again." }) });
  });
  await login(p2, "SUP001");
  await p2.waitForSelector("text=The server is limiting requests", { timeout: 8000 });
  const dash = await p2.locator("main").innerText();
  report("Rate limit: 429 -> clear message, rest of the dashboard still shown (not blank)", /Active CHWs/.test(dash) && /Visits per day/.test(dash));
  report("Rate limit: retry button waits for Retry-After", /Try again in [1-4]s/.test(dash) && (await p2.isDisabled('button:has-text("Try again in")')), dash.match(/.{0,100}(Try again|limiting).{0,100}/s)?.[0]);
  await axe(p2, "Dashboard with rate-limit notice");
  await p2.waitForTimeout(2000);
  report("Rate limit: no automatic retry hammering the server", limited === 1, limited);
  await p2.waitForSelector('button:has-text("Try again"):not([disabled])', { timeout: 6000 });
  await p2.unroute("**/api/sync/log**");
  await p2.click('button:has-text("Try again")');
  await p2.waitForTimeout(1500);
  report("Rate limit: manual retry after the wait recovers", !(await p2.isVisible("text=The server is limiting requests")));
  await c2.close();
  await ctx.close();
}

// =====================================================================
// 5. CONTACT NOTICE - honest when not configured
// =====================================================================
{
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  track(page, "contact");
  await page.goto(`${BASE}/`, { waitUntil: "networkidle" });
  await page.click('footer button:has-text("Contact")');
  const text = await page.locator("dialog[open]").innerText();
  report("Contact: unconfigured -> points to the system administrator, no invented details", /contact your system administrator/.test(text) && !/@|\+\d|mailto/.test(text), text);
  await page.keyboard.press("Escape");
  await page.click('footer button:has-text("Privacy")');
  const privacy = await page.locator("dialog[open]").innerText();
  report("Privacy notice describes per-account storage, sign-out behaviour, and says it's not encrypted", /separately for each account/.test(privacy) && /not encrypted/.test(privacy) && /Remove my data from this device/.test(privacy));
  await ctx.close();
}

await browser.close();
console.log(`\nConsole/page errors: ${errors.length}`); errors.forEach((e) => console.log("  ", e));
console.log(`axe findings (any impact): ${axeProblems.length}`); axeProblems.forEach((e) => console.log("  ", e));
console.log(`\n${pass} passed, ${fail} failed. TEST_STAMP=${STAMP}`);
