import { beforeEach, describe, expect, it, vi } from "vitest";

const { patientFindUnique, chwFindUnique } = vi.hoisted(() => ({
  patientFindUnique: vi.fn(),
  chwFindUnique: vi.fn(),
}));

vi.mock("../../db", () => ({
  prisma: {
    patient: { findUnique: patientFindUnique },
    chw: { findUnique: chwFindUnique },
  },
}));

// Vitest hoists vi.mock above this import, so validation.ts's `import {
// prisma } from "../db"` resolves to the mock above rather than the real
// Prisma client - no live database needed to test these rules.
import { validatePatientFields, validateVisitFields } from "../validation";

describe("validatePatientFields", () => {
  const validPatient = {
    patient_id: "MBR-0001",
    first_name: "Rudo",
    last_name: "Chirwa",
    village: "Mbare",
    gender: "F",
    date_of_birth: "2016-05-07",
  };

  it("accepts a fully valid patient", () => {
    expect(validatePatientFields(validPatient, { partial: false })).toEqual([]);
  });

  it("requires the core string fields", () => {
    const errors = validatePatientFields({ ...validPatient, first_name: "  " }, { partial: false });
    expect(errors).toContain("First name is required");
  });

  it("rejects a gender that is not M or F", () => {
    const errors = validatePatientFields({ ...validPatient, gender: "X" }, { partial: false });
    expect(errors).toContain("Gender must be M or F");
  });

  it("rejects an unparseable date of birth", () => {
    const errors = validatePatientFields({ ...validPatient, date_of_birth: "not-a-date" }, { partial: false });
    expect(errors).toContain("Date of birth is not a valid date");
  });

  it("rejects a phone number that isn't 10 digits starting with 0", () => {
    const errors = validatePatientFields({ ...validPatient, phone_number: "123" }, { partial: false });
    expect(errors.some((e) => e.includes("Phone number"))).toBe(true);
  });

  it("allows a missing phone number (it's optional)", () => {
    expect(validatePatientFields(validPatient, { partial: false })).toEqual([]);
  });

  it("in partial mode, skips fields that are simply absent", () => {
    const errors = validatePatientFields({ village: "Mbare" }, { partial: true });
    expect(errors).toEqual([]);
  });

  it("in partial mode, still validates a field that IS present", () => {
    const errors = validatePatientFields({ gender: "X" }, { partial: true });
    expect(errors).toEqual(["Gender must be M or F"]);
  });
});

describe("validateVisitFields", () => {
  const validVisit = {
    patient_id: "patient-uuid-1",
    chw_id: "CHW001",
    visit_date: "2026-03-01",
    visit_type: "Antenatal",
  };

  beforeEach(() => {
    patientFindUnique.mockReset().mockResolvedValue({ id: "patient-uuid-1" });
    chwFindUnique.mockReset().mockResolvedValue({ chw_id: "CHW001" });
  });

  it("accepts a fully valid visit", async () => {
    expect(await validateVisitFields(validVisit, { partial: false })).toEqual([]);
  });

  it("rejects a patient_id that doesn't exist", async () => {
    patientFindUnique.mockResolvedValue(null);
    const errors = await validateVisitFields(validVisit, { partial: false });
    expect(errors).toContain("Patient not found");
  });

  it("rejects a chw_id that doesn't exist", async () => {
    chwFindUnique.mockResolvedValue(null);
    const errors = await validateVisitFields(validVisit, { partial: false });
    expect(errors).toContain("CHW not found");
  });

  it("rejects a visit_type outside the fixed list", async () => {
    const errors = await validateVisitFields({ ...validVisit, visit_type: "Checkup" }, { partial: false });
    expect(errors.some((e) => e.startsWith("visit_type must be one of"))).toBe(true);
  });

  it("rejects an out-of-range weight", async () => {
    const errors = await validateVisitFields({ ...validVisit, weight: 500 }, { partial: false });
    expect(errors).toContain("weight must be a number between 0 and 300 kg");
  });

  it("rejects a malformed blood pressure reading", async () => {
    const errors = await validateVisitFields({ ...validVisit, blood_pressure: "12080" }, { partial: false });
    expect(errors.some((e) => e.includes("blood_pressure"))).toBe(true);
  });

  it("accepts a well-formed blood pressure reading", async () => {
    const errors = await validateVisitFields({ ...validVisit, blood_pressure: "120/80" }, { partial: false });
    expect(errors).toEqual([]);
  });
});
