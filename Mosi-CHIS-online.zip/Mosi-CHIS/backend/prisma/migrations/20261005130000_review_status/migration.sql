-- Feature 4 - supervisor review queue. Additive only; sync_status untouched.
-- Approved as proposed (dry-run: 75 patients + 184 visits -> confirmed, nothing else changed).

CREATE TYPE "ReviewStatus" AS ENUM ('awaiting_review', 'confirmed', 'flagged');

-- 1. Add the columns. DEFAULT 'confirmed' fills every EXISTING row as
--    confirmed in the same statement (Postgres 11+ stores it as metadata,
--    no table rewrite). Existing data is historical/seed data.
ALTER TABLE "patients"
  ADD COLUMN "review_status"      "ReviewStatus" NOT NULL DEFAULT 'confirmed',
  ADD COLUMN "review_flag_reason" TEXT,
  ADD COLUMN "reviewed_at"        TIMESTAMP(3),
  ADD COLUMN "reviewed_by"        TEXT;

ALTER TABLE "visits"
  ADD COLUMN "review_status"      "ReviewStatus" NOT NULL DEFAULT 'confirmed',
  ADD COLUMN "review_flag_reason" TEXT,
  ADD COLUMN "reviewed_at"        TIMESTAMP(3),
  ADD COLUMN "reviewed_by"        TEXT;

-- 2. From now on, anything not explicitly set waits for review.
ALTER TABLE "patients" ALTER COLUMN "review_status" SET DEFAULT 'awaiting_review';
ALTER TABLE "visits"   ALTER COLUMN "review_status" SET DEFAULT 'awaiting_review';

-- 3. Indexes for the queue, and reviewer -> CHW account (kept if account deleted).
CREATE INDEX "patients_review_status_idx" ON "patients"("review_status");
CREATE INDEX "visits_review_status_idx"   ON "visits"("review_status");
ALTER TABLE "patients" ADD CONSTRAINT "patients_reviewed_by_fkey" FOREIGN KEY ("reviewed_by") REFERENCES "chws"("chw_id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "visits"   ADD CONSTRAINT "visits_reviewed_by_fkey"   FOREIGN KEY ("reviewed_by") REFERENCES "chws"("chw_id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Rollback (loses only review decisions, never patient/visit data):
--   ALTER TABLE patients DROP COLUMN review_status, DROP COLUMN review_flag_reason, DROP COLUMN reviewed_at, DROP COLUMN reviewed_by;
--   ALTER TABLE visits   DROP COLUMN review_status, DROP COLUMN review_flag_reason, DROP COLUMN reviewed_at, DROP COLUMN reviewed_by;
--   DROP TYPE "ReviewStatus";
