import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { CloudOff, Search, UploadCloud } from "lucide-react";
import { db } from "../../db/indexedDb";
import * as authService from "../../services/authService";
import { generateId } from "../../utils/uuid";
import { localIsoDate } from "../../utils/localDate";
import { useNetwork } from "../../contexts/NetworkContext";
import { offlineSaveExplanation, syncLaterHint } from "../../services/connectivity";
import { useSync } from "../../contexts/SyncContext";
import { useAnnouncer } from "../../contexts/AnnouncerContext";
import { usePageTitle } from "../../hooks/usePageTitle";
import { validateVisitForm, type FormErrors } from "../../utils/validators";
import { VISIT_TYPES, type Visit, type VisitType } from "../../models/visit";
import type { Patient } from "../../models/patient";
import { TextField } from "../../components/ui/TextField";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { SavedRecordStatus } from "../../components/SavedRecordStatus";
import { cn } from "../../lib/utils";

const STEPS = ["Patient & visit", "Measurements & notes", "Review & save"] as const;
type Step = 0 | 1 | 2;

// Which fields belong to which step - so "Continue" only validates what the
// CHW can actually see, and an error on review can send them back to the
// right step.
const STEP_FIELDS: Record<Step, string[]> = {
  0: ["patient_id", "visit_date", "visit_type"],
  1: ["weight", "height", "blood_pressure", "notes"],
  2: [],
};

const FIELD_LABELS: Record<string, string> = {
  patient_id: "Patient",
  visit_date: "Visit date",
  visit_type: "Visit type",
  weight: "Weight",
  height: "Height",
  blood_pressure: "Blood pressure",
  notes: "Notes",
};

const MAX_PICKER_RESULTS = 6;

function patientAge(dateOfBirth: string): number {
  return Math.floor((Date.now() - new Date(dateOfBirth).getTime()) / (365.25 * 24 * 60 * 60 * 1000));
}

function initials(patient: Patient): string {
  return `${patient.first_name[0] ?? ""}${patient.last_name[0] ?? ""}`.toUpperCase();
}

function PatientSummary({ patient, onChange }: { patient: Patient; onChange?: () => void }) {
  return (
    <div className="flex items-center gap-3.5 rounded-xl border border-stone-200 bg-stone-50 p-4">
      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-forest-800 text-sm font-semibold text-white" aria-hidden="true">
        {initials(patient)}
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-stone-900">
          {patient.first_name} {patient.last_name}
        </p>
        <p className="text-xs text-stone-500">
          {patient.patient_id} · {patient.gender === "F" ? "Female" : "Male"} · {patientAge(patient.date_of_birth)} years ·{" "}
          {patient.village}
        </p>
      </div>
      {onChange && (
        <Button type="button" variant="ghost" onClick={onChange}>
          Change
        </Button>
      )}
    </div>
  );
}

// Searchable radio list instead of a dropdown holding every patient in the
// clinic: on a phone, typing two letters of a name beats scrolling a list
// of 75, and native radios give screen readers and arrow keys the right
// behaviour for free.
function PatientPicker({
  patients,
  value,
  onChange,
  error,
}: {
  patients: Patient[] | undefined;
  value: string;
  onChange: (id: string) => void;
  error?: string;
}) {
  const [query, setQuery] = useState("");
  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    const sorted = (patients ?? []).slice().sort((a, b) => a.last_name.localeCompare(b.last_name));
    return q
      ? sorted.filter((p) => `${p.first_name} ${p.last_name} ${p.patient_id} ${p.village}`.toLowerCase().includes(q))
      : sorted;
  }, [patients, query]);
  const shown = matches.slice(0, MAX_PICKER_RESULTS);

  return (
    <fieldset aria-describedby={error ? "patient_id-error" : undefined} className="space-y-3">
      <legend className="text-sm font-medium text-stone-700">Patient</legend>
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-500" aria-hidden="true" />
        <label htmlFor="patient-search" className="sr-only">
          Search patients by name, ID or village
        </label>
        <input
          id="patient-search"
          type="search"
          autoComplete="off"
          placeholder="Search name, ID or village"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full rounded-lg border border-stone-300 py-3 pl-9 pr-3.5 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700"
        />
      </div>

      {patients === undefined && <p className="text-sm text-stone-500">Loading patients…</p>}
      {patients && matches.length === 0 && (
        <p className="text-sm text-stone-600">
          No patient matches "{query}".{" "}
          <Link to="/chw/patients/new" className="font-medium text-forest-800 underline underline-offset-2">
            Register a new patient
          </Link>
        </p>
      )}

      <div className="space-y-2">
        {shown.map((patient) => (
          <label
            key={patient.id}
            className={cn(
              "flex min-h-14 cursor-pointer items-center gap-3 rounded-lg border px-3.5 py-2.5 transition-colors has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-forest-700/40",
              value === patient.id ? "border-forest-700 bg-sage-50" : "border-stone-200 bg-white hover:bg-stone-50",
            )}
          >
            <input
              type="radio"
              name="patient"
              value={patient.id}
              checked={value === patient.id}
              onChange={() => onChange(patient.id)}
              className="h-4 w-4 accent-forest-800"
            />
            <span className="min-w-0">
              <span className="block text-sm font-medium text-stone-900">
                {patient.first_name} {patient.last_name}
              </span>
              <span className="block text-xs text-stone-500">
                {patient.patient_id} · {patient.village}
              </span>
            </span>
          </label>
        ))}
      </div>
      {matches.length > shown.length && (
        <p className="text-xs text-stone-500">
          Showing {shown.length} of {matches.length} - type more of the name to narrow it down.
        </p>
      )}
      {error && (
        <p id="patient_id-error" className="text-sm text-red-700">
          {error}
        </p>
      )}
    </fieldset>
  );
}

function AddVisit() {
  usePageTitle("Record a visit");
  const navigate = useNavigate();
  const { isOnline, status: connectivity } = useNetwork();
  const { syncNow } = useSync();
  const { announce } = useAnnouncer();
  const [searchParams] = useSearchParams();
  const preselectedPatientId = searchParams.get("patient_id");
  const session = authService.getSession();
  const chwId = session?.chw.chw_id ?? "";

  const patients = useLiveQuery(() => db.patients.toArray(), []);

  const [step, setStep] = useState<Step>(0);
  const [patientId, setPatientId] = useState(preselectedPatientId ?? "");
  const [changingPatient, setChangingPatient] = useState(false);
  const [visitDate, setVisitDate] = useState(localIsoDate);
  const [visitType, setVisitType] = useState("");
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [systolic, setSystolic] = useState("");
  const [diastolic, setDiastolic] = useState("");
  const [notes, setNotes] = useState("");

  const [errors, setErrors] = useState<FormErrors>({});
  const [submitting, setSubmitting] = useState(false);
  const [savedVisit, setSavedVisit] = useState<Visit | null>(null);

  const stepHeadingRef = useRef<HTMLHeadingElement>(null);
  const errorSummaryRef = useRef<HTMLDivElement>(null);
  const savedHeadingRef = useRef<HTMLHeadingElement>(null);
  const didMount = useRef(false);

  const selectedPatient = patients?.find((p) => p.id === patientId);
  // The picker stays open while choosing: arrow keys move the radio
  // selection, so collapsing on change would trap keyboard users on the
  // first patient. The compact summary is only for a patient passed in from
  // their profile page.
  const showPicker = !preselectedPatientId || !selectedPatient || changingPatient;
  const bloodPressure = systolic.trim() || diastolic.trim() ? `${systolic.trim()}/${diastolic.trim()}` : "";

  // Move focus to the new step's heading so keyboard and screen-reader
  // users land at the top of what just appeared, not on a vanished button.
  useEffect(() => {
    if (!didMount.current) {
      didMount.current = true;
      return;
    }
    stepHeadingRef.current?.focus();
  }, [step]);

  useEffect(() => {
    if (savedVisit) savedHeadingRef.current?.focus();
  }, [savedVisit]);

  function validate(): FormErrors {
    const found = validateVisitForm({
      patient_id: patientId,
      chw_id: chwId,
      visit_date: visitDate,
      visit_type: visitType,
      weight,
      height,
      blood_pressure: bloodPressure,
      notes,
    });
    if (!found.patient_id && !selectedPatient) found.patient_id = "Choose the patient this visit is for.";
    if ((systolic.trim() && !diastolic.trim()) || (!systolic.trim() && diastolic.trim())) {
      found.blood_pressure = "Enter both numbers for blood pressure (top and bottom), or leave both empty.";
    }
    return found;
  }

  function showErrors(found: FormErrors) {
    setErrors(found);
    // Let the summary render, then move focus to it so it's read out.
    window.setTimeout(() => errorSummaryRef.current?.focus(), 0);
  }

  function handleContinue() {
    const found = validate();
    const stepErrors = Object.fromEntries(Object.entries(found).filter(([key]) => STEP_FIELDS[step].includes(key)));
    if (Object.keys(stepErrors).length > 0) {
      showErrors(stepErrors);
      return;
    }
    setErrors({});
    setStep((s) => Math.min(2, s + 1) as Step);
  }

  function handleBack() {
    setErrors({});
    if (step === 0) navigate(-1);
    else setStep((s) => (s - 1) as Step);
  }

  async function handleSave(event: FormEvent) {
    event.preventDefault();
    if (step !== 2) {
      handleContinue();
      return;
    }
    const found = validate();
    if (Object.keys(found).length > 0) {
      // Something on an earlier step is invalid - go back to the first one
      // that has an error rather than failing silently on review.
      const firstBadStep = ([0, 1] as Step[]).find((s) => STEP_FIELDS[s].some((f) => found[f])) ?? 0;
      setStep(firstBadStep);
      showErrors(found);
      return;
    }

    setSubmitting(true);
    const now = new Date().toISOString();
    const visit: Visit = {
      id: generateId(),
      patient_id: patientId,
      chw_id: chwId,
      visit_date: visitDate,
      visit_type: visitType as VisitType,
      weight: weight.trim() ? Number(weight) : null,
      height: height.trim() ? Number(height) : null,
      blood_pressure: bloodPressure || null,
      notes: notes.trim() || null,
      created_at: now,
      updated_at: now,
      sync_status: "pending",
    };

    // The save itself is local and instant, online or not - syncing is a
    // separate step that follows only if there's a connection.
    await db.visits.add(visit);
    setSavedVisit(visit);
    setSubmitting(false);
    announce(isOnline ? "Visit saved on this device. Syncing now." : `Visit saved on this device. ${syncLaterHint(connectivity)}`);
    if (isOnline) void syncNow();
  }

  function handleAddAnother() {
    setStep(0);
    setVisitDate(localIsoDate());
    setVisitType("");
    setWeight("");
    setHeight("");
    setSystolic("");
    setDiastolic("");
    setNotes("");
    setSavedVisit(null);
    setErrors({});
    setChangingPatient(false);
    if (!preselectedPatientId) setPatientId("");
  }

  if (savedVisit) {
    return (
      <div className="max-w-2xl mx-auto space-y-5">
        <h1 ref={savedHeadingRef} tabIndex={-1} className="text-xl sm:text-2xl font-semibold text-stone-900 outline-none">
          Visit recorded
        </h1>
        <SavedRecordStatus table="visits" id={savedVisit.id} noun="visit" />
        <Card className="text-sm text-stone-700">
          {savedVisit.visit_type} visit for{" "}
          <span className="font-medium text-stone-900">
            {selectedPatient ? `${selectedPatient.first_name} ${selectedPatient.last_name}` : "patient"}
          </span>{" "}
          on {new Date(`${savedVisit.visit_date}T00:00:00`).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}
        </Card>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button type="button" size="lg" onClick={handleAddAnother} className="sm:flex-1">
            Record another visit
          </Button>
          <Button asChild variant="secondary" size="lg" className="sm:flex-1">
            <Link to={`/patients/${savedVisit.patient_id}`}>View patient</Link>
          </Button>
        </div>
      </div>
    );
  }

  const errorEntries = Object.entries(errors);
  const bpErrorId = errors.blood_pressure ? "blood_pressure-error" : undefined;

  return (
    <div className="max-w-2xl mx-auto space-y-5 pb-28 sm:pb-0">
      <div>
        <h1 className="text-xl sm:text-2xl font-semibold text-stone-900">Record a visit</h1>
        <p className="mt-1 text-sm text-stone-500">Saved on this device straight away - no connection needed.</p>
      </div>

      {/* Where am I? */}
      <ol className="flex gap-2" aria-label="Progress">
        {STEPS.map((label, index) => (
          <li key={label} className="flex-1" aria-current={index === step ? "step" : undefined}>
            <span className={cn("block h-1.5 rounded-full", index <= step ? "bg-forest-800" : "bg-stone-200")} aria-hidden="true" />
            <span className={cn("mt-1.5 hidden xs:block text-xs", index === step ? "font-semibold text-forest-900" : "text-stone-500")}>
              {label}
            </span>
            <span className="sr-only">
              {`Step ${index + 1}: ${label}`}
              {index < step ? " (done)" : index === step ? " (current)" : ""}
            </span>
          </li>
        ))}
      </ol>

      <form id="add-visit-form" onSubmit={(e) => void handleSave(e)} noValidate className="space-y-5">
        <h2 ref={stepHeadingRef} tabIndex={-1} className="scroll-mt-32 text-base font-semibold text-stone-900 outline-none">
          <span className="text-stone-500 font-normal">Step {step + 1} of 3 · </span>
          {STEPS[step]}
          {step === 1 && <span className="text-stone-500 font-normal"> (optional)</span>}
        </h2>

        {errorEntries.length > 0 && (
          <div ref={errorSummaryRef} tabIndex={-1} role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 outline-none">
            <p className="text-sm font-semibold text-red-800">
              {errorEntries.length === 1 ? "One thing needs fixing:" : `${errorEntries.length} things need fixing:`}
            </p>
            <ul className="mt-1 list-disc pl-5 text-sm text-red-800">
              {errorEntries.map(([field, message]) => (
                <li key={field}>
                  <span className="font-medium">{FIELD_LABELS[field] ?? field}:</span> {message}
                </li>
              ))}
            </ul>
          </div>
        )}

        {step === 0 && (
          <Card className="space-y-6">
            {showPicker ? (
              <PatientPicker
                patients={patients}
                value={patientId}
                onChange={setPatientId}
                error={errors.patient_id}
              />
            ) : (
              <div className="space-y-1.5">
                <p className="text-sm font-medium text-stone-700">Patient</p>
                <PatientSummary
                  patient={selectedPatient}
                  onChange={() => setChangingPatient(true)}
                />
              </div>
            )}

            <TextField
              label="Visit date"
              name="visit_date"
              type="date"
              max={localIsoDate()}
              value={visitDate}
              onChange={(e) => setVisitDate(e.target.value)}
              error={errors.visit_date}
              className="text-base sm:text-sm"
            />

            <fieldset aria-describedby={errors.visit_type ? "visit_type-error" : undefined}>
              <legend className="text-sm font-medium text-stone-700">Visit type</legend>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {VISIT_TYPES.map((type) => (
                  <label
                    key={type}
                    className={cn(
                      "flex min-h-12 cursor-pointer items-center gap-2.5 rounded-lg border px-3 py-2 text-sm transition-colors has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-forest-700/40",
                      visitType === type ? "border-forest-700 bg-sage-50 font-medium text-forest-900" : "border-stone-200 bg-white text-stone-700 hover:bg-stone-50",
                    )}
                  >
                    <input
                      type="radio"
                      name="visit_type"
                      value={type}
                      checked={visitType === type}
                      onChange={() => setVisitType(type)}
                      className="h-4 w-4 shrink-0 accent-forest-800"
                    />
                    {type}
                  </label>
                ))}
              </div>
              {errors.visit_type && (
                <p id="visit_type-error" className="mt-2 text-sm text-red-700">
                  {errors.visit_type}
                </p>
              )}
            </fieldset>
          </Card>
        )}

        {step === 1 && (
          <Card className="space-y-5">
            <p className="text-sm text-stone-600">Fill in what you measured. Anything you didn't measure can stay empty.</p>
            <div className="grid grid-cols-2 gap-3">
              <TextField
                label="Weight (kg)"
                name="weight"
                inputMode="decimal"
                autoComplete="off"
                placeholder="e.g. 62.5"
                value={weight}
                onChange={(e) => setWeight(e.target.value.replace(",", "."))}
                error={errors.weight}
                className="text-base sm:text-sm"
              />
              <TextField
                label="Height (cm)"
                name="height"
                inputMode="decimal"
                autoComplete="off"
                placeholder="e.g. 160"
                value={height}
                onChange={(e) => setHeight(e.target.value.replace(",", "."))}
                error={errors.height}
                className="text-base sm:text-sm"
              />
            </div>

            <fieldset aria-describedby={bpErrorId}>
              <legend className="text-sm font-medium text-stone-700">Blood pressure (mmHg)</legend>
              <div className="mt-1.5 flex items-center gap-2">
                <label htmlFor="bp_systolic" className="sr-only">
                  Top number (systolic)
                </label>
                <input
                  id="bp_systolic"
                  inputMode="numeric"
                  autoComplete="off"
                  maxLength={3}
                  placeholder="120"
                  value={systolic}
                  onChange={(e) => setSystolic(e.target.value.replace(/\D/g, ""))}
                  aria-invalid={errors.blood_pressure ? "true" : undefined}
                  className={cn(
                    "w-full rounded-lg border px-3.5 py-2.5 text-base sm:text-sm text-center focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700",
                    errors.blood_pressure ? "border-red-400" : "border-stone-300",
                  )}
                />
                <span className="text-lg text-stone-500" aria-hidden="true">
                  /
                </span>
                <label htmlFor="bp_diastolic" className="sr-only">
                  Bottom number (diastolic)
                </label>
                <input
                  id="bp_diastolic"
                  inputMode="numeric"
                  autoComplete="off"
                  maxLength={3}
                  placeholder="80"
                  value={diastolic}
                  onChange={(e) => setDiastolic(e.target.value.replace(/\D/g, ""))}
                  aria-invalid={errors.blood_pressure ? "true" : undefined}
                  className={cn(
                    "w-full rounded-lg border px-3.5 py-2.5 text-base sm:text-sm text-center focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700",
                    errors.blood_pressure ? "border-red-400" : "border-stone-300",
                  )}
                />
              </div>
              {errors.blood_pressure && (
                <p id="blood_pressure-error" className="mt-1.5 text-sm text-red-700">
                  {errors.blood_pressure}
                </p>
              )}
            </fieldset>

            <div className="space-y-1.5">
              <label htmlFor="notes" className="block text-sm font-medium text-stone-700">
                Notes
              </label>
              <textarea
                id="notes"
                rows={4}
                maxLength={2000}
                aria-describedby="notes-hint"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full rounded-lg border border-stone-300 px-3.5 py-2.5 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700"
              />
              <p id="notes-hint" className="text-xs text-stone-500">
                Anything worth remembering about this visit. {notes.length > 1800 && `${2000 - notes.length} characters left.`}
              </p>
            </div>
          </Card>
        )}

        {step === 2 && selectedPatient && (
          <Card className="space-y-4">
            <PatientSummary patient={selectedPatient} />
            <dl className="divide-y divide-stone-100 text-sm">
              {[
                ["Visit date", new Date(`${visitDate}T00:00:00`).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }), 0],
                ["Visit type", visitType, 0],
                ["Weight", weight ? `${weight} kg` : "Not recorded", 1],
                ["Height", height ? `${height} cm` : "Not recorded", 1],
                ["Blood pressure", bloodPressure ? `${bloodPressure} mmHg` : "Not recorded", 1],
                ["Notes", notes.trim() || "None", 1],
              ].map(([label, value, targetStep]) => (
                <div key={label as string} className="flex items-start justify-between gap-4 py-2.5">
                  <dt className="text-stone-500 shrink-0">{label}</dt>
                  <dd className="flex items-start gap-3 text-right text-stone-900 min-w-0">
                    <span className="break-words">{value}</span>
                    <button
                      type="button"
                      onClick={() => setStep(targetStep as Step)}
                      className="-my-2.5 min-h-11 shrink-0 px-2 text-sm font-medium text-forest-800 underline underline-offset-2"
                    >
                      Edit<span className="sr-only"> {label as string}</span>
                    </button>
                  </dd>
                </div>
              ))}
            </dl>
            <div className="flex items-start gap-2.5 rounded-lg bg-sage-50 px-4 py-3 text-sm text-forest-900">
              {isOnline ? (
                <UploadCloud className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              ) : (
                <CloudOff className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
              )}
              <p>
                <span className="font-medium">When you save: </span>
                {isOnline
                  ? "the visit is stored on this device straight away, then synced to the server."
                  : offlineSaveExplanation(connectivity, "visit")}
              </p>
            </div>
          </Card>
        )}

        {/* One action bar: pinned above the bottom nav on phones so the next
            step is always one thumb-tap away, inline on larger screens. */}
        <div className="fixed inset-x-0 bottom-16 z-30 flex gap-3 border-t border-stone-200 bg-white p-3 sm:static sm:justify-end sm:border-0 sm:bg-transparent sm:p-0">
          <Button type="button" variant="secondary" size="lg" onClick={handleBack} className="flex-1 sm:flex-none">
            {step === 0 ? "Cancel" : "Back"}
          </Button>
          {/* Distinct keys matter: without them React reuses one <button> and
              flips it to type="submit" mid-click, so "Continue" on step 2
              would submit the form and skip the review step. */}
          {step < 2 ? (
            <Button key="continue" type="button" size="lg" onClick={handleContinue} className="flex-1 sm:flex-none">
              Continue
            </Button>
          ) : (
            <Button key="save" type="submit" size="lg" disabled={submitting} className="flex-1 sm:flex-none">
              {submitting ? "Saving…" : "Save visit"}
            </Button>
          )}
        </div>
      </form>
    </div>
  );
}

export default AddVisit;
