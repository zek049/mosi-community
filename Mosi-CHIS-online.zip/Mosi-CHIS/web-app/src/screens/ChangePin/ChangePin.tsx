import { useEffect, useRef, useState, type FormEvent } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { KeyRound } from "lucide-react";
import * as api from "../../services/api";
import { ApiError, NetworkError } from "../../services/api";
import * as authService from "../../services/authService";
import { useNetwork } from "../../contexts/NetworkContext";
import { usePageTitle } from "../../hooks/usePageTitle";
import { validateChangePin, type ChangePinErrors } from "../../utils/validators";
import { ConnectivityIndicator } from "../../components/Connectivity";
import { Logo } from "../../components/Logo";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { TextField } from "../../components/ui/TextField";

// Shown (and enforced by the route guards) while a supervisor-set temporary
// PIN is in force. The server refuses every other request until this
// succeeds, so it's not just a screen that can be skipped.
function ChangePin() {
  usePageTitle("Choose a new PIN");
  const navigate = useNavigate();
  const { isOnline } = useNetwork();
  const session = authService.getSession();
  const [current, setCurrent] = useState("");
  const [pin, setPin] = useState("");
  const [confirm, setConfirm] = useState("");
  const [errors, setErrors] = useState<ChangePinErrors>({});
  const errorRef = useRef<HTMLParagraphElement>(null);

  const change = useMutation({
    mutationFn: () => api.changePin(current, pin),
    onSuccess: () => {
      setCurrent("");
      setPin("");
      setConfirm("");
      authService.markMustChangePin(false);
      const updated = authService.getSession();
      if (updated) navigate(authService.entryRoute(updated), { replace: true });
    },
  });

  useEffect(() => {
    if (change.isError) errorRef.current?.focus();
  }, [change.isError]);

  if (!session) return <Navigate to="/login" replace />;

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    const found = validateChangePin(current, pin, confirm);
    setErrors(found);
    if (Object.keys(found).length > 0) {
      window.setTimeout(() => document.getElementById(found.current ? "current_pin" : found.pin ? "new_pin" : "confirm_pin")?.focus(), 0);
      return;
    }
    change.mutate();
  }

  async function signOut() {
    await authService.signOut();
    navigate("/login", { replace: true });
  }

  const changeError =
    change.error instanceof NetworkError
      ? "Couldn't reach the Mosi server. Your PIN wasn't changed - try again when you're connected."
      : change.error instanceof ApiError && change.error.status < 500
        ? change.error.message
        : change.isError
          ? "Something went wrong on the server. Your PIN wasn't changed - please try again."
          : null;

  const pinField = (id: string, label: string, value: string, set: (v: string) => void, error?: string, autoComplete = "new-password") => (
    <TextField
      label={label}
      name={id}
      id={id}
      type="password"
      inputMode="numeric"
      autoComplete={autoComplete}
      maxLength={4}
      value={value}
      onChange={(e) => set(e.target.value.replace(/\D/g, "").slice(0, 4))}
      error={error}
      className="text-base sm:text-sm"
    />
  );

  return (
    <div className="flex min-h-screen flex-col bg-cream">
      <header className="px-6 py-5">
        <Logo size="sm" />
      </header>
      <main className="flex flex-1 justify-center px-4 pb-16 sm:px-6">
        <div className="w-full max-w-sm">
          <Card className="space-y-5 p-6 sm:p-8">
            <div>
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-sage-100 text-forest-800">
                <KeyRound className="h-5 w-5" aria-hidden="true" />
              </span>
              <h1 className="mt-3 text-xl font-semibold text-stone-900">Choose a new PIN</h1>
              <p className="mt-1 text-sm text-stone-600">
                {session.mustChangePin
                  ? `Hi ${session.chw.full_name.split(" ")[0]}. A supervisor set you a temporary PIN. Choose a new PIN that only you know before you continue.`
                  : "Choose a new PIN that only you know."}
              </p>
              <div className="mt-3">
                <ConnectivityIndicator />
              </div>
            </div>
            <form onSubmit={handleSubmit} noValidate className="space-y-4">
              {pinField("current_pin", session.mustChangePin ? "Temporary PIN" : "Current PIN", current, setCurrent, errors.current, "current-password")}
              {pinField("new_pin", "New PIN", pin, setPin, errors.pin)}
              {pinField("confirm_pin", "Type the new PIN again", confirm, setConfirm, errors.confirm)}
              <p className="text-xs text-stone-600">4 digits. Avoid easy ones like 1234, 0000 or 2580.</p>
              {!isOnline && (
                <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
                  Changing your PIN needs the Mosi server. Connect (or turn off Work Offline) to continue.
                </p>
              )}
              {changeError && (
                <p ref={errorRef} tabIndex={-1} role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800 outline-none">
                  {changeError}
                </p>
              )}
              <Button type="submit" size="lg" className="w-full" disabled={!isOnline || change.isPending}>
                {change.isPending ? "Saving…" : "Save new PIN"}
              </Button>
            </form>
            <p className="text-center text-sm">
              {session.mustChangePin ? (
                <button type="button" onClick={() => void signOut()} className="min-h-11 font-medium text-forest-800 underline underline-offset-2">
                  Sign out instead
                </button>
              ) : (
                <Link to={authService.entryRoute(session)} className="font-medium text-forest-800 underline underline-offset-2">
                  Cancel
                </Link>
              )}
            </p>
          </Card>
        </div>
      </main>
    </div>
  );
}

export default ChangePin;
