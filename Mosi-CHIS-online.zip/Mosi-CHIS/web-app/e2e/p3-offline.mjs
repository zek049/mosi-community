// Phase 3 real-offline acceptance test against the PRODUCTION build
// (vite preview :4173, service worker active). Uses Playwright's
// context.setOffline(true) - real loss of network, not the demo toggle.
import { chromium } from "playwright";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const errors = [];
const announcements = [];
const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 375, height: 812 } });
let offline = false;

let pass = 0, fail = 0;
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
function watch(page) {
  page.on("console", (msg) => {
    if (msg.type() !== "error") return;
    const text = msg.text();
    // Chrome logs failed fetches while genuinely offline - expected, not app errors.
    if (offline && /ERR_INTERNET_DISCONNECTED|Failed to load resource|Failed to fetch/.test(text)) return;
    errors.push({ offline, text });
  });
  page.on("pageerror", (err) => errors.push({ offline, text: String(err) }));
}
async function recordAnnouncements(page) {
  await page.exposeFunction("__announce", (t) => announcements.push(t)).catch(() => {});
  await page.addInitScript(() => {
    const hook = () => {
      const el = document.querySelector('[role="status"][aria-live="polite"].sr-only');
      if (!el) return setTimeout(hook, 200);
      new MutationObserver(() => { if (el.textContent) window.__announce(el.textContent); }).observe(el, { childList: true, characterData: true, subtree: true });
    };
    hook();
  });
}

const page = await context.newPage();
watch(page);
await recordAnnouncements(page);

// 1. Sign in online
await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
await page.fill("#chwId", "CHW001");
await page.fill("#pin", "1234");
await page.click('button:has-text("Sign in")');
await page.waitForURL("**/chw", { timeout: 10000 });
report("1. Signed in online as CHW001", true);

// 2. Service worker ready + lazy chunks precached
await page.evaluate(() => navigator.serviceWorker.ready);
let precached = false;
for (let i = 0; i < 40 && !precached; i++) {
  precached = await page.evaluate(async () => {
    // Whatever the current shell cache version is (sw.js bumps it).
    const name = (await caches.keys()).find((k) => k.startsWith("mosi-shell-"));
    if (!name) return false; // service worker not installed yet
    const cache = await caches.open(name);
    const keys = (await cache.keys()).map((r) => new URL(r.url).pathname);
    return ["AddVisit", "AddPatient", "SyncStatus", "PatientList", "VisitList"].every((n) => keys.some((k) => new RegExp(`/assets/${n}-.*\\.js$`).test(k)));
  });
  if (!precached) await page.waitForTimeout(500);
}
report("2. Service worker precached route chunks", precached);

// 3. Go genuinely offline
offline = true;
await context.setOffline(true);
await page.waitForTimeout(500);
const pill = await page.locator("a[href='/sync']:visible", { hasText: /Offline|waiting|Synced|Online/ }).first().innerText().catch(() => "");
report("3. Status shows Offline without reload", /Offline/.test(pill), pill);

// 4. Reload with zero connectivity
await page.reload({ waitUntil: "domcontentloaded" });
await page.waitForTimeout(800);
report("4. App reloads offline (cached shell)", await page.isVisible("text=Record visit"));

// 5. Create patient offline
const stamp = Date.now();
await page.click("text=Add patient");
await page.waitForURL("**/chw/patients/new"); await page.waitForSelector("h1:has-text(\"Add patient\")");
const formText = await page.locator("main").innerText();
report("5a. Add patient form tells the truth about offline", /You.re offline\. The patient will be saved on this device/.test(formText), formText.slice(-260));
await page.click('button:has-text("Save patient")');
await page.waitForSelector('[role="alert"]');
await page.waitForTimeout(150);
const summaryFocused = await page.evaluate(() => document.activeElement?.getAttribute("role") === "alert");
report("5b. Empty submit shows focused error summary", summaryFocused && (await page.isVisible("text=Enter the first name.")));
await page.fill("#patient_id", `P3-${stamp}`);
await page.fill("#first_name", "Tariro");
await page.fill("#last_name", "Offlinetest");
await page.fill("#date_of_birth", "1992-04-10");
await page.check('input[name="gender"][value="F"]');
await page.fill("#village", "Mbare");
await page.click('button:has-text("Save patient")');
await page.waitForSelector("text=Patient registered", { timeout: 5000 });
const pStatus = await page.locator("main").innerText();
report("5c. Patient saved offline: 'Saved on this device / Will sync when you're connected'",
  /Saved on this device/.test(pStatus) && /Will sync when you're connected/.test(pStatus) && !/Saved and synced|awaiting supervisor review|confirmed/i.test(pStatus));

// 6. Record a visit offline for that patient (full step flow)
await page.click("text=Record a visit for this patient");
await page.waitForURL("**/chw/visits/new**");
report("6a. Patient preselected", await page.isVisible("text=Tariro Offlinetest"));
await page.click('button:has-text("Continue")');
report("6b. Missing visit type blocks Continue with clear message", await page.isVisible("text=Choose the type of visit."));
await page.check('input[name="visit_type"][value="Antenatal"]');
await page.click('button:has-text("Continue")');
await page.waitForSelector("h2:has-text(\"Measurements & notes\")");
const headingFocused = await page.evaluate(() => document.activeElement?.tagName === "H2");
report("6c. Step 2 heading receives focus", headingFocused);
await page.fill("#weight", "61,5");
await page.fill("#bp_systolic", "118");
await page.click('button:has-text("Continue")');
report("6d. Half-entered BP is rejected", await page.isVisible("text=Enter both numbers for blood pressure"));
await page.fill("#bp_diastolic", "76");
await page.fill("#notes", "Phase 3 offline acceptance test");
await page.click('button:has-text("Continue")');
await page.waitForSelector("h2:has-text(\"Review & save\")");
const review = await page.locator("main").innerText();
report("6e. Review shows values incl. comma->dot weight and combined BP", /61\.5 kg/.test(review) && /118\/76 mmHg/.test(review), review.match(/Weight.*|Blood pressure.*/g));
report("6f. Review explains offline save", /You.re offline. The visit will be saved on this device/.test(review));
await page.click('button:has-text("Save visit")');
await page.waitForSelector("text=Visit recorded", { timeout: 5000 });
const vStatus = await page.locator("main").innerText();
report("6g. Visit saved offline with honest status", /Saved on this device/.test(vStatus) && /Will sync when you're connected/.test(vStatus));

// 7. Close the tab and reopen (still offline)
await page.close();
const page2 = await context.newPage();
watch(page2);
await recordAnnouncements(page2);
await page2.goto(`${BASE}/sync`, { waitUntil: "domcontentloaded" }).catch(() => {});
await page2.waitForSelector("text=You're offline", { timeout: 8000 }).catch(() => {});
const syncOffline = await page2.locator("main").innerText();
report("7. After close/reopen offline, Sync says offline with 2 waiting", /You're offline/.test(syncOffline) && /2 changes are saved on this device/.test(syncOffline), syncOffline.slice(0, 200));
report("7b. Waiting tab lists both records by name", /Tariro Offlinetest/.test(syncOffline) && /Antenatal visit/.test(syncOffline));
report("7c. No technical terms on CHW sync screen", !/HTTP|409|Prisma|UUID|cursor|LWW|Attempted/i.test(syncOffline));

// 8. Deep links offline
for (const [path, expect] of [["/patients", /Tariro Offlinetest|MBR-/], ["/visits", /Antenatal|Visits/], ["/chw", /Record visit/]]) {
  await page2.goto(`${BASE}${path}`, { waitUntil: "domcontentloaded" }).catch(() => {});
  await page2.waitForTimeout(900);
  const text = await page2.locator("body").innerText().catch(() => "");
  report(`8. Deep link ${path} works offline`, expect.test(text));
}
await page2.goto(`${BASE}/patients`, { waitUntil: "domcontentloaded" }).catch(() => {});
await page2.waitForTimeout(600);
await page2.fill('input[type="search"]', "Offlinetest");
await page2.waitForTimeout(400);
report("8b. Offline patient searchable by name", await page2.locator("text=Tariro Offlinetest >> visible=true").count() > 0);
await page2.fill('input[type="search"]', "mbare");
await page2.waitForTimeout(400);
report("8c. Search matches village", (await page2.locator("main li").count()) > 0);

// 9. Reconnect -> automatic sync
await page2.goto(`${BASE}/sync`, { waitUntil: "domcontentloaded" }).catch(() => {});
await page2.waitForTimeout(600);
offline = false;
await context.setOffline(false);
const upToDate = await page2.waitForSelector("text=Everything is up to date", { timeout: 20000 }).then(() => true).catch(() => false);
report("9. Reconnecting syncs automatically, no button press", upToDate);
const syncOnline = await page2.locator("main").innerText();
report("9b. 'Last synced just now' shown", /Last synced just now/.test(syncOnline), syncOnline.match(/Last synced.*/)?.[0]);
report("9c. Queue cleared (Waiting 0)", /Waiting \(0\)/.test(syncOnline));

// 10. Verify on the server
const serverCheck = await page2.evaluate(async ({ API, stamp }) => {
  const res = await fetch(`${API}/patients?search=P3-${stamp}`, { credentials: "include" });
  const body = await res.json();
  const list = Array.isArray(body.data) ? body.data : body.data?.items ?? body.data?.data ?? [];
  const patient = list.find((p) => p.patient_id === `P3-${stamp}`);
  if (!patient) return { found: false, status: res.status, sample: JSON.stringify(body).slice(0, 200) };
  const vres = await fetch(`${API}/visits?patient_id=${patient.id}`, { credentials: "include" });
  const vbody = await vres.json();
  const visits = Array.isArray(vbody.data) ? vbody.data : vbody.data?.items ?? [];
  const visit = visits.find((v) => v.patient_id === patient.id);
  return { found: true, patientId: patient.id, visit: visit ? { bp: visit.blood_pressure, weight: visit.weight, type: visit.visit_type } : null };
}, { API, stamp });
report("10. Server has the offline patient", serverCheck.found, serverCheck);
report("10b. Server has the offline visit with correct values", serverCheck.visit?.bp === "118/76" && Number(serverCheck.visit?.weight) === 61.5, serverCheck.visit);

// 11. Online save: shows "Saved and synced" only after server ack
await page2.goto(`${BASE}/chw/visits/new?patient_id=${serverCheck.patientId}`, { waitUntil: "networkidle" });
await page2.check('input[name="visit_type"][value="Health Education"]');
await page2.click('button:has-text("Continue")');
await page2.click('button:has-text("Continue")');
await page2.click('button:has-text("Save visit")');
// Since the review queue (Feature 4) a CHW's record on the server is shown
// as awaiting supervisor review - never "confirmed" - once the server has it.
const synced = await page2.waitForSelector("text=Sent - awaiting supervisor review", { timeout: 15000 }).then(() => true).catch(() => false);
report("11. Online save progresses to 'Sent - awaiting supervisor review' (after server ack)", synced);

console.log("\nAnnouncements heard (live region):");
for (const a of [...new Set(announcements)]) console.log("  •", a);
console.log(`\nConsole/page errors: ${errors.length}`);
for (const e of errors) console.log("  ", e);
console.log(`\n${pass} passed, ${fail} failed. TEST_STAMP=P3-${stamp}`);
await browser.close();
