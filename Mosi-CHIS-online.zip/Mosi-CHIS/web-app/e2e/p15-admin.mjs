// Feature 10 - administrator role + clinic-scoped supervisors. Production build, real backend + database.
// SUP001 = ADMIN (all clinics); SUP002 = Mbare Clinic supervisor. Creates a test supervisor T15S<n> (cleanup removes it).
import { chromium } from "playwright";
import { readFileSync } from "node:fs";
import { execSync } from "node:child_process";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const NEW_ID = `T15S${String(Date.now()).slice(-6)}`;
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
async function axe(page, label) {
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}: ${x.nodes.map((n) => n.target.join(" ")).slice(0, 3).join(" | ")}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
const sql = (q) => execSync(`docker exec mosi-postgres psql -U mosi -d mosi -At -c "${q.replace(/"/g, '\\"')}"`).toString().trim();
function track(page, who, allow = []) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => { if (m.type() === "error" && !/ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(m.text()) && !allow.some((r) => r.test(m.text()))) errors.push(`${who}: ${m.text()}`); });
}
async function login(page, id, pin = "1234") {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => document.body.innerText.includes("Online"));
  await page.fill("#chwId", id); await page.fill("#pin", pin); await page.press("#pin", "Enter");
}
const api = (page, path, init) => page.evaluate(async ([API, path, init]) => { const r = await fetch(`${API}${path}`, { credentials: "include", headers: { "Content-Type": "application/json" }, ...init }); return { status: r.status, body: await r.json().catch(() => null) }; }, [API, path, init]);
const noHScroll = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);
const idOf = (code) => sql(`select id from clinics where code='${code}'`);
const MBARE = idOf("MBR"), HAT = idOf("HTC");

report("Accounts: SUP001 is ADMIN, SUP002 is a Mbare supervisor", sql("select string_agg(chw_id||':'||role||':'||clinic, ',' order by chw_id) from chws where chw_id like 'SUP%'") === "SUP001:ADMIN:Harare Provincial Health Office,SUP002:SUPERVISOR:Mbare Clinic");
const mbarePatients = Number(sql(`select count(*) from patients where deleted_at is null and review_status='confirmed' and clinic_id='${MBARE}'`));
const allPatients = Number(sql("select count(*) from patients where deleted_at is null and review_status='confirmed'"));

const browser = await chromium.launch();

// ---------- 1. Mbare supervisor ----------
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
  const sp = await ctx.newPage();
  track(sp, "mbare-sup", [/status of 40[34]/]);
  await login(sp, "SUP002");
  await sp.waitForURL("**/supervisor");
  await sp.waitForTimeout(2500);
  const main = await sp.locator("body").innerText();
  report("Mbare supervisor: shown as 'Supervisor · Mbare Clinic'", main.includes("Supervisor · Mbare Clinic"));
  report(`Dashboard: Confirmed patients = Mbare's ${mbarePatients} (not all ${allPatients})`, new RegExp(`${mbarePatients}\\s*\\n?\\s*Confirmed patients`).test(main), main.match(/\d+\s*\n?\s*Confirmed patients/)?.[0]);
  report("No 'Manage supervisors' in the menu", !(await sp.isVisible('a[href="/supervisor/supervisors"]')));
  await sp.goto(`${BASE}/supervisor/supervisors`, { waitUntil: "networkidle" });
  report("Typing /supervisor/supervisors redirects to the dashboard", new URL(sp.url()).pathname === "/supervisor");

  await sp.goto(`${BASE}/patients`, { waitUntil: "networkidle" });
  await sp.waitForTimeout(1500);
  const list = await sp.locator("main").innerText();
  report("Patient list: Mbare patients only (MBR-), no Hatcliffe/Epworth", /MBR-/.test(list) && !/HTC-|EPW-/.test(list));
  const pats = await api(sp, "/patients?limit=500");
  const clinics = [...new Set((pats.body?.data ?? []).map((p) => p.clinic_id))];
  report("API: GET /patients returns Mbare only", clinics.length === 1 && clinics[0] === MBARE, clinics);
  const hatId = sql(`select id from patients where clinic_id='${HAT}' limit 1`);
  report("API: a Hatcliffe patient by id -> 403", (await api(sp, `/patients/${hatId}`)).status === 403);
  report("API: archive a Hatcliffe patient -> 404 (nothing archived)", (await api(sp, `/patients/${hatId}`, { method: "DELETE" })).status === 404 && sql(`select deleted_at is null from patients where id='${hatId}'`) === "t");
  const chws = await api(sp, "/chws");
  report("API: CHW list is Mbare only", (chws.body?.data ?? []).every((c) => c.clinic_id === MBARE), (chws.body?.data ?? []).map((c) => c.chw_id));
  report("API: revoking a Hatcliffe CHW -> 404", (await api(sp, "/chws/CHW002/revoke", { method: "POST" })).status === 404 && sql("select status from chws where chw_id='CHW002'") === "active");
  report("API: creating a supervisor -> 403", (await api(sp, "/chws", { method: "POST", body: JSON.stringify({ chw_id: "T15X1", full_name: "X", clinic_id: MBARE, role: "SUPERVISOR", pin: "4829" }) })).status === 403);
  report("API: listing supervisors -> 403", (await api(sp, "/chws/manage?role=SUPERVISOR")).status === 403);
  const log = await api(sp, "/sync/log?limit=500");
  report("API: sync log only about Mbare records", (log.body?.data ?? []).length === 0 || Number(sql(`select count(*) from sync_log l left join patients p on l.record_type='patient' and p.id=l.record_id left join visits v on l.record_type='visit' and v.id=l.record_id where l.id in (${(log.body.data).map((e) => e.id).join(",")}) and coalesce(p.clinic_id, v.clinic_id) <> '${MBARE}'`)) === 0);

  await sp.goto(`${BASE}/supervisor/chws`, { waitUntil: "networkidle" });
  await sp.waitForSelector("h1:has-text('Manage CHWs')");
  const cards = await sp.getByRole("list", { name: "CHW accounts" }).innerText();
  report("Manage CHWs: only Mbare's CHW (Jane Moyo)", cards.includes("Jane Moyo") && !cards.includes("John Ncube") && !cards.includes("Tariro Gumbo"));
  await sp.click('button:has-text("Add CHW")');
  await sp.click("#new_clinic_id");
  const options = await sp.getByRole("option").allInnerTexts();
  report("Add CHW: the clinic list offers Mbare Clinic only (pre-selected)", options.length === 1 && options[0].includes("Mbare"), options);
  await sp.keyboard.press("Escape");
  await ctx.close();
}

// ---------- 2. Administrator ----------
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
  const ap = await ctx.newPage();
  track(ap, "admin", [/status of 40[04]/]); // the test itself checks a 400 (create ADMIN) and 404 (self-revoke)
  await login(ap, "SUP001");
  await ap.waitForURL("**/supervisor");
  await ap.waitForTimeout(2500);
  const main = await ap.locator("body").innerText();
  report("Admin: shown as 'Administrator · all clinics'", main.includes("Administrator · all clinics"));
  report(`Admin dashboard: Confirmed patients = all ${allPatients}`, new RegExp(`${allPatients}\\s*\\n?\\s*Confirmed patients`).test(main));
  await ap.click('a[href="/supervisor/supervisors"]');
  await ap.waitForSelector("h1:has-text('Manage supervisors')");
  const sups = await ap.getByRole("list", { name: "Supervisor accounts" }).innerText();
  report("Manage supervisors: lists SUP002 (Mbare), not the admin itself", sups.includes("Farai Mupfumi") && sups.includes("SUP002") && sups.includes("Mbare Clinic") && !sups.includes("SUP001"));
  await axe(ap, "Manage supervisors");

  // Add a Hatcliffe supervisor
  await ap.click('button:has-text("Add supervisor")');
  await ap.fill("#new_full_name", "Test Supervisor");
  await ap.fill("#new_chw_id", NEW_ID);
  await ap.click("#new_clinic_id"); await ap.click('[role="option"]:has-text("Hatcliffe Clinic")');
  await ap.fill("#new_pin", "4829"); await ap.fill("#new_confirm", "4829");
  await axe(ap, "Add supervisor form");
  await ap.click('form button[type="submit"]:has-text("Add supervisor")');
  await ap.waitForSelector(`text=Test Supervisor (${NEW_ID}) was added`, { timeout: 8000 });
  report("Database: new account is a Hatcliffe SUPERVISOR who must change the PIN", sql(`select role||'|'||clinic||'|'||must_change_pin from chws where chw_id='${NEW_ID}'`) === "SUPERVISOR|Hatcliffe Clinic|true");

  // The admin's PIN-reset screen includes supervisors
  await ap.goto(`${BASE}/supervisor/pin-reset`, { waitUntil: "networkidle" });
  await ap.waitForTimeout(1000);
  report("Reset a PIN (admin): supervisor accounts are offered too", (await ap.locator("main").innerText()).includes("Farai Mupfumi"));
  report("API: nobody can create an ADMIN (400)", (await api(ap, "/chws", { method: "POST", body: JSON.stringify({ chw_id: "T15A1", full_name: "X", clinic_id: MBARE, role: "ADMIN", pin: "4829" }) })).status === 400);
  report("API: the admin can't revoke themselves (404)", (await api(ap, "/chws/SUP001/revoke", { method: "POST" })).status === 404);

  // ---------- 3. The new supervisor signs in: own clinic only ----------
  const c2 = await browser.newContext({ viewport: { width: 375, height: 812 }, bypassCSP: true });
  const np = await c2.newPage();
  track(np, "new-sup", [/status of 403/]);
  await login(np, NEW_ID, "4829");
  report("New supervisor: first sign-in asks for a new PIN", await np.waitForURL("**/change-pin", { timeout: 8000 }).then(() => true).catch(() => false));
  await np.fill("#current_pin", "4829"); await np.fill("#new_pin", "5917"); await np.fill("#confirm_pin", "5917");
  await np.press("#confirm_pin", "Enter");
  report("...then lands on the supervisor dashboard", await np.waitForURL("**/supervisor", { timeout: 8000 }).then(() => true).catch(() => false));
  const pats = await api(np, "/patients?limit=500");
  const cl = [...new Set((pats.body?.data ?? []).map((p) => p.clinic_id))];
  report("New Hatcliffe supervisor sees Hatcliffe patients only", cl.length === 1 && cl[0] === HAT, cl);
  report("No horizontal scroll at 375px (supervisor dashboard)", await noHScroll(np));

  // Revoke -> their session stops working; reactivate; delete (no history)
  await ap.goto(`${BASE}/supervisor/supervisors`, { waitUntil: "networkidle" });
  const card = ap.locator("li", { hasText: NEW_ID });
  await card.getByRole("button", { name: /Revoke/ }).click();
  await ap.click('dialog[open] button:has-text("Revoke access")');
  await ap.waitForSelector("text=access was revoked", { timeout: 8000 });
  const after = await api(np, "/patients");
  report("Revoked supervisor's open session is refused on the next request", after.status === 403 && after.body?.code === "ACCOUNT_REVOKED", after.status);
  await card.getByRole("button", { name: /Delete/ }).click();
  await ap.click('dialog[open] button:has-text("Delete permanently")');
  await ap.waitForSelector("text=account was deleted", { timeout: 8000 });
  report("Admin deletes the test supervisor (no history)", sql(`select count(*) from chws where chw_id='${NEW_ID}'`) === "0");
  report("Audit: supervisor created, revoked and deleted by SUP001", sql(`select string_agg(action, ',' order by id) from audit_log where resource_id='${NEW_ID}' and actor_id='SUP001'`) === "CHW_CREATED,CHW_REVOKED,CHW_DELETED");
  await ap.setViewportSize({ width: 360, height: 800 });
  await ap.waitForTimeout(1500);
  report("No horizontal scroll at 360px (Manage supervisors)", await noHScroll(ap));
  await c2.close();
  await ctx.close();
}

report("Data intact: 75 patients, 184 visits", sql("select (select count(*) from patients)||','||(select count(*) from visits)") === "75,184");
report("No page errors or console errors", errors.length === 0, errors.length ? errors.slice(0, 5) : undefined);
console.log(`\n${pass} passed, ${fail} failed (${NEW_ID})`);
await browser.close();
process.exit(fail ? 1 : 0);
