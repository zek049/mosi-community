// Feature 5 - installable PWA. Production build (:4173).
import { chromium } from "playwright";
import { readFileSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const BASE = "http://localhost:4173";
const IPHONE_SAFARI = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
const ANDROID_CHROME = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36";
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
async function axe(page, label) {
  await page.waitForTimeout(300);
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}: ${x.nodes.map((n) => n.target.join(" ")).slice(0, 3).join(" | ")}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
function track(page, who) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => { if (m.type() === "error" && !/ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(m.text())) errors.push(`${who}: ${m.text()}`); });
}
const pngSize = (buf) => ({ w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) });
const noHScroll = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);

// ---------- 1. Chrome's own installability verdict (persistent profile = not incognito) ----------
{
  const ctx = await chromium.launchPersistentContext(mkdtempSync(join(tmpdir(), "mosi-pwa-")), { viewport: { width: 1280, height: 900 } });
  const page = ctx.pages()[0] ?? (await ctx.newPage());
  track(page, "desktop");
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload({ waitUntil: "networkidle" }); // now controlled by the service worker
  const cdp = await ctx.newCDPSession(page);
  const manifest = await cdp.send("Page.getAppManifest");
  const parsed = JSON.parse(manifest.data || "{}");
  report("Manifest parses with no errors", manifest.errors.length === 0, manifest.errors);
  report("Manifest: name 'Mosi', standalone, start_url /, forest theme, cream background", parsed.name === "Mosi" && parsed.short_name === "Mosi" && parsed.display === "standalone" && parsed.start_url === "/" && parsed.theme_color === "#0F3D34" && parsed.background_color === "#FAF8F2");
  report("Manifest icons: 192 + 512 (any) and a 512 maskable", ["192x192:any", "512x512:any", "512x512:maskable"].every((k) => parsed.icons.some((i) => `${i.sizes}:${i.purpose}` === k)));
  const inst = await cdp.send("Page.getInstallabilityErrors");
  report("Chrome reports NO installability errors", inst.installabilityErrors.length === 0, inst.installabilityErrors.map((e) => e.errorId));

  for (const [file, size] of [["icon-192.png", 192], ["icon-512.png", 512], ["icon-maskable-512.png", 512], ["apple-touch-icon.png", 180]]) {
    const res = await page.request.get(`${BASE}/icons/${file}`);
    const dim = pngSize(await res.body());
    report(`${file}: PNG, ${size}x${size}`, res.ok() && res.headers()["content-type"] === "image/png" && dim.w === size && dim.h === size, dim);
  }
  const apple = await page.request.get(`${BASE}/icons/apple-touch-icon.png`);
  const opaque = await page.evaluate(async (b64) => {
    const img = new Image(); img.src = `data:image/png;base64,${b64}`; await img.decode();
    const c = document.createElement("canvas"); c.width = img.width; c.height = img.height;
    const g = c.getContext("2d"); g.drawImage(img, 0, 0);
    const corner = g.getImageData(0, 0, 1, 1).data; return corner[3];
  }, (await apple.body()).toString("base64"));
  report("apple-touch-icon is opaque at the corner (iOS rounds it itself)", opaque === 255, opaque);
  const html = await page.content();
  report("index.html links the manifest, apple-touch-icon and SVG favicon", html.includes('rel="manifest"') && html.includes("apple-touch-icon.png") && html.includes("favicon.svg"));

  const cached = await page.evaluate(async () => ({ names: await caches.keys(), icons: await Promise.all(["/icons/icon-192.png", "/icons/icon-512.png", "/icons/apple-touch-icon.png", "/icons/favicon.svg", "/manifest.json"].map(async (u) => !!(await (await caches.open("mosi-shell-v3")).match(u)))) }));
  report("Service worker cache v3 holds the icons and manifest (old caches removed)", cached.names.join() === "mosi-shell-v3" && cached.icons.every(Boolean), cached);
  await ctx.setOffline(true);
  await page.reload({ waitUntil: "domcontentloaded" });
  report("Offline: the app shell still loads (Login)", await page.waitForSelector("#chwId", { timeout: 8000 }).then(() => true).catch(() => false));
  report("Offline: the icon is served from the cache", await page.evaluate(async () => (await fetch("/icons/icon-192.png")).ok));
  await ctx.setOffline(false);
  await ctx.close();
}

// ---------- 2. Install card (Chromium's beforeinstallprompt), phone width ----------
{
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, userAgent: ANDROID_CHROME, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "android");
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => document.body.innerText.includes("Online"));
  report("Android: no iOS steps; the generic tip is shown", (await page.locator("main").innerText()).includes("Install app") && !(await page.locator("body").innerText()).includes("In Safari, tap"));
  await page.evaluate(() => {
    const e = new Event("beforeinstallprompt", { cancelable: true });
    e.prompt = () => { window.__prompted = true; return Promise.resolve(); };
    e.userChoice = Promise.resolve({ outcome: "accepted" });
    window.dispatchEvent(e);
  });
  const card = page.getByRole("region", { name: "Install Mosi", exact: true });
  await card.waitFor({ timeout: 4000 });
  const sizes = await card.getByRole("button").evaluateAll((bs) => bs.map((b) => Math.round(b.getBoundingClientRect().height)));
  report("Install card buttons are at least 44px tall", sizes.every((h) => h >= 44), sizes);
  await axe(page, "Login with install card (phone)");

  // On a signed-in phone screen the card must clear the bottom navigation.
  await page.fill("#chwId", "CHW001"); await page.fill("#pin", "1234"); await page.press("#pin", "Enter");
  await page.waitForURL("**/chw");
  await page.waitForTimeout(1500);
  await page.evaluate(() => {
    const e = new Event("beforeinstallprompt", { cancelable: true });
    e.prompt = () => { window.__prompted = true; return Promise.resolve(); };
    e.userChoice = Promise.resolve({ outcome: "accepted" });
    window.dispatchEvent(e);
  });
  await card.waitFor({ timeout: 4000 });
  const overlap = await page.evaluate(() => {
    const cardBox = [...document.querySelectorAll('section[aria-label="Install Mosi"]')].find((s) => s.querySelector("button"))?.getBoundingClientRect();
    const nav = [...document.querySelectorAll("nav")].map((n) => n.getBoundingClientRect()).find((r) => r.bottom >= window.innerHeight - 1 && r.top > window.innerHeight / 2);
    return { cardBottom: cardBox?.bottom, navTop: nav?.top };
  });
  report("Install card sits above the bottom navigation", overlap.navTop !== undefined && overlap.cardBottom <= overlap.navTop, overlap);
  await card.getByRole("button", { name: "Install", exact: true }).click();
  report("Install -> the browser's install prompt is shown", await page.evaluate(() => window.__prompted === true));
  report("...and the card goes away", await card.isHidden());
  await ctx.close();
  await browser.close();
}

// ---------- 3. iPhone Safari ----------
{
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, userAgent: IPHONE_SAFARI, hasTouch: true, isMobile: true, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "iphone");
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const hint = page.getByRole("region", { name: "Add Mosi to your home screen" });
  report("iPhone Safari: Login shows Safari's steps (Share -> Add to Home Screen)", (await hint.innerText()).includes("In Safari, tap") && (await hint.innerText()).includes("Add to Home Screen"));
  await axe(page, "Login with iOS install hint");
  report("No horizontal scroll at 390px with the hint", await noHScroll(page));
  await page.setViewportSize({ width: 360, height: 800 });
  report("No horizontal scroll at 360px with the hint", await noHScroll(page));
  await hint.getByRole("button", { name: "Dismiss install tip" }).click();
  report("Dismiss hides it", await hint.isHidden());
  await page.reload({ waitUntil: "networkidle" });
  report("...and it stays dismissed after reload", (await page.getByRole("region", { name: "Add Mosi to your home screen" }).count()) === 0);
  await ctx.close();

  // Opened from the home screen (navigator.standalone) -> no hint at all
  const ctx2 = await browser.newContext({ viewport: { width: 390, height: 844 }, userAgent: IPHONE_SAFARI, hasTouch: true, isMobile: true, bypassCSP: true });
  await ctx2.addInitScript(() => Object.defineProperty(Navigator.prototype, "standalone", { get: () => true }));
  const p2 = await ctx2.newPage();
  track(p2, "iphone-installed");
  await p2.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  report("Installed on iPhone (standalone): no install hint", (await p2.getByRole("region", { name: "Add Mosi to your home screen" }).count()) === 0);
  await p2.fill("#chwId", "CHW001"); await p2.fill("#pin", "1234"); await p2.press("#pin", "Enter");
  await p2.waitForURL("**/chw");
  report("...and none on CHW Home either", (await p2.getByRole("region", { name: "Add Mosi to your home screen" }).count()) === 0);
  await ctx2.close();

  // Not installed: CHW Home also shows the iOS steps
  const ctx3 = await browser.newContext({ viewport: { width: 390, height: 844 }, userAgent: IPHONE_SAFARI, hasTouch: true, isMobile: true, bypassCSP: true });
  const p3 = await ctx3.newPage();
  track(p3, "iphone-home");
  await p3.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await p3.waitForFunction(() => document.body.innerText.includes("Online"));
  await p3.fill("#chwId", "CHW001"); await p3.fill("#pin", "1234"); await p3.press("#pin", "Enter");
  await p3.waitForURL("**/chw");
  report("CHW Home on iPhone Safari shows the same steps", (await p3.getByRole("region", { name: "Add Mosi to your home screen" }).innerText()).includes("In Safari, tap"));
  await ctx3.close();
  await browser.close();
}

report("No page errors or console errors", errors.length === 0, errors.length ? errors.slice(0, 5) : undefined);
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
