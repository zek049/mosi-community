import { Router } from "express";
import bcrypt from "bcryptjs";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { requireRole } from "../middleware/auth";
import { canManageAccount, clinicScope, isAdmin } from "../middleware/authz";
import { requireStringParam } from "../utils/params";
import { parsePageParams, buildPagination } from "../utils/pagination";
import { parseBody, chwCreateSchema, chwUpdateSchema } from "../validation/schemas";
import { writeAuditLog } from "../utils/audit";
import { isWeakPin, WEAK_PIN_MESSAGE } from "../utils/pinPolicy";

const router = Router();

// Explicit select (not the default findMany shape) so pin_hash can never
// accidentally end up in an API response, per section 32 of the original
// spec - still true now that there are more fields to list out.
const CHW_SELECT = {
  id: true,
  chw_id: true,
  full_name: true,
  clinic: true,
  clinic_id: true,
  phone_number: true,
  role: true,
  status: true,
  last_login_at: true,
  created_at: true,
} as const;

router.get("/", async (req, res) => {
  const { search, clinic_id: clinicId, status } = req.query as Record<string, string | undefined>;
  const pageParams = parsePageParams(req);
  const statusFilter: "active" | "revoked" | undefined =
    status === "active" || status === "revoked" ? status : undefined;

  // Everyone but an administrator sees only their own clinic's accounts;
  // a clinic_id filter can narrow that, never widen it.
  const scope = clinicScope(req.user!);
  const where = {
    AND: [
      scope ? { clinic_id: scope } : {},
      clinicId ? { clinic_id: clinicId } : {},
      statusFilter ? { status: statusFilter } : {},
      search
        ? {
            OR: [
              { chw_id: { contains: search, mode: "insensitive" as const } },
              { full_name: { contains: search, mode: "insensitive" as const } },
            ],
          }
        : {},
    ],
  };

  const [chws, total] = await Promise.all([
    prisma.chw.findMany({
      where,
      select: CHW_SELECT,
      orderBy: { full_name: "asc" },
      skip: pageParams.skip,
      take: pageParams.take,
    }),
    prisma.chw.count({ where }),
  ]);

  res.json({ success: true, data: chws, pagination: buildPagination(pageParams, total) });
});

// Provisioning a real account (section 54) - previously the only way to
// create a CHW/Supervisor login was re-running the demo seed script.
// Supervisor management list: CHW accounts in the supervisor's scope, with
// how much history each one has (which decides whether it can be deleted).
// ?role=SUPERVISOR lists supervisor accounts instead (administrators only).
router.get("/manage", requireRole("SUPERVISOR"), async (req, res) => {
  const role = req.query.role === "SUPERVISOR" ? "SUPERVISOR" : "CHW";
  if (role === "SUPERVISOR" && !isAdmin(req.user!)) {
    throw new AppError(403, "Only an administrator can manage supervisor accounts");
  }
  const scope = clinicScope(req.user!);
  const chws = await prisma.chw.findMany({
    where: { role, ...(scope ? { clinic_id: scope } : {}) },
    select: { ...CHW_SELECT, _count: { select: { visitsRecorded: true, patientsRegistered: true } } },
    orderBy: [{ status: "asc" }, { full_name: "asc" }],
  });
  res.json({
    success: true,
    data: chws.map(({ _count, ...chw }) => ({
      ...chw,
      visit_count: _count.visitsRecorded,
      patients_registered: _count.patientsRegistered,
      can_delete: _count.visitsRecorded === 0 && _count.patientsRegistered === 0,
    })),
  });
});

router.post("/", requireRole("SUPERVISOR"), async (req, res) => {
  const body = parseBody(chwCreateSchema, req.body ?? {});
  // Supervisors create CHW accounts only, in their own clinic. Supervisor
  // accounts are an administrator's job. Nobody creates an ADMIN here (the
  // schema only accepts CHW | SUPERVISOR).
  if (body.role === "SUPERVISOR" && !isAdmin(req.user!)) {
    throw new AppError(403, "Only an administrator can create supervisor accounts");
  }
  const scope = clinicScope(req.user!);
  if (scope && body.clinic_id !== scope) {
    throw new AppError(403, "You can only add CHWs to your own clinic");
  }
  // Same rule the Add CHW form shows, so the two can't disagree.
  if (isWeakPin(body.pin)) throw new AppError(400, WEAK_PIN_MESSAGE, "WEAK_PIN");

  const [existing, clinic] = await Promise.all([
    prisma.chw.findUnique({ where: { chw_id: body.chw_id } }),
    prisma.clinic.findUnique({ where: { id: body.clinic_id } }),
  ]);

  if (existing) {
    throw new AppError(409, `CHW ID "${body.chw_id}" already exists`);
  }
  if (!clinic) {
    throw new AppError(400, "clinic_id does not refer to an existing clinic");
  }

  const pinHash = await bcrypt.hash(body.pin, 10);
  const chw = await prisma.chw.create({
    data: {
      chw_id: body.chw_id,
      full_name: body.full_name,
      clinic: clinic.name,
      clinic_id: clinic.id,
      phone_number: body.phone_number ?? null,
      pin_hash: pinHash,
      role: body.role,
      // The supervisor knows this PIN, so the CHW must replace it at first
      // sign-in (same as a supervisor-set PIN after a reset).
      must_change_pin: true,
    },
    select: CHW_SELECT,
  });

  await writeAuditLog({
    actor: req.user,
    action: "CHW_CREATED",
    resourceType: "chw",
    resourceId: chw.chw_id,
    requestId: req.requestId,
    metadata: { clinic_id: clinic.id, role: chw.role },
  });

  res.status(201).json({ success: true, data: chw });
});

router.patch("/:chwId", requireRole("SUPERVISOR"), async (req, res) => {
  const chwId = requireStringParam(req, "chwId");
  const body = parseBody(chwUpdateSchema, req.body ?? {});

  const existing = await findManageable(chwId, req.user!);
  const scope = clinicScope(req.user!);
  if (scope && body.clinic_id && body.clinic_id !== scope) {
    throw new AppError(403, "You can only assign CHWs to your own clinic");
  }

  let clinicName: string | undefined;
  if (body.clinic_id) {
    const clinic = await prisma.clinic.findUnique({ where: { id: body.clinic_id } });
    if (!clinic) {
      throw new AppError(400, "clinic_id does not refer to an existing clinic");
    }
    clinicName = clinic.name;
  }

  const pinHash = body.pin ? await bcrypt.hash(body.pin, 10) : undefined;

  const chw = await prisma.chw.update({
    where: { chw_id: existing.chw_id },
    data: {
      full_name: body.full_name,
      clinic_id: body.clinic_id,
      clinic: clinicName,
      phone_number: body.phone_number === undefined ? undefined : body.phone_number,
      pin_hash: pinHash,
      // A supervisor-set PIN is temporary: the owner must replace it at
      // their next sign-in. It's also the moment a lockout stops applying.
      ...(pinHash ? { failed_login_count: 0, locked_until: null, must_change_pin: true } : {}),
    },
    select: CHW_SELECT,
  });

  await writeAuditLog({
    actor: req.user,
    action: "CHW_UPDATED",
    resourceType: "chw",
    resourceId: chw.chw_id,
    requestId: req.requestId,
    clinicId: chw.clinic_id,
    // The PIN itself is never recorded - only the fact that it was reset.
    metadata: { changed: Object.keys(body).filter((k) => k !== "pin"), pin_reset: body.pin !== undefined },
  });

  res.json({ success: true, data: chw });
});

// Status changes are their own audited actions (not generic edits).
router.post("/:chwId/revoke", requireRole("SUPERVISOR"), async (req, res) => {
  const existing = await findManageable(requireStringParam(req, "chwId"), req.user!);
  if (existing.status === "revoked") throw new AppError(409, "This account is already revoked");
  // Takes effect on the CHW's very next request: authenticate() re-checks
  // status every time. History (patients, visits, audit) is untouched.
  const chw = await prisma.chw.update({ where: { chw_id: existing.chw_id }, data: { status: "revoked" }, select: CHW_SELECT });
  await writeAuditLog({ actor: req.user, action: "CHW_REVOKED", resourceType: "chw", resourceId: chw.chw_id, requestId: req.requestId, metadata: { clinic_id: chw.clinic_id } });
  res.json({ success: true, data: chw });
});

router.post("/:chwId/reactivate", requireRole("SUPERVISOR"), async (req, res) => {
  const existing = await findManageable(requireStringParam(req, "chwId"), req.user!);
  if (existing.status === "active") throw new AppError(409, "This account is already active");
  const chw = await prisma.chw.update({
    where: { chw_id: existing.chw_id },
    data: { status: "active", failed_login_count: 0, locked_until: null },
    select: CHW_SELECT,
  });
  await writeAuditLog({ actor: req.user, action: "CHW_REACTIVATED", resourceType: "chw", resourceId: chw.chw_id, requestId: req.requestId, metadata: { clinic_id: chw.clinic_id } });
  res.json({ success: true, data: chw });
});

// Permanent deletion is only for accounts that never recorded anything
// (e.g. created by mistake). Clinical history is never deleted with an
// account: a CHW with visits or registered patients must be revoked instead.
router.delete("/:chwId", requireRole("SUPERVISOR"), async (req, res) => {
  const existing = await findManageable(requireStringParam(req, "chwId"), req.user!);
  const [visits, patients] = await Promise.all([
    prisma.visit.count({ where: { chw_id: existing.chw_id } }),
    prisma.patient.count({ where: { registered_by_chw_id: existing.chw_id } }),
  ]);
  if (visits > 0 || patients > 0) {
    throw new AppError(409, "This CHW has recorded visits or patients, so the account can't be deleted. Revoke it instead - history is kept.", "HAS_HISTORY");
  }
  await prisma.chw.delete({ where: { chw_id: existing.chw_id } });
  await writeAuditLog({
    actor: req.user,
    action: "CHW_DELETED",
    resourceType: "chw",
    resourceId: existing.chw_id,
    requestId: req.requestId,
    metadata: { clinic_id: existing.clinic_id, full_name: existing.full_name },
  });
  res.json({ success: true, data: { chw_id: existing.chw_id, deleted: true } });
});

// Load an account the actor may manage; anything else looks like "not found"
// (so supervisors can't probe accounts outside their scope).
async function findManageable(chwId: string, actor: Parameters<typeof canManageAccount>[0]) {
  const existing = await prisma.chw.findUnique({ where: { chw_id: chwId } });
  if (!existing || !canManageAccount(actor, existing)) {
    throw new AppError(404, "CHW not found");
  }
  return existing;
}

export default router;
