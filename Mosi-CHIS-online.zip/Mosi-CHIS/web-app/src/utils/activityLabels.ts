// Plain-language wording for activity-log entries (backend audit actions).
// Only fields known to be safe are turned into words - nothing here ever
// shows raw JSON, and entries never contain PINs or tokens to begin with.

export type ActivityEntry = {
  action: string;
  actor_id: string | null;
  actor_name?: string | null;
  resource_type: string | null;
  resource_id: string | null;
  metadata?: Record<string, unknown> | null;
};

export const ACTION_LABELS: Record<string, string> = {
  LOGIN_SUCCESS: "Signed in",
  LOGIN_FAILURE: "Sign-in failed",
  ACCOUNT_LOCKED: "Account locked after failed sign-ins",
  PIN_CHANGED: "Changed their PIN",
  PIN_RESET_REQUESTED: "Asked for a PIN reset",
  PIN_RESET_COMPLETED: "Set a temporary PIN",
  PATIENT_CREATED: "Registered a patient",
  PATIENT_UPDATED: "Edited a patient",
  PATIENT_ARCHIVED: "Archived a patient",
  VISIT_CREATED: "Recorded a visit",
  VISIT_UPDATED: "Edited a visit",
  VISIT_ARCHIVED: "Archived a visit",
  SYNC_STARTED: "Started a sync",
  SYNC_COMPLETED: "Finished a sync",
  SYNC_CONFLICT: "Sync conflict found",
  CONFLICT_RESOLVED: "Resolved a sync conflict",
  RECORD_CONFIRMED: "Confirmed a record",
  RECORD_FLAGGED: "Flagged a record",
  CHW_CREATED: "Added an account",
  CHW_UPDATED: "Changed an account",
  CHW_DEACTIVATED: "Deactivated an account",
  CHW_REVOKED: "Revoked an account",
  CHW_REACTIVATED: "Reactivated an account",
  CHW_DELETED: "Deleted an account",
  CLINIC_CREATED: "Added a clinic",
  ACCOUNT_REQUESTED: "Requested an account",
  ACCOUNT_APPROVED: "Approved an account request",
  ACCOUNT_REJECTED: "Rejected an account request",
};

// Groups for the action filter (value = comma-separated actions).
export const ACTION_GROUPS: { label: string; actions: string[] }[] = [
  { label: "Sign-ins and PINs", actions: ["LOGIN_SUCCESS", "LOGIN_FAILURE", "ACCOUNT_LOCKED", "PIN_CHANGED", "PIN_RESET_REQUESTED", "PIN_RESET_COMPLETED"] },
  { label: "Patients and visits", actions: ["PATIENT_CREATED", "PATIENT_UPDATED", "PATIENT_ARCHIVED", "VISIT_CREATED", "VISIT_UPDATED", "VISIT_ARCHIVED"] },
  { label: "Review decisions", actions: ["RECORD_CONFIRMED", "RECORD_FLAGGED"] },
  { label: "Syncing and conflicts", actions: ["SYNC_STARTED", "SYNC_COMPLETED", "SYNC_CONFLICT", "CONFLICT_RESOLVED"] },
  { label: "Accounts", actions: ["CHW_CREATED", "CHW_UPDATED", "CHW_DEACTIVATED", "CHW_REVOKED", "CHW_REACTIVATED", "CHW_DELETED", "ACCOUNT_REQUESTED", "ACCOUNT_APPROVED", "ACCOUNT_REJECTED", "CLINIC_CREATED"] },
];

const FAILURE_REASONS: Record<string, string> = {
  bad_pin: "wrong PIN",
  not_found: "unknown ID",
  locked: "account locked",
  revoked: "account revoked",
  request_pending: "account request not approved yet",
  change_pin_bad_current: "wrong current PIN while changing PIN",
};

const RECORD_NOUN: Record<string, string> = { patient: "patient", visit: "visit", household: "household", chw: "account", account_request: "account request", clinic: "clinic" };

export function actionLabel(action: string): string {
  return ACTION_LABELS[action] ?? action.toLowerCase().replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase());
}

const str = (v: unknown) => (typeof v === "string" ? v : undefined);
const num = (v: unknown) => (typeof v === "number" ? v : undefined);
const plural = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`;

// One short line of detail, or null when there's nothing useful to add.
export function activityDetail(entry: ActivityEntry): string | null {
  const meta = entry.metadata ?? {};
  switch (entry.action) {
    case "LOGIN_FAILURE": {
      const reason = str(meta.reason);
      return reason ? `Reason: ${FAILURE_REASONS[reason] ?? reason}` : null;
    }
    case "ACCOUNT_LOCKED":
      return num(meta.minutes) !== undefined ? `Locked for ${meta.minutes} minutes` : null;
    case "PIN_CHANGED":
      return meta.was_temporary === true ? "Replaced a temporary PIN" : null;
    case "RECORD_FLAGGED":
      return str(meta.reason) ? `Reason: ${meta.reason}` : null;
    case "RECORD_CONFIRMED":
      return meta.from === "flagged" ? "Was flagged before" : null;
    case "CONFLICT_RESOLVED":
      return meta.resolution === "APPLY_INCOMING" ? "Kept the device's version" : meta.resolution === "KEEP_SERVER" ? "Kept the server's version" : null;
    case "SYNC_STARTED": {
      const parts = [
        num(meta.patients) ? plural(meta.patients as number, "patient", "patients") : null,
        num(meta.visits) ? plural(meta.visits as number, "visit", "visits") : null,
        num(meta.households) ? plural(meta.households as number, "household", "households") : null,
      ].filter(Boolean);
      return parts.length ? `Sent ${parts.join(", ")}` : "Nothing to send";
    }
    case "SYNC_COMPLETED": {
      const s = num(meta.synced) ?? 0, c = num(meta.conflicts) ?? 0, f = num(meta.failed) ?? 0;
      return [`${s} accepted`, c ? `${c} conflict${c === 1 ? "" : "s"}` : null, f ? `${f} rejected` : null].filter(Boolean).join(", ");
    }
    case "CHW_CREATED":
      return meta.role === "SUPERVISOR" ? "Supervisor account" : null;
    case "CHW_UPDATED": {
      if (meta.role && typeof meta.role === "object") return "Role changed";
      const changed = Array.isArray(meta.changed) ? (meta.changed as unknown[]).filter((k): k is string => typeof k === "string") : [];
      const words = changed.map((k) => ({ full_name: "name", clinic_id: "clinic", phone_number: "phone number" })[k] ?? k);
      return [meta.pin_reset === true ? "set a temporary PIN" : null, words.length ? `changed ${words.join(", ")}` : null].filter(Boolean).join("; ").replace(/^./, (c) => c.toUpperCase()) || null;
    }
    case "ACCOUNT_REJECTED":
      return str(meta.reason) ? `Reason: ${meta.reason}` : null;
    case "VISIT_CREATED":
    case "PATIENT_CREATED":
    case "VISIT_UPDATED":
    case "PATIENT_UPDATED":
      return meta.via === "sync" ? "Sent from a device" : null;
    default:
      return null;
  }
}

// What the action was done to, e.g. "patient MBR-0012" or "account CHW002".
export function activityTarget(entry: ActivityEntry): string | null {
  if (!entry.resource_type) return null;
  const noun = RECORD_NOUN[entry.resource_type] ?? entry.resource_type;
  const meta = entry.metadata ?? {};
  const readable = str(meta.patient_id) ?? str(meta.chw_id) ?? str(meta.requested_chw_id) ?? str(meta.code);
  if (entry.resource_type === "chw") return `${noun} ${entry.resource_id ?? ""}`.trim();
  if (readable) return `${noun} ${readable}`;
  // Record ids are long UUIDs - show a short form only.
  return entry.resource_id ? `${noun} ${entry.resource_id.slice(0, 8)}` : noun;
}
