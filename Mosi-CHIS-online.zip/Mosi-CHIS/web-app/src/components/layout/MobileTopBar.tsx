import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { Check, LogOut } from "lucide-react";
import { useNetwork } from "../../contexts/NetworkContext";
import { ConnectivityIndicator } from "../Connectivity";
import { Logo } from "../Logo";

type MobileTopBarProps = {
  userName: string;
  userSubtitle: string;
  onSignOut: () => void;
};

function initials(name: string): string {
  return name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

// Mobile-only (md:hidden - Sidebar takes over above that breakpoint).
// White, not the sidebar's dark forest-teal: the sidebar is one specific
// piece of desktop furniture, this is the mobile equivalent of the plain
// content header every screen already sits under.
export function MobileTopBar({ userName, userSubtitle, onSignOut }: MobileTopBarProps) {
  const { workOffline, setWorkOffline } = useNetwork();
  return (
    <header className="sticky top-0 z-40 flex items-center justify-between gap-3 border-b border-stone-200 bg-white px-4 py-3 md:hidden">
      <Logo size="sm" />
      <div className="flex items-center gap-2">
        <ConnectivityIndicator />
        <DropdownMenu.Root modal={false}>
          <DropdownMenu.Trigger asChild>
            <button
              type="button"
              aria-label={`Account menu for ${userName}`}
              className="-m-1.5 flex h-11 w-11 shrink-0 items-center justify-center rounded-full"
            >
              <span className="flex h-8 w-8 items-center justify-center rounded-full bg-forest-800 text-xs font-semibold text-white" aria-hidden="true">
                {initials(userName)}
              </span>
            </button>
          </DropdownMenu.Trigger>
          <DropdownMenu.Portal>
            <DropdownMenu.Content
              align="end"
              sideOffset={8}
              className="z-50 w-52 rounded-lg border border-stone-200 bg-white p-1.5 shadow-md"
            >
              <div className="px-2.5 py-2">
                <p className="truncate text-sm font-medium text-stone-900">{userName}</p>
                <p className="truncate text-xs text-stone-500">{userSubtitle}</p>
              </div>
              <DropdownMenu.Separator className="my-1 h-px bg-stone-100" />
              {/* Work Offline lives here on phones (the desktop header has a switch). */}
              <DropdownMenu.CheckboxItem
                checked={workOffline}
                onCheckedChange={(checked) => setWorkOffline(checked === true)}
                onSelect={(e) => e.preventDefault()}
                className="flex min-h-11 cursor-pointer items-center gap-2 rounded-md px-2.5 py-2 text-sm text-stone-700 outline-none data-[highlighted]:bg-stone-100"
              >
                <span className="flex h-4 w-4 items-center justify-center rounded border border-stone-400" aria-hidden="true">
                  <DropdownMenu.ItemIndicator>
                    <Check className="h-3.5 w-3.5 text-forest-800" />
                  </DropdownMenu.ItemIndicator>
                </span>
                Work offline
              </DropdownMenu.CheckboxItem>
              <DropdownMenu.Item
                onSelect={onSignOut}
                className="flex min-h-11 cursor-pointer items-center gap-2 rounded-md px-2.5 py-2 text-sm text-stone-700 outline-none data-[highlighted]:bg-stone-100"
              >
                <LogOut className="h-4 w-4" aria-hidden="true" />
                Sign out
              </DropdownMenu.Item>
            </DropdownMenu.Content>
          </DropdownMenu.Portal>
        </DropdownMenu.Root>
      </div>
    </header>
  );
}
