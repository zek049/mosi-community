import { Router } from "express";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { requireRole } from "../middleware/auth";
import { parseBody, clinicCreateSchema } from "../validation/schemas";
import { writeAuditLog } from "../utils/audit";

const router = Router();

// Every authenticated role can read the clinic list (a CHW's own "Add
// Patient"/filters need to resolve clinic names; a supervisor needs the
// full list to assign CHWs to clinics) - only creating a clinic is
// administrator-only (supervisors are scoped to one clinic).
router.get("/", async (_req, res) => {
  const clinics = await prisma.clinic.findMany({
    where: { active: true },
    orderBy: { name: "asc" },
  });
  res.json({ success: true, data: clinics });
});

router.post("/", requireRole("ADMIN"), async (req, res) => {
  const body = parseBody(clinicCreateSchema, req.body ?? {});

  const existing = await prisma.clinic.findUnique({ where: { code: body.code } });
  if (existing) {
    throw new AppError(409, `Clinic code "${body.code}" already exists`);
  }

  const clinic = await prisma.clinic.create({
    data: { code: body.code, name: body.name, location: body.location ?? null },
  });

  await writeAuditLog({
    actor: req.user,
    action: "CLINIC_CREATED",
    resourceType: "clinic",
    resourceId: clinic.id,
    requestId: req.requestId,
    metadata: { code: clinic.code, name: clinic.name },
  });

  res.status(201).json({ success: true, data: clinic });
});

export default router;
