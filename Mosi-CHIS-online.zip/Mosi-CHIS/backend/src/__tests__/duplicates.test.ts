import { beforeEach, describe, expect, it, vi } from "vitest";
import { dayOf, isPossibleDuplicate, normalizeForMatch } from "../utils/duplicates";

// Same table as web-app/src/utils/__tests__/findPossibleDuplicates.test.ts.
const base = { first_name: "Chiedza", last_name: "Moyo", village: "Mbare", date_of_birth: "2022-03-14" };
const CASES: Array<[string, Partial<typeof base>, boolean]> = [
  ["identical", {}, true],
  ["different case", { first_name: "CHIEDZA", last_name: "moyo", village: "mbare" }, true],
  ["extra / inner spaces", { first_name: "  Chiedza ", village: "Mbare " }, true],
  ["accents ignored", { last_name: "Möyo" }, true],
  ["DOB given as a server timestamp", { date_of_birth: "2022-03-14T00:00:00.000Z" }, true],
  ["different first name", { first_name: "Rudo" }, false],
  ["different village", { village: "Epworth" }, false],
  ["different DOB", { date_of_birth: "2022-03-15" }, false],
  ["first/last swapped", { first_name: "Moyo", last_name: "Chiedza" }, false],
];

describe("duplicate matching rule", () => {
  it.each(CASES)("%s", (_label, change, expected) => {
    expect(isPossibleDuplicate(base, { ...base, ...change })).toBe(expected);
  });
  it("normalises names", () => {
    expect(normalizeForMatch("  Tendai   Mütasa ")).toBe("tendai mutasa");
    expect(normalizeForMatch(null)).toBe("");
    expect(dayOf(new Date("2022-03-14T00:00:00Z"))).toBe("2022-03-14");
  });
});

// --- endpoint -------------------------------------------------------------

vi.hoisted(() => {
  process.env.JWT_SECRET = "test-secret-for-integration-tests";
});
const m = vi.hoisted(() => ({ chwFindUnique: vi.fn(), patientFindMany: vi.fn() }));
vi.mock("../db", () => ({
  prisma: { chw: { findUnique: m.chwFindUnique }, patient: { findMany: m.patientFindMany }, auditLog: { create: vi.fn() } },
}));

import request from "supertest";
import app from "../app";
import { signSessionToken } from "../middleware/auth";

const chwAuth = { Authorization: `Bearer ${signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Jane" })}` };
const q = "first_name=chiedza&last_name=MOYO&village=mbare&date_of_birth=2022-03-14";

beforeEach(() => {
  vi.clearAllMocks();
  m.chwFindUnique.mockResolvedValue({ chw_id: "CHW001", status: "active", locked_until: null, clinic_id: "clinic-a" });
  m.patientFindMany.mockResolvedValue([
    { id: "p1", patient_id: "MBR-0017", first_name: "Chiedza", last_name: "Möyo", village: "Mbare ", date_of_birth: new Date("2022-03-14T00:00:00Z") },
    { id: "p2", patient_id: "MBR-0099", first_name: "Rudo", last_name: "Moyo", village: "Mbare", date_of_birth: new Date("2022-03-14T00:00:00Z") },
  ]);
});

describe("GET /api/patients/possible-duplicates", () => {
  it("requires a session", async () => {
    expect((await request(app).get(`/api/patients/possible-duplicates?${q}`)).status).toBe(401);
  });

  it("returns only true matches, scoped to the CHW's clinic, with minimal fields", async () => {
    const res = await request(app).get(`/api/patients/possible-duplicates?${q}`).set(chwAuth);
    expect(res.status).toBe(200);
    expect(res.body.data.map((p: { id: string }) => p.id)).toEqual(["p1"]);
    const query = m.patientFindMany.mock.calls[0][0];
    expect(query.where.clinic_id).toBe("clinic-a");
    expect(query.where.deleted_at).toBeNull();
    expect(Object.keys(query.select).sort()).toEqual(["date_of_birth", "first_name", "id", "last_name", "patient_id", "village"]);
  });

  it("validates input", async () => {
    const res = await request(app).get("/api/patients/possible-duplicates?first_name=x").set(chwAuth);
    expect(res.status).toBe(400);
    expect(m.patientFindMany).not.toHaveBeenCalled();
  });
});
