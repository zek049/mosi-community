// Feature 8 - Follow-up / due tracking. Production build (:4173), real backend (:4000).
// The follow-up visit is recorded OFFLINE and the context is closed without
// going back online, so nothing reaches the server (notes carry P13-<stamp>
// and cleanup.sql removes them anyway).
import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const STAMP = `P13-${String(Date.now()).slice(-6)}`;
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
async function axe(page, label) {
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}: ${x.nodes.map((n) => n.target.join(" ")).slice(0, 3).join(" | ")}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
const noHScroll = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);
function track(page, who) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => { if (m.type() === "error" && !/ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(m.text())) errors.push(`${who}: ${m.text()}`); });
}
async function login(page, id) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => document.body.innerText.includes("Online"));
  await page.fill("#chwId", id); await page.fill("#pin", "1234"); await page.press("#pin", "Enter");
}

// Independent re-implementation of the rule, run on the device's data, to
// check the screen's numbers (not the app's own function).
const expectedDue = (page) => page.evaluate(async () => {
  const db = await new Promise((res) => { const r = indexedDB.open("mosi-chis-user-CHW001"); r.onsuccess = () => res(r.result); });
  const all = (s) => new Promise((res) => { const c = db.transaction(s).objectStore(s).getAll(); c.onsuccess = () => res(c.result); });
  const [visits, patients] = [await all("visits"), await all("patients")];
  db.close();
  const live = new Set(patients.filter((p) => !p.deleted_at).map((p) => p.id));
  const days = { Antenatal: 30, Immunization: 90, "Growth Monitoring": 30, "HIV/TB Support": 30 };
  const latest = {};
  for (const v of visits) {
    if (v.deleted_at || !(v.visit_type in days) || !live.has(v.patient_id)) continue;
    const k = `${v.patient_id}|${v.visit_type}`;
    const d = v.visit_date.slice(0, 10);
    if (!latest[k] || d > latest[k]) latest[k] = d;
  }
  const t = new Date(); const today = Date.UTC(t.getFullYear(), t.getMonth(), t.getDate());
  const out = [];
  for (const [k, d] of Object.entries(latest)) {
    const [pid, type] = k.split("|");
    const due = Date.parse(`${d}T00:00:00Z`) + days[type] * 86400000;
    const overdue = Math.round((today - due) / 86400000);
    if (overdue > -7) out.push({ pid, type, overdue });
  }
  return out;
});

const browser = await chromium.launch();

// ---------- CHW Home ----------
const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, bypassCSP: true });
const page = await ctx.newPage();
track(page, "chw");
await login(page, "CHW001");
await page.waitForURL("**/chw");
await page.waitForTimeout(2500);
const expected = await expectedDue(page);
const section = page.getByRole("region", { name: /Due this week/ });
await section.waitFor({ timeout: 8000 });
const heading = await section.getByRole("heading").first().innerText();
report("CHW Home: 'Due this week (N)' matches an independent count from the device", heading === `Due this week (${expected.length})`, { heading, expected: expected.length });
report("CHW Home: shows 5 then 'Show all N'", expected.length <= 5 || ((await section.getByRole("listitem").count()) === 5 && (await section.getByRole("button", { name: `Show all ${expected.length}` }).isVisible())));
const overdueCount = expected.filter((e) => e.overdue > 0).length;
if (overdueCount > 0) report("CHW Home: overdue count shown in words", (await section.innerText()).includes(`${overdueCount} overdue`));
const firstRow = await section.getByRole("listitem").first().innerText();
const mostOverdue = Math.max(...expected.map((e) => e.overdue));
report("CHW Home: most overdue first, with words not colour alone", firstRow.includes(mostOverdue > 0 ? `${mostOverdue} day` : mostOverdue === 0 ? "Due today" : "Due "), firstRow);
report("CHW Home: the intervals are explained", (await section.innerText()).includes("Antenatal 30 days, Immunization 90 days, Growth Monitoring 30 days, HIV/TB Support 30 days"));
if (expected.length > 5) {
  const toggle = section.getByRole("button", { name: `Show all ${expected.length}` });
  await toggle.click();
  report("Show all: lists every item, aria-expanded=true", (await section.getByRole("listitem").count()) === expected.length && (await section.getByRole("button", { name: "Show fewer" }).getAttribute("aria-expanded")) === "true");
  await section.getByRole("button", { name: "Show fewer" }).click();
}
await axe(page, "CHW Home with Due this week");
for (const w of [360, 400]) {
  await page.setViewportSize({ width: w, height: 800 });
  report(`No horizontal scroll at ${w}px (CHW Home)`, await noHScroll(page));
}
await page.setViewportSize({ width: 375, height: 812 });

// Pick the first item; recording that visit type clears it.
const target = await section.getByRole("listitem").first();
const targetText = await target.innerText();
const targetType = ["Antenatal", "Immunization", "Growth Monitoring", "HIV/TB Support"].find((t) => targetText.includes(t));
const targetName = targetText.split("\n")[0];
await target.getByRole("link").click();
await page.waitForURL("**/patients/**");
const patientRecordId = new URL(page.url()).pathname.split("/").pop();
report("Row opens that patient's detail", await page.waitForSelector(`h1:has-text("${targetName}")`, { timeout: 5000 }).then(() => true).catch(() => false), targetName);

// ---------- Offline: record the follow-up -> it leaves the list ----------
await ctx.setOffline(true);
await page.waitForTimeout(1500);
await page.goto(`${BASE}/chw`, { waitUntil: "domcontentloaded" }).catch(() => {});
// The SPA is served by the service worker / cache; if a hard reload offline
// fails, navigate within the app instead.
if (!(await page.isVisible("text=Due this week").catch(() => false))) {
  await ctx.setOffline(false);
  await page.goto(`${BASE}/chw`, { waitUntil: "networkidle" });
  await ctx.setOffline(true);
  await page.waitForTimeout(1500);
}
report("Offline: Due this week still shown (computed on the device)", await page.getByRole("region", { name: /Due this week/ }).isVisible());
await page.evaluate((url) => { history.pushState({}, "", url); dispatchEvent(new PopStateEvent("popstate")); }, `/chw/visits/new?patient_id=${patientRecordId}`);
await page.waitForSelector("text=Visit type", { timeout: 8000 }).catch(() => {});
await page.check(`input[name="visit_type"][value="${targetType}"]`);
await page.click('button:has-text("Continue")');
await page.waitForSelector('h2:has-text("Measurements & notes")');
await page.fill("#notes", `${STAMP} follow-up`);
await page.click('button:has-text("Continue")');
await page.waitForSelector('h2:has-text("Review & save")');
await page.click('button:has-text("Save visit")');
await page.waitForSelector("text=Visit recorded", { timeout: 8000 });
await page.evaluate(() => { history.pushState({}, "", "/chw"); dispatchEvent(new PopStateEvent("popstate")); });
const section2 = page.getByRole("region", { name: /Due this week/ });
await section2.waitFor();
await page.waitForTimeout(500);
const heading2 = await section2.getByRole("heading").first().innerText();
report("Offline: recording the follow-up removes it straight away (count - 1)", heading2 === (expected.length - 1 > 0 ? `Due this week (${expected.length - 1})` : "Due this week"), { before: expected.length, heading2 });
const showAll = section2.getByRole("button", { name: /Show all/ });
if (await showAll.isVisible().catch(() => false)) await showAll.click();
const stillListed = await section2.getByRole("listitem").filter({ hasText: targetName }).filter({ hasText: targetType }).count();
report("Offline: that patient + visit type is no longer listed", stillListed === 0);
await ctx.close(); // never back online: the test visit stays off the server

// ---------- Supervisor widget ----------
const sctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
const sp = await sctx.newPage();
track(sp, "supervisor");
await login(sp, "SUP001");
await sp.waitForURL("**/supervisor");
const widget = sp.locator("h2:has-text('Follow-ups due this week') >> xpath=ancestor::div[contains(@class,'rounded')][1]");
await sp.waitForSelector("text=Follow-ups due this week");
await sp.waitForFunction(() => /\d+ due/.test(document.body.innerText), null, { timeout: 8000 });
const today = await sp.evaluate(() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; });
const server = await sp.evaluate(async ([API, today]) => (await (await fetch(`${API}/patients/due?today=${today}`, { credentials: "include" })).json()).data, [API, today]);
const wText = await widget.innerText();
report("Supervisor: widget total + overdue match the API", wText.includes(`${server.total} due`) && (server.overdue === 0 || wText.includes(`${server.overdue} overdue`)), { wText: wText.slice(0, 200), total: server.total, overdue: server.overdue });
report("Supervisor: per-type counts shown", Object.entries(server.by_type).filter(([, n]) => n > 0).every(([t, n]) => wText.includes(`${t}: ${n}`)));
report("Supervisor: lists up to 5 patients linking to their detail", (await widget.getByRole("link").count()) === Math.min(5, server.items.length));
await axe(sp, "Supervisor dashboard with follow-ups widget");
await sp.setViewportSize({ width: 360, height: 800 });
await sp.waitForTimeout(1500); // the trend chart animates its resize for ~1s
report("No horizontal scroll at 360px (dashboard)", await noHScroll(sp));
const chwRes = await sp.evaluate(async () => 0);
await sctx.close();

// CHW can't call the supervisor endpoint
const c2 = await browser.newContext();
const cp2 = await c2.newPage();
await login(cp2, "CHW002");
await cp2.waitForURL("**/chw");
const denied = await cp2.evaluate(async (API) => (await fetch(`${API}/patients/due`, { credentials: "include" })).status, API);
report("CHW calling GET /patients/due -> 403", denied === 403, denied);
await c2.close();

report("No page errors or console errors", errors.length === 0, errors.length ? errors.slice(0, 5) : undefined);
console.log(`\n${pass} passed, ${fail} failed (${STAMP})`);
await browser.close();
process.exit(fail ? 1 : 0);
