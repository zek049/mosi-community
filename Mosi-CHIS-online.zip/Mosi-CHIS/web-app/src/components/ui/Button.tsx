import type { ButtonHTMLAttributes } from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../lib/utils";

// Shared with any <Link> styled as a button (see asChild below) so
// navigation links and real <button> actions look identical, per section
// 22's "consistent buttons" requirement, without making a Link render as a
// <button> element (which would be the wrong semantics/a11y role).
export const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-forest-700/40 focus-visible:ring-offset-1",
  {
    variants: {
      variant: {
        primary: "bg-forest-800 text-white hover:bg-forest-900",
        secondary: "border border-stone-300 bg-white text-stone-700 hover:bg-stone-50",
        ghost: "text-stone-700 hover:bg-stone-100",
        danger: "bg-red-600 text-white hover:bg-red-700",
      },
      size: {
        sm: "h-8 px-3 text-xs",
        md: "h-10 px-4",
        lg: "h-12 px-6 text-base",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & {
    // Radix's Slot pattern (the same one shadcn/ui's Button uses): renders
    // this component's single child directly - with the button's classes
    // and other props merged onto it - instead of wrapping it in a
    // <button>. Lets a <Link> carry Button's exact visual styling while
    // staying a real <a>.
    asChild?: boolean;
  };

export function Button({ variant, size, className, asChild = false, ...props }: ButtonProps) {
  const Comp = asChild ? Slot : "button";
  return <Comp className={cn(buttonVariants({ variant, size }), className)} {...props} />;
}
