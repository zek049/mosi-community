import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, KeyRound } from "lucide-react";
import * as api from "../../services/api";
import { ApiError, type PinResetRequest } from "../../services/api";
import { formatDate } from "../../utils/formatDate";
import { generatePin, isValidPin } from "../../utils/validators";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { ModalDialog } from "../../components/ui/ModalDialog";
import { LoadErrorNotice } from "../../components/LoadErrorNotice";

function when(iso: string): string {
  return new Date(iso).toLocaleString(undefined, { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" });
}

// "Forgot PIN?" requests from CHWs. Completing one sets a TEMPORARY PIN: the
// CHW must choose a new one at their next sign-in (enforced by the server).
export function PinResetRequests() {
  const queryClient = useQueryClient();
  const pendingQuery = useQuery({ queryKey: ["pinResetRequests", "pending"], queryFn: () => api.getPinResetRequests("pending") });
  const completedQuery = useQuery({ queryKey: ["pinResetRequests", "completed"], queryFn: () => api.getPinResetRequests("completed") });
  // One controlled temporary-PIN input per pending request.
  const [pins, setPins] = useState<Record<string, string>>({});
  const [fieldError, setFieldError] = useState<Record<string, string>>({});
  const [confirming, setConfirming] = useState<PinResetRequest | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const doneRef = useRef<HTMLDivElement>(null);

  const complete = useMutation({
    mutationFn: (r: PinResetRequest) => api.completePinReset(r.id, pins[r.id]),
    onSuccess: (_d, r) => {
      setConfirming(null);
      setPins((p) => {
        const { [r.id]: _sent, ...rest } = p; // don't keep the PIN around
        return rest;
      });
      setDone(`Temporary PIN set for ${r.full_name} (${r.chw_id}). Tell them in person - they'll choose their own PIN when they sign in.`);
      void queryClient.invalidateQueries({ queryKey: ["pinResetRequests"] });
    },
  });

  useEffect(() => {
    if (done) doneRef.current?.focus();
  }, [done]);

  function ask(r: PinResetRequest) {
    const pin = pins[r.id] ?? "";
    if (!isValidPin(pin)) {
      setFieldError((e) => ({ ...e, [r.id]: "Enter a temporary PIN of exactly 4 digits, or generate one." }));
      document.getElementById(`temp-pin-${r.id}`)?.focus();
      return;
    }
    setFieldError((e) => ({ ...e, [r.id]: "" }));
    complete.reset();
    setConfirming(r);
  }

  const pending = pendingQuery.data;
  const completed = completedQuery.data;

  return (
    <section aria-labelledby="pin-requests-heading" className="space-y-3">
      <h2 id="pin-requests-heading" className="text-base font-semibold text-stone-900">
        Requests from CHWs{pending ? ` (${pending.length})` : ""}
      </h2>

      {done && (
        <div ref={doneRef} tabIndex={-1} role="status" className="flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 outline-none focus-visible:ring-2 focus-visible:ring-emerald-700">
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-800" aria-hidden="true" />
          <p className="text-sm text-emerald-900">{done}</p>
        </div>
      )}

      {pendingQuery.isError && <LoadErrorNotice error={pendingQuery.error} what="PIN reset requests" onRetry={() => void pendingQuery.refetch()} />}
      {pending && pending.length === 0 && <p className="text-sm text-stone-600">No CHW has asked for a PIN reset.</p>}

      {pending && pending.length > 0 && (
        <ul className="space-y-3">
          {pending.map((r) => (
            <li key={r.id}>
              <Card className="space-y-3">
                <div>
                  <p className="text-base font-semibold text-stone-900">{r.full_name}</p>
                  <p className="text-sm text-stone-600">
                    {r.chw_id} · {r.clinic} · asked {when(r.requested_at)}
                  </p>
                </div>
                <div className="flex flex-wrap items-end gap-2">
                  <div className="space-y-1.5">
                    <label htmlFor={`temp-pin-${r.id}`} className="block text-sm font-medium text-stone-700">
                      Temporary PIN
                    </label>
                    <input
                      id={`temp-pin-${r.id}`}
                      inputMode="numeric"
                      autoComplete="off"
                      maxLength={4}
                      value={pins[r.id] ?? ""}
                      onChange={(e) => setPins((p) => ({ ...p, [r.id]: e.target.value.replace(/\D/g, "").slice(0, 4) }))}
                      aria-invalid={fieldError[r.id] ? "true" : undefined}
                      aria-describedby={fieldError[r.id] ? `temp-pin-${r.id}-error` : undefined}
                      className="w-28 rounded-lg border border-stone-300 px-3 py-2.5 text-base tracking-[0.3em] focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700"
                    />
                  </div>
                  <Button type="button" variant="ghost" onClick={() => setPins((p) => ({ ...p, [r.id]: generatePin() }))}>
                    <KeyRound className="h-4 w-4" aria-hidden="true" />
                    Generate<span className="sr-only"> a temporary PIN for {r.full_name}</span>
                  </Button>
                  <Button type="button" onClick={() => ask(r)}>
                    Set temporary PIN<span className="sr-only"> for {r.full_name}</span>
                  </Button>
                </div>
                {fieldError[r.id] && (
                  <p id={`temp-pin-${r.id}-error`} className="text-sm text-red-700">
                    {fieldError[r.id]}
                  </p>
                )}
              </Card>
            </li>
          ))}
        </ul>
      )}

      {completed && completed.length > 0 && (
        <details className="rounded-xl border border-stone-200 bg-white px-4 py-3">
          <summary className="min-h-11 cursor-pointer py-2 text-sm font-medium text-stone-800">Recently completed ({completed.length})</summary>
          <ul className="mt-2 divide-y divide-stone-100">
            {completed.map((r) => (
              <li key={r.id} className="py-2 text-sm text-stone-700">
                {r.full_name} ({r.chw_id}) - temporary PIN set by {r.reviewed_by_name ?? "a supervisor"}
                {r.reviewed_at ? ` on ${formatDate(r.reviewed_at)}` : ""}
              </li>
            ))}
          </ul>
        </details>
      )}

      <ModalDialog
        open={confirming !== null}
        title={confirming ? `Set a temporary PIN for ${confirming.full_name}?` : ""}
        onClose={() => setConfirming(null)}
        busy={complete.isPending}
        actions={
          <>
            <Button type="button" variant="secondary" onClick={() => setConfirming(null)} disabled={complete.isPending}>
              Cancel
            </Button>
            <Button type="button" onClick={() => confirming && complete.mutate(confirming)} disabled={complete.isPending}>
              {complete.isPending ? "Saving…" : "Set temporary PIN"}
            </Button>
          </>
        }
      >
        {confirming && (
          <p>
            {confirming.full_name}'s current PIN stops working now. When they sign in with the temporary PIN, Mosi makes them
            choose a new one. Tell them the temporary PIN in person.
          </p>
        )}
        {complete.isError && (
          <p role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-red-800">
            {complete.error instanceof ApiError && complete.error.status < 500 ? complete.error.message : "Couldn't save. Check your connection and try again."}
          </p>
        )}
      </ModalDialog>
    </section>
  );
}
