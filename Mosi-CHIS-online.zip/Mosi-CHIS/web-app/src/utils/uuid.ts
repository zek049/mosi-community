// Wraps the Web Crypto API's UUID v4 generator - available in every modern
// browser (including on the phones CHWs would use in the field) and used
// the same way by backend/prisma/seed.ts, so there's exactly one UUID
// strategy across the whole system, not a separate npm dependency per side.
//
// crypto.randomUUID() requires a secure context (HTTPS, or localhost during
// development) - true for this app both in dev and once deployed as a PWA.
export function generateId(): string {
  return crypto.randomUUID();
}
