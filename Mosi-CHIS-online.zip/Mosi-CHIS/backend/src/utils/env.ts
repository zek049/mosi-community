import { logger } from "../logger";

// Fails fast at boot rather than the old behaviour of silently signing every
// token with a publicly-known fallback secret ("mosi-dev-secret-change-me")
// the first time someone logged in. A missing secret is now a startup error
// in every environment, not just production - there is no safe default for
// something that signs session tokens.
export function assertRequiredEnv(): void {
  const missing: string[] = [];

  if (!process.env.JWT_SECRET) {
    missing.push("JWT_SECRET");
  }

  if (missing.length > 0) {
    logger.fatal(
      { missing },
      `Missing required environment variable(s): ${missing.join(", ")}. ` +
        "Copy backend/.env.example to backend/.env and set them before starting the server.",
    );
    process.exit(1);
  }
}
