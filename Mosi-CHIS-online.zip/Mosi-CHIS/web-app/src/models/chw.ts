// Mirrors the shape returned by GET /api/chws exactly (see
// backend/src/routes/chws.ts) - pin_hash is never part of this type because
// the server never sends it. CHW/supervisor accounts are provisioned
// server-side, never created offline, so this is a read-only local cache
// populated by services/api.ts (Step 5) whenever the app is online.

/** ADMIN: organisation-wide; SUPERVISOR: one clinic (see backend middleware/authz.ts). */
export type Role = "CHW" | "SUPERVISOR" | "ADMIN";

export function isSupervisorRole(role: Role | undefined): boolean {
  return role === "SUPERVISOR" || role === "ADMIN";
}

export type AccountStatus = "active" | "revoked";

export interface Chw {
  id: number;
  chw_id: string;
  full_name: string;
  clinic: string;
  phone_number: string | null;
  role: Role;
  created_at: string;
  // Account lifecycle (backend MVP hardening) - optional since nothing
  // client-side reads these yet (a deactivated CHW is denied by the server
  // on every request regardless of what the frontend does or doesn't show).
  clinic_id?: string;
  status?: AccountStatus;
  last_login_at?: string | null;
}
