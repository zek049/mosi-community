import { describe, expect, it } from "vitest";
import { homeRouteForRole } from "../roleRoutes";

describe("homeRouteForRole", () => {
  it("sends a CHW to /chw", () => {
    expect(homeRouteForRole("CHW")).toBe("/chw");
  });

  it("sends a SUPERVISOR to /supervisor", () => {
    expect(homeRouteForRole("SUPERVISOR")).toBe("/supervisor");
  });
});

describe("administrator role", () => {
  it("an ADMIN lands on the supervisor dashboard (all clinics)", () => {
    expect(homeRouteForRole("ADMIN")).toBe("/supervisor");
  });
});
