/// <reference types="vite/client" />

interface ImportMetaEnv {
  // Base URL of the Mosi API. Optional - services/api.ts falls back to
  // http://localhost:4000/api when unset, so the app needs zero
  // configuration to start (see section 3 of the spec).
  readonly VITE_API_URL?: string;
  // Optional public contact for the landing page (see src/config/contact.ts).
  readonly VITE_PUBLIC_CONTACT_NAME?: string;
  readonly VITE_PUBLIC_CONTACT_EMAIL?: string;
  // "true" only for demo builds: lists the seeded demo accounts on Login.
  readonly VITE_SHOW_DEMO_ACCOUNTS?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
