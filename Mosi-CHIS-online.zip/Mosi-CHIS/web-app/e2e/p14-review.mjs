// Feature 4 - Review queue. Production build (:4173), real backend (:4000), real database.
// Creates P14-<stamp> test records (removed by cleanup.sql).
import { chromium } from "playwright";
import { readFileSync } from "node:fs";
import { execSync } from "node:child_process";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const STAMP = `P14-${String(Date.now()).slice(-6)}`;
const REASON = "Weight looks wrong - please re-measure";
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
async function axe(page, label) {
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}: ${x.nodes.map((n) => n.target.join(" ")).slice(0, 3).join(" | ")}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
function sql(q) {
  return execSync(`docker exec mosi-postgres psql -U mosi -d mosi -At -c "${q.replace(/"/g, '\\"')}"`).toString().trim();
}
function track(page, who, allow = []) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => { if (m.type() === "error" && !/ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(m.text()) && !allow.some((r) => r.test(m.text()))) errors.push(`${who}: ${m.text()}`); });
}
async function login(page, id) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => document.body.innerText.includes("Online"));
  await page.fill("#chwId", id); await page.fill("#pin", "1234"); await page.press("#pin", "Enter");
}
const noHScroll = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);
const local = (page, store, id) => page.evaluate(async ([store, id]) => {
  const db = await new Promise((res) => { const r = indexedDB.open("mosi-chis-user-CHW001"); r.onsuccess = () => res(r.result); });
  const row = await new Promise((res) => { const c = db.transaction(store).objectStore(store).get(id); c.onsuccess = () => res(c.result); });
  db.close();
  return row;
}, [store, id]);
const active = (page) => page.evaluate(() => ({ tag: document.activeElement?.tagName, text: (document.activeElement?.textContent || "").trim().slice(0, 60), id: document.activeElement?.id }));

// ---------- 0. Migration evidence (database) ----------
report("Migration 20261005130000_review_status recorded as finished", sql("select count(*) from _prisma_migrations where migration_name='20261005130000_review_status' and finished_at is not null and rolled_back_at is null") === "1");
const before = sql("select (select count(*) from patients where deleted_at is null)||','||(select count(*) from visits where deleted_at is null)||','||(select count(*) from patients where review_status<>'confirmed')||','||(select count(*) from visits where review_status<>'confirmed')");
report("Existing data intact and all confirmed: 75 patients, 184 visits, 0 not confirmed", before === "75,184,0,0", before);

const browser = await chromium.launch();

// ---------- 1. CHW: register a patient + record a visit offline, then sync ----------
const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, bypassCSP: true });
const page = await ctx.newPage();
track(page, "chw", [/status of 403/]); // the test itself checks a CHW gets 403
await login(page, "CHW001");
await page.waitForURL("**/chw");
await page.waitForTimeout(2000);
await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "domcontentloaded" });
await page.waitForSelector("h1:has-text('Add patient')");
await ctx.setOffline(true);
await page.waitForTimeout(1500);
await page.fill("#patient_id", `${STAMP}-A`); await page.fill("#first_name", "Rufaro"); await page.fill("#last_name", "Reviewtest");
await page.fill("#date_of_birth", "1994-05-06"); await page.check('input[name="gender"][value="F"]'); await page.fill("#village", "Mbare");
await page.click('button:has-text("Save patient")');
await page.waitForSelector("text=Patient registered", { timeout: 8000 });
const patientRow = await page.evaluate(async (pid) => {
  const db = await new Promise((res) => { const r = indexedDB.open("mosi-chis-user-CHW001"); r.onsuccess = () => res(r.result); });
  const rows = await new Promise((res) => { const c = db.transaction("patients").objectStore("patients").getAll(); c.onsuccess = () => res(c.result); });
  db.close();
  return rows.find((p) => p.patient_id === pid);
}, `${STAMP}-A`);
await page.evaluate((url) => { history.pushState({}, "", url); dispatchEvent(new PopStateEvent("popstate")); }, `/chw/visits/new?patient_id=${patientRow.id}`);
await page.waitForSelector('input[name="visit_type"]');
await page.check('input[name="visit_type"][value="Antenatal"]');
await page.click('button:has-text("Continue")');
await page.waitForSelector('h2:has-text("Measurements & notes")');
await page.fill("#weight", "95");
await page.fill("#notes", `${STAMP} review test`);
await page.click('button:has-text("Continue")');
await page.waitForSelector('h2:has-text("Review & save")');
await page.click('button:has-text("Save visit")');
await page.waitForSelector("text=Visit recorded", { timeout: 8000 });
const visitId = await page.evaluate(async (pid) => {
  const db = await new Promise((res) => { const r = indexedDB.open("mosi-chis-user-CHW001"); r.onsuccess = () => res(r.result); });
  const rows = await new Promise((res) => { const c = db.transaction("visits").objectStore("visits").getAll(); c.onsuccess = () => res(c.result); });
  db.close();
  return rows.find((v) => v.patient_id === pid)?.id;
}, patientRow.id);
await ctx.setOffline(false);
await page.waitForFunction(() => document.body.innerText.includes("Sent - awaiting supervisor review"), null, { timeout: 25000 }).catch(() => {});
report("After sync, the saved-visit status says 'Sent - awaiting supervisor review' (not 'synced'/'confirmed')", await page.isVisible("text=Sent - awaiting supervisor review"));
report("Dexie: patient + visit stored as synced, awaiting_review", (await local(page, "patients", patientRow.id))?.review_status === "awaiting_review" && (await local(page, "visits", visitId))?.review_status === "awaiting_review");
report("Database: new CHW records are awaiting_review", sql(`select review_status from patients where id='${patientRow.id}'`) === "awaiting_review" && sql(`select review_status from visits where id='${visitId}'`) === "awaiting_review");

await page.evaluate(() => { history.pushState({}, "", "/sync"); dispatchEvent(new PopStateEvent("popstate")); });
const awaitingTab = page.getByRole("tab", { name: /^Awaiting review \(\d+\)$/ });
await awaitingTab.waitFor({ timeout: 8000 });
await awaitingTab.click();
const awaitingPanel = await page.getByRole("tabpanel").innerText();
report("CHW Sync: 'Awaiting review' tab lists the new patient and visit", awaitingPanel.includes("Rufaro Reviewtest") && awaitingPanel.includes("Antenatal visit"), awaitingPanel.slice(0, 200));
await page.getByRole("tab", { name: /^Confirmed/ }).click();
report("CHW Sync: they are NOT under 'Confirmed'", !(await page.getByRole("tabpanel").innerText()).includes("Rufaro Reviewtest"));
const tabNames = await page.getByRole("tab").allInnerTexts();
report("CHW Sync: tabs distinguish Waiting / Couldn't sync / Conflict / Awaiting review / Confirmed / Flagged", ["Waiting", "Couldn't sync", "Conflict", "Awaiting review", "Confirmed", "Flagged"].every((t) => tabNames.some((n) => n.startsWith(t))), tabNames);
await page.waitForTimeout(400);
await axe(page, "CHW Sync screen with review buckets");
for (const w of [360, 400]) { await page.setViewportSize({ width: w, height: 800 }); report(`No horizontal scroll at ${w}px (CHW Sync)`, await noHScroll(page)); }
await page.setViewportSize({ width: 375, height: 812 });
const chwDenied = await page.evaluate(async (API) => (await fetch(`${API}/review/pending`, { credentials: "include" })).status, API);
report("CHW calling GET /api/review/pending -> 403", chwDenied === 403, chwDenied);

// ---------- 2. Supervisor: queue, flag, confirm ----------
const sctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
const sp = await sctx.newPage();
track(sp, "supervisor", [/status of 409/]); // the test itself checks 409s
await login(sp, "SUP001");
await sp.waitForURL("**/supervisor");
await sp.waitForSelector("#review-queue-heading");
await sp.waitForFunction(() => /Awaiting review \(\d+\)/.test(document.body.innerText), null, { timeout: 8000 });
const statsText = await sp.locator("main").innerText();
report("Dashboard: 'Confirmed patients' 75 and 'Confirmed visits' 184 - new records not counted yet", /75\s*\n?\s*Confirmed patients/.test(statsText) && /184\s*\n?\s*Confirmed visits/.test(statsText), statsText.match(/.{0,20}Confirmed (patients|visits)/g));
report("Attention panel: '2 records are awaiting review' (1 patient, 1 visit), shown separately", statsText.includes("2 records are awaiting review") && statsText.includes("1 patient, 1 visit"));
const queue = sp.locator("#review-queue");
const qText = await queue.innerText();
report("Queue: grouped under the CHW (Jane Moyo · CHW001 · 2 records)", /Jane Moyo · CHW001 · 2 records/.test(qText), qText.slice(0, 300));
report("Queue: one sync batch with both records ('Synced from the device ... 2 records in this sync')", /Synced from the device .* · 2 records in this sync/.test(qText));
report("Queue: details shown (patient ID, born, village; visit type, weight, notes) + submitted time", qText.includes(`${STAMP}-A`) && qText.includes("Mbare") && qText.includes("95 kg") && qText.includes(`${STAMP} review test`) && /Submitted \w+ \d/.test(qText), [`${STAMP}-A`, "Mbare", "95 kg", `${STAMP} review test`].map((x) => [x, qText.includes(x)]));
await axe(sp, "Dashboard with review queue");

// Jump from the Attention panel moves focus to the queue
await sp.click("text=Go to the review queue");
await sp.waitForTimeout(400);
report("'Go to the review queue' moves focus to the queue", (await active(sp)).id === "review-queue");

// Flag the visit: reason required, keyboard focus handled
const visitLabel = `Antenatal visit · Rufaro Reviewtest (visit)`;
await sp.getByRole("button", { name: `Flag: ${visitLabel}` }).click();
await sp.waitForTimeout(150);
report("Flag: reason box opens with focus in it", (await active(sp)).tag === "TEXTAREA");
await axe(sp, "Flag reason form open");
await sp.click('button:has-text("Flag record")');
report("Flag: empty reason refused with a clear message, nothing sent", await sp.isVisible("text=Say why you're flagging it"));
await sp.click('#review-queue button:has-text("Cancel")');
await sp.waitForTimeout(150);
report("Flag: Cancel returns focus to the Flag button", /Flag/.test((await active(sp)).text));
await sp.getByRole("button", { name: `Flag: ${visitLabel}` }).click();
await sp.keyboard.type(REASON);
await sp.click('button:has-text("Flag record")');
await sp.waitForSelector(`text=Flagged: ${visitLabel}`, { timeout: 8000 });
await sp.waitForTimeout(300);
report("Flag: confirmation announced and focused", (await active(sp)).text.startsWith("Flagged:"), await active(sp));
report("Database: visit flagged with reason, reviewer SUP001, review time set; updated_at unchanged", sql(`select review_status||'|'||review_flag_reason||'|'||reviewed_by||'|'||(reviewed_at is not null)||'|'||(updated_at=created_at) from visits where id='${visitId}'`) === `flagged|${REASON}|SUP001|true|true`, sql(`select review_status||'|'||reviewed_by from visits where id='${visitId}'`));

// Confirm the patient
await sp.getByRole("button", { name: `Confirm: Rufaro Reviewtest (patient)` }).click();
await sp.waitForSelector("text=Confirmed: Rufaro Reviewtest (patient).", { timeout: 8000 });
await sp.waitForTimeout(1000);
const statsAfter = await sp.locator("main").innerText();
report("After confirming: Confirmed patients 76; awaiting count gone", /76\s*\n?\s*Confirmed patients/.test(statsAfter) && !statsAfter.includes("awaiting review\n"), statsAfter.match(/.{0,10}Confirmed patients/g));
report("Attention panel now shows the flagged record to follow up", statsAfter.includes("1 flagged record to follow up"));
report("Queue empty message shown", statsAfter.includes("Nothing waiting for review."));
await sp.getByRole("tab", { name: /^Flagged \(1\)$/ }).click();
const flaggedText = await sp.getByRole("tabpanel").innerText();
report("Flagged tab: record, reason, who flagged it and when, the CHW", flaggedText.includes("Antenatal visit · Rufaro Reviewtest") && flaggedText.includes(`Reason: ${REASON}`) && /Flagged by Grace Chikwanha/.test(flaggedText) && flaggedText.includes("CHW: Jane Moyo"), flaggedText.slice(0, 300));
await sp.waitForTimeout(400);
await axe(sp, "Flagged tab");

// Invalid transitions through the API
const again = await sp.evaluate(async ([API, id]) => { const r = await fetch(`${API}/review/patients/${id}/confirm`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: "{}" }); return { status: r.status, body: await r.json() }; }, [API, patientRow.id]);
report("Confirming an already-confirmed patient -> 409 INVALID_REVIEW_TRANSITION", again.status === 409 && again.body.code === "INVALID_REVIEW_TRANSITION", again);
const reflag = await sp.evaluate(async ([API, id]) => (await fetch(`${API}/review/visits/${id}/flag`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ reason: "again" }) })).status, [API, visitId]);
report("Flagging an already-flagged visit -> 409", reflag === 409, reflag);

// ---------- 3. CHW sees the decisions ----------
await page.goto(`${BASE}/chw`, { waitUntil: "networkidle" }); // layout refresh pulls server state
await page.waitForTimeout(2500);
await page.goto(`${BASE}/sync`, { waitUntil: "networkidle" });
await page.getByRole("tab", { name: /^Flagged \(\d+\)$/ }).click();
const chwFlagged = await page.getByRole("tabpanel").innerText();
report("CHW Sync: visit under 'Flagged' with the supervisor's reason", chwFlagged.includes("Antenatal visit") && chwFlagged.includes(`Reason: ${REASON}`), chwFlagged.slice(0, 200));
await page.getByRole("tab", { name: /^Confirmed/ }).click();
report("CHW Sync: patient now under 'Confirmed'", (await page.getByRole("tabpanel").innerText()).includes("Rufaro Reviewtest"));
await page.waitForTimeout(400); // tab colours animate for 150ms after a click
await axe(page, "CHW Sync - Flagged tab");

// ---------- 4. CHW corrects the flagged visit (API - the app has no edit screen) ----------
const edit = await page.evaluate(async ([API, id]) => { const r = await fetch(`${API}/visits/${id}`, { method: "PUT", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ weight: 59 }) }); return r.status; }, [API, visitId]);
report("CHW edits the flagged visit (PUT /visits/:id) -> 200", edit === 200, edit);
report("Database: edited flagged visit -> awaiting_review, previous reason + reviewer kept", sql(`select review_status||'|'||review_flag_reason||'|'||reviewed_by from visits where id='${visitId}'`) === `awaiting_review|${REASON}|SUP001`);
await sp.reload({ waitUntil: "networkidle" });
await sp.waitForSelector("#review-queue-heading");
await sp.waitForFunction(() => /Awaiting review \(1\)/.test(document.body.innerText), null, { timeout: 8000 });
const q2 = await sp.locator("#review-queue").innerText();
report("Queue: the edit is back, marked 'Edited', shows 'Previously flagged' reason and new weight", q2.includes("Edited") && q2.includes(`Previously flagged`) && q2.includes(REASON) && q2.includes("59 kg"), q2.slice(0, 400));
report("Queue: entered online (not a sync) is labelled so", q2.includes("Entered online"));
await sp.getByRole("button", { name: `Confirm: ${visitLabel}` }).click();
await sp.waitForSelector(`text=Confirmed: ${visitLabel}.`, { timeout: 8000 });
report("Database: visit confirmed; reason history still stored", sql(`select review_status||'|'||review_flag_reason from visits where id='${visitId}'`) === `confirmed|${REASON}`);

// ---------- 5. Editing a CONFIRMED patient sends it back ----------
const pedit = await page.evaluate(async ([API, id]) => (await fetch(`${API}/patients/${id}`, { method: "PUT", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ village: "Epworth" }) })).status, [API, patientRow.id]);
report("Editing a confirmed patient -> awaiting_review (reviewer kept)", pedit === 200 && sql(`select review_status||'|'||reviewed_by from patients where id='${patientRow.id}'`) === "awaiting_review|SUP001");

// ---------- 6. Supervisor-created record is confirmed ----------
const supCreated = await sp.evaluate(async ([API, pid]) => {
  const id = crypto.randomUUID();
  const r = await fetch(`${API}/visits`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, patient_id: pid, chw_id: "CHW001", visit_date: "2026-10-05", visit_type: "Other", notes: "P14 supervisor visit" }) });
  return { status: r.status, id };
}, [API, patientRow.id]);
report("Supervisor-created visit is confirmed on creation", supCreated.status === 201 && sql(`select review_status||'|'||reviewed_by from visits where id='${supCreated.id}'`) === "confirmed|SUP001", supCreated);

await sp.setViewportSize({ width: 360, height: 800 });
await sp.waitForTimeout(1500); // the trend chart animates its resize for ~1s
report("No horizontal scroll at 360px (dashboard with review queue)", await noHScroll(sp), await sp.evaluate(() => [...document.querySelectorAll("body *")].filter((e) => e.getBoundingClientRect().right > window.innerWidth + 1).slice(0, 6).map((e) => `${e.tagName}.${(e.className || "").toString().slice(0, 60)} ${Math.round(e.getBoundingClientRect().right)} ${(e.textContent || "").slice(0, 30)}`)));

await sctx.close();
await ctx.close();
report("No page errors or console errors", errors.length === 0, errors.length ? errors.slice(0, 5) : undefined);
console.log(`\n${pass} passed, ${fail} failed (${STAMP})`);
await browser.close();
process.exit(fail ? 1 : 0);
