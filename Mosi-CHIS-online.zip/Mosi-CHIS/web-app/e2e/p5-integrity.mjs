// Final data-integrity review - production build (:4173), real backend.
import { chromium } from "playwright";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const STAMP = `P5-${Date.now()}`;
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
function track(page, who) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => {
    const t = m.text();
    if (m.type() === "warning" && /blocked/.test(t)) errors.push(`${who}: ${t}`);
    if (m.type() === "error" && !/ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(t)) errors.push(`${who}: ${t}`);
  });
}
async function login(page, id) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.fill("#chwId", id); await page.fill("#pin", "1234"); await page.press("#pin", "Enter");
  await page.waitForURL((u) => !u.pathname.startsWith("/login"), { timeout: 10000 });
  await page.waitForTimeout(1500);
}
async function signOut(page, choice) {
  if (await page.isVisible('aside button:has-text("Sign out")')) {
    await page.click('aside button:has-text("Sign out")');
  } else {
    await page.click('button[aria-label^="Account menu"]');
    await page.click('[role="menuitem"]:has-text("Sign out")');
  }
  if (choice) { await page.waitForSelector("dialog[open]"); await page.click(`dialog[open] button:has-text("${choice}")`); }
  await page.waitForURL("**/login");
  await page.waitForTimeout(400);
}
const dbNames = (page) => page.evaluate(async () => (await indexedDB.databases()).map((d) => d.name).sort());
const readDb = (page, name) => page.evaluate(async (name) => {
  if (!(await indexedDB.databases()).some((d) => d.name === name)) return null;
  const db = await new Promise((res) => { const r = indexedDB.open(name); r.onsuccess = () => res(r.result); });
  const all = async (store) => new Promise((res) => { const g = db.transaction(store).objectStore(store).getAll(); g.onsuccess = () => res(g.result); });
  const out = { patients: (await all("patients")).map((p) => `${p.first_name} ${p.last_name}:${p.sync_status}`).sort(), visits: (await all("visits")).map((v) => `${v.notes ?? v.id}:${v.sync_status}`).sort(), attempts: (await all("syncAttempts")).length, chws: (await all("chws")).length };
  db.close();
  return out;
}, name);
const apiGet = (page, path) => page.evaluate(async ({ API, path }) => { const r = await fetch(`${API}${path}`, { credentials: "include" }); const b = await r.json(); return Array.isArray(b.data) ? b.data : []; }, { API, path });
async function addPatientOffline(page, ctx, suffix, first, last) {
  await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "networkidle" });
  await ctx.setOffline(true);
  await page.fill("#patient_id", `${STAMP}-${suffix}`);
  await page.fill("#first_name", first); await page.fill("#last_name", last);
  await page.fill("#date_of_birth", "1990-05-05");
  await page.check('input[name="gender"][value="F"]');
  await page.fill("#village", "Mbare");
  await page.click('button:has-text("Save patient")');
  await page.waitForSelector("text=Patient registered");
  // ...and a visit for that patient, with a unique note
  await page.click("text=Record a visit for this patient");
  await page.waitForSelector('input[name="visit_type"]');
  await page.check('input[name="visit_type"][value="Other"]');
  await page.click('button:has-text("Continue")');
  await page.fill("#notes", `note-${suffix}`);
  await page.click('button:has-text("Continue")');
  await page.click('button:has-text("Save visit")');
  await page.waitForSelector("text=Visit recorded");
}
async function visibleInApp(page, name, note) {
  await page.goto(`${BASE}/patients`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector('input[type="search"]');
  await page.fill('input[type="search"]', name);
  await page.waitForTimeout(400);
  const patients = !(await page.locator("main").innerText()).includes("No patients match");
  await page.goto(`${BASE}/visits`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector("h1");
  await page.waitForTimeout(400);
  const visitsText = await page.locator("main").innerText();
  await page.goto(`${BASE}/sync`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector("text=Waiting (");
  const syncText = await page.locator("main").innerText();
  return { patients, visitsListed: visitsText.includes(name), queue: syncText.includes(name) || syncText.includes(note) };
}

const browser = await chromium.launch();

// ---------------------------------------------------------------------
// 1. LEGACY SHARED-DATABASE MIGRATION (real browser, real sign-ins)
// ---------------------------------------------------------------------
{
  // Real patient ids from the server for each CHW's clinic.
  const helper = await browser.newContext();
  const hp = await helper.newPage();
  await login(hp, "CHW001");
  const mbare = (await apiGet(hp, "/patients?search=MBR-0017"))[0];
  await signOut(hp);
  await login(hp, "CHW002");
  const hatcliffe = (await apiGet(hp, "/patients"))[0];
  await signOut(hp);
  await helper.close();

  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const page = await ctx.newPage();
  track(page, "legacy");
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  // Build the OLD shared database exactly as the previous app version did
  // (Dexie version 1 == IndexedDB version 10, same stores and indexes).
  await page.evaluate(({ STAMP, mbareId, hatId }) => new Promise((resolve, reject) => {
    const req = indexedDB.open("mosi-chis", 10);
    req.onupgradeneeded = () => {
      const db = req.result;
      const p = db.createObjectStore("patients", { keyPath: "id" }); ["patient_id", "village", "sync_status", "last_name"].forEach((i) => p.createIndex(i, i));
      const v = db.createObjectStore("visits", { keyPath: "id" }); ["patient_id", "chw_id", "visit_date", "visit_type", "sync_status"].forEach((i) => v.createIndex(i, i));
      const c = db.createObjectStore("chws", { keyPath: "chw_id" }); c.createIndex("role", "role");
      const s = db.createObjectStore("syncAttempts", { keyPath: "id" }); ["record_type", "status"].forEach((i) => s.createIndex(i, i));
    };
    req.onsuccess = () => {
      const db = req.result;
      const now = new Date().toISOString();
      const tx = db.transaction(["patients", "visits"], "readwrite");
      const orphanId = crypto.randomUUID();
      tx.objectStore("patients").put({ id: orphanId, patient_id: `${STAMP}-ORPHAN`, first_name: "Legacy", last_name: "Ownerless", date_of_birth: "1980-01-01", gender: "F", village: "Mbare", phone_number: null, created_at: now, updated_at: now, sync_status: "pending" });
      const visit = (chw, pid, note) => ({ id: crypto.randomUUID(), patient_id: pid, chw_id: chw, visit_date: now.slice(0, 10), visit_type: "Other", weight: null, height: null, blood_pressure: null, notes: note, created_at: now, updated_at: now, sync_status: "pending" });
      tx.objectStore("visits").put(visit("CHW001", mbareId, `${STAMP} legacy A`));
      tx.objectStore("visits").put(visit("CHW002", hatId, `${STAMP} legacy B`));
      tx.objectStore("visits").put(visit("CHW001", orphanId, `${STAMP} legacy A for ownerless`));
      tx.oncomplete = () => { db.close(); resolve(); };
      tx.onerror = () => reject(tx.error);
    };
    req.onerror = () => reject(req.error);
  }), { STAMP, mbareId: mbare.id, hatId: hatcliffe.id });
  report("Legacy: old shared database seeded (1 ownerless patient, 3 unsynced visits)", (await dbNames(page)).includes("mosi-chis"));

  // CHW002 signs in FIRST.
  await login(page, "CHW002");
  await page.goto(`${BASE}/sync`, { waitUntil: "networkidle" });
  await page.waitForSelector("text=Everything is up to date", { timeout: 15000 }).catch(() => {});
  let b = await readDb(page, "mosi-chis-user-CHW002");
  report("Legacy: first user (CHW002) did NOT receive the ownerless patient", !b.patients.some((p) => /Ownerless/.test(p)), b.patients.filter((p) => /Legacy/.test(p)));
  report("Legacy: CHW002 received only CHW002's visit, and it synced", b.visits.some((v) => v.includes(`${STAMP} legacy B:synced`)) && !b.visits.some((v) => v.includes("legacy A")), b.visits.filter((v) => v.includes(STAMP)));
  report("Legacy: Sync screen discloses 3 older unassigned records still held", await page.isVisible("text=This device also holds 3 older unsynced records"));
  await signOut(page);

  // CHW001 signs in SECOND.
  await login(page, "CHW001");
  await page.goto(`${BASE}/sync`, { waitUntil: "networkidle" });
  await page.waitForSelector("text=Everything is up to date", { timeout: 15000 }).catch(() => {});
  const a = await readDb(page, "mosi-chis-user-CHW001");
  report("Legacy: CHW001 received only its own visit on a known patient, and it synced", a.visits.some((v) => v.includes(`${STAMP} legacy A:synced`)) && !a.visits.some((v) => v.includes("legacy B") || v.includes("for ownerless")), a.visits.filter((v) => v.includes(STAMP)));
  report("Legacy: ownerless patient NOT given to the second user either", !a.patients.some((p) => /Ownerless/.test(p)));
  const onServer = await apiGet(page, `/patients?search=${STAMP}-ORPHAN`);
  report("Legacy: ownerless patient was never synced under anyone's account", onServer.length === 0);
  const held = await readDb(page, "mosi-chis");
  report("Legacy: ownerless patient + its dependent visit kept (not deleted), unassigned", held && held.patients.length === 1 && held.visits.length === 1 && /for ownerless:pending/.test(held.visits[0]), held);
  report("Legacy: remaining count disclosed (2)", await page.isVisible("text=This device also holds 2 older unsynced records"));
  await signOut(page);
  await ctx.close();
}

// ---------------------------------------------------------------------
// 2. DEVICE ISOLATION, BOTH DIRECTIONS (offline patient + visit each)
// ---------------------------------------------------------------------
{
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const page = await ctx.newPage();
  track(page, "isolation");

  await login(page, "CHW001");
  await addPatientOffline(page, ctx, "A", "Alpha", "Isolatea");
  await signOut(page, "Sign out, keep them here");
  await ctx.setOffline(false);
  const lsAfterA = await page.evaluate(() => Object.keys(localStorage).sort());
  report("Isolation: after A signs out, no session/user keys left in localStorage", !lsAfterA.some((k) => /session|lastSync/.test(k)), lsAfterA);

  await login(page, "CHW002");
  let seen = await visibleInApp(page, "Alpha Isolatea", "note-A");
  report("Isolation A->B: B cannot see A's patient, visit, or queued changes", !seen.patients && !seen.visitsListed && !seen.queue, seen);
  let bDb = await readDb(page, "mosi-chis-user-CHW002");
  report("Isolation A->B: nothing of A's in B's IndexedDB", !JSON.stringify(bDb).includes("Isolatea") && !JSON.stringify(bDb).includes("note-A"));
  report("Isolation A->B: A's pending data still intact in A's own database", JSON.stringify(await readDb(page, "mosi-chis-user-CHW001")).includes("Alpha Isolatea:pending"));
  await addPatientOffline(page, ctx, "B", "Bravo", "Isolateb");
  await signOut(page, "Sign out, keep them here");
  await ctx.setOffline(false);

  await login(page, "CHW001");
  seen = await visibleInApp(page, "Bravo Isolateb", "note-B");
  report("Isolation B->A: A cannot see B's patient, visit, or queued changes", !seen.patients && !seen.visitsListed && !seen.queue, seen);
  await page.goto(`${BASE}/sync`, { waitUntil: "networkidle" });
  await page.waitForSelector("text=Everything is up to date", { timeout: 20000 }).catch(() => {});
  const aDb = await readDb(page, "mosi-chis-user-CHW001");
  report("Isolation B->A: A's own kept changes synced on return; nothing of B's", JSON.stringify(aDb).includes("Alpha Isolatea:synced") && !JSON.stringify(aDb).includes("Isolateb"));
  report("Isolation: B's pending changes untouched by A's sync", JSON.stringify(await readDb(page, "mosi-chis-user-CHW002")).includes("Bravo Isolateb:pending"));
  const bOnServer = await apiGet(page, `/patients?search=${STAMP}-B`);
  report("Isolation: B's record was not uploaded under A's session", bOnServer.length === 0);
  await signOut(page);
  await login(page, "CHW002");
  await page.goto(`${BASE}/sync`, { waitUntil: "networkidle" });
  const bSynced = await page.waitForSelector("text=Everything is up to date", { timeout: 20000 }).then(() => true).catch(() => false);
  report("Isolation: B's kept changes sync when B returns", bSynced && JSON.stringify(await readDb(page, "mosi-chis-user-CHW002")).includes("Bravo Isolateb:synced"));
  await signOut(page);

  // Cached API data: supervisor data must not survive into the next session (same tab, no reload).
  await login(page, "SUP001");
  await page.goto(`${BASE}/supervisor`, { waitUntil: "networkidle" });
  const supDb = await readDb(page, "mosi-chis-user-SUP001");
  report("Isolation: supervisor has its own database with cached data while signed in", supDb && supDb.patients.length > 0, supDb && supDb.patients.length);
  await signOut(page);
  report("Isolation: supervisor's cached data removed on sign-out", !(await dbNames(page)).includes("mosi-chis-user-SUP001"), await dbNames(page));
  await login(page, "CHW001");
  const requests = [];
  page.on("request", (r) => { if (r.url().includes("/api/dashboard") || r.url().includes("/api/conflicts")) requests.push(r.url()); });
  report("Isolation: CHW sees no supervisor screens/data after supervisor signed out", !(await page.locator("body").innerText()).match(/Active CHWs|Needs your attention|Open conflicts/));
  await signOut(page);
  await ctx.close();
}

// ---------------------------------------------------------------------
// 3. DEVICE WIPE - local only, server untouched
// ---------------------------------------------------------------------
{
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 } });
  const page = await ctx.newPage();
  track(page, "wipe");
  await login(page, "CHW001");
  // One record that reaches the server...
  await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "networkidle" });
  await page.fill("#patient_id", `${STAMP}-W1`); await page.fill("#first_name", "Wipe"); await page.fill("#last_name", "Synced");
  await page.fill("#date_of_birth", "1990-05-05"); await page.check('input[name="gender"][value="M"]'); await page.fill("#village", "Mbare");
  await page.click('button:has-text("Save patient")');
  await page.waitForSelector("text=Sent - awaiting supervisor review", { timeout: 15000 }); // on the server (review queue wording)
  // ...and one that doesn't.
  await addPatientOffline(page, ctx, "W2", "Wipe", "Unsynced");
  await page.goto(`${BASE}/sync`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector("text=Remove my data from this device");
  const before = await readDb(page, "mosi-chis-user-CHW001");
  report("Wipe: before - local DB holds patients, visits, pending records, sync metadata, CHW list", before.patients.length > 1 && before.visits.length > 0 && before.chws > 0 && JSON.stringify(before).includes(":pending"), { patients: before.patients.length, visits: before.visits.length, chws: before.chws });
  await page.click('button:has-text("Remove my data from this device")');
  await page.check('dialog[open] input[type="checkbox"]');
  await page.click('dialog[open] button:has-text("Remove and sign out")');
  await page.waitForURL("**/login");
  await page.waitForTimeout(500);
  report("Wipe: account's local database removed entirely", !(await dbNames(page)).includes("mosi-chis-user-CHW001"), await dbNames(page));
  const ls = await page.evaluate(() => Object.keys(localStorage).sort());
  report("Wipe: session + per-user sync metadata removed from localStorage", !ls.some((k) => /session|lastSync/.test(k)), ls);
  await ctx.setOffline(false);
  for (const path of ["/chw", "/patients", "/sync"]) {
    await page.goto(`${BASE}${path}`, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(400);
    report(`Wipe: ${path} requires sign-in again`, new URL(page.url()).pathname === "/login");
  }
  await login(page, "CHW001");
  const serverSide = await apiGet(page, `/patients?search=${STAMP}-W1`);
  report("Wipe: the synced record is still on the server (wipe is local only)", serverSide.length === 1);
  report("Wipe: the unsynced record never reached the server (lost, as the user confirmed)", (await apiGet(page, `/patients?search=${STAMP}-W2`)).length === 0);
  await signOut(page);
  await ctx.close();
}

// ---------------------------------------------------------------------
// 4. DEMO CREDENTIALS NOT ADVERTISED IN A PRODUCTION BUILD
// ---------------------------------------------------------------------
{
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  const text = await page.locator("body").innerText();
  report("Demo creds: production build's Login screen does not list demo accounts or 'PIN 1234'", !/PIN 1234|Demo accounts/i.test(text));
  await ctx.close();
}

await browser.close();
console.log(`\nConsole/page errors (incl. blocked-delete warnings): ${errors.length}`); errors.forEach((e) => console.log("  ", e));
console.log(`${pass} passed, ${fail} failed. TEST_STAMP=${STAMP}`);
