import type { Gender } from "../models/patient";
import { VISIT_TYPES, type VisitType } from "../models/visit";

// Mirrors backend/src/services/validation.ts's rules by hand. They have to
// live in two places: the server must never trust client input, and the
// client must be able to validate a form with no network at all (that's the
// whole point of section 13's offline-first Add Patient flow) - there's no
// shared package between the two separate npm projects in this structure to
// hang a single copy off of. Keep the two in sync if a rule changes.

const PHONE_PATTERN = /^0\d{9}$/;
const BLOOD_PRESSURE_PATTERN = /^\d{2,3}\/\d{2,3}$/;
const PIN_PATTERN = /^\d{4}$/;

export function isValidPin(value: string): boolean {
  return PIN_PATTERN.test(value);
}

export function isValidGender(value: string): value is Gender {
  return value === "M" || value === "F";
}

export function isValidVisitType(value: string): value is VisitType {
  return (VISIT_TYPES as readonly string[]).includes(value);
}

export function isValidDateString(value: string): boolean {
  return value.trim() !== "" && !Number.isNaN(new Date(value).getTime());
}

export function isValidPhoneNumber(value: string): boolean {
  return PHONE_PATTERN.test(value);
}

export function isValidBloodPressure(value: string): boolean {
  return BLOOD_PRESSURE_PATTERN.test(value);
}

export type PatientFormInput = {
  patient_id: string;
  first_name: string;
  last_name: string;
  date_of_birth: string;
  gender: string;
  village: string;
  phone_number: string;
};

export type FormErrors = Record<string, string>;

export function validatePatientForm(input: PatientFormInput): FormErrors {
  const errors: FormErrors = {};

  if (!input.patient_id.trim()) errors.patient_id = "Enter the patient ID.";
  if (!input.first_name.trim()) errors.first_name = "Enter the first name.";
  if (!input.last_name.trim()) errors.last_name = "Enter the last name.";
  if (!input.village.trim()) errors.village = "Enter the village.";

  if (!isValidGender(input.gender)) {
    errors.gender = "Choose female or male.";
  }

  if (!isValidDateString(input.date_of_birth)) {
    errors.date_of_birth = "Enter the date of birth.";
  } else if (new Date(input.date_of_birth).getTime() > Date.now()) {
    errors.date_of_birth = "Date of birth cannot be in the future";
  }

  const phone = input.phone_number.trim();
  if (phone && !isValidPhoneNumber(phone)) {
    errors.phone_number = "Enter 10 digits starting with 0, for example 0771234567 - or leave it empty.";
  }

  return errors;
}

export type VisitFormInput = {
  patient_id: string;
  chw_id: string;
  visit_date: string;
  visit_type: string;
  weight: string;
  height: string;
  blood_pressure: string;
  notes: string;
};

const ONE_DAY_MS = 24 * 60 * 60 * 1000;

export function validateVisitForm(input: VisitFormInput): FormErrors {
  const errors: FormErrors = {};

  if (!input.patient_id.trim()) errors.patient_id = "Choose the patient this visit is for.";
  if (!input.chw_id.trim()) errors.chw_id = "CHW is required";

  if (!isValidDateString(input.visit_date)) {
    errors.visit_date = "Enter the date of the visit.";
  } else if (new Date(input.visit_date).getTime() > Date.now() + ONE_DAY_MS) {
    errors.visit_date = "The visit date can't be in the future - use today's date or earlier.";
  }

  if (!isValidVisitType(input.visit_type)) {
    errors.visit_type = "Choose the type of visit.";
  }

  const weight = input.weight.trim();
  if (weight) {
    const value = Number(weight);
    if (!Number.isFinite(value) || value <= 0 || value > 300) {
      errors.weight = "Enter weight in kilograms, between 0 and 300 - for example 62.5.";
    }
  }

  const height = input.height.trim();
  if (height) {
    const value = Number(height);
    if (!Number.isFinite(value) || value <= 0 || value > 250) {
      errors.height = "Enter height in centimetres, between 0 and 250 - for example 160.";
    }
  }

  const bloodPressure = input.blood_pressure.trim();
  if (bloodPressure && !isValidBloodPressure(bloodPressure)) {
    errors.blood_pressure = "Enter blood pressure as two numbers of 2-3 digits, for example 120 and 80.";
  }

  return errors;
}

export type PinResetErrors = { pin?: string; confirm?: string };

// Same rule the server enforces for PATCH /api/chws/:chwId (exactly 4
// digits); the confirmation just catches a typo before it locks someone out.
export function validatePinReset(pin: string, confirm: string): PinResetErrors {
  const errors: PinResetErrors = {};
  if (!isValidPin(pin)) errors.pin = "Enter a new PIN of exactly 4 digits.";
  else if (confirm !== pin) errors.confirm = "The two PINs don't match. Type the new PIN again.";
  return errors;
}

// A random 4-digit PIN from the browser's cryptographic generator (never
// Math.random), with leading zeros kept.
export function generatePin(random: (buffer: Uint32Array) => Uint32Array = (b) => crypto.getRandomValues(b)): string {
  const [value] = random(new Uint32Array(1));
  return String(value % 10000).padStart(4, "0");
}

// Mirrors backend/src/utils/pinPolicy.ts (NIST 800-63B: no commonly used
// values for PINs people choose themselves).
const COMMON_PINS = new Set(["1234", "4321", "1212", "1122", "2580", "0852", "6969", "1004", "2000", "2001", "1010", "7777", "1313", "5683"]);

export function isWeakPin(pin: string): boolean {
  if (!/^\d{4}$/.test(pin)) return false;
  if (/^(\d)\1{3}$/.test(pin)) return true;
  const digits = [...pin].map(Number);
  const steps = digits.slice(1).map((d, i) => d - digits[i]);
  if (steps.every((s) => s === 1) || steps.every((s) => s === -1)) return true;
  return COMMON_PINS.has(pin);
}

export const WEAK_PIN_MESSAGE = "That PIN is too easy to guess (like 1234, 0000 or 2580). Choose a less obvious one.";

export type ChangePinErrors = { current?: string; pin?: string; confirm?: string };

export function validateChangePin(current: string, pin: string, confirm: string): ChangePinErrors {
  const errors: ChangePinErrors = {};
  if (!isValidPin(current)) errors.current = "Enter your current 4-digit PIN.";
  if (!isValidPin(pin)) errors.pin = "Choose a new PIN of exactly 4 digits.";
  else if (pin === current) errors.pin = "Choose a PIN that's different from the current one.";
  else if (isWeakPin(pin)) errors.pin = WEAK_PIN_MESSAGE;
  else if (confirm !== pin) errors.confirm = "The two PINs don't match. Type the new PIN again.";
  return errors;
}

export type AccountRequestForm = { full_name: string; chw_id: string; clinic_id: string; phone_number: string; pin: string; confirm: string };
export type AccountRequestErrors = Partial<Record<keyof AccountRequestForm, string>>;

// Mirrors the server's accountRequestSchema (backend/src/validation/schemas.ts).
export function validateAccountRequest(form: AccountRequestForm): AccountRequestErrors {
  const errors: AccountRequestErrors = {};
  if (form.full_name.trim().length < 2) errors.full_name = "Enter your full name.";
  const id = form.chw_id.trim();
  if (id.length < 3 || id.length > 20 || !/^[A-Za-z0-9_-]+$/.test(id)) {
    errors.chw_id = "Use 3-20 letters, numbers, hyphens or underscores, for example CHW005.";
  }
  if (!form.clinic_id) errors.clinic_id = "Choose your clinic.";
  if (form.phone_number.trim() && !isValidPhoneNumber(form.phone_number.trim())) {
    errors.phone_number = "Enter 10 digits starting with 0, for example 0771234567 - or leave it empty.";
  }
  const pinErrors = validatePinReset(form.pin, form.confirm);
  if (pinErrors.pin) errors.pin = "Choose a PIN of exactly 4 digits.";
  else if (isWeakPin(form.pin)) errors.pin = WEAK_PIN_MESSAGE;
  if (pinErrors.confirm) errors.confirm = pinErrors.confirm;
  return errors;
}
