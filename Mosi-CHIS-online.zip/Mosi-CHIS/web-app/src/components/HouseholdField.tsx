import { useId, useMemo, useState } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { RefreshCw, Search } from "lucide-react";
import { db } from "../db/indexedDb";
import { generateHouseholdCode } from "../utils/householdCode";
import { normalizeForMatch } from "../utils/findPossibleDuplicates";
import { cn } from "../lib/utils";

export type HouseholdChoice = { kind: "none" } | { kind: "existing"; id: string } | { kind: "new"; code: string };

const MAX_SHOWN = 6;

const optionClass = (selected: boolean) =>
  cn(
    "flex min-h-11 cursor-pointer items-center gap-2.5 rounded-lg border px-3 py-2 text-sm has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-forest-700/40",
    selected ? "border-forest-700 bg-sage-50 font-medium text-forest-900" : "border-stone-300 text-stone-700 hover:bg-stone-50",
  );

// Optional household for a patient being registered. Works fully offline:
// existing households come from this device; a new one gets a code made on
// the device and is created together with the patient, then synced.
export function HouseholdField({
  village,
  value,
  onChange,
  error,
}: {
  village: string;
  value: HouseholdChoice;
  onChange: (choice: HouseholdChoice) => void;
  error?: string;
}) {
  const groupName = useId();
  const searchId = useId();
  const [query, setQuery] = useState("");

  const households = useLiveQuery(async () => {
    const [all, patients] = await Promise.all([db.households.toArray(), db.patients.toArray()]);
    const counts = new Map<string, number>();
    for (const p of patients) if (p.household_id && !p.deleted_at) counts.set(p.household_id, (counts.get(p.household_id) ?? 0) + 1);
    return all.map((h) => ({ ...h, members: counts.get(h.id) ?? 0 }));
  }, []);

  // Same village first, then by code; filtered by what's typed.
  const matches = useMemo(() => {
    const q = normalizeForMatch(query);
    const v = normalizeForMatch(village);
    return (households ?? [])
      .filter((h) => !q || normalizeForMatch(`${h.household_code} ${h.village}`).includes(q))
      .sort((a, b) => Number(normalizeForMatch(b.village) === v) - Number(normalizeForMatch(a.village) === v) || a.household_code.localeCompare(b.household_code));
  }, [households, query, village]);

  return (
    <fieldset aria-describedby={error ? `${groupName}-error` : undefined} className="space-y-2">
      <legend className="text-sm font-medium text-stone-700">Household (optional)</legend>
      <div className="grid gap-2 sm:grid-cols-3">
        <label className={optionClass(value.kind === "none")}>
          <input type="radio" name={groupName} checked={value.kind === "none"} onChange={() => onChange({ kind: "none" })} className="h-4 w-4 accent-forest-800" />
          No household
        </label>
        <label className={optionClass(value.kind === "existing")}>
          <input
            type="radio"
            name={groupName}
            checked={value.kind === "existing"}
            onChange={() => onChange({ kind: "existing", id: "" })}
            className="h-4 w-4 accent-forest-800"
          />
          Existing household
        </label>
        <label className={optionClass(value.kind === "new")}>
          <input
            type="radio"
            name={groupName}
            checked={value.kind === "new"}
            onChange={() => onChange({ kind: "new", code: generateHouseholdCode(village || "HH") })}
            className="h-4 w-4 accent-forest-800"
          />
          New household
        </label>
      </div>

      {value.kind === "existing" && (
        <div className="space-y-2 rounded-lg border border-stone-200 p-3">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-500" aria-hidden="true" />
            <label htmlFor={searchId} className="sr-only">
              Search households by code or village
            </label>
            <input
              id={searchId}
              type="search"
              placeholder="Household code or village"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full rounded-lg border border-stone-300 py-2.5 pl-9 pr-3 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700"
            />
          </div>
          {households && matches.length === 0 && (
            <p className="text-sm text-stone-600">No household matches. Choose "New household" to create one.</p>
          )}
          <div role="radiogroup" aria-label="Households" className="space-y-1.5">
            {matches.slice(0, MAX_SHOWN).map((h) => (
              <label key={h.id} className={optionClass(value.id === h.id)}>
                <input
                  type="radio"
                  name={`${groupName}-existing`}
                  checked={value.id === h.id}
                  onChange={() => onChange({ kind: "existing", id: h.id })}
                  className="h-4 w-4 accent-forest-800"
                />
                <span>
                  <span className="font-medium">{h.household_code}</span>
                  <span className="text-stone-600">
                    {" "}
                    · {h.village} · {h.members} {h.members === 1 ? "member" : "members"}
                  </span>
                </span>
              </label>
            ))}
          </div>
          {matches.length > MAX_SHOWN && <p className="text-xs text-stone-500">Showing {MAX_SHOWN} of {matches.length} - type to narrow it down.</p>}
        </div>
      )}

      {value.kind === "new" && (
        <div className="flex flex-wrap items-center gap-3 rounded-lg border border-stone-200 p-3 text-sm">
          <p>
            New household code: <span className="font-semibold tracking-wide text-stone-900">{value.code}</span>
            <span className="block text-xs text-stone-600">Created with this patient{village.trim() ? ` in ${village.trim()}` : ""}. Write the code down for the family.</span>
          </p>
          <button
            type="button"
            onClick={() => onChange({ kind: "new", code: generateHouseholdCode(village || "HH") })}
            className="inline-flex min-h-11 items-center gap-1.5 rounded-lg px-2 font-medium text-forest-800 underline underline-offset-2"
          >
            <RefreshCw className="h-4 w-4" aria-hidden="true" />
            New code
          </button>
        </div>
      )}

      {error && (
        <p id={`${groupName}-error`} className="text-sm text-red-700">
          {error}
        </p>
      )}
    </fieldset>
  );
}
