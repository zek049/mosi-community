-- CreateEnum
CREATE TYPE "AccountRequestStatus" AS ENUM ('pending', 'approved', 'rejected');

-- CreateTable
CREATE TABLE "account_requests" (
    "id" TEXT NOT NULL,
    "full_name" TEXT NOT NULL,
    "requested_chw_id" TEXT NOT NULL,
    "clinic_id" TEXT NOT NULL,
    "phone_number" TEXT,
    "pin_hash" TEXT,
    "status" "AccountRequestStatus" NOT NULL DEFAULT 'pending',
    "requested_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reviewed_at" TIMESTAMP(3),
    "reviewed_by" TEXT,

    CONSTRAINT "account_requests_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "account_requests_status_idx" ON "account_requests"("status");

-- CreateIndex
CREATE INDEX "account_requests_clinic_id_idx" ON "account_requests"("clinic_id");

-- CreateIndex
CREATE INDEX "account_requests_requested_chw_id_idx" ON "account_requests"("requested_chw_id");

-- AddForeignKey
ALTER TABLE "account_requests" ADD CONSTRAINT "account_requests_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

