import { Router } from "express";
import { prisma } from "../db";
import { syncHousehold, syncPatient, syncVisit, type SyncRecordResult } from "../services/syncService";
import { parseBody, syncBatchSchema } from "../validation/schemas";
import { writeAuditLog, writeAuditLogs, type AuditAction } from "../utils/audit";
import { clinicScope } from "../middleware/authz";
import { syncLogIdsInClinic } from "../utils/recordScope";

const router = Router();

router.post("/", async (req, res) => {
  const body = parseBody(syncBatchSchema, req.body ?? {});
  const patients = body.patients as Record<string, unknown>[];
  const visits = body.visits as Record<string, unknown>[];
  const households = body.households as Record<string, unknown>[];
  const actor = req.user!;

  await writeAuditLog({
    actor,
    action: "SYNC_STARTED",
    requestId: req.requestId,
    metadata: { households: households.length, patients: patients.length, visits: visits.length, batch_id: body.batch_id, device_id: body.device_id },
  });

  // Processed sequentially (not in parallel) so two records sharing the same
  // patient_id in one batch can't both pass the uniqueness check at once.
  // Households first, so patients created offline can point at households
  // created offline in the same batch.
  const householdResults: SyncRecordResult[] = [];
  for (const household of households) {
    householdResults.push(await syncHousehold(household, actor));
  }

  const patientResults: SyncRecordResult[] = [];
  for (const patient of patients) {
    patientResults.push(await syncPatient(patient, actor));
  }

  const visitResults: SyncRecordResult[] = [];
  for (const visit of visits) {
    visitResults.push(await syncVisit(visit, actor));
  }

  // One entry per patient/visit this batch actually created or changed, tied
  // to the batch by request_id (the SYNC_STARTED entry above has the same
  // one). The review queue reads these for "submitted by / when / in which
  // sync" - sync_log alone doesn't record who sent a record.
  const submitted = (results: SyncRecordResult[], type: "patient" | "visit") =>
    results
      .filter((r) => r.status === "synced" && (r.reason === "created" || r.reason === "updated"))
      .map((r) => ({
        actor,
        action: `${type.toUpperCase()}_${r.reason === "created" ? "CREATED" : "UPDATED"}` as AuditAction,
        resourceType: type,
        resourceId: r.id,
        requestId: req.requestId,
        metadata: { via: "sync" },
      }));
  await writeAuditLogs([...submitted(patientResults, "patient"), ...submitted(visitResults, "visit")]);

  await writeAuditLog({
    actor,
    action: "SYNC_COMPLETED",
    requestId: req.requestId,
    metadata: {
      synced: [...householdResults, ...patientResults, ...visitResults].filter((r) => r.status === "synced").length,
      conflicts: [...householdResults, ...patientResults, ...visitResults].filter((r) => r.status === "conflict").length,
      failed: [...householdResults, ...patientResults, ...visitResults].filter((r) => r.status === "failed").length,
    },
  });

  res.json({
    success: true,
    data: { households: householdResults, patients: patientResults, visits: visitResults },
  });
});

router.get("/log", async (req, res) => {
  const limitParam = Number(req.query.limit);
  const limit = Number.isFinite(limitParam) && limitParam > 0 ? Math.min(limitParam, 500) : 100;

  // Only entries about records in the caller's clinic (administrators: all).
  const scope = clinicScope(req.user!);
  const entries = await prisma.syncLog.findMany({
    where: scope ? { id: { in: await syncLogIdsInClinic(scope, limit) } } : {},
    orderBy: { synced_at: "desc" },
    take: limit,
  });

  res.json({ success: true, data: entries });
});

export default router;
