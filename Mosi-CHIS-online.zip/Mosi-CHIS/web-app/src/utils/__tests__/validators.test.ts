import { describe, expect, it } from "vitest";
import {
  isValidBloodPressure,
  isValidPhoneNumber,
  isValidPin,
  isValidVisitType,
  validatePatientForm,
  validateVisitForm,
  type PatientFormInput,
  type VisitFormInput,
} from "../validators";

describe("isValidPin", () => {
  it("accepts exactly 4 digits", () => {
    expect(isValidPin("1234")).toBe(true);
  });

  it.each(["123", "12345", "12a4", ""])("rejects %j", (value) => {
    expect(isValidPin(value)).toBe(false);
  });
});

describe("isValidPhoneNumber", () => {
  it("accepts a 10-digit number starting with 0", () => {
    expect(isValidPhoneNumber("0771234567")).toBe(true);
  });

  it("rejects a number not starting with 0", () => {
    expect(isValidPhoneNumber("1771234567")).toBe(false);
  });

  it("rejects the wrong length", () => {
    expect(isValidPhoneNumber("077123")).toBe(false);
  });
});

describe("isValidBloodPressure", () => {
  it("accepts systolic/diastolic format", () => {
    expect(isValidBloodPressure("120/80")).toBe(true);
  });

  it("rejects a missing slash", () => {
    expect(isValidBloodPressure("12080")).toBe(false);
  });
});

describe("isValidVisitType", () => {
  it("accepts a value from the fixed list", () => {
    expect(isValidVisitType("Immunization")).toBe(true);
  });

  it("rejects a value outside the fixed list", () => {
    expect(isValidVisitType("Checkup")).toBe(false);
  });
});

describe("validatePatientForm", () => {
  const validPatient: PatientFormInput = {
    patient_id: "MBR-0001",
    first_name: "Rudo",
    last_name: "Chirwa",
    date_of_birth: "2016-05-07",
    gender: "F",
    village: "Mbare",
    phone_number: "",
  };

  it("returns no errors for a fully valid form", () => {
    expect(validatePatientForm(validPatient)).toEqual({});
  });

  it("flags a blank required field", () => {
    const errors = validatePatientForm({ ...validPatient, first_name: "   " });
    expect(errors.first_name).toBeDefined();
  });

  it("flags a future date of birth", () => {
    const errors = validatePatientForm({ ...validPatient, date_of_birth: "2999-01-01" });
    expect(errors.date_of_birth).toBe("Date of birth cannot be in the future");
  });

  it("leaves phone_number optional when blank", () => {
    const errors = validatePatientForm({ ...validPatient, phone_number: "" });
    expect(errors.phone_number).toBeUndefined();
  });

  it("flags a malformed phone_number when one is entered", () => {
    const errors = validatePatientForm({ ...validPatient, phone_number: "123" });
    expect(errors.phone_number).toBeDefined();
  });
});

describe("validateVisitForm", () => {
  const validVisit: VisitFormInput = {
    patient_id: "patient-uuid-1",
    chw_id: "CHW001",
    visit_date: new Date().toISOString().slice(0, 10),
    visit_type: "Antenatal",
    weight: "62",
    height: "160",
    blood_pressure: "120/80",
    notes: "",
  };

  it("returns no errors for a fully valid form", () => {
    expect(validateVisitForm(validVisit)).toEqual({});
  });

  it("requires a patient to be selected", () => {
    const errors = validateVisitForm({ ...validVisit, patient_id: "" });
    expect(errors.patient_id).toBeDefined();
  });

  it("flags a visit date more than a day in the future", () => {
    const farFuture = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    const errors = validateVisitForm({ ...validVisit, visit_date: farFuture });
    expect(errors.visit_date).toBeDefined();
  });

  it("leaves optional vitals (weight/height/blood pressure) untouched when blank", () => {
    const errors = validateVisitForm({ ...validVisit, weight: "", height: "", blood_pressure: "" });
    expect(errors.weight).toBeUndefined();
    expect(errors.height).toBeUndefined();
    expect(errors.blood_pressure).toBeUndefined();
  });

  it("flags an out-of-range weight", () => {
    const errors = validateVisitForm({ ...validVisit, weight: "301" });
    expect(errors.weight).toBeDefined();
  });

  it("flags an unrecognised visit type", () => {
    const errors = validateVisitForm({ ...validVisit, visit_type: "Checkup" });
    expect(errors.visit_type).toBeDefined();
  });
});
