import { prisma } from "../db";

// Framework-agnostic on purpose: this module knows nothing about Express or
// HTTP status codes, only "is this record valid". Two very different callers
// use it the same way - routes/patients.ts and routes/visits.ts turn a
// non-empty error list into a thrown AppError (aborting one request),
// while services/syncService.ts turns it into a per-record "failed" result
// inside a batch (so one bad record doesn't abort the other 49).

export const GENDERS = ["M", "F"] as const;

export const VISIT_TYPES = [
  "Immunization",
  "Antenatal",
  "Growth Monitoring",
  "HIV/TB Support",
  "Health Education",
  "Disease Surveillance",
  "Other",
] as const;

const PHONE_PATTERN = /^0\d{9}$/;
const BLOOD_PRESSURE_PATTERN = /^\d{2,3}\/\d{2,3}$/;

// Postgres refuses to write a btree index row over ~8191 bytes (patients has
// an index on last_name+first_name), and an unbounded string field is a
// resource-exhaustion vector regardless of any index - an oversized value
// must be rejected here, at the application boundary, as a clean 400,
// rather than ever reaching the database and surfacing as a raw 500 (found
// via adversarial testing: a 2MB first_name previously did exactly that).
const MAX_NAME_LENGTH = 100;
const MAX_VILLAGE_LENGTH = 100;
const MAX_PATIENT_ID_LENGTH = 50;
const MAX_NOTES_LENGTH = 2000;

export function isValidDateString(value: unknown): value is string {
  return typeof value === "string" && !Number.isNaN(new Date(value).getTime());
}

// partial:true is used for updates (PUT), where any field may be omitted
// (left unchanged) - only fields that ARE present get validated.
export const HOUSEHOLD_CODE_PATTERN = /^[A-Za-z0-9-]{3,40}$/;

export function validateHouseholdFields(body: Record<string, unknown>): string[] {
  const errors: string[] = [];
  if (typeof body.household_code !== "string" || !HOUSEHOLD_CODE_PATTERN.test(body.household_code)) {
    errors.push("Household code must be 3-40 letters, numbers or hyphens");
  }
  if (typeof body.village !== "string" || !body.village.trim()) errors.push("Village is required");
  else if (body.village.length > MAX_VILLAGE_LENGTH) errors.push(`Village must be at most ${MAX_VILLAGE_LENGTH} characters`);
  if (typeof body.created_at !== "string" || Number.isNaN(new Date(body.created_at).getTime())) errors.push("created_at is required");
  return errors;
}

export function validatePatientFields(
  body: Record<string, unknown>,
  { partial }: { partial: boolean },
): string[] {
  const errors: string[] = [];

  const requiredStrings: Array<[string, string, number]> = [
    ["patient_id", "Patient ID", MAX_PATIENT_ID_LENGTH],
    ["first_name", "First name", MAX_NAME_LENGTH],
    ["last_name", "Last name", MAX_NAME_LENGTH],
    ["village", "Village", MAX_VILLAGE_LENGTH],
  ];

  for (const [key, label, maxLength] of requiredStrings) {
    const value = body[key];
    if (partial && value === undefined) continue;
    if (typeof value !== "string" || !value.trim()) {
      errors.push(`${label} is required`);
    } else if (value.length > maxLength) {
      errors.push(`${label} must be at most ${maxLength} characters`);
    }
  }

  if (!partial || body.gender !== undefined) {
    if (!(GENDERS as readonly string[]).includes(body.gender as string)) {
      errors.push("Gender must be M or F");
    }
  }

  if (!partial || body.date_of_birth !== undefined) {
    if (!isValidDateString(body.date_of_birth)) {
      errors.push("Date of birth is not a valid date");
    }
  }

  if (body.phone_number !== undefined && body.phone_number !== null) {
    if (typeof body.phone_number !== "string" || !PHONE_PATTERN.test(body.phone_number)) {
      errors.push("Phone number must be 10 digits starting with 0, e.g. 0771234567");
    }
  }

  return errors;
}

export async function validateVisitFields(
  body: Record<string, unknown>,
  { partial }: { partial: boolean },
): Promise<string[]> {
  const errors: string[] = [];

  if (!partial || body.patient_id !== undefined) {
    if (typeof body.patient_id !== "string" || !body.patient_id.trim()) {
      errors.push("patient_id is required");
    } else if (!(await prisma.patient.findUnique({ where: { id: body.patient_id } }))) {
      errors.push("Patient not found");
    }
  }

  if (!partial || body.chw_id !== undefined) {
    if (typeof body.chw_id !== "string" || !body.chw_id.trim()) {
      errors.push("chw_id is required");
    } else if (!(await prisma.chw.findUnique({ where: { chw_id: body.chw_id } }))) {
      errors.push("CHW not found");
    }
  }

  if (!partial || body.visit_date !== undefined) {
    if (!isValidDateString(body.visit_date)) {
      errors.push("visit_date is not a valid date");
    }
  }

  if (!partial || body.visit_type !== undefined) {
    if (!(VISIT_TYPES as readonly string[]).includes(body.visit_type as string)) {
      errors.push(`visit_type must be one of: ${VISIT_TYPES.join(", ")}`);
    }
  }

  if (body.weight !== undefined && body.weight !== null) {
    if (typeof body.weight !== "number" || body.weight <= 0 || body.weight > 300) {
      errors.push("weight must be a number between 0 and 300 kg");
    }
  }

  if (body.height !== undefined && body.height !== null) {
    if (typeof body.height !== "number" || body.height <= 0 || body.height > 250) {
      errors.push("height must be a number between 0 and 250 cm");
    }
  }

  if (body.blood_pressure !== undefined && body.blood_pressure !== null) {
    if (typeof body.blood_pressure !== "string" || !BLOOD_PRESSURE_PATTERN.test(body.blood_pressure)) {
      errors.push("blood_pressure must be in the format systolic/diastolic, e.g. 120/80");
    }
  }

  if (body.notes !== undefined && body.notes !== null) {
    if (typeof body.notes !== "string") {
      errors.push("notes must be a string");
    } else if (body.notes.length > MAX_NOTES_LENGTH) {
      errors.push(`notes must be at most ${MAX_NOTES_LENGTH} characters`);
    }
  }

  return errors;
}
