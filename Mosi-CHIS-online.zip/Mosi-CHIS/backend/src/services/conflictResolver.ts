import { createHash } from "node:crypto";

// Implements section 19's last-write-wins rule:
//   - newer incoming edit -> apply it
//   - older incoming edit -> keep what the server already has
//   - IDENTICAL timestamps -> there's no "latest" to fall back on, so
//     compare a content hash instead. Same content -> it's the same edit
//     arriving again (an idempotent retry, not a conflict). Different
//     content -> a genuine conflict that gets flagged for supervisor
//     review rather than silently guessed at.
export type ConflictDecision =
  | { outcome: "apply"; reason: "newer" }
  | { outcome: "keep_existing"; reason: "older" }
  | { outcome: "keep_existing"; reason: "identical" }
  | { outcome: "flag_conflict"; reason: "hash_mismatch" };

// Stable key order so the hash never depends on how the caller happened to
// build the object, and Dates are normalised to ISO strings so a JS Date and
// the equivalent string compare equal.
export function hashContent(fields: Record<string, unknown>): string {
  const ordered = Object.keys(fields)
    .sort()
    .reduce<Record<string, unknown>>((acc, key) => {
      const value = fields[key];
      acc[key] = value instanceof Date ? value.toISOString() : (value ?? null);
      return acc;
    }, {});

  return createHash("sha256").update(JSON.stringify(ordered)).digest("hex");
}

export function resolveConflict(params: {
  incomingUpdatedAt: Date;
  existingUpdatedAt: Date;
  incomingContent: Record<string, unknown>;
  existingContent: Record<string, unknown>;
}): ConflictDecision {
  const { incomingUpdatedAt, existingUpdatedAt, incomingContent, existingContent } = params;

  if (incomingUpdatedAt.getTime() > existingUpdatedAt.getTime()) {
    return { outcome: "apply", reason: "newer" };
  }

  if (incomingUpdatedAt.getTime() < existingUpdatedAt.getTime()) {
    return { outcome: "keep_existing", reason: "older" };
  }

  if (hashContent(incomingContent) === hashContent(existingContent)) {
    return { outcome: "keep_existing", reason: "identical" };
  }

  return { outcome: "flag_conflict", reason: "hash_mismatch" };
}
