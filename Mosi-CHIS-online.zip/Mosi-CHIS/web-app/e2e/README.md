# Browser tests (Playwright)

End-to-end suites that drive the **production build** in a real Chromium
against the **real backend and database**: offline save and sync,
keyboard and screen-reader behaviour, accessibility (axe, WCAG 2.2 AA),
layout at 320–1440 px, and each feature's flows (account requests, CHW and
supervisor management, duplicates, PIN resets, households, follow-ups,
review queue, admin/clinic scoping, activity log, installable app).

They are separate from the unit tests (`npm test` in `web-app/` and
`backend/`) and have their own dependencies, so the app itself doesn't
depend on Playwright.

## Run

1. Start the stack: Postgres in Docker (`mosi-postgres`), the backend on
   :4000 (`cd backend && npm run dev`), and the production web build on
   :4173 (`cd web-app && npm run build && npx vite preview --port 4173`).
2. Install once: `cd web-app/e2e && npm install && npx playwright install chromium`
3. Run everything (about 15 minutes): `node run-all.mjs`
   - or some suites: `node run-all.mjs p14 p15`
   - or one directly: `node p14-review.mjs`

The suites create test records marked `P<n>-…` (patients/visits) and
`T<n>…` (accounts). `run-all.mjs` removes them between suites with
`cleanup.sql`, which also resets the demo accounts to PIN `1234`
(`demo-pin-hash.txt` is the bcrypt hash of that demo PIN - not a secret).
Run `cleanup.sql` yourself after running a suite directly:

```
docker exec -i mosi-postgres psql -U mosi -d mosi < cleanup.sql
```

## Notes

- Expected database at rest: 75 patients, 184 visits, 6 accounts
  (CHW001–CHW004, SUP001 administrator, SUP002 Mbare supervisor).
- `p3-sweep` paces itself to stay under the API's 300 requests/minute limit.
- `generate-icons.mjs` regenerates `public/icons/*` from the leaf logo.
