import rateLimit, { ipKeyGenerator } from "express-rate-limit";

// Login is the one endpoint that matters most: CHW PINs are 4 digits (10,000
// possible values, see routes/auth.ts), so without throttling a login route
// is brute-forceable in minutes. Keyed by IP + attempted chw_id together, so
// one CHW's PIN being hammered doesn't lock out every other CHW behind the
// same NAT/clinic router sharing that IP. ipKeyGenerator (not raw req.ip) is
// required for IPv6 requests - it normalizes to a /56 subnet so a client
// can't dodge the limit by varying the low bits of its own IPv6 address.
export const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  // Only failed attempts count. Without this, a CHW who signs in correctly
  // 10+ times in 15 minutes (shared clinic tablet, re-logins on a flaky
  // connection) was locked out despite knowing their PIN - found during the
  // frontend redesign's browser testing. PIN guessing is still capped at 10
  // wrong attempts per window, plus the per-account lockout in routes/auth.ts.
  skipSuccessfulRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => {
    const chwId = typeof req.body?.chw_id === "string" ? req.body.chw_id.trim().toLowerCase() : "";
    return `${ipKeyGenerator(req.ip ?? "")}:${chwId}`;
  },
  handler: (_req, res) => {
    res.status(429).json({ success: false, message: "Too many login attempts. Try again in a few minutes." });
  },
});

// A generous ceiling on every other route, mainly as a backstop against
// runaway clients/scripts rather than a targeted defense against any one
// endpoint - the login limiter above is the one doing real security work.
export const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 300,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    res.status(429).json({ success: false, message: "Too many requests. Please slow down." });
  },
});

// Public account requests: a handful per hour per IP is plenty for real
// people, and it caps both spam and probing which CHW IDs are taken.
export const accountRequestLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 5,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    res.status(429).json({ success: false, message: "Too many account requests from this network. Try again later." });
  },
});

// "Forgot PIN?" requests: same reasoning as account requests.
export const pinResetRequestLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 5,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (_req, res) => {
    res.status(429).json({ success: false, message: "Too many requests from this network. Try again later." });
  },
});

// Deliberately generous (section 14): a field CHW's device retries sync
// automatically with backoff (5s/10s/20s, see web-app's syncService.ts)
// whenever a connection is flaky, and a batch can contain up to 200 records
// each (see MAX_SYNC_BATCH_RECORDS). This exists only as a backstop against
// a runaway/broken client hammering the endpoint, not to throttle normal
// field retry behavior.
export const syncLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.user?.chwId ?? ipKeyGenerator(req.ip ?? ""),
  handler: (_req, res) => {
    res.status(429).json({ success: false, message: "Too many sync attempts. Please wait a moment and try again." });
  },
});
