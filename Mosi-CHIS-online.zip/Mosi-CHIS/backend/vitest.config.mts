import { defineConfig } from "vitest/config";

// Explicit include (not vitest's default glob) so a leftover dist/ build
// output - which contains compiled, CommonJS test files that error out
// trying to require() the ESM-only vitest package - is never picked up
// alongside the real TypeScript sources under src/.
export default defineConfig({
  test: {
    include: ["src/**/*.test.ts"],
  },
});
