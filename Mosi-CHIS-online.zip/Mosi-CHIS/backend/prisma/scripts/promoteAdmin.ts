// One-off, idempotent account update for an EXISTING demo database when the
// admin-role feature is introduced - without re-running the seed (which
// rebuilds every patient and visit). It changes accounts only:
//   - SUP001 (organisation-wide until now) becomes ADMIN, so it keeps seeing
//     every clinic once supervisors are clinic-scoped;
//   - SUP002, a Mbare Clinic supervisor, is added if missing (demo PIN 1234,
//     same as every other demo account).
// Each change is written to the audit log. Running it again changes nothing.
//
//   npx tsx prisma/scripts/promoteAdmin.ts
import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const sup001 = await prisma.chw.findUnique({ where: { chw_id: "SUP001" }, select: { role: true } });
  if (sup001?.role === "SUPERVISOR") {
    await prisma.$transaction([
      prisma.chw.update({ where: { chw_id: "SUP001" }, data: { role: "ADMIN" } }),
      prisma.auditLog.create({
        data: { action: "CHW_UPDATED", resource_type: "chw", resource_id: "SUP001", metadata: { role: { from: "SUPERVISOR", to: "ADMIN" }, via: "prisma/scripts/promoteAdmin.ts" } },
      }),
    ]);
    console.log("SUP001: SUPERVISOR -> ADMIN");
  } else {
    console.log(`SUP001: unchanged (${sup001?.role ?? "missing"})`);
  }

  const mbare = await prisma.clinic.findUnique({ where: { code: "MBR" } });
  if (!mbare) throw new Error("Mbare Clinic (code MBR) not found");
  if (await prisma.chw.findUnique({ where: { chw_id: "SUP002" } })) {
    console.log("SUP002: already exists, unchanged");
  } else {
    await prisma.$transaction([
      prisma.chw.create({
        data: { chw_id: "SUP002", full_name: "Farai Mupfumi", clinic: mbare.name, clinic_id: mbare.id, pin_hash: await bcrypt.hash("1234", 10), role: "SUPERVISOR", status: "active" },
      }),
      prisma.auditLog.create({
        data: { action: "CHW_CREATED", resource_type: "chw", resource_id: "SUP002", metadata: { role: "SUPERVISOR", clinic_id: mbare.id, via: "prisma/scripts/promoteAdmin.ts" } },
      }),
    ]);
    console.log("SUP002: created (Mbare Clinic supervisor)");
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
