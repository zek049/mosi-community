import type { Chw } from "../models/chw";
import type { Visit } from "../models/visit";
import type { SyncLogEntry } from "../services/api";

const ACTIVE_WINDOW_MS = 7 * 24 * 60 * 60 * 1000;

export type ChwActivityRow = {
  chw: Chw;
  visitCount: number;
  lastSyncTime: string | null;
  isActive: boolean;
};

// Shared by CHW Activity and the Supervisor Dashboard's "Recent CHW
// Activity" summary, so both compute the same numbers the same way.
//
// "Last sync time" is deliberately derived from sync_log (which visit ids
// belonging to this CHW have a recorded sync event), not from a visit's own
// updated_at - the same "only claim what the server actually observed"
// principle as the dashboard's Attention panel. Seeded demo visits were
// written directly by the seed script, not through the sync endpoint, so a
// CHW correctly shows "Never synced" until a real sync happens for one of
// their records - that's accurate, not a bug.
export function summarizeChwActivity(chws: Chw[], visits: Visit[], syncLog: SyncLogEntry[]): ChwActivityRow[] {
  return chws
    .filter((chw) => chw.role === "CHW")
    .map((chw) => {
      const chwVisits = visits.filter((v) => v.chw_id === chw.chw_id);
      const visitIds = new Set(chwVisits.map((v) => v.id));

      const relevantSyncTimes = syncLog
        .filter((entry) => entry.record_type === "visit" && visitIds.has(entry.record_id))
        .map((entry) => entry.synced_at);
      const lastSyncTime = relevantSyncTimes.length > 0 ? relevantSyncTimes.sort().at(-1)! : null;

      const visitDates = chwVisits.map((v) => v.visit_date).sort();
      const mostRecentVisitDate = visitDates.at(-1);
      const isActive = mostRecentVisitDate
        ? Date.now() - new Date(mostRecentVisitDate).getTime() < ACTIVE_WINDOW_MS
        : false;

      return { chw, visitCount: chwVisits.length, lastSyncTime, isActive };
    });
}
