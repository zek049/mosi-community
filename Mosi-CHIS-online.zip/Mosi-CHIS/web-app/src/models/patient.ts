// Field names and shape deliberately mirror backend/prisma/schema.prisma's
// Patient model exactly (snake_case, same fields) - this same object shape
// is used in IndexedDB, in the sync request/response payload, and in the
// server database. Do not rename fields.
//
// Dates are stored as ISO 8601 strings (not Date objects) everywhere on the
// client, so a record read from IndexedDB can be dropped straight into a
// sync payload with no conversion.

export type Gender = "M" | "F";

export type SyncStatus = "pending" | "synced";

/** Mirrors the backend ReviewStatus enum (review queue). */
export type ReviewStatus = "awaiting_review" | "confirmed" | "flagged";

export interface Patient {
  id: string;
  patient_id: string;
  first_name: string;
  last_name: string;
  date_of_birth: string;
  gender: Gender;
  village: string;
  phone_number: string | null;
  created_at: string;
  updated_at: string;
  sync_status: SyncStatus;
  // Server-assigned (backend MVP hardening) - optional here because records
  // created before this were seeded/synced without them, and because
  // nothing client-side needs to set or filter on them yet. Never sent by
  // the client on create/update; the server always derives them from the
  // authenticated actor.
  clinic_id?: string;
  registered_by_chw_id?: string | null;
  deleted_at?: string | null;
  /** Optional household grouping (null/absent = not in a household). */
  household_id?: string | null;
  // Supervisor review (server-owned, read-only here): filled from sync
  // results and cache refreshes. Absent = not known on this device yet.
  review_status?: ReviewStatus;
  review_flag_reason?: string | null;
  reviewed_at?: string | null;
  reviewed_by?: string | null;
}
