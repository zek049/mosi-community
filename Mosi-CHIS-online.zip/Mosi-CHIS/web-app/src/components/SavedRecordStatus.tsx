import { useLiveQuery } from "dexie-react-hooks";
import { AlertCircle, CheckCircle2, Clock, CloudOff, Flag, RefreshCw, UploadCloud } from "lucide-react";
import { db } from "../db/indexedDb";
import { useNetwork } from "../contexts/NetworkContext";
import { syncLaterHint } from "../services/connectivity";
import { useSync } from "../contexts/SyncContext";
import { cn } from "../lib/utils";

type Props = { table: "patients" | "visits"; id: string; noun: "patient" | "visit" };

// The honest post-save status for ONE record, read live from its local row
// and the real sync state. It never says "synced" until the server has
// actually accepted the record (runSync marks it synced only then).
export function SavedRecordStatus({ table, id, noun }: Props) {
  const { isOnline, status: connectivity } = useNetwork();
  const { phase } = useSync();
  const record = useLiveQuery<{ sync_status: string; review_status?: string; review_flag_reason?: string | null } | undefined>(
    () => (table === "patients" ? db.patients.get(id) : db.visits.get(id)),
    [table, id],
  );
  const attempt = useLiveQuery(() => db.syncAttempts.get(id), [id]);

  if (record === undefined) return null;

  let Icon = UploadCloud;
  let title = "Saved on this device";
  let detail = "Waiting to sync.";
  let tone = "border-amber-200 bg-amber-50 text-amber-900";
  let spin = false;

  if (record.sync_status === "synced" && attempt?.status === "conflict") {
    Icon = Flag;
    title = "Saved and sent";
    detail = `This ${noun} was also changed somewhere else, so a supervisor will review it.`;
  } else if (record.sync_status === "synced" && record.review_status === "awaiting_review") {
    // On the server, but not confirmed - say exactly that.
    Icon = Clock;
    title = "Sent - awaiting supervisor review";
    detail = `The server has this ${noun}. Your supervisor will check it.`;
    tone = "border-sky-200 bg-sky-50 text-sky-900";
  } else if (record.sync_status === "synced" && record.review_status === "flagged") {
    Icon = Flag;
    title = "Flagged by your supervisor";
    detail = record.review_flag_reason ? `Reason: ${record.review_flag_reason}` : "Check with your supervisor.";
    tone = "border-red-200 bg-red-50 text-red-900";
  } else if (record.sync_status === "synced") {
    Icon = CheckCircle2;
    title = record.review_status === "confirmed" ? "Saved and confirmed" : "Saved and synced";
    detail = `The server has this ${noun}.`;
    tone = "border-emerald-200 bg-emerald-50 text-emerald-900";
  } else if (!isOnline) {
    Icon = CloudOff;
    detail = syncLaterHint(connectivity).replace("It will", "Will");
  } else if (phase === "syncing") {
    Icon = RefreshCw;
    detail = "Syncing now…";
    spin = true;
  } else if (attempt?.status === "failed" || phase === "paused") {
    Icon = AlertCircle;
    detail = "Waiting to sync. It's safe on this device - see Sync Status for details.";
  }

  return (
    <div className={cn("flex items-start gap-3 rounded-xl border px-5 py-4", tone)}>
      <Icon className={cn("mt-0.5 h-5 w-5 shrink-0", spin && "animate-spin motion-reduce:animate-none")} aria-hidden="true" />
      <div>
        <p className="text-sm font-semibold">{title}</p>
        <p className="text-sm">{detail}</p>
      </div>
    </div>
  );
}
