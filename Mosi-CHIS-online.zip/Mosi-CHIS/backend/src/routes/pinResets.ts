import { Router } from "express";
import bcrypt from "bcryptjs";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { authenticate, requireRole } from "../middleware/auth";
import { canManageAccount, clinicScope, isAdmin } from "../middleware/authz";
import { pinResetRequestLimiter } from "../middleware/rateLimit";
import { requireStringParam } from "../utils/params";
import { parseBody, pinResetRequestSchema, pinResetCompleteSchema } from "../validation/schemas";
import { writeAuditLog } from "../utils/audit";

// "Forgot PIN?" requests.
//
// Public side: whatever is typed, the answer is the same 202 and the same
// message (OWASP account-enumeration guidance) - a request is only actually
// recorded for an ACTIVE CHW account with no request already waiting.
//
// Supervisor side: completing a request sets a TEMPORARY PIN (hashed; the
// account must choose a new one at its next sign-in - must_change_pin) and
// clears any lockout, in one transaction with marking the request done.

const ACCEPTED_MESSAGE = "A supervisor will reset your PIN — check with them for your new temporary PIN.";

export const publicPinResetRoutes = Router();

publicPinResetRoutes.post("/", pinResetRequestLimiter, async (req, res) => {
  const { chw_id: rawId } = parseBody(pinResetRequestSchema, req.body ?? {});
  const chwId = rawId.trim();

  const chw = await prisma.chw.findUnique({ where: { chw_id: chwId }, select: { chw_id: true, role: true, status: true, clinic_id: true } });
  if (chw && chw.role === "CHW" && chw.status === "active") {
    const open = await prisma.pinResetRequest.findFirst({ where: { chw_id: chw.chw_id, status: "pending" }, select: { id: true } });
    if (!open) {
      const created = await prisma.pinResetRequest.create({ data: { chw_id: chw.chw_id }, select: { id: true } });
      await writeAuditLog({
        actor: null,
        action: "PIN_RESET_REQUESTED",
        resourceType: "pin_reset_request",
        resourceId: created.id,
        requestId: req.requestId,
        metadata: { chw_id: chw.chw_id, clinic_id: chw.clinic_id },
      });
    }
  }
  // Same response in every case (unknown ID, supervisor, revoked, duplicate).
  res.status(202).json({ success: true, data: { message: ACCEPTED_MESSAGE } });
});

export const pinResetReviewRoutes = Router();
pinResetReviewRoutes.use(authenticate, requireRole("SUPERVISOR"));

// ?status=pending (default) | completed (most recent 50)
pinResetReviewRoutes.get("/", async (req, res) => {
  const completed = req.query.status === "completed";
  const scope = clinicScope(req.user!);
  const requests = await prisma.pinResetRequest.findMany({
    // Only accounts the viewer can act on: supervisors -> CHWs in their
    // clinic; administrators -> CHWs and supervisors anywhere.
    where: {
      status: completed ? "completed" : "pending",
      chw: { ...(scope ? { clinic_id: scope } : {}), role: isAdmin(req.user!) ? { in: ["CHW", "SUPERVISOR"] } : "CHW" },
    },
    select: {
      id: true,
      chw_id: true,
      status: true,
      requested_at: true,
      reviewed_at: true,
      reviewed_by: true,
      chw: { select: { full_name: true, clinic: true } },
    },
    orderBy: completed ? { reviewed_at: "desc" } : { requested_at: "asc" },
    take: completed ? 50 : 200,
  });
  const reviewerIds = [...new Set(requests.map((r) => r.reviewed_by).filter((id): id is string => Boolean(id)))];
  const reviewers = reviewerIds.length
    ? await prisma.chw.findMany({ where: { chw_id: { in: reviewerIds } }, select: { chw_id: true, full_name: true } })
    : [];
  const reviewerName = new Map(reviewers.map((r) => [r.chw_id, r.full_name]));
  res.json({
    success: true,
    data: requests.map(({ chw, ...r }) => ({
      ...r,
      full_name: chw.full_name,
      clinic: chw.clinic,
      reviewed_by_name: r.reviewed_by ? (reviewerName.get(r.reviewed_by) ?? r.reviewed_by) : null,
    })),
  });
});

pinResetReviewRoutes.post("/:id/complete", async (req, res) => {
  const id = requireStringParam(req, "id");
  const { new_pin: newPin } = parseBody(pinResetCompleteSchema, req.body ?? {});

  const request = await prisma.pinResetRequest.findUnique({ where: { id }, include: { chw: true } });
  // Outside the supervisor's scope looks exactly like missing.
  if (!request || !canManageAccount(req.user!, request.chw)) throw new AppError(404, "PIN reset request not found");
  if (request.status !== "pending") throw new AppError(409, "This request has already been completed", "ALREADY_COMPLETED");

  await prisma.$transaction([
    prisma.chw.update({
      where: { chw_id: request.chw_id },
      data: { pin_hash: await bcrypt.hash(newPin, 10), must_change_pin: true, failed_login_count: 0, locked_until: null },
    }),
    prisma.pinResetRequest.update({
      where: { id },
      data: { status: "completed", reviewed_at: new Date(), reviewed_by: req.user!.chwId },
    }),
  ]);

  // The PIN itself is never recorded.
  await writeAuditLog({
    actor: req.user,
    action: "PIN_RESET_COMPLETED",
    resourceType: "pin_reset_request",
    resourceId: id,
    requestId: req.requestId,
    metadata: { chw_id: request.chw_id, clinic_id: request.chw.clinic_id },
  });

  res.json({ success: true, data: { request_id: id, status: "completed", chw_id: request.chw_id, must_change_pin: true } });
});
