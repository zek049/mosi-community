import { useEffect, useId, useRef, type ReactNode } from "react";

type ModalDialogProps = {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  /** Buttons row. The first focusable element inside the dialog gets focus on open. */
  actions: ReactNode;
  /** Keep the dialog open on Escape/backdrop while an action is in progress. */
  busy?: boolean;
};

// Native <dialog> with showModal(): the browser supplies the focus trap,
// Escape-to-close and the inert background (same approach as InfoDialog and
// the conflict confirmation). Focus returns to whatever opened it.
export function ModalDialog({ open, title, onClose, children, actions, busy = false }: ModalDialogProps) {
  const ref = useRef<HTMLDialogElement>(null);
  const returnFocusRef = useRef<HTMLElement | null>(null);
  const actionsRef = useRef<HTMLDivElement>(null);
  const titleId = useId();
  const bodyId = useId();

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) {
      returnFocusRef.current = document.activeElement as HTMLElement | null;
      dialog.showModal();
      // Start on the first action - by convention the safe one (Cancel /
      // Stay signed in) - not on whatever field happens to come first.
      // (React's autoFocus doesn't survive showModal(), which re-focuses.)
      actionsRef.current?.querySelector<HTMLElement>("button:not([disabled])")?.focus();
    } else if (!open && dialog.open) {
      dialog.close();
      if (returnFocusRef.current?.isConnected) returnFocusRef.current.focus();
    }
  }, [open]);

  return (
    <dialog
      ref={ref}
      aria-labelledby={titleId}
      aria-describedby={bodyId}
      onCancel={(e) => {
        e.preventDefault();
        if (!busy) onClose();
      }}
      className="w-[calc(100%-2rem)] max-w-md rounded-2xl p-0 text-stone-800 shadow-xl backdrop:bg-stone-900/50"
    >
      <div className="space-y-4 p-6">
        <h2 id={titleId} className="text-lg font-semibold text-stone-900">
          {title}
        </h2>
        <div id={bodyId} className="space-y-3 text-sm leading-relaxed text-stone-700">
          {children}
        </div>
        <div ref={actionsRef} className="flex flex-col-reverse gap-3 pt-1 sm:flex-row sm:flex-wrap sm:justify-end">
          {actions}
        </div>
      </div>
    </dialog>
  );
}
