import { useEffect, useId, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Trash2 } from "lucide-react";
import * as authService from "../services/authService";
import { countPending, countUnassignedLegacyRecords } from "../db/indexedDb";
import { plural } from "../utils/syncMessages";
import { Card } from "./ui/Card";
import { Button } from "./ui/Button";
import { ModalDialog } from "./ui/ModalDialog";
import type { SignedOutState } from "./SignOutFlow";

// Explicit privacy action for shared devices: removes everything this
// account has stored in this browser, then signs out. If anything is still
// unsynced it says so plainly and needs a deliberate extra confirmation,
// because that work would be lost for good.
export function ClearDeviceSection() {
  const navigate = useNavigate();
  const checkboxId = useId();
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(0);
  const [understood, setUnderstood] = useState(false);
  const [busy, setBusy] = useState(false);
  const [legacy, setLegacy] = useState(0);

  useEffect(() => {
    countUnassignedLegacyRecords()
      .then((c) => setLegacy(c.patients + c.visits))
      .catch(() => setLegacy(0));
  }, []);

  async function openDialog() {
    setPending(await countPending().catch(() => 0));
    setUnderstood(false);
    setOpen(true);
  }

  async function confirm() {
    setBusy(true);
    await authService.signOut("wipe");
    const state: SignedOutState = { signedOut: true, keptUnsynced: 0 };
    navigate("/login", { replace: true, state });
  }

  const canConfirm = pending === 0 || understood;

  return (
    <Card>
      <h2 className="text-sm font-semibold text-stone-900">This device</h2>
      <p className="mt-1 text-sm text-stone-600">
        Signing out already removes records that are safely on the server. On a shared or borrowed device you can also
        remove everything of yours stored here, including anything not yet synced.
      </p>
      {legacy > 0 && (
        <p className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          This device also holds {plural(legacy, "older unsynced record", "older unsynced records")} saved before a Mosi
          update, which couldn't be matched to an account. {legacy === 1 ? "It is" : "They are"} kept, but not shown or
          synced to anyone. Ask your supervisor or system administrator before clearing this browser's data.
        </p>
      )}
      <Button type="button" variant="secondary" className="mt-3" onClick={() => void openDialog()}>
        <Trash2 className="h-4 w-4" aria-hidden="true" />
        Remove my data from this device
      </Button>

      <ModalDialog
        open={open}
        title="Remove your data from this device?"
        onClose={() => setOpen(false)}
        busy={busy}
        actions={
          <>
            <Button type="button" variant="secondary" onClick={() => setOpen(false)} disabled={busy} autoFocus>
              Cancel
            </Button>
            <Button type="button" variant="danger" onClick={() => void confirm()} disabled={!canConfirm || busy}>
              {busy ? "Removing…" : "Remove and sign out"}
            </Button>
          </>
        }
      >
        {pending === 0 ? (
          <p>
            Everything you have on this device is already on the server, so nothing will be lost. Your patients and
            visits will be removed from this browser (not from the server) and you'll be signed out.
          </p>
        ) : (
          <>
            <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 font-medium text-red-900">
              {plural(pending, "change has", "changes have")} not reached the server. Removing your data deletes{" "}
              {pending === 1 ? "it" : "them"} permanently.
            </p>
            <p>
              Records already on the server are not affected. To keep {pending === 1 ? "it" : "them"}, cancel and sync
              first, or just sign out - unsynced changes are kept for your next sign-in.
            </p>
            <div className="flex items-start gap-2.5">
              <input
                id={checkboxId}
                type="checkbox"
                checked={understood}
                onChange={(e) => setUnderstood(e.target.checked)}
                className="mt-0.5 h-5 w-5 shrink-0 accent-red-700"
              />
              <label htmlFor={checkboxId} className="text-stone-800">
                I understand {plural(pending, "unsynced change", "unsynced changes")} will be lost.
              </label>
            </div>
          </>
        )}
      </ModalDialog>
    </Card>
  );
}
