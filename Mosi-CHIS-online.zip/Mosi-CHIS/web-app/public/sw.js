// Caches the app shell (HTML/JS/CSS/icons) so Mosi still loads with no
// connection at all, e.g. opening the installed app in an area with no
// signal. This is deliberately separate from the app's real offline data
// story: every patient/visit read and write goes through IndexedDB
// (db/indexedDb.ts) and the sync engine (services/syncService.ts), never
// through this cache. Requests to /api/* (and any other origin, which is
// where the API lives) are explicitly left untouched below so the sync
// engine's own network-failure detection (api.ts's NetworkError) keeps
// working exactly as it does with no service worker - and authenticated
// health data is never written into this cache.
// v3: new leaf icons (replaces the old "M" placeholder icons on devices
// that cached them).
const CACHE_NAME = "mosi-shell-v3";

// Not referenced by index.html's /assets links, so listed explicitly - the
// installed app's icon and favicon must work offline too.
const STATIC_FILES = [
  "/manifest.json",
  "/icons/favicon.svg",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/icons/icon-maskable-512.png",
  "/icons/apple-touch-icon.png",
];

// Every JS/CSS chunk this build produced, including the lazily-loaded
// screen chunks that index.html never references directly. Without this, a
// CHW who goes offline before ever opening e.g. Add Visit would find that
// screen unavailable. Vite writes this manifest because build.manifest is
// enabled in vite.config.ts.
async function precacheBuild(cache) {
  const shellResponse = await fetch("/", { cache: "no-store" });
  if (!shellResponse.ok) return;
  const shellText = await shellResponse.clone().text();
  await cache.put("/", shellResponse);

  const urls = new Set(Array.from(shellText.matchAll(/(?:src|href)="(\/assets\/[^"]+)"/g)).map((m) => m[1]));

  try {
    const manifestResponse = await fetch("/.vite/manifest.json", { cache: "no-store" });
    if (manifestResponse.ok) {
      const manifest = await manifestResponse.json();
      for (const entry of Object.values(manifest)) {
        if (entry.file) urls.add(`/${entry.file}`);
        for (const css of entry.css ?? []) urls.add(`/${css}`);
      }
    }
  } catch {
    // No manifest (e.g. an older build) - the HTML-referenced assets above
    // are still cached, and lazy chunks get cached the first time they load.
  }

  // /assets/* filenames are content-hashed, so an already-cached one can
  // never be stale - skip it rather than re-downloading the whole bundle on
  // every app open (mobile data is metered for most CHWs).
  await Promise.all(
    [...urls, ...STATIC_FILES].map(async (url) => {
      try {
        if (url.startsWith("/assets/") && (await cache.match(url, { ignoreVary: true }))) return;
        const response = await fetch(url);
        if (response.ok) await cache.put(url, response);
      } catch {
        // One asset failing shouldn't abort caching the rest.
      }
    }),
  );
}

self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      await precacheBuild(await caches.open(CACHE_NAME));
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  const url = new URL(request.url);

  if (request.method !== "GET" || url.origin !== self.location.origin || url.pathname.startsWith("/api/")) {
    return;
  }

  // SPA navigations (/chw, /patients/abc, ...) all render the same
  // index.html - serve the cached shell for any of them, so reopening the
  // app on a deep link with no connection still works. Online, try the
  // network first so a new deploy is picked up, and refresh every cached
  // chunk in the background: this is how a new build's lazy screen chunks
  // get precached even though this file (and so the install event) doesn't
  // change between builds.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (response.ok) {
            event.waitUntil(caches.open(CACHE_NAME).then((cache) => precacheBuild(cache)).catch(() => {}));
          }
          return response;
        })
        .catch(async () => (await caches.match("/", { ignoreVary: true })) ?? Response.error()),
    );
    return;
  }

  // Stale-while-revalidate for static assets: a cached file is served
  // instantly, then refreshed in the background for next time. Anything
  // never cached just goes to the network.
  //
  // ignoreVary: servers may send "Vary: Origin" on static files, and module
  // scripts are CORS-mode requests that carry an Origin header while the
  // precache fetch() above doesn't - without this, every precached chunk
  // failed to match and the app couldn't start offline (found by testing
  // with real network loss, not the demo toggle). Same-origin,
  // content-hashed assets never actually vary by Origin.
  event.respondWith(
    caches.match(request, { ignoreVary: true }).then((cached) => {
      if (cached) {
        fetch(request)
          .then((response) => {
            if (response.ok) caches.open(CACHE_NAME).then((cache) => cache.put(request, response));
          })
          .catch(() => {});
        return cached;
      }
      return fetch(request).then((response) => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
        }
        return response;
      });
    }),
  );
});
