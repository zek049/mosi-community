import { useState } from "react";
import { Share, Smartphone, X } from "lucide-react";
import { currentEnv, isStandalone, shouldShowIosInstallHint } from "../utils/installEnvironment";

const DISMISSED_KEY = "mosi.installHintDismissed";

// How to put Mosi on the home screen, in the words that fit this device:
// - already installed (opened from the home screen): nothing;
// - iPhone/iPad Safari: Safari's own steps (iOS has no install prompt, so
//   this is the only way to find it);
// - anything else: the short generic tip (Chrome/Edge additionally get the
//   browser's real Install button from InstallPrompt.tsx).
// Dismissible; the choice is remembered on this device.
export function InstallHint() {
  const env = currentEnv();
  const [dismissed, setDismissed] = useState(() => {
    try {
      return localStorage.getItem(DISMISSED_KEY) === "1";
    } catch {
      return false;
    }
  });

  if (dismissed || isStandalone(env)) return null;
  const ios = shouldShowIosInstallHint(env);

  function dismiss() {
    setDismissed(true);
    try {
      localStorage.setItem(DISMISSED_KEY, "1");
    } catch {
      // Blocked storage: it just reappears next time.
    }
  }

  return (
    <section aria-label="Add Mosi to your home screen" className="flex items-start gap-3 rounded-xl border border-sage-100 bg-sage-50 py-3 pl-4 pr-1">
      <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white text-forest-700">
        <Smartphone className="h-4 w-4" aria-hidden="true" />
      </span>
      <div className="min-w-0 flex-1 py-0.5">
        <p className="text-sm font-medium text-forest-900">Add Mosi to your home screen</p>
        {ios ? (
          <p className="mt-0.5 text-sm text-forest-900">
            In Safari, tap <Share className="inline h-4 w-4 align-text-bottom" aria-hidden="true" />
            <span className="font-medium"> Share</span>, then <span className="font-medium">Add to Home Screen</span>. Mosi then opens like an app, even without signal.
          </p>
        ) : (
          <p className="mt-0.5 text-sm text-forest-900">
            Use your browser menu ("Install app" or "Add to Home Screen") to open Mosi like an app in the field.
          </p>
        )}
      </div>
      <button
        type="button"
        onClick={dismiss}
        aria-label="Dismiss install tip"
        className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg text-forest-800 hover:bg-sage-100"
      >
        <X className="h-4 w-4" aria-hidden="true" />
      </button>
    </section>
  );
}
