import { useEffect, useState } from "react";
import { useQueries } from "@tanstack/react-query";
import { Download, UserCheck } from "lucide-react";
import * as api from "../../services/api";
import { downloadCsv } from "../../utils/csvExport";
import { localIsoDate } from "../../utils/localDate";
import { usePageTitle } from "../../hooks/usePageTitle";
import { summarizeChwActivity, type ChwActivityRow } from "../../utils/chwActivity";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { Badge } from "../../components/ui/Badge";
import { PageHeader } from "../../components/ui/PageHeader";
import { EmptyState } from "../../components/ui/EmptyState";
import { LoadErrorNotice } from "../../components/LoadErrorNotice";
import { useSyncLog } from "../../hooks/useSyncLog";
import { Pagination } from "../../components/ui/Pagination";

const PAGE_SIZE = 10;

function initials(name: string): string {
  return name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

function formatDateTime(value: string): string {
  return new Date(value).toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function CHWActivity() {
  usePageTitle("CHW Activity");
  const [page, setPage] = useState(1);
  const [chwsQuery, visitsQuery] = useQueries({
    queries: [
      { queryKey: ["chws"], queryFn: api.getChws },
      { queryKey: ["visits"], queryFn: () => api.getVisits() },
    ],
  });
  const syncLogQuery = useSyncLog();

  const loading = chwsQuery.isPending || visitsQuery.isPending || syncLogQuery.isPending;
  const errorObj = chwsQuery.error ?? visitsQuery.error ?? syncLogQuery.error;
  const rows: ChwActivityRow[] | null =
    chwsQuery.data && visitsQuery.data && syncLogQuery.data
      ? summarizeChwActivity(chwsQuery.data, visitsQuery.data, syncLogQuery.data)
      : null;

  useEffect(() => setPage(1), [rows?.length]);
  const pageItems = rows?.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function retry() {
    void chwsQuery.refetch();
    void visitsQuery.refetch();
    void syncLogQuery.refetch();
  }

  function handleExport() {
    if (!rows || rows.length === 0) return;
    downloadCsv(
      `mosi-chw-activity-${localIsoDate()}.csv`,
      ["chw_id", "full_name", "clinic", "visit_count", "last_sync_time", "activity_status"],
      rows.map((row) => [
        row.chw.chw_id,
        row.chw.full_name,
        row.chw.clinic,
        row.visitCount,
        row.lastSyncTime,
        row.isActive ? "Active" : "Inactive",
      ]),
    );
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="CHW Activity"
        description="Visits recorded by each CHW and when their device last synced."
        actions={
          <Button variant="secondary" onClick={handleExport} disabled={!rows || rows.length === 0}>
            <Download className="h-4 w-4" aria-hidden="true" />
            Export CSV
          </Button>
        }
      />

      {errorObj && <LoadErrorNotice error={errorObj} what="CHW activity" onRetry={retry} />}

      {loading && !rows && !errorObj && <p className="text-sm text-stone-500">Loading CHW activity…</p>}

      {rows && rows.length === 0 && <EmptyState icon={UserCheck} title="No CHW accounts found" />}

      {pageItems && pageItems.length > 0 && (
        <>
          {/* Desktop table */}
          <Card className="hidden md:block overflow-hidden p-0">
            <table className="w-full text-sm">
              <thead className="bg-stone-50 border-b border-stone-200 text-left text-xs text-stone-500">
                <tr>
                  <th scope="col" className="px-4 py-2.5 font-medium">Name</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">CHW ID</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Clinic</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Visits</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Last sync</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {pageItems.map((row) => (
                  <tr key={row.chw.chw_id}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <span aria-hidden="true" className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-forest-800 text-xs font-semibold text-white">
                          {initials(row.chw.full_name)}
                        </span>
                        <span className="font-medium text-stone-900">{row.chw.full_name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-stone-600">{row.chw.chw_id}</td>
                    <td className="px-4 py-3 text-stone-600">{row.chw.clinic}</td>
                    <td className="px-4 py-3 text-stone-600">{row.visitCount}</td>
                    <td className="px-4 py-3 text-stone-600">
                      {row.lastSyncTime ? formatDateTime(row.lastSyncTime) : "Never synced"}
                    </td>
                    <td className="px-4 py-3">
                      {row.isActive ? (
                        <Badge variant="success" dot>Active</Badge>
                      ) : (
                        <Badge variant="neutral" dot>Inactive</Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          {/* Mobile cards */}
          <div className="md:hidden space-y-2">
            {pageItems.map((row) => (
              <Card key={row.chw.chw_id} className="p-4">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span aria-hidden="true" className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-forest-800 text-xs font-semibold text-white">
                      {initials(row.chw.full_name)}
                    </span>
                    <p className="font-medium text-stone-900">{row.chw.full_name}</p>
                  </div>
                  {row.isActive ? (
                    <Badge variant="success" dot>Active</Badge>
                  ) : (
                    <Badge variant="neutral" dot>Inactive</Badge>
                  )}
                </div>
                <p className="mt-2 text-xs text-stone-600">
                  {row.chw.chw_id} · {row.chw.clinic}
                </p>
                <p className="mt-1.5 text-xs text-stone-600">
                  {row.visitCount} visits · Last sync: {row.lastSyncTime ? formatDateTime(row.lastSyncTime) : "Never synced"}
                </p>
              </Card>
            ))}
          </div>

          <Pagination page={page} pageSize={PAGE_SIZE} totalItems={rows?.length ?? 0} onPageChange={setPage} itemLabel="CHWs" />
        </>
      )}

      <p className="text-xs text-stone-500 pt-4 border-t border-stone-200">
        Synthetic demonstration data - not real patient records.
      </p>
    </div>
  );
}

export default CHWActivity;
