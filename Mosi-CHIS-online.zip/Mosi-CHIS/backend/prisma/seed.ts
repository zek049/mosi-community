import { randomUUID } from "node:crypto";
import bcrypt from "bcryptjs";
import { prisma } from "../src/db";

// ---------------------------------------------------------------------------
// Mosi CHIS - demo seed data
//
// This script resets Patient/Visit/SyncLog to a clean, repeatable demo state
// every time it runs (safe to re-run whenever a dissertation demo needs a
// fresh start). CHW/supervisor accounts are upserted instead of wiped, so
// login credentials stay stable across reseeds.
//
// All data below is synthetic and generated for demonstration purposes only
// - see the "Synthetic demonstration data" notice shown throughout the app.
// ---------------------------------------------------------------------------

const PIN = "1234";

const MALE_FIRST_NAMES = [
  "Tendai", "Farai", "Tapiwa", "Blessing", "Tinashe", "Takudzwa",
  "Ngonidzashe", "Munashe", "Simbarashe", "Kudakwashe", "Thabani", "Sipho",
  "Mthunzi", "Nkosana", "Wellington", "Brian", "Kelvin", "Prosper",
  "Learnmore", "Godfrey",
];

const FEMALE_FIRST_NAMES = [
  "Chiedza", "Rudo", "Nyasha", "Vimbai", "Tariro", "Ropafadzo", "Panashe",
  "Fadzai", "Memory", "Precious", "Sithembile", "Nomvula", "Thandiwe",
  "Nokuthula", "Constance", "Patience", "Sarudzai", "Rutendo", "Anesu",
  "Loveness",
];

const LAST_NAMES = [
  "Moyo", "Ncube", "Sibanda", "Dube", "Chikwanha", "Mutasa", "Chirwa",
  "Gumbo", "Mabhena", "Banda", "Chikafu", "Mavhungu", "Nyathi", "Zulu",
  "Mhlanga", "Chidziva", "Marufu", "Chinyerere", "Musarurwa", "Chigumba",
];

const VISIT_NOTES: Record<string, string[]> = {
  Immunization: [
    "Received scheduled vaccine dose.",
    "No adverse reaction observed.",
    "Immunization card updated.",
  ],
  Antenatal: [
    "Routine antenatal check-up completed.",
    "Advised on nutrition and rest.",
    "Referred for routine bloodwork.",
  ],
  "Growth Monitoring": [
    "Growth within expected range.",
    "Mild underweight noted, advised follow-up.",
    "Healthy growth progress since last visit.",
  ],
  "HIV/TB Support": [
    "Adherence counselling provided.",
    "Medication refill collected.",
    "Follow-up scheduled in 4 weeks.",
  ],
  "Health Education": [
    "Discussed hygiene and sanitation practices.",
    "Family planning information shared.",
    "Nutrition education session held.",
  ],
  "Disease Surveillance": [
    "No symptoms of communicable disease reported.",
    "Household screened, no concerns noted.",
    "Reported mild flu-like symptoms, monitoring advised.",
  ],
  Other: [
    "General wellness check.",
    "Follow-up on previous concern.",
    "Community outreach visit.",
  ],
};

type ClinicSeed = {
  code: string;
  clinicName: string;
  location: string;
  chwId: string;
  chwFullName: string;
  village: string;
  patientPrefix: string;
};

// Three clinics, not two - deliberately more than the original two-clinic
// demo, so "multi-clinic" is something this seed data actually exercises
// (patient search/list/dashboard all need to work across >2 clinics), not
// just something the schema happens to allow. Application logic must never
// hardcode this list - see backend/src/routes/clinics.ts, which reads
// clinics from the database.
const CLINICS: ClinicSeed[] = [
  {
    code: "MBR",
    clinicName: "Mbare Clinic",
    location: "Mbare, Harare",
    chwId: "CHW001",
    chwFullName: "Jane Moyo",
    village: "Mbare",
    patientPrefix: "MBR",
  },
  {
    code: "HTC",
    clinicName: "Hatcliffe Clinic",
    location: "Hatcliffe, Harare",
    chwId: "CHW002",
    chwFullName: "John Ncube",
    village: "Hatcliffe",
    patientPrefix: "HTC",
  },
  {
    code: "EPW",
    clinicName: "Epworth Clinic",
    location: "Epworth, Harare",
    chwId: "CHW003",
    chwFullName: "Tariro Gumbo",
    village: "Epworth",
    patientPrefix: "EPW",
  },
];

const HEAD_OFFICE_CODE = "HQ";

const PATIENTS_PER_CLINIC = 25;
const DAY_MS = 24 * 60 * 60 * 1000;

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomFloat(min: number, max: number, decimals = 1): number {
  const value = Math.random() * (max - min) + min;
  return Number(value.toFixed(decimals));
}

function randomChoice<T>(items: T[]): T {
  return items[randomInt(0, items.length - 1)];
}

function daysAgo(days: number): Date {
  return new Date(Date.now() - days * DAY_MS);
}

function randomPhoneNumber(): string {
  const prefix = randomChoice(["077", "078", "071", "073"]);
  const rest = Array.from({ length: 7 }, () => randomInt(0, 9)).join("");
  return `${prefix}${rest}`;
}

type AgeBracket = {
  minYears: number;
  maxYears: number;
  weightRange: [number, number];
  heightRange: [number, number];
  visitTypes: string[];
  allowAntenatal: boolean;
};

const AGE_BRACKETS: AgeBracket[] = [
  {
    minYears: 0,
    maxYears: 5,
    weightRange: [3, 20],
    heightRange: [50, 110],
    visitTypes: ["Immunization", "Growth Monitoring", "Health Education", "Disease Surveillance"],
    allowAntenatal: false,
  },
  {
    minYears: 6,
    maxYears: 17,
    weightRange: [18, 65],
    heightRange: [110, 175],
    visitTypes: ["Health Education", "Disease Surveillance", "HIV/TB Support"],
    allowAntenatal: false,
  },
  {
    minYears: 18,
    maxYears: 45,
    weightRange: [50, 95],
    heightRange: [150, 190],
    visitTypes: ["Health Education", "Disease Surveillance", "HIV/TB Support", "Other"],
    allowAntenatal: true,
  },
  {
    minYears: 46,
    maxYears: 85,
    weightRange: [45, 85],
    heightRange: [150, 185],
    visitTypes: ["Health Education", "Disease Surveillance", "HIV/TB Support", "Other"],
    allowAntenatal: false,
  },
];

function buildVitalsAndNotes(visitType: string, bracket: AgeBracket) {
  const recordsVitals = ["Immunization", "Growth Monitoring", "Antenatal", "HIV/TB Support"].includes(
    visitType,
  );
  const recordsBloodPressure = ["Antenatal", "HIV/TB Support", "Disease Surveillance", "Other"].includes(
    visitType,
  );

  const weight = recordsVitals ? randomFloat(bracket.weightRange[0], bracket.weightRange[1]) : null;
  const height = recordsVitals ? randomFloat(bracket.heightRange[0], bracket.heightRange[1], 0) : null;
  const bloodPressure = recordsBloodPressure
    ? `${randomInt(105, 140)}/${randomInt(65, 90)}`
    : null;
  const notes = randomChoice(VISIT_NOTES[visitType] ?? VISIT_NOTES.Other);

  return { weight, height, bloodPressure, notes };
}

async function seedClinics(): Promise<Map<string, string>> {
  const idByCode = new Map<string, string>();

  for (const clinic of CLINICS) {
    const row = await prisma.clinic.upsert({
      where: { code: clinic.code },
      update: { name: clinic.clinicName, location: clinic.location, active: true },
      create: { code: clinic.code, name: clinic.clinicName, location: clinic.location, active: true },
    });
    idByCode.set(clinic.code, row.id);
  }

  const headOffice = await prisma.clinic.upsert({
    where: { code: HEAD_OFFICE_CODE },
    update: { name: "Harare Provincial Health Office", location: "Harare", active: true },
    create: { code: HEAD_OFFICE_CODE, name: "Harare Provincial Health Office", location: "Harare", active: true },
  });
  idByCode.set(HEAD_OFFICE_CODE, headOffice.id);

  return idByCode;
}

async function seedChws(clinicIdByCode: Map<string, string>) {
  const pinHash = await bcrypt.hash(PIN, 10);

  for (const clinic of CLINICS) {
    const clinicId = clinicIdByCode.get(clinic.code);
    if (!clinicId) throw new Error(`Clinic "${clinic.code}" was not seeded before seedChws() ran`);

    await prisma.chw.upsert({
      where: { chw_id: clinic.chwId },
      update: {
        full_name: clinic.chwFullName,
        clinic: clinic.clinicName,
        clinic_id: clinicId,
        status: "active",
      },
      create: {
        chw_id: clinic.chwId,
        full_name: clinic.chwFullName,
        clinic: clinic.clinicName,
        clinic_id: clinicId,
        phone_number: randomPhoneNumber(),
        pin_hash: pinHash,
        role: "CHW",
        status: "active",
      },
    });
  }

  // No supervisor account is defined in the spec's seed data (section 11 only
  // lists CHW001/CHW002), but sections 12/21 require a supervisor login and
  // supervisor dashboard. SUP001 below is a reasonable synthetic addition to
  // make that flow demonstrable - flagged in the STEP 1 report for the user
  // to confirm or rename.
  const headOfficeId = clinicIdByCode.get(HEAD_OFFICE_CODE);
  if (!headOfficeId) throw new Error("Head office clinic was not seeded before seedChws() ran");

  // SUP001 is the organisation-wide ADMINISTRATOR (admin-role feature):
  // every clinic, and manages supervisor accounts. Supervisors themselves
  // are scoped to one clinic - SUP002 below shows that.
  await prisma.chw.upsert({
    where: { chw_id: "SUP001" },
    update: {
      full_name: "Grace Chikwanha",
      clinic: "Harare Provincial Health Office",
      clinic_id: headOfficeId,
      role: "ADMIN",
      status: "active",
    },
    create: {
      chw_id: "SUP001",
      full_name: "Grace Chikwanha",
      clinic: "Harare Provincial Health Office",
      clinic_id: headOfficeId,
      phone_number: randomPhoneNumber(),
      pin_hash: pinHash,
      role: "ADMIN",
      status: "active",
    },
  });

  // A clinic supervisor: sees and manages Mbare Clinic only.
  const mbareId = clinicIdByCode.get("MBR");
  if (!mbareId) throw new Error("Mbare clinic was not seeded before seedChws() ran");
  await prisma.chw.upsert({
    where: { chw_id: "SUP002" },
    update: { full_name: "Farai Mupfumi", clinic: "Mbare Clinic", clinic_id: mbareId, role: "SUPERVISOR", status: "active" },
    create: {
      chw_id: "SUP002",
      full_name: "Farai Mupfumi",
      clinic: "Mbare Clinic",
      clinic_id: mbareId,
      phone_number: randomPhoneNumber(),
      pin_hash: pinHash,
      role: "SUPERVISOR",
      status: "active",
    },
  });

  // A permanently-deactivated demo account, so the "a deactivated CHW must
  // immediately lose access" requirement (section 6/12) is something a
  // reviewer can actually try logging in as (same PIN as everyone else),
  // not just something covered by an automated test.
  const epworthId = clinicIdByCode.get("EPW");
  if (!epworthId) throw new Error("Epworth clinic was not seeded before seedChws() ran");

  await prisma.chw.upsert({
    where: { chw_id: "CHW004" },
    update: {
      full_name: "Nyasha Chidziva",
      clinic: "Epworth Clinic",
      clinic_id: epworthId,
      status: "revoked",
    },
    create: {
      chw_id: "CHW004",
      full_name: "Nyasha Chidziva",
      clinic: "Epworth Clinic",
      clinic_id: epworthId,
      phone_number: randomPhoneNumber(),
      pin_hash: pinHash,
      role: "CHW",
      status: "revoked",
    },
  });
}

async function seedPatientsAndVisits(clinicIdByCode: Map<string, string>) {
  // Wiped and rebuilt on every run so the demo dataset is always in a known,
  // clean state. CHW/supervisor accounts (seeded above via upsert) are left
  // untouched so login credentials never change between reseeds.
  await prisma.syncConflict.deleteMany();
  await prisma.syncLog.deleteMany();
  await prisma.visit.deleteMany();
  await prisma.patient.deleteMany();

  const createdVisitIds: string[] = [];
  const createdPatientIds: string[] = [];

  for (const clinic of CLINICS) {
    const clinicId = clinicIdByCode.get(clinic.code);
    if (!clinicId) throw new Error(`Clinic "${clinic.code}" was not seeded before seedPatientsAndVisits() ran`);

    for (let i = 1; i <= PATIENTS_PER_CLINIC; i++) {
      const bracket = randomChoice(AGE_BRACKETS);
      const ageYears = randomInt(bracket.minYears, bracket.maxYears);
      const gender: "M" | "F" = Math.random() < 0.5 ? "M" : "F";
      const firstName = randomChoice(gender === "M" ? MALE_FIRST_NAMES : FEMALE_FIRST_NAMES);
      const lastName = randomChoice(LAST_NAMES);
      const dateOfBirth = daysAgo(ageYears * 365 + randomInt(0, 364));

      const patientId = `${clinic.patientPrefix}-${String(i).padStart(4, "0")}`;
      const id = randomUUID();
      const createdAt = daysAgo(randomInt(7, 150));
      const updatedAt = new Date(createdAt.getTime() + randomInt(0, 20) * DAY_MS);

      await prisma.patient.create({
        data: {
          id,
          patient_id: patientId,
          first_name: firstName,
          last_name: lastName,
          date_of_birth: dateOfBirth,
          gender,
          village: clinic.village,
          phone_number: Math.random() < 0.9 ? randomPhoneNumber() : null,
          created_at: createdAt,
          updated_at: updatedAt,
          sync_status: "synced",
          clinic_id: clinicId,
          registered_by_chw_id: clinic.chwId,
        },
      });

      createdPatientIds.push(id);

      const eligibleVisitTypes = bracket.allowAntenatal && gender === "F"
        ? [...bracket.visitTypes, "Antenatal"]
        : bracket.visitTypes;

      const visitCount = randomInt(1, 4);
      for (let v = 0; v < visitCount; v++) {
        const visitType = randomChoice(eligibleVisitTypes);
        const { weight, height, bloodPressure, notes } = buildVitalsAndNotes(visitType, bracket);

        const earliestVisit = createdAt.getTime();
        const visitDate = new Date(earliestVisit + Math.random() * (Date.now() - earliestVisit));

        const visitId = randomUUID();
        await prisma.visit.create({
          data: {
            id: visitId,
            patient_id: id,
            chw_id: clinic.chwId,
            visit_date: visitDate,
            visit_type: visitType,
            weight,
            height,
            blood_pressure: bloodPressure,
            notes,
            created_at: visitDate,
            updated_at: visitDate,
            sync_status: "synced",
            clinic_id: clinicId,
          },
        });

        createdVisitIds.push(visitId);
      }
    }
  }

  return { createdPatientIds, createdVisitIds };
}

async function seedSyncLog(createdPatientIds: string[], createdVisitIds: string[]) {
  const sampleVisitIds = createdVisitIds.slice(0, 4);
  const [conflictPatientId] = createdPatientIds;
  const [failedVisitId] = createdVisitIds.slice(-1);

  const entries = [
    ...sampleVisitIds.map((visitId, index) => ({
      record_type: "visit",
      record_id: visitId,
      action: "create",
      status: "success",
      synced_at: daysAgo(index + 1),
    })),
    {
      record_type: "visit",
      record_id: failedVisitId,
      action: "create",
      status: "failed",
      synced_at: daysAgo(2),
    },
    {
      record_type: "patient",
      record_id: conflictPatientId,
      action: "conflict_resolved",
      status: "success",
      synced_at: daysAgo(1),
    },
  ];

  for (const entry of entries) {
    await prisma.syncLog.create({ data: entry });
  }
}

async function main() {
  console.log("Seeding Mosi demo data...");

  const clinicIdByCode = await seedClinics();
  console.log(`  ${clinicIdByCode.size} clinics ready (${CLINICS.map((c) => c.code).join(", ")}, ${HEAD_OFFICE_CODE}).`);

  await seedChws(clinicIdByCode);
  console.log("  Accounts ready: CHW001, CHW002, CHW003, CHW004 [revoked], SUP001 [admin], SUP002 [Mbare supervisor].");

  const { createdPatientIds, createdVisitIds } = await seedPatientsAndVisits(clinicIdByCode);
  console.log(`  Created ${createdPatientIds.length} patients and ${createdVisitIds.length} visits.`);

  await seedSyncLog(createdPatientIds, createdVisitIds);
  console.log("  Sample sync log entries created.");

  console.log("Seed complete.");
}

main()
  .catch((error) => {
    console.error("Seed failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
