import { describe, expect, it } from "vitest";
import { hashContent, resolveConflict } from "../conflictResolver";

describe("resolveConflict", () => {
  const baseContent = { first_name: "Constance", last_name: "Nyathi" };

  it("applies the incoming record when it is newer", () => {
    const result = resolveConflict({
      incomingUpdatedAt: new Date("2026-02-02T00:00:00.000Z"),
      existingUpdatedAt: new Date("2026-01-01T00:00:00.000Z"),
      incomingContent: baseContent,
      existingContent: baseContent,
    });
    expect(result).toEqual({ outcome: "apply", reason: "newer" });
  });

  it("keeps the existing record when the incoming one is older", () => {
    const result = resolveConflict({
      incomingUpdatedAt: new Date("2026-01-01T00:00:00.000Z"),
      existingUpdatedAt: new Date("2026-02-02T00:00:00.000Z"),
      incomingContent: baseContent,
      existingContent: baseContent,
    });
    expect(result).toEqual({ outcome: "keep_existing", reason: "older" });
  });

  it("treats an identical-timestamp retry with identical content as a no-op, not a conflict", () => {
    const sameInstant = new Date("2026-03-01T09:05:00.611Z");
    const result = resolveConflict({
      incomingUpdatedAt: sameInstant,
      existingUpdatedAt: sameInstant,
      incomingContent: { ...baseContent },
      existingContent: { ...baseContent },
    });
    expect(result).toEqual({ outcome: "keep_existing", reason: "identical" });
  });

  it("flags a genuine conflict when timestamps match but content differs", () => {
    const sameInstant = new Date("2026-03-01T09:05:00.611Z");
    const result = resolveConflict({
      incomingUpdatedAt: sameInstant,
      existingUpdatedAt: sameInstant,
      incomingContent: { ...baseContent, first_name: "ConflictingEdit" },
      existingContent: baseContent,
    });
    expect(result).toEqual({ outcome: "flag_conflict", reason: "hash_mismatch" });
  });

  // Regression test for a real bug (Step 3): an incoming raw ISO date
  // string and an existing Date object for the same instant used to hash
  // differently, so every identical-content retry was misflagged as a
  // conflict. hashContent must normalise both the same way.
  it("hashes a Date and the equivalent ISO string identically", () => {
    const asDate = hashContent({ updated_at: new Date("2026-03-01T09:05:00.611Z") });
    const asString = hashContent({ updated_at: "2026-03-01T09:05:00.611Z" });
    expect(asDate).toBe(asString);
  });

  it("hashes identically regardless of key order", () => {
    const a = hashContent({ first_name: "Constance", last_name: "Nyathi" });
    const b = hashContent({ last_name: "Nyathi", first_name: "Constance" });
    expect(a).toBe(b);
  });

  it("produces a different hash when content genuinely differs", () => {
    const a = hashContent({ first_name: "Constance" });
    const b = hashContent({ first_name: "ConflictingEdit" });
    expect(a).not.toBe(b);
  });

  it("treats undefined and null fields the same way", () => {
    const a = hashContent({ phone_number: undefined });
    const b = hashContent({ phone_number: null });
    expect(a).toBe(b);
  });
});
