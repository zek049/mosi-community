import { useState } from "react";
import { useNavigate } from "react-router-dom";
import * as authService from "../services/authService";
import { countPending } from "../db/indexedDb";
import { useNetwork } from "../contexts/NetworkContext";
import { useSync } from "../contexts/SyncContext";
import { plural } from "../utils/syncMessages";
import { ModalDialog } from "./ui/ModalDialog";
import { Button } from "./ui/Button";

export type SignedOutState = { signedOut: true; keptUnsynced: number };

// Sign-out that never silently loses work. With nothing unsynced, it signs
// out at once and removes this user's synced copies from the device. With
// unsynced changes, it stops and offers: sync first, or keep them on this
// device (visible only to this user after they sign in again), or stay.
export function useSignOutFlow() {
  const navigate = useNavigate();
  const { isOnline } = useNetwork();
  const { syncNow } = useSync();
  const [pending, setPending] = useState(0);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState<null | "syncing" | "signing-out">(null);
  const [note, setNote] = useState<string | null>(null);

  async function finish(mode: authService.SignOutMode) {
    setBusy("signing-out");
    const { keptUnsynced } = await authService.signOut(mode);
    setOpen(false);
    setBusy(null);
    const state: SignedOutState = { signedOut: true, keptUnsynced };
    navigate("/login", { replace: true, state });
  }

  async function request() {
    const count = await countPending().catch(() => 0);
    if (count === 0) {
      await finish("keep-unsynced");
      return;
    }
    setPending(count);
    setNote(null);
    setOpen(true);
  }

  async function syncThenSignOut() {
    setBusy("syncing");
    setNote(null);
    await syncNow({ manual: true });
    const left = await countPending().catch(() => pending);
    if (left === 0) {
      await finish("keep-unsynced");
      return;
    }
    setBusy(null);
    setPending(left);
    setNote(`${plural(left, "change is", "changes are")} still waiting - the server didn't accept ${left === 1 ? "it" : "them"} yet.`);
  }

  const dialog = (
    <ModalDialog
      open={open}
      title={`${plural(pending, "change hasn't", "changes haven't")} synced yet`}
      onClose={() => setOpen(false)}
      busy={busy !== null}
      actions={
        <>
          <Button type="button" variant="secondary" onClick={() => setOpen(false)} disabled={busy !== null} autoFocus>
            Stay signed in
          </Button>
          <Button type="button" variant="secondary" onClick={() => void finish("keep-unsynced")} disabled={busy !== null}>
            Sign out, keep them here
          </Button>
          {isOnline && (
            <Button type="button" onClick={() => void syncThenSignOut()} disabled={busy !== null}>
              {busy === "syncing" ? "Syncing…" : "Sync, then sign out"}
            </Button>
          )}
        </>
      }
    >
      <p>They're saved on this device, but the server doesn't have them yet.</p>
      <p>
        If you sign out now they stay on this device, hidden from anyone else who signs in here, and sync the next
        time you sign in.
        {!isOnline && " You're offline, so they can't be synced right now."}
      </p>
      <p>
        Until then, the patient information in {pending === 1 ? "it" : "them"} stays stored on this device, and is not
        encrypted. Only leave unsynced changes on a device your clinic controls.
      </p>
      {note && (
        <p role="status" className="rounded-lg bg-amber-50 px-3 py-2 text-amber-900">
          {note}
        </p>
      )}
    </ModalDialog>
  );

  return { request, dialog };
}
