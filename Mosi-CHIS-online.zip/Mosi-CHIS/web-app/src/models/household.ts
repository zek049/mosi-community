import type { SyncStatus } from "./patient";

// A family / homestead grouping of patients. Created on the device (client
// UUID, works offline) and uploaded in the sync batch; mirrors
// backend/prisma/schema.prisma's Household. Patients point to it through the
// optional patient.household_id.
export interface Household {
  id: string;
  household_code: string;
  village: string;
  created_at: string;
  sync_status: SyncStatus;
  // Server-assigned; present on households downloaded from the server.
  clinic_id?: string;
}
