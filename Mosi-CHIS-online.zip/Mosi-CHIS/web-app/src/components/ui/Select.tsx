import * as SelectPrimitive from "@radix-ui/react-select";
import * as LabelPrimitive from "@radix-ui/react-label";
import { ChevronDown } from "lucide-react";
import { cn } from "../../lib/utils";

export type SelectOption = { value: string; label: string };

type SelectProps = {
  value: string;
  onValueChange: (value: string) => void;
  placeholder: string;
  options: SelectOption[];
  label?: string;
  id?: string;
  /** Accessible name when there's no visible label (compact filters). */
  ariaLabel?: string;
  error?: string;
  disabled?: boolean;
  className?: string;
};

// Radix's Select.Item forbids an empty-string value (it's reserved
// internally to mean "no selection"), but this app's filter dropdowns
// genuinely need a real, always-selectable "All villages"/"All CHWs" item
// bound to "". This sentinel is swapped in/out at the edges (onValueChange
// in, value out) so every caller below still just thinks in plain "" for
// "nothing selected/no filter" - the same convention the native <select>s
// this replaces already used.
const UNSET = "__unset__";

// Shared Radix Select used both as a compact filter (no label, an explicit
// "All X" item with value "") and as a labelled required form field (no such
// item - the placeholder alone represents "nothing chosen yet"), covering
// every <select> this app had. Keyboard nav, typeahead, and correct
// aria wiring all come from Radix rather than being hand-rolled per screen.
export function Select({ value, onValueChange, placeholder, options, label, id, ariaLabel, error, disabled, className = "" }: SelectProps) {
  const triggerId = id ?? label?.toLowerCase().replace(/\s+/g, "-");

  return (
    <div className={label ? "space-y-1.5" : undefined}>
      {label && (
        <LabelPrimitive.Root htmlFor={triggerId} className="block text-sm font-medium text-stone-700">
          {label}
        </LabelPrimitive.Root>
      )}
      <SelectPrimitive.Root
        value={value === "" ? UNSET : value}
        onValueChange={(next) => onValueChange(next === UNSET ? "" : next)}
        disabled={disabled}
      >
        <SelectPrimitive.Trigger
          id={triggerId}
          aria-label={label ? undefined : ariaLabel}
          aria-invalid={error ? "true" : undefined}
          aria-describedby={error && triggerId ? `${triggerId}-error` : undefined}
          className={cn(
            "inline-flex min-h-11 w-full items-center justify-between gap-2 rounded-lg border bg-white px-3.5 py-2.5 text-sm text-stone-700 focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700 disabled:opacity-50 disabled:cursor-not-allowed data-[placeholder]:text-stone-500",
            error ? "border-red-400" : "border-stone-300",
            className,
          )}
        >
          <SelectPrimitive.Value placeholder={placeholder} />
          <SelectPrimitive.Icon>
            <ChevronDown className="h-4 w-4 text-stone-400" aria-hidden="true" />
          </SelectPrimitive.Icon>
        </SelectPrimitive.Trigger>
        <SelectPrimitive.Portal>
          <SelectPrimitive.Content
            position="popper"
            sideOffset={4}
            className="z-50 overflow-hidden rounded-lg border border-stone-200 bg-white shadow-md"
          >
            <SelectPrimitive.Viewport className="p-1">
              {options.map((option) => {
                const itemValue = option.value === "" ? UNSET : option.value;
                return (
                  <SelectPrimitive.Item
                    key={itemValue}
                    value={itemValue}
                    className="relative flex cursor-pointer select-none items-center rounded-md px-3 py-2 min-h-11 text-sm text-stone-700 outline-none data-[highlighted]:bg-sage-50 data-[highlighted]:text-forest-900"
                  >
                    <SelectPrimitive.ItemText>{option.label}</SelectPrimitive.ItemText>
                  </SelectPrimitive.Item>
                );
              })}
            </SelectPrimitive.Viewport>
          </SelectPrimitive.Content>
        </SelectPrimitive.Portal>
      </SelectPrimitive.Root>
      {error && (
        <p id={triggerId ? `${triggerId}-error` : undefined} className="text-sm text-red-700">
          {error}
        </p>
      )}
    </div>
  );
}
