import { calendarDay } from "./localDate";

// Possible-duplicate patient matching - a WARNING for the CHW, never a block.
// Rule: first name + last name + village + date of birth, after trimming,
// collapsing spaces, ignoring case and accents. Mirrors
// backend/src/utils/duplicates.ts (same test table); the server copy runs
// when online so patients registered on other devices are caught too.

export type DuplicateCandidate = { first_name: string; last_name: string; village: string; date_of_birth: string };

export function normalizeForMatch(value: string | null | undefined): string {
  return (value ?? "")
    .normalize("NFKD")
    .replace(/\p{M}/gu, "")
    .trim()
    .replace(/\s+/g, " ")
    .toLowerCase();
}

export function isPossibleDuplicate(a: DuplicateCandidate, b: DuplicateCandidate): boolean {
  return (
    normalizeForMatch(a.first_name) === normalizeForMatch(b.first_name) &&
    normalizeForMatch(a.last_name) === normalizeForMatch(b.last_name) &&
    normalizeForMatch(a.village) === normalizeForMatch(b.village) &&
    calendarDay(a.date_of_birth) === calendarDay(b.date_of_birth)
  );
}

/** Matches among `patients` (archived ones ignored), most recently created first. */
export function findPossibleDuplicates<T extends DuplicateCandidate & { deleted_at?: string | null; created_at?: string }>(
  candidate: DuplicateCandidate,
  patients: T[],
): T[] {
  return patients
    .filter((p) => !p.deleted_at && isPossibleDuplicate(candidate, p))
    .sort((a, b) => ((a.created_at ?? "") < (b.created_at ?? "") ? 1 : -1));
}
