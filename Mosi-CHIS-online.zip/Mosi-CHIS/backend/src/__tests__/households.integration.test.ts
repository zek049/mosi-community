import { beforeEach, describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  process.env.JWT_SECRET = "test-secret-for-integration-tests";
});

const m = vi.hoisted(() => ({
  chwFindUnique: vi.fn(),
  householdFindUnique: vi.fn(),
  householdCreate: vi.fn(),
  householdFindMany: vi.fn(),
  patientFindUnique: vi.fn(),
  patientCreate: vi.fn(),
  patientFindMany: vi.fn(),
  syncLogCreate: vi.fn(),
  auditLogCreate: vi.fn(),
  transaction: vi.fn(),
}));

vi.mock("../db", () => ({
  prisma: {
    chw: { findUnique: m.chwFindUnique },
    household: { findUnique: m.householdFindUnique, create: m.householdCreate, findMany: m.householdFindMany },
    patient: { findUnique: m.patientFindUnique, create: m.patientCreate, findMany: m.patientFindMany },
    syncLog: { create: m.syncLogCreate },
    auditLog: { create: m.auditLogCreate },
    $transaction: m.transaction,
  },
}));

import request from "supertest";
import app from "../app";
import { signSessionToken } from "../middleware/auth";

const HH = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa";
const P = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb";
const now = new Date().toISOString();
const household = { id: HH, household_code: "MBR-7Q2K", village: "Mbare", created_at: now };
const patient = { id: P, patient_id: "MBR-9001", first_name: "A", last_name: "B", date_of_birth: "1990-01-01", gender: "F", village: "Mbare", phone_number: null, created_at: now, updated_at: now, household_id: HH };
const chwAuth = { Authorization: `Bearer ${signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Jane" })}` };

// A tiny in-memory "database" so creates in one step are visible to the next.
let households: Record<string, { id: string; household_code: string; clinic_id: string }>;

beforeEach(() => {
  vi.clearAllMocks();
  households = {};
  m.chwFindUnique.mockResolvedValue({ chw_id: "CHW001", status: "active", locked_until: null, clinic_id: "clinic-a", must_change_pin: false });
  m.householdFindUnique.mockImplementation(async ({ where }: { where: { id?: string; household_code?: string } }) =>
    where.id ? (households[where.id] ?? null) : (Object.values(households).find((h) => h.household_code === where.household_code) ?? null),
  );
  m.householdCreate.mockImplementation(async ({ data }: { data: { id: string; household_code: string; clinic_id: string } }) => {
    households[data.id] = data;
    return data;
  });
  m.patientFindUnique.mockResolvedValue(null);
  m.patientCreate.mockImplementation(async ({ data }: { data: unknown }) => data);
  m.syncLogCreate.mockResolvedValue({});
  m.auditLogCreate.mockResolvedValue({});
  m.transaction.mockImplementation(async (ops: unknown[]) => Promise.all(ops));
});

describe("households in the sync batch (offline-created)", () => {
  it("a household and a patient pointing at it, created offline, both sync in ONE batch (households first)", async () => {
    const res = await request(app).post("/api/sync").set(chwAuth).send({ households: [household], patients: [patient], visits: [] });
    expect(res.status).toBe(200);
    expect(res.body.data.households).toEqual([{ id: HH, status: "synced", reason: "created" }]);
    expect(res.body.data.patients[0]).toMatchObject({ id: P, status: "synced" });
    const createdHousehold = m.householdCreate.mock.calls[0][0].data;
    expect(createdHousehold).toMatchObject({ clinic_id: "clinic-a", created_by_chw_id: "CHW001" }); // from the actor, not the payload
    expect(m.patientCreate.mock.calls[0][0].data.household_id).toBe(HH);
  });

  it("a household re-sent after it was saved is just acknowledged", async () => {
    households[HH] = { ...household, clinic_id: "clinic-a" };
    const res = await request(app).post("/api/sync").set(chwAuth).send({ households: [household], patients: [], visits: [] });
    expect(res.body.data.households[0]).toMatchObject({ status: "synced", reason: "identical" });
    expect(m.householdCreate).not.toHaveBeenCalled();
  });

  it("a code already used by a different household fails just that record", async () => {
    households.other = { id: "other", household_code: "MBR-7Q2K", clinic_id: "clinic-a" };
    const res = await request(app).post("/api/sync").set(chwAuth).send({ households: [household], patients: [], visits: [] });
    expect(res.body.data.households[0]).toMatchObject({ status: "failed", reason: "validation_error" });
  });

  it("a patient pointing at an unknown household, or one in another clinic, fails (stays pending on the device)", async () => {
    let res = await request(app).post("/api/sync").set(chwAuth).send({ patients: [patient], visits: [] });
    expect(res.body.data.patients[0]).toMatchObject({ status: "failed", reason: "validation_error" });
    households[HH] = { ...household, clinic_id: "clinic-b" };
    res = await request(app).post("/api/sync").set(chwAuth).send({ patients: [patient], visits: [] });
    expect(res.body.data.patients[0]).toMatchObject({ status: "failed" });
    expect(m.patientCreate).not.toHaveBeenCalled();
  });

  it("patients without a household still sync exactly as before (old app versions send no households field)", async () => {
    const { household_id: _h, ...plain } = patient;
    const res = await request(app).post("/api/sync").set(chwAuth).send({ patients: [plain], visits: [] });
    expect(res.status).toBe(200);
    expect(res.body.data.patients[0]).toMatchObject({ status: "synced" });
    expect(m.patientCreate.mock.calls[0][0].data.household_id).toBeNull();
  });

  it("validates household fields", async () => {
    const res = await request(app).post("/api/sync").set(chwAuth).send({ households: [{ ...household, household_code: "x" }], patients: [], visits: [] });
    expect(res.body.data.households[0]).toMatchObject({ status: "failed", reason: "validation_error" });
  });
});

describe("REST endpoints", () => {
  it("require a session", async () => {
    expect((await request(app).get("/api/households")).status).toBe(401);
    expect((await request(app).post("/api/households").send(household)).status).toBe(401);
    expect((await request(app).get(`/api/households/${HH}/patients`)).status).toBe(401);
  });

  it("list is scoped to the CHW's clinic, with member counts", async () => {
    m.householdFindMany.mockResolvedValue([{ id: HH, household_code: "MBR-7Q2K", village: "Mbare", clinic_id: "clinic-a", created_at: now, _count: { patients: 3 } }]);
    const res = await request(app).get("/api/households").set(chwAuth);
    expect(m.householdFindMany.mock.calls[0][0].where).toEqual({ clinic_id: "clinic-a" });
    expect(res.body.data[0].member_count).toBe(3);
  });

  it("POST creates in the actor's clinic; a used code is 409", async () => {
    const res = await request(app).post("/api/households").set(chwAuth).send(household);
    expect(res.status).toBe(201);
    expect(m.householdCreate.mock.calls[0][0].data.clinic_id).toBe("clinic-a");
    const again = await request(app).post("/api/households").set(chwAuth).send({ ...household, id: "cccccccc-cccc-4ccc-8ccc-cccccccccccc" });
    expect(again.status).toBe(409);
  });

  it("members: other clinic's household looks like not found", async () => {
    households[HH] = { ...household, clinic_id: "clinic-b" };
    expect((await request(app).get(`/api/households/${HH}/patients`).set(chwAuth)).status).toBe(404);
    households[HH] = { ...household, clinic_id: "clinic-a" };
    m.patientFindMany.mockResolvedValue([{ id: P }]);
    const res = await request(app).get(`/api/households/${HH}/patients`).set(chwAuth);
    expect(res.status).toBe(200);
    expect(res.body.data.patients).toEqual([{ id: P }]);
  });
});
