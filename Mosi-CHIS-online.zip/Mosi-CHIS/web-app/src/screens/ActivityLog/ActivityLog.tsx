import { useId, useState } from "react";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { History } from "lucide-react";
import * as api from "../../services/api";
import * as authService from "../../services/authService";
import { usePageTitle } from "../../hooks/usePageTitle";
import { ACTION_GROUPS, activityDetail, activityTarget, actionLabel } from "../../utils/activityLabels";
import { PageHeader } from "../../components/ui/PageHeader";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { Select } from "../../components/ui/Select";
import { TextField } from "../../components/ui/TextField";
import { EmptyState } from "../../components/ui/EmptyState";
import { Pagination } from "../../components/ui/Pagination";
import { LoadErrorNotice } from "../../components/LoadErrorNotice";

const PAGE_SIZE = 50;
const ALL = "all";
const EMPTY_FILTERS = { action: ALL, actor: ALL, from: "", to: "" };

function when(iso: string): string {
  return new Date(iso).toLocaleString(undefined, { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

// The viewer's own calendar day boundaries, sent as exact instants so the
// server filters by the viewer's day (not UTC's).
const dayStart = (d: string) => new Date(`${d}T00:00:00`).toISOString();
const dayEnd = (d: string) => new Date(`${d}T23:59:59.999`).toISOString();

// Who did what, when, to which record - newest first. Supervisors see their
// own clinic's activity; administrators see every clinic (the server
// decides). PINs and tokens are never recorded, so never shown.
function ActivityLog() {
  usePageTitle("Activity log");
  const isAdmin = authService.getSession()?.chw.role === "ADMIN";
  const clinic = authService.getSession()?.chw.clinic;
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [page, setPage] = useState(1);
  const resultsId = useId();

  const rangeError = filters.from && filters.to && filters.from > filters.to ? "The start date is after the end date." : null;
  const query = {
    page,
    limit: PAGE_SIZE,
    action: filters.action === ALL ? undefined : filters.action,
    actor_id: filters.actor === ALL ? undefined : filters.actor,
    from: filters.from ? dayStart(filters.from) : undefined,
    to: filters.to ? dayEnd(filters.to) : undefined,
  };
  const logQuery = useQuery({
    queryKey: ["activityLog", query],
    queryFn: () => api.getActivityLog(query),
    placeholderData: keepPreviousData,
    enabled: !rangeError,
  });
  const peopleQuery = useQuery({ queryKey: ["chws"], queryFn: api.getChws });

  function update(change: Partial<typeof EMPTY_FILTERS>) {
    setFilters((f) => ({ ...f, ...change }));
    setPage(1);
  }

  const entries = logQuery.data?.data;
  const total = logQuery.data?.pagination.total ?? 0;
  const filtered = JSON.stringify(filters) !== JSON.stringify(EMPTY_FILTERS);

  return (
    <div className="max-w-5xl space-y-6">
      <PageHeader
        title="Activity log"
        description={isAdmin ? "Who did what across every clinic, newest first." : `Who did what in ${clinic ?? "your clinic"}, newest first.`}
      />

      <Card>
        <form className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-label="Filter activity" aria-controls={resultsId} onSubmit={(e) => e.preventDefault()}>
          <Select
            label="Activity"
            id="activity_action"
            value={filters.action}
            onValueChange={(v) => update({ action: v })}
            placeholder="All activity"
            options={[{ value: ALL, label: "All activity" }, ...ACTION_GROUPS.map((g) => ({ value: g.actions.join(","), label: g.label }))]}
          />
          <Select
            label="Person"
            id="activity_actor"
            value={filters.actor}
            onValueChange={(v) => update({ actor: v })}
            placeholder="Everyone"
            options={[
              { value: ALL, label: "Everyone" },
              ...(peopleQuery.data ?? [])
                .slice()
                .sort((a, b) => a.full_name.localeCompare(b.full_name))
                .map((c) => ({ value: c.chw_id, label: `${c.full_name} (${c.chw_id})` })),
            ]}
          />
          <TextField label="From" name="activity_from" type="date" value={filters.from} onChange={(e) => update({ from: e.target.value })} className="text-base sm:text-sm" />
          <TextField label="To" name="activity_to" type="date" value={filters.to} onChange={(e) => update({ to: e.target.value })} error={rangeError ?? undefined} className="text-base sm:text-sm" />
        </form>
        {filtered && (
          <Button type="button" variant="ghost" className="mt-3 min-h-11" onClick={() => update(EMPTY_FILTERS)}>
            Clear filters
          </Button>
        )}
      </Card>

      <section id={resultsId} aria-labelledby={`${resultsId}-heading`} aria-busy={logQuery.isFetching}>
        <h2 id={`${resultsId}-heading`} className="sr-only">
          Activity
        </h2>
        <p role="status" className="mb-2 text-sm text-stone-600">
          {logQuery.isPending ? "Loading activity…" : logQuery.isError ? "" : `${total} ${total === 1 ? "entry" : "entries"}${filtered ? " match the filters" : ""}`}
        </p>
        {logQuery.isError && <LoadErrorNotice error={logQuery.error} what="the activity log" onRetry={() => void logQuery.refetch()} />}
        {entries && entries.length === 0 && (
          <EmptyState icon={History} title={filtered ? "Nothing matches these filters" : "No activity yet"} description={filtered ? "Try a wider date range or 'All activity'." : "Sign-ins, records, reviews and account changes will appear here."} />
        )}
        {entries && entries.length > 0 && (
          <ol className="divide-y divide-stone-100 overflow-hidden rounded-xl border border-stone-200 bg-white">
            {entries.map((e) => {
              const detail = activityDetail(e);
              const target = activityTarget(e);
              const who = e.actor_id ? `${e.actor_name ?? e.actor_id} (${e.actor_id})` : "Someone not signed in";
              return (
                <li key={e.id} className="grid gap-1 px-4 py-3 sm:grid-cols-[11rem_1fr] sm:gap-4">
                  <time dateTime={e.created_at} className="text-xs text-stone-600 sm:pt-0.5">
                    {when(e.created_at)}
                  </time>
                  <div className="min-w-0">
                    <p className="text-sm text-stone-900">
                      <span className="font-semibold">{who}</span> · {actionLabel(e.action)}
                      {target && <span className="text-stone-700"> · {target}</span>}
                    </p>
                    {detail && <p className="mt-0.5 break-words text-sm text-stone-700">{detail}</p>}
                    {isAdmin && <p className="mt-0.5 text-xs text-stone-600">{e.clinic_name ?? "No clinic"}</p>}
                  </div>
                </li>
              );
            })}
          </ol>
        )}
        <div className="mt-3">
          <Pagination page={page} pageSize={PAGE_SIZE} totalItems={total} onPageChange={setPage} itemLabel="entries" />
        </div>
      </section>
    </div>
  );
}

export default ActivityLog;
