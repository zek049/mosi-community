import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from "react";

// One polite live region for the whole app, so connection/sync changes
// ("You're offline", "3 changes synced") reach screen-reader users without
// them having to find a status pill visually. Deliberately a single region
// with a short cool-down rather than one per component: several regions
// firing at once is the "announcement spam" the brief warns against.
type AnnouncerValue = { announce: (message: string) => void };

const AnnouncerContext = createContext<AnnouncerValue | undefined>(undefined);

export function AnnouncerProvider({ children }: { children: ReactNode }) {
  const [message, setMessage] = useState("");
  const lastRef = useRef<{ text: string; at: number }>({ text: "", at: 0 });

  const announce = useCallback((text: string) => {
    const now = Date.now();
    // Same message within 3s = the same event reported twice (e.g. both the
    // online event and a sync starting) - say it once.
    if (lastRef.current.text === text && now - lastRef.current.at < 3000) return;
    lastRef.current = { text, at: now };
    // Clearing first guarantees assistive tech treats a repeated message
    // (same text, later event) as new content worth reading.
    setMessage("");
    window.setTimeout(() => setMessage(text), 50);
  }, []);

  return (
    <AnnouncerContext.Provider value={{ announce }}>
      {children}
      <div role="status" aria-live="polite" aria-atomic="true" className="sr-only">
        {message}
      </div>
    </AnnouncerContext.Provider>
  );
}

export function useAnnouncer(): AnnouncerValue {
  const context = useContext(AnnouncerContext);
  if (!context) throw new Error("useAnnouncer must be used within an AnnouncerProvider");
  return context;
}
