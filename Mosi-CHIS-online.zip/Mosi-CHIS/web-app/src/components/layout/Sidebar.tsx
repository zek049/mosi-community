import { Link, useLocation } from "react-router-dom";
import { LogOut } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Logo } from "../Logo";
import { cn } from "../../lib/utils";

// badge: a count of things needing attention behind this item (e.g. open
// sync conflicts), shown as a number, never as colour alone.
export type NavItem = { to: string; label: string; icon: LucideIcon; end?: boolean; badge?: number };

type SidebarProps = {
  navItems: NavItem[];
  userName: string;
  userSubtitle: string;
  onSignOut: () => void;
};

function initials(name: string): string {
  return name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

// Desktop-only (md:flex, hidden below that - MobileTopBar/MobileBottomNav
// take over there). Dark forest-teal, per the reference, rather than this
// app's earlier light header bar - the app's one piece of "furniture" that
// stays constant while screens underneath change.
export function Sidebar({ navItems, userName, userSubtitle, onSignOut }: SidebarProps) {
  const location = useLocation();

  return (
    <aside className="hidden md:fixed md:inset-y-0 md:flex md:w-60 md:flex-col bg-sidebar">
      <div className="px-5 py-5">
        <Logo onDark size="sm" />
      </div>

      <nav aria-label="Main" className="flex-1 space-y-0.5 overflow-y-auto px-3">
        {navItems.map((item) => {
          const active = item.end ? location.pathname === item.to : location.pathname.startsWith(item.to);
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              aria-current={active ? "page" : undefined}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                active ? "bg-white/10 text-white" : "text-white/65 hover:bg-white/5 hover:text-white",
              )}
            >
              <Icon className="h-5 w-5 shrink-0" aria-hidden="true" />
              <span className="flex-1">{item.label}</span>
              {(item.badge ?? 0) > 0 && (
                <span className="rounded-full bg-amber-400 px-2 py-0.5 text-xs font-semibold text-forest-900">
                  <span className="sr-only">, </span>
                  {item.badge}
                  <span className="sr-only"> open</span>
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-white/10 px-3 py-4">
        <div className="flex items-center gap-2.5 px-2 py-1.5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/10 text-xs font-semibold text-white">
            {initials(userName)}
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-medium text-white">{userName}</p>
            <p className="truncate text-xs text-white/75">{userSubtitle}</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onSignOut}
          className="mt-1 flex w-full items-center gap-2.5 rounded-lg px-2 py-2 text-sm text-white/65 transition-colors hover:bg-white/5 hover:text-white"
        >
          <LogOut className="h-4 w-4" aria-hidden="true" />
          Sign out
        </button>
      </div>
    </aside>
  );
}
