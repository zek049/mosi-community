import pino from "pino";

// Structured JSON logs in production (so they can be shipped to a log
// aggregator), human-readable pretty-printing in development, and silent
// during tests (vitest.setup / npm test sets NODE_ENV=test) so request logs
// don't drown out test output. pino-pretty is a devDependency only - it must
// never be required in a production install.
export const LOG_REDACT = {
  paths: ["req.headers.cookie", "req.headers.authorization", 'res.headers["set-cookie"]'],
  censor: "[redacted]",
};

export const logger = pino({
  // Request logs (pino-http) include headers. The session cookie / bearer
  // token would let anyone with log access act as that user until it
  // expires, so they're never written out.
  redact: LOG_REDACT,
  level: process.env.NODE_ENV === "test" ? "silent" : (process.env.LOG_LEVEL ?? "info"),
  transport:
    process.env.NODE_ENV === "production" || process.env.NODE_ENV === "test"
      ? undefined
      : { target: "pino-pretty", options: { colorize: true, translateTime: "HH:MM:ss", ignore: "pid,hostname" } },
});
