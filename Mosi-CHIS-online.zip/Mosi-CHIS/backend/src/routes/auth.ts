import { Router } from "express";
import bcrypt from "bcryptjs";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { signSessionToken, authenticateForPinChange } from "../middleware/auth";
import { isWeakPin, WEAK_PIN_MESSAGE } from "../utils/pinPolicy";
import { loginLimiter } from "../middleware/rateLimit";
import { parseBody, loginSchema, changePinSchema } from "../validation/schemas";
import { writeAuditLog } from "../utils/audit";
import { setSessionCookie, clearSessionCookie } from "../utils/sessionCookie";

const router = Router();

// Failed-PIN lockout (section 11): five wrong PINs locks the account for 15
// minutes. Both numbers are intentionally forgiving for field conditions -
// a CHW fumbling a 4-digit PIN a couple of times on a cracked phone screen
// is the common case, not an attacker; the login rate limiter (10 attempts
// per 15 minutes per IP+chw_id, see middleware/rateLimit.ts) is the other
// half of this defense.
// A real bcrypt hash (cost 10) of a random value nobody knows, used only to
// spend the same time on unknown IDs as on real ones.
const DUMMY_HASH = "$2a$10$CwTycUXWue0Thq9StjUM0uJ8.y4KD3s7RQ6eGv0xTdfX3Ri3mQ9iS";

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

router.post("/login", loginLimiter, async (req, res) => {
  const { chw_id: chwId, pin } = parseBody(loginSchema, req.body ?? {});

  const chw = await prisma.chw.findUnique({ where: { chw_id: chwId } });

  // Exactly the same message and status code whichever of "CHW doesn't
  // exist" / "PIN is wrong" / "account is locked" is actually true (section
  // 11) - only the audit log (server-side only) records which one it was.
  const invalidCredentials = () => new AppError(401, "Invalid CHW ID or PIN");

  if (!chw) {
    // Someone whose account REQUEST is still waiting: tell them so - but
    // only if they've proven the PIN they chose for it, so this can't be
    // used to discover pending request IDs.
    const pending = await prisma.accountRequest.findFirst({
      where: { requested_chw_id: chwId, status: "pending" },
      select: { pin_hash: true },
    });
    if (pending?.pin_hash && (await bcrypt.compare(pin, pending.pin_hash))) {
      await writeAuditLog({ action: "LOGIN_FAILURE", resourceType: "chw", resourceId: chwId, metadata: { reason: "request_pending" } });
      throw new AppError(403, "Your account request is waiting for a supervisor to approve it.", "ACCOUNT_PENDING");
    }
    // Same bcrypt cost as a real wrong-PIN check, so response time doesn't
    // reveal which CHW IDs exist.
    if (!pending?.pin_hash) await bcrypt.compare(pin, DUMMY_HASH);
    await writeAuditLog({ action: "LOGIN_FAILURE", resourceType: "chw", resourceId: chwId, metadata: { reason: "not_found" } });
    throw invalidCredentials();
  }

  if (chw.locked_until && chw.locked_until.getTime() > Date.now()) {
    await writeAuditLog({ action: "LOGIN_FAILURE", resourceType: "chw", resourceId: chwId, clinicId: chw.clinic_id, metadata: { reason: "locked" } });
    throw invalidCredentials();
  }

  const pinMatches = await bcrypt.compare(pin, chw.pin_hash);
  if (!pinMatches) {
    const failedCount = chw.failed_login_count + 1;
    const lockingNow = failedCount >= MAX_FAILED_ATTEMPTS;

    await prisma.chw.update({
      where: { chw_id: chwId },
      data: {
        failed_login_count: lockingNow ? 0 : failedCount,
        locked_until: lockingNow ? new Date(Date.now() + LOCKOUT_MINUTES * 60 * 1000) : null,
      },
    });

    await writeAuditLog({ action: "LOGIN_FAILURE", resourceType: "chw", resourceId: chwId, clinicId: chw.clinic_id, metadata: { reason: "bad_pin", failedCount } });
    if (lockingNow) {
      await writeAuditLog({ action: "ACCOUNT_LOCKED", resourceType: "chw", resourceId: chwId, clinicId: chw.clinic_id, metadata: { minutes: LOCKOUT_MINUTES } });
    }

    throw invalidCredentials();
  }

  // Account status is revealed ONLY to someone who has just proven the PIN
  // (so it can't be used to discover which IDs exist). None of these get a
  // session. The code lets the app also withdraw any offline sign-in it has
  // cached for this account.
  if (chw.status !== "active") {
    await writeAuditLog({ action: "LOGIN_FAILURE", resourceType: "chw", resourceId: chwId, clinicId: chw.clinic_id, metadata: { reason: chw.status } });
    throw new AppError(403, "This account has been deactivated", "ACCOUNT_REVOKED");
  }

  await prisma.chw.update({
    where: { chw_id: chwId },
    data: { failed_login_count: 0, locked_until: null, last_login_at: new Date() },
  });

  await writeAuditLog({
    actor: { chwId: chw.chw_id, role: chw.role, clinicId: chw.clinic_id },
    action: "LOGIN_SUCCESS",
    resourceType: "chw",
    resourceId: chwId,
  });

  const token = signSessionToken({
    chwId: chw.chw_id,
    role: chw.role,
    fullName: chw.full_name,
  });

  // The token is set as an httpOnly cookie, not returned in the JSON body -
  // returning it both ways would defeat the point (see Security & data
  // isolation in the README). The frontend never sees or stores the raw
  // token at all; the browser attaches the cookie automatically.
  setSessionCookie(res, token);

  res.json({
    success: true,
    data: {
      chw: {
        chw_id: chw.chw_id,
        full_name: chw.full_name,
        clinic: chw.clinic,
        clinic_id: chw.clinic_id,
        role: chw.role,
        // true after a supervisor set a temporary PIN: the app must ask for a
        // new one; every other API call is refused until then.
        must_change_pin: chw.must_change_pin,
      },
    },
  });
});

// Choose a new PIN. Required after a supervisor-set (temporary) PIN; also
// usable any time. Wrong current PINs count towards the same lockout as
// sign-in, so this can't be used to guess PINs.
router.post("/change-pin", authenticateForPinChange, async (req, res) => {
  const { current_pin: currentPin, new_pin: newPin } = parseBody(changePinSchema, req.body ?? {});
  const chw = await prisma.chw.findUnique({ where: { chw_id: req.user!.chwId } });
  if (!chw) throw new AppError(401, "Invalid or expired session");

  if (!(await bcrypt.compare(currentPin, chw.pin_hash))) {
    const failedCount = chw.failed_login_count + 1;
    const lockingNow = failedCount >= MAX_FAILED_ATTEMPTS;
    await prisma.chw.update({
      where: { chw_id: chw.chw_id },
      data: {
        failed_login_count: lockingNow ? 0 : failedCount,
        locked_until: lockingNow ? new Date(Date.now() + LOCKOUT_MINUTES * 60 * 1000) : null,
      },
    });
    await writeAuditLog({ actor: req.user, action: "LOGIN_FAILURE", resourceType: "chw", resourceId: chw.chw_id, metadata: { reason: "change_pin_bad_current", failedCount } });
    throw new AppError(401, "Your current PIN isn't right.", "BAD_CURRENT_PIN");
  }
  if (newPin === currentPin) throw new AppError(400, "Choose a PIN that's different from the current one.", "SAME_PIN");
  if (isWeakPin(newPin)) throw new AppError(400, WEAK_PIN_MESSAGE, "WEAK_PIN");

  await prisma.chw.update({
    where: { chw_id: chw.chw_id },
    data: { pin_hash: await bcrypt.hash(newPin, 10), must_change_pin: false, failed_login_count: 0, locked_until: null },
  });
  await writeAuditLog({ actor: req.user, action: "PIN_CHANGED", resourceType: "chw", resourceId: chw.chw_id, requestId: req.requestId, metadata: { was_temporary: chw.must_change_pin } });
  res.json({ success: true, data: { must_change_pin: false } });
});

// No auth required to call this - it only ever clears whatever cookie the
// browser sent (or no-ops if there wasn't one), so it can't be used to
// affect anyone else's session, and a client with an already-expired/
// invalid token still needs to be able to clear it.
router.post("/logout", (_req, res) => {
  clearSessionCookie(res);
  res.json({ success: true, message: "Signed out" });
});

export default router;
