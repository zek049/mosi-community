import Dexie, { type Table } from "dexie";
import type { Patient } from "../models/patient";
import type { Visit } from "../models/visit";
import type { Chw } from "../models/chw";
import type { Household } from "../models/household";
import { getStoredSession } from "../utils/session";

// A pending patient/visit's sync_status stays "pending" whether it has
// never been attempted or has been attempted and rejected - the two-value
// sync_status enum has no room for a third state. This table lets the Sync
// screen tell "waiting" apart from "couldn't sync" and "needs review";
// written by services/syncService.ts after every batch, keyed by the
// patient/visit id it describes.
export type SyncAttemptStatus = "failed" | "conflict";

export interface SyncAttemptRecord {
  id: string;
  record_type: "patient" | "visit" | "household";
  status: SyncAttemptStatus;
  message?: string;
  attempted_at: string;
}

const SCHEMA = {
  patients: "id, patient_id, village, sync_status, last_name",
  visits: "id, patient_id, chw_id, visit_date, visit_type, sync_status",
  chws: "chw_id, role",
  syncAttempts: "id, record_type, status",
};

// The offline-first local store. patients/visits are keyed by the same
// client-generated UUID used everywhere else, so a record created here can
// be pushed to POST /api/sync with no transformation.
// Version 2 (households feature) only ADDS a households store and a
// household_id index on patients; Dexie upgrades an existing version-1
// database in place and keeps every record.
const SCHEMA_V2 = {
  ...SCHEMA,
  patients: "id, patient_id, village, sync_status, last_name, household_id",
  households: "id, household_code, village, sync_status",
};

export class MosiDatabase extends Dexie {
  households!: Table<Household, string>;
  patients!: Table<Patient, string>;
  visits!: Table<Visit, string>;
  chws!: Table<Chw, string>;
  syncAttempts!: Table<SyncAttemptRecord, string>;

  constructor(name: string) {
    super(name);
    this.version(1).stores(SCHEMA);
    this.version(2).stores(SCHEMA_V2);
  }
}

// ---------------------------------------------------------------------
// One database PER SIGNED-IN USER (device privacy)
//
// Each account gets its own IndexedDB database, named after its CHW ID.
// The app only ever opens the database of whoever is signed in, so the
// next person to sign in on a shared device can't see - or accidentally
// sync - someone else's cached or unsynced records through the app. (The
// data is NOT encrypted: someone with the device and browser developer
// tools could still read another account's database. Clearing on
// sign-out, below, keeps what's left there to a minimum.)
// ---------------------------------------------------------------------

/** The database used by versions of Mosi before per-user storage. */
export const LEGACY_DB_NAME = "mosi-chis";
const SIGNED_OUT_DB_NAME = "mosi-chis-signed-out";

export function dbNameFor(chwId: string): string {
  return `mosi-chis-user-${encodeURIComponent(chwId.trim().toUpperCase())}`;
}

function databaseForSession(): MosiDatabase {
  const chwId = getStoredSession()?.chw.chw_id;
  // Signed out: an instance that is never queried (every data screen is
  // behind a sign-in guard), so it's never actually opened or created.
  return new MosiDatabase(chwId ? dbNameFor(chwId) : SIGNED_OUT_DB_NAME);
}

// `export let` is a live binding: every module that imports `db` sees the
// new database as soon as switchDatabaseTo() runs - no import changes.
export let db: MosiDatabase = databaseForSession();

export function switchDatabaseTo(chwId: string | null): void {
  const name = chwId ? dbNameFor(chwId) : SIGNED_OUT_DB_NAME;
  if (db.name === name) return;
  db.close();
  db = new MosiDatabase(name);
}

export async function countPendingPatients(): Promise<number> {
  return db.patients.where("sync_status").equals("pending").count();
}

export async function countPendingVisits(): Promise<number> {
  return db.visits.where("sync_status").equals("pending").count();
}

export async function countPending(): Promise<number> {
  const [patients, visits, households] = await Promise.all([
    countPendingPatients(),
    countPendingVisits(),
    db.households.where("sync_status").equals("pending").count(),
  ]);
  return patients + visits + households;
}

/**
 * Sign-out cleanup for the current user's database. Removes every record
 * that is already safely on the server (synced patients/visits, the CHW
 * directory, stale sync markers). Records still waiting to sync are KEPT -
 * they're never deleted without the user's explicit, informed choice (see
 * wipeCurrentUserData). If nothing is left, the whole database is deleted.
 * Returns how many unsynced records were kept.
 */
export async function clearSyncedDataForSignOut(): Promise<number> {
  // Point the app at the signed-out instance FIRST, so no screen that's
  // still mounted during sign-out can reopen this database (which would
  // block deleting it); then clean up through a private connection.
  const name = db.name;
  switchDatabaseTo(null);
  const target = new MosiDatabase(name);
  const kept = await target.transaction("rw", [target.patients, target.visits, target.households, target.chws, target.syncAttempts], async () => {
    await target.patients.where("sync_status").equals("synced").delete();
    await target.visits.where("sync_status").equals("synced").delete();
    await target.households.where("sync_status").equals("synced").delete();
    await target.chws.clear();
    const [pendingPatientIds, pendingVisitIds, pendingHouseholdIds] = await Promise.all([
      target.patients.toCollection().primaryKeys(),
      target.visits.toCollection().primaryKeys(),
      target.households.toCollection().primaryKeys(),
    ]);
    const stillPending = new Set<string>([...pendingPatientIds, ...pendingVisitIds, ...pendingHouseholdIds]);
    // Keep a "couldn't sync" marker only for records that are still here.
    await target.syncAttempts.filter((a) => !stillPending.has(a.id)).delete();
    return stillPending.size;
  });
  target.close();
  if (kept === 0) await Dexie.delete(name);
  return kept;
}

/** "Remove my data from this device": deletes everything, including unsynced changes. */
export async function wipeCurrentUserData(): Promise<void> {
  const name = db.name;
  switchDatabaseTo(null);
  await Dexie.delete(name);
}

/**
 * One-time, DETERMINISTIC move of unsynced records out of the database used
 * before per-user storage ("mosi-chis"), run when a CHW signs in.
 *
 * Ownership is only ever taken from data that proves it - never guessed:
 *   - An unsynced VISIT carries chw_id, set from the signed-in session when
 *     it was recorded (and the server rejects a visit whose chw_id isn't
 *     the sender's). It moves only to that CHW.
 *   - An unsynced PATIENT has no owner field (a patient isn't tied to one
 *     CHW, and the server assigns registered_by only when it syncs). Its
 *     owner therefore can't be established, so it is NEVER moved to whoever
 *     signs in. It stays in the old database as UNASSIGNED: not shown, not
 *     synced, not deleted. Visits for such a patient stay with it, so the
 *     two are never split up (a visit synced without its patient would be
 *     rejected by the server).
 *   - Synced records are already on the server; they're dropped here and
 *     reloaded by the normal sign-in refresh.
 *
 * The old database is deleted only once nothing unsynced remains in it.
 * Resolving UNASSIGNED patients needs a supervisor/administrator on the
 * device - see countUnassignedLegacyRecords() and the README.
 */
export async function migrateLegacyDatabase(chwId: string, role: string): Promise<void> {
  if (role !== "CHW" || !(await Dexie.exists(LEGACY_DB_NAME))) return;
  const legacy = new MosiDatabase(LEGACY_DB_NAME);
  try {
    const [pendingPatients, pendingVisits, attempts] = await Promise.all([
      legacy.patients.where("sync_status").equals("pending").toArray(),
      legacy.visits.where("sync_status").equals("pending").toArray(),
      legacy.syncAttempts.toArray(),
    ]);
    const unassignedPatientIds = new Set(pendingPatients.map((p) => p.id));
    const mine = pendingVisits.filter((v) => v.chw_id === chwId && !unassignedPatientIds.has(v.patient_id));
    const movedIds = new Set(mine.map((v) => v.id));

    if (mine.length > 0) {
      await db.transaction("rw", [db.visits, db.syncAttempts], async () => {
        await db.visits.bulkPut(mine);
        await db.syncAttempts.bulkPut(attempts.filter((a) => movedIds.has(a.id)));
      });
    }

    const remainingPending = pendingPatients.length + pendingVisits.length - mine.length;
    if (remainingPending === 0) {
      legacy.close();
      await Dexie.delete(LEGACY_DB_NAME);
      return;
    }
    // Keep only what is still unsynced and unowned-or-someone-else's.
    await legacy.transaction("rw", [legacy.patients, legacy.visits, legacy.chws, legacy.syncAttempts], async () => {
      await legacy.patients.where("sync_status").equals("synced").delete();
      await legacy.visits.filter((v) => v.sync_status !== "pending" || movedIds.has(v.id)).delete();
      await legacy.chws.clear();
      await legacy.syncAttempts.filter((a) => movedIds.has(a.id)).delete();
    });
    legacy.close();
  } catch {
    // Never block sign-in on this; the old database is left as it was and
    // the move is tried again at the next sign-in.
    legacy.close();
  }
}

/** Unsynced records still held in the old shared database (not visible in the app). */
export async function countUnassignedLegacyRecords(): Promise<{ patients: number; visits: number }> {
  if (!(await Dexie.exists(LEGACY_DB_NAME))) return { patients: 0, visits: 0 };
  const legacy = new MosiDatabase(LEGACY_DB_NAME);
  try {
    const [patients, visits] = await Promise.all([
      legacy.patients.where("sync_status").equals("pending").count(),
      legacy.visits.where("sync_status").equals("pending").count(),
    ]);
    return { patients, visits };
  } finally {
    legacy.close();
  }
}
