import type { InputHTMLAttributes, ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import * as LabelPrimitive from "@radix-ui/react-label";
import { cn } from "../../lib/utils";

type TextFieldProps = InputHTMLAttributes<HTMLInputElement> & {
  label?: string;
  error?: string;
  icon?: LucideIcon;
  endAdornment?: ReactNode;
};

// Accessible by default (section 29): Radix's Label primitive (guaranteed
// correct click-to-focus wiring to htmlFor) plus aria-invalid/aria-describedby
// on the input so a screen reader announces an error - not just a colour
// change. `label` is optional so this doubles as the plain search input
// (Patient List) without an empty label element in the DOM.
export function TextField({ label, error, id, icon: Icon, endAdornment, className = "", ...props }: TextFieldProps) {
  const inputId = id ?? props.name;

  return (
    <div className="space-y-1.5">
      {label && (
        <LabelPrimitive.Root htmlFor={inputId} className="block text-sm font-medium text-stone-700">
          {label}
        </LabelPrimitive.Root>
      )}
      <div className="relative">
        {Icon && (
          <Icon
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400"
            aria-hidden="true"
          />
        )}
        <input
          id={inputId}
          className={cn(
            "w-full rounded-lg border px-3.5 py-2.5 text-sm text-stone-900 placeholder:text-stone-500 focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700",
            error ? "border-red-400" : "border-stone-300",
            Icon && "pl-9",
            endAdornment && "pr-10",
            className,
          )}
          aria-invalid={error ? "true" : undefined}
          aria-describedby={error ? `${inputId}-error` : undefined}
          {...props}
        />
        {endAdornment && <div className="absolute right-2.5 top-1/2 -translate-y-1/2">{endAdornment}</div>}
      </div>
      {error && (
        <p id={`${inputId}-error`} className="text-sm text-red-700">
          {error}
        </p>
      )}
    </div>
  );
}
