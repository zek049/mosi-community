-- Standard post-test cleanup (test data only, identified by its markers).
begin;
create temp table t as
  select id::text id from patients where patient_id ~ '^P[0-9]+-'
  union all select v.id::text from visits v join patients p on p.id=v.patient_id where p.patient_id ~ '^P[0-9]+-'
  union all select id::text from visits where notes ~ '^P5-[0-9]+ legacy' or notes ~ '^P13-[0-9]+ follow-up'
  union all select v.id::text from visits v join patients p on p.id=v.patient_id
     where p.patient_id = 'MBR-0019' and v.visit_type='Growth Monitoring' and v.weight = 14.2;
create temp table th as select distinct household_id id from patients where patient_id ~ '^P[0-9]+-' and household_id is not null;
delete from sync_conflicts where record_id::text in (select id from t);
delete from sync_log where record_id::text in (select id from t);
delete from visits where id::text in (select id from t);
delete from patients where id::text in (select id from t);
delete from sync_log where record_id::text in (select id::text from th);
delete from households where id in (select id from th) and not exists (select 1 from patients p where p.household_id = households.id);
delete from account_requests where requested_chw_id ~ '^T[0-9]+[A-Z][0-9]+$';
delete from chws where chw_id ~ '^T[0-9]+[A-Z][0-9]+$' and not exists (select 1 from visits v where v.chw_id = chws.chw_id);
-- Demo accounts back to the demo PIN 1234 (PIN tests change CHW002's).
update chws set pin_hash='$2b$10$j2yWE3OSbOpD7RKdE0UureY38br26zx3oCjzYq9sHmAl/k7SJ.W6m', must_change_pin=false, failed_login_count=0, locked_until=null where chw_id in ('CHW001','CHW002','CHW003','SUP001','SUP002');
select (select count(*) from patients where deleted_at is null) patients, (select count(*) from visits where deleted_at is null) visits,
       (select count(*) from sync_conflicts where status='open') open_conflicts, (select count(*) from chws) chws, (select count(*) from account_requests) requests, (select count(*) from households) households;
commit;
