import { Link } from "react-router-dom";
import * as authService from "../../services/authService";
import { homeRouteForRole } from "../../utils/roleRoutes";
import { usePageTitle } from "../../hooks/usePageTitle";
import { Logo } from "../../components/Logo";
import { Button } from "../../components/ui/Button";

function NotFound() {
  usePageTitle("Page not found");
  const session = authService.getSession();
  const home = session ? homeRouteForRole(session.chw.role) : "/";
  return (
    <div className="flex min-h-screen flex-col bg-cream">
      <header className="px-6 py-5">
        <Link to="/" aria-label="Mosi home">
          <Logo size="sm" />
        </Link>
      </header>
      <main className="flex flex-1 items-center justify-center px-6 pb-16">
        <div className="max-w-sm text-center">
          <h1 className="text-2xl font-semibold text-stone-900">Page not found</h1>
          <p className="mt-2 text-sm text-stone-600">This address doesn't match any page in Mosi. Your saved work is not affected.</p>
          <Button asChild size="lg" className="mt-6">
            <Link to={home}>{session ? "Go to your home screen" : "Go to the Mosi home page"}</Link>
          </Button>
        </div>
      </main>
    </div>
  );
}

export default NotFound;
