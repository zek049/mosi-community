import { Link, useLocation } from "react-router-dom";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { MoreHorizontal } from "lucide-react";
import type { NavItem } from "./Sidebar";
import { cn } from "../../lib/utils";

function isActive(item: NavItem, pathname: string) {
  return item.end ? pathname === item.to : pathname.startsWith(item.to);
}

const ITEM_CLASS = "flex min-h-14 flex-col items-center justify-center gap-1 py-2 text-xs font-medium transition-colors";

// Mobile-only primary navigation - large touch targets, icon + label.
// Never more than five slots: anything beyond the core destinations goes
// behind "More" (a real, keyboard-navigable Radix menu), which carries a
// badge when something inside it needs attention - e.g. a supervisor's
// open sync conflicts - so it stays discoverable without its own slot.
export function MobileBottomNav({ navItems, moreItems = [] }: { navItems: NavItem[]; moreItems?: NavItem[] }) {
  const location = useLocation();
  const slots = navItems.length + (moreItems.length > 0 ? 1 : 0);
  const moreActive = moreItems.some((item) => isActive(item, location.pathname));
  const moreBadge = moreItems.reduce((sum, item) => sum + (item.badge ?? 0), 0);

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-stone-200 bg-white pb-[env(safe-area-inset-bottom)] md:hidden"
      aria-label="Primary"
    >
      <div className={cn("grid", slots >= 5 ? "grid-cols-5" : "grid-cols-4")}>
        {navItems.map((item) => {
          const active = isActive(item, location.pathname);
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              aria-current={active ? "page" : undefined}
              className={cn(ITEM_CLASS, active ? "text-forest-800" : "text-stone-500 hover:text-stone-700")}
            >
              <Icon className="h-5 w-5" strokeWidth={active ? 2.5 : 2} aria-hidden="true" />
              {item.label}
            </Link>
          );
        })}

        {moreItems.length > 0 && (
          <DropdownMenu.Root modal={false}>
            <DropdownMenu.Trigger
              className={cn(
                ITEM_CLASS,
                "outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-forest-700/40",
                moreActive ? "text-forest-800" : "text-stone-500 hover:text-stone-700",
              )}
            >
              <span className="relative">
                <MoreHorizontal className="h-5 w-5" strokeWidth={moreActive ? 2.5 : 2} aria-hidden="true" />
                {moreBadge > 0 && (
                  <span className="absolute -right-1.5 -top-1 h-2.5 w-2.5 rounded-full bg-amber-600 ring-2 ring-white" aria-hidden="true" />
                )}
              </span>
              More
              {moreBadge > 0 && <span className="sr-only">, {moreBadge} {moreBadge === 1 ? "item needs" : "items need"} attention</span>}
            </DropdownMenu.Trigger>
            <DropdownMenu.Portal>
              <DropdownMenu.Content
                side="top"
                align="end"
                sideOffset={8}
                className="z-50 w-56 rounded-xl border border-stone-200 bg-white p-1.5 shadow-lg"
              >
                {moreItems.map((item) => {
                  const Icon = item.icon;
                  const active = isActive(item, location.pathname);
                  return (
                    <DropdownMenu.Item key={item.to} asChild>
                      <Link
                        to={item.to}
                        aria-current={active ? "page" : undefined}
                        className="flex min-h-11 items-center gap-3 rounded-lg px-3 text-sm text-stone-800 outline-none data-[highlighted]:bg-sage-50"
                      >
                        <Icon className="h-4 w-4 text-forest-700" aria-hidden="true" />
                        <span className="flex-1">{item.label}</span>
                        {(item.badge ?? 0) > 0 && (
                          <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-800">
                            <span className="sr-only">, </span>
                            {item.badge} open
                          </span>
                        )}
                      </Link>
                    </DropdownMenu.Item>
                  );
                })}
              </DropdownMenu.Content>
            </DropdownMenu.Portal>
          </DropdownMenu.Root>
        )}
      </div>
    </nav>
  );
}
