// Feature 7 - PIN reset requests + forced change of temporary PINs. Production build, real backend.
// Uses CHW002 (John Ncube); the cleanup step restores its PIN to the demo value afterwards.
import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const MESSAGE = "A supervisor will reset your PIN — check with them for your new temporary PIN.";
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
function track(page, who, allow = []) {
  page.on("pageerror", (e) => errors.push(`${who}: ${e}`));
  page.on("console", (m) => { if (m.type() === "error" && !allow.some((re) => re.test(m.text()))) errors.push(`${who}: ${m.text()}`); });
}
async function axe(page, label) {
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
const active = (page) => page.evaluate(() => ({ tag: document.activeElement?.tagName, id: document.activeElement?.id, text: (document.activeElement?.textContent || "").trim().slice(0, 50), role: document.activeElement?.getAttribute("role") }));
async function waitOnline(page) {
  await page.waitForFunction(() => document.body.innerText.includes("Online"), null, { timeout: 10000 });
}
async function login(page, id, pin) {
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await waitOnline(page);
  await page.fill("#chwId", id); await page.fill("#pin", pin); await page.press("#pin", "Enter");
}

const browser = await chromium.launch();

// 1. CHW asks
{
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "forgot");
  await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
  await page.click("text=Forgot PIN?");
  await page.waitForURL("**/forgot-pin");
  await waitOnline(page);
  await axe(page, "Forgot PIN form");
  await page.fill("#forgot_chw_id", "chw002");
  report("Forgot: CHW ID upper-cased as typed", (await page.inputValue("#forgot_chw_id")) === "CHW002");
  await page.click('button:has-text("Ask for a PIN reset")');
  await page.waitForSelector("text=Request sent", { timeout: 8000 });
  report("Forgot: shows the exact message", (await page.locator("main").innerText()).includes(MESSAGE));
  report("Forgot: confirmation heading receives focus", (await active(page)).tag === "H1");
  await axe(page, "Forgot PIN sent");
  // Unknown ID gets the identical answer
  const unknown = await page.evaluate(async (API) => { const r = await fetch(`${API}/pin-reset-requests`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chw_id: "NOPE99" }) }); return { status: r.status, body: await r.json() }; }, API);
  const known = await page.evaluate(async (API) => { const r = await fetch(`${API}/pin-reset-requests`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chw_id: "CHW002" }) }); return { status: r.status, body: await r.json() }; }, API);
  report("Forgot: unknown ID and real ID get identical responses (no enumeration)", JSON.stringify(unknown) === JSON.stringify(known), { unknown, known });
  await ctx.close();
}

// 2. Supervisor completes
let tempPin = "";
{
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "supervisor");
  await login(page, "SUP001", "1234");
  await page.waitForURL("**/supervisor");
  await page.waitForTimeout(1500);
  const nav = await page.locator('aside a[href="/supervisor/pin-reset"]').innerText();
  report("Supervisor: 'Reset a PIN' shows 1 waiting request (duplicate request not counted twice)", /\b1\b/.test(nav), nav);
  await page.click('aside a[href="/supervisor/pin-reset"]');
  await page.waitForSelector("#pin-requests-heading");
  const list = await page.locator("section[aria-labelledby='pin-requests-heading']").innerText();
  report("Supervisor: request shows name, ID, clinic, when", /John Ncube/.test(list) && /CHW002/.test(list) && /Hatcliffe/.test(list) && /asked /.test(list));
  await axe(page, "PIN reset requests list");
  const setBtn = page.getByRole("button", { name: "Set temporary PIN for John Ncube" });
  await setBtn.click();
  await page.waitForTimeout(150);
  const a = await active(page);
  report("Supervisor: empty temporary PIN -> error, focus on the field", /^temp-pin-/.test(a.id) && (await page.isVisible("text=Enter a temporary PIN of exactly 4 digits")), a);
  await page.getByRole("button", { name: "Generate a temporary PIN for John Ncube" }).click();
  tempPin = await page.locator("input[id^='temp-pin-']").inputValue();
  report("Supervisor: Generate fills a 4-digit temporary PIN (controlled input)", /^\d{4}$/.test(tempPin), tempPin.length);
  await setBtn.click();
  await page.waitForSelector("dialog[open]");
  report("Supervisor: confirmation dialog, focus on Cancel", (await active(page)).text === "Cancel");
  await axe(page, "Set temporary PIN dialog");
  await page.click('dialog[open] button:has-text("Set temporary PIN")');
  await page.waitForSelector("text=Temporary PIN set for John Ncube", { timeout: 8000 });
  report("Supervisor: done message focused; request moves to 'Recently completed'", (await active(page)).role === "status" && (await page.isVisible("text=Recently completed")));
  report("Supervisor: the temporary PIN isn't left on screen", !(await page.locator("main").innerText()).includes(tempPin));
  await ctx.close();
}

// 3. CHW signs in with the temporary PIN -> must change it
{
  const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, bypassCSP: true });
  const page = await ctx.newPage();
  track(page, "change", [/status of 401/, /status of 403/, /status of 400/]);
  await login(page, "CHW002", "1234");
  await page.waitForSelector("text=Invalid CHW ID or PIN", { timeout: 8000 });
  report("Old PIN no longer works", true);
  await login(page, "CHW002", tempPin);
  await page.waitForURL("**/change-pin", { timeout: 8000 });
  report("Temporary PIN -> sent straight to 'Choose a new PIN'", await page.waitForSelector("h1:has-text('Choose a new PIN')", { timeout: 8000 }).then(() => true).catch(() => false));
  await axe(page, "Choose a new PIN");
  await page.goto(`${BASE}/chw`, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(500);
  report("Can't skip it: /chw redirects back to /change-pin", new URL(page.url()).pathname === "/change-pin");
  const blocked = await page.evaluate(async (API) => { const r = await fetch(`${API}/patients`, { credentials: "include" }); return { status: r.status, code: (await r.json()).code }; }, API);
  report("Server refuses other API calls until changed (403 PIN_CHANGE_REQUIRED)", blocked.status === 403 && blocked.code === "PIN_CHANGE_REQUIRED", blocked);
  await page.fill("#current_pin", tempPin); await page.fill("#new_pin", "1234"); await page.fill("#confirm_pin", "1234");
  await page.click('button:has-text("Save new PIN")');
  await page.waitForTimeout(200);
  report("Guessable new PIN refused before sending", await page.isVisible("text=That PIN is too easy to guess"));
  await page.fill("#new_pin", "8264"); await page.fill("#confirm_pin", "8265");
  await page.click('button:has-text("Save new PIN")');
  await page.waitForTimeout(200);
  report("Mismatched confirmation refused, focus on that field", (await active(page)).id === "confirm_pin");
  await page.fill("#current_pin", "0000"); await page.fill("#confirm_pin", "8264");
  await page.click('button:has-text("Save new PIN")');
  await page.waitForSelector("text=Your current PIN isn't right", { timeout: 8000 });
  report("Wrong temporary PIN -> server says so, focus on the message", (await active(page)).role === "alert");
  await page.fill("#current_pin", tempPin);
  await page.click('button:has-text("Save new PIN")');
  await page.waitForURL("**/chw", { timeout: 8000 });
  report("Valid new PIN -> into the app", true);
  await page.evaluate(() => localStorage.clear());
  await login(page, "CHW002", "8264");
  report("Next sign-in with the new PIN goes straight to the app", await page.waitForURL("**/chw", { timeout: 8000 }).then(() => true).catch(() => false));
  await ctx.close();
}

await browser.close();
console.log(`\nConsole/page errors: ${errors.length}`); errors.forEach((e) => console.log("  ", e));
console.log(`${pass} passed, ${fail} failed`);
