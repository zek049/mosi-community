import { describe, expect, it } from "vitest";
import { isIos, isIosSafari, isStandalone, shouldShowIosInstallHint } from "../installEnvironment";

const IPHONE_SAFARI = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
const IPHONE_CHROME = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/126.0.6478.54 Mobile/15E148 Safari/604.1";
const IPAD_AS_MAC = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15";
const ANDROID_CHROME = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36";
const MAC_SAFARI = IPAD_AS_MAC;

describe("install environment", () => {
  it("iPhone Safari, not installed -> show the iOS hint", () => {
    expect(shouldShowIosInstallHint({ userAgent: IPHONE_SAFARI })).toBe(true);
  });

  it("already installed (opened from the home screen) -> no hint", () => {
    expect(shouldShowIosInstallHint({ userAgent: IPHONE_SAFARI, navigatorStandalone: true })).toBe(false);
    expect(shouldShowIosInstallHint({ userAgent: IPHONE_SAFARI, standaloneMedia: true })).toBe(false);
    expect(isStandalone({ userAgent: ANDROID_CHROME, standaloneMedia: true })).toBe(true);
  });

  it("Chrome on iPhone isn't Safari -> no Safari steps", () => {
    expect(isIos({ userAgent: IPHONE_CHROME })).toBe(true);
    expect(isIosSafari({ userAgent: IPHONE_CHROME })).toBe(false);
  });

  it("an iPad reporting itself as a Mac is still iOS (touch), a real Mac isn't", () => {
    expect(shouldShowIosInstallHint({ userAgent: IPAD_AS_MAC, platform: "MacIntel", maxTouchPoints: 5 })).toBe(true);
    expect(shouldShowIosInstallHint({ userAgent: MAC_SAFARI, platform: "MacIntel", maxTouchPoints: 0 })).toBe(false);
  });

  it("Android Chrome uses the browser's own install prompt -> no iOS hint", () => {
    expect(shouldShowIosInstallHint({ userAgent: ANDROID_CHROME, platform: "Linux armv8l", maxTouchPoints: 5 })).toBe(false);
  });
});
