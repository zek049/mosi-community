import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// No environment variables are required to start this app - the dev
// server port below and the API URL default (see src/services/api.ts,
// added in Step 5) are both sensible built-in defaults.
//
// frame-ancestors can only be enforced via a real HTTP header (browsers
// silently ignore it on a <meta> CSP tag, see index.html) - set here for
// dev/`vite preview`, and again in nginx.conf for the built Docker image.
const clickjackingHeaders = {
  "X-Frame-Options": "DENY",
  "Content-Security-Policy": "frame-ancestors 'none'",
};

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    headers: clickjackingHeaders,
  },
  preview: {
    headers: clickjackingHeaders,
  },
  build: {
    // public/sw.js reads dist/.vite/manifest.json to precache every route
    // chunk, not just the ones index.html references directly.
    manifest: true,
  },
});
