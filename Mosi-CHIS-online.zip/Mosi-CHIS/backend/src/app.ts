// Imported first so backend/.env is loaded (and DATABASE_URL/JWT_SECRET
// fallbacks applied) before any other module reads process.env.
import "./db";

import cookieParser from "cookie-parser";
import cors from "cors";
import express from "express";
import helmet from "helmet";
import pinoHttp from "pino-http";

import { publicAccountRequestRoutes, accountReviewRoutes } from "./routes/accountRequests";
import { publicPinResetRoutes, pinResetReviewRoutes } from "./routes/pinResets";
import householdsRoutes from "./routes/households";
import reviewRoutes from "./routes/review";
import authRoutes from "./routes/auth";
import chwsRoutes from "./routes/chws";
import clinicsRoutes from "./routes/clinics";
import conflictsRoutes from "./routes/conflicts";
import auditRoutes from "./routes/audit";
import dashboardRoutes from "./routes/dashboard";
import patientsRoutes from "./routes/patients";
import syncRoutes from "./routes/sync";
import visitsRoutes from "./routes/visits";

import { authenticate, requireRole } from "./middleware/auth";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler";
import { apiLimiter, syncLimiter } from "./middleware/rateLimit";
import { requestId } from "./middleware/requestId";
import { assertRequiredEnv } from "./utils/env";
import { logger } from "./logger";
import { prisma } from "./db";

// Refuses to start (rather than quietly signing tokens with a known default
// secret) if required configuration is missing. Must run before anything
// else touches process.env.
assertRequiredEnv();

const app = express();

// Online deployment: the API sits behind a reverse proxy (Caddy, see
// docker-compose.prod.yml), so every request reaches this process from the
// proxy's address. Without this, req.ip is the proxy for EVERY user and the
// per-IP rate limits (login, API backstop) would be shared by all of them.
// TRUST_PROXY=1 means "trust exactly one proxy hop". Unset locally.
const trustProxy = process.env.TRUST_PROXY;
if (trustProxy) {
  app.set("trust proxy", /^\d+$/.test(trustProxy) ? Number(trustProxy) : trustProxy);
}

// CSP is left off here: this is a pure JSON API with no HTML/script
// responses of its own, so a CSP header on it does nothing useful. The
// frontend (which actually renders untrusted-adjacent content) carries its
// own CSP via a meta tag instead. crossOriginResourcePolicy is relaxed
// because the frontend is deliberately a different origin (different port
// in dev, often a different host in production) and needs to read these
// responses.
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: "cross-origin" } }));

// Origin allowlist, not `cors()` wide open: comma-separated ALLOWED_ORIGINS
// env var, defaulting to the Vite dev server + preview ports so local
// development keeps working with zero configuration. A real deployment sets
// ALLOWED_ORIGINS explicitly to its real frontend origin(s).
const allowedOrigins = (process.env.ALLOWED_ORIGINS ?? "http://localhost:5173,http://localhost:4173")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

app.use(
  cors({
    origin(origin, callback) {
      // No Origin header (curl, server-to-server, same-origin) - allow.
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
        return;
      }
      callback(new Error(`Origin "${origin}" is not allowed`));
    },
    // Required for the browser to send/receive the httpOnly session cookie
    // cross-origin (the frontend dev server and this API run on different
    // ports) - safe specifically because origin is never wildcarded above;
    // credentials + a wildcard origin is what CORS forbids for good reason.
    credentials: true,
    // Lets the web app read how long a rate-limited (429) response asks it
    // to wait, so it can hold off retrying instead of guessing.
    exposedHeaders: ["Retry-After"],
  }),
);

// Explicit body-size ceiling (section 13/29): a sync batch can carry up to
// 200 patients + 200 visits, so this needs headroom beyond Express's
// 100kb-ish implicit default, but an unbounded body is its own resource-
// exhaustion vector.
app.use(express.json({ limit: "5mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));
app.use(cookieParser());

// Every response here carries either nothing sensitive or authenticated
// health-data JSON - never something a shared/browser cache should retain
// (section 24). Set globally, before any route, so nothing can accidentally
// ship without it.
app.use((_req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  next();
});

app.use(requestId);
app.use(
  pinoHttp({
    logger,
    autoLogging: { ignore: (req) => req.url?.startsWith("/api/health") ?? false },
    genReqId: (req) => req.requestId,
  }),
);
app.use("/api", apiLimiter);

// live: is the process up at all (no DB dependency - a DB outage shouldn't
// make an orchestrator think the process itself needs restarting).
app.get("/api/health/live", (_req, res) => {
  res.json({ success: true, message: "Mosi API process is alive", timestamp: new Date().toISOString() });
});

// ready: can this instance actually serve traffic right now (DB reachable).
// /api/health is kept as an alias of /ready for backward compatibility -
// existing tooling/monitoring pointed at the original single health check
// keeps working unchanged.
async function readinessCheck(_req: express.Request, res: express.Response) {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ success: true, message: "Mosi API is running", database: "connected", timestamp: new Date().toISOString() });
  } catch (error) {
    logger.error({ err: error }, "Health check: database unreachable");
    res
      .status(503)
      .json({ success: false, message: "Database unreachable", database: "disconnected", timestamp: new Date().toISOString() });
  }
}
app.get("/api/health/ready", readinessCheck);
app.get("/api/health", readinessCheck);

app.use("/api/auth", authRoutes);
// Account requests: the request form is public (rate-limited); reviewing
// requests is supervisor-only (enforced inside accountReviewRoutes). The
// public router only handles GET /clinics and POST /, so everything else
// falls through to the review router.
app.use("/api/account-requests", publicAccountRequestRoutes, accountReviewRoutes);
// "Forgot PIN?" - public request, supervisor completion (same split as above).
app.use("/api/pin-reset-requests", publicPinResetRoutes, pinResetReviewRoutes);
app.use("/api/patients", authenticate, patientsRoutes);
app.use("/api/households", authenticate, householdsRoutes);
app.use("/api/visits", authenticate, visitsRoutes);
app.use("/api/chws", authenticate, chwsRoutes);
app.use("/api/clinics", authenticate, clinicsRoutes);
app.use("/api/sync", authenticate, syncLimiter, syncRoutes);
// Aggregate stats, conflict review/resolution, and the audit trail are all
// supervisor-only per the authorization matrix (middleware/authz.ts) - none
// of them are read by any CHW-role screen today (confirmed against the
// actual frontend call sites before restricting these).
app.use("/api/dashboard", authenticate, requireRole("SUPERVISOR"), dashboardRoutes);
app.use("/api/review", authenticate, requireRole("SUPERVISOR"), reviewRoutes);
app.use("/api/conflicts", authenticate, requireRole("SUPERVISOR"), conflictsRoutes);
app.use("/api/audit-logs", authenticate, requireRole("SUPERVISOR"), auditRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

const PORT = Number(process.env.PORT) || 4000;

// Only start listening when this file is run directly (`npm run dev` /
// `npm start`), not when it's imported - e.g. by a future test file that
// wants the configured `app` without also binding a port.
if (require.main === module) {
  const server = app.listen(PORT, () => {
    logger.info(`Mosi API listening on http://localhost:${PORT}`);
  });

  // Without this, `docker stop` (SIGTERM) has nothing to catch: Node
  // doesn't exit gracefully on its own while an HTTP server is holding the
  // event loop open, so the container would sit idle for the full stop
  // timeout and then get SIGKILLed, abruptly cutting off any in-flight
  // request instead of letting it finish. Stop accepting new connections
  // immediately, let in-flight ones complete, then disconnect Prisma and
  // exit - with a hard-exit fallback in case a connection never finishes.
  function shutdown(signal: string) {
    logger.info(`${signal} received, shutting down gracefully`);
    server.close(() => {
      void prisma.$disconnect().finally(() => process.exit(0));
    });
    setTimeout(() => {
      logger.error("Graceful shutdown timed out, forcing exit");
      process.exit(1);
    }, 10_000).unref();
  }

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
}

export default app;
