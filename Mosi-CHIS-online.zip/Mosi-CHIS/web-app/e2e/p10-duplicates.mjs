// Feature 6 - duplicate patient detection (warning only). Production build, real backend.
import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const STAMP = `P10-${Date.now()}`;
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
async function axe(page, label) {
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
const active = (page) => page.evaluate(() => (document.activeElement?.textContent || "").trim().slice(0, 40));
const localCount = (page) => page.evaluate(async () => {
  const db = await new Promise((res) => { const r = indexedDB.open("mosi-chis-user-CHW001"); r.onsuccess = () => res(r.result); });
  const n = await new Promise((res) => { const c = db.transaction("patients").objectStore("patients").count(); c.onsuccess = () => res(c.result); });
  db.close();
  return n;
});

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, bypassCSP: true });
const page = await ctx.newPage();
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => { if (m.type() === "error" && !/ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(m.text())) errors.push(m.text()); });
const dupRequests = [];
page.on("request", (r) => { if (r.url().includes("/possible-duplicates")) dupRequests.push(r.url()); });

await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
await page.waitForFunction(() => document.body.innerText.includes("Online"));
await page.fill("#chwId", "CHW001"); await page.fill("#pin", "1234"); await page.press("#pin", "Enter");
await page.waitForURL("**/chw");
await page.waitForTimeout(2000);
const target = await page.evaluate(async (API) => (await (await fetch(`${API}/patients?search=MBR-0017`, { credentials: "include" })).json()).data[0], API);
const dob = target.date_of_birth.slice(0, 10);

async function fill(id, first, last, village, birth) {
  await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector("h1:has-text('Add patient')");
  await page.fill("#patient_id", id); await page.fill("#first_name", first); await page.fill("#last_name", last);
  await page.fill("#date_of_birth", birth); await page.check('input[name="gender"][value="F"]'); await page.fill("#village", village);
  await page.click('button:has-text("Save patient")');
}

// 1. Match differing only in case/spaces
const before = await localCount(page);
await fill(`${STAMP}-A`, "  CHIEDZA ", "moyo", "mbare ", dob);
await page.waitForSelector("dialog[open]", { timeout: 8000 });
const text = await page.locator("dialog[open]").innerText();
report("Match (case/spaces differ): warning dialog with name, village, DOB", /A similar patient already exists/.test(text) && /Chiedza Moyo/.test(text) && /Mbare/.test(text) && /born /.test(text), text.slice(0, 200));
report("Dialog offers Register anyway / View existing patient / Cancel", /Register anyway/.test(text) && /View existing patient/.test(text) && /Cancel/.test(text));
report("Focus starts on Cancel (safe)", (await active(page)) === "Cancel");
report("Online: the server was also checked", dupRequests.length === 1);
await axe(page, "Duplicate warning dialog (375px)");
await page.keyboard.press("Escape");
await page.waitForTimeout(200);
report("Cancel/Escape: nothing saved, form values kept", (await localCount(page)) === before && (await page.inputValue("#first_name")) === "  CHIEDZA ");

// 2. View existing
await page.click('button:has-text("Save patient")');
await page.waitForSelector("dialog[open]");
await page.click('dialog[open] button:has-text("View existing patient")');
await page.waitForURL(`**/patients/${target.id}`);
report("View existing patient -> opens that patient", await page.waitForSelector("h1:has-text('Chiedza Moyo')", { timeout: 8000 }).then(() => true).catch(() => false));

// 3. Register anyway
await fill(`${STAMP}-B`, "Chiedza", "Moyo", "Mbare", dob);
await page.waitForSelector("dialog[open]");
await page.click('dialog[open] button:has-text("Register anyway")');
await page.waitForSelector("text=Patient registered", { timeout: 8000 });
report("Register anyway -> saved (warning never blocks)", (await localCount(page)) === before + 1);

// 4. No match -> no dialog
await fill(`${STAMP}-C`, "Chiedza", "Moyo", "Epworth", dob);
await page.waitForSelector("text=Patient registered", { timeout: 8000 });
report("Different village -> no warning, saved directly", true);

// 5. Offline: local check still works
await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "domcontentloaded" });
await ctx.setOffline(true);
const offlineReqs = dupRequests.length;
await page.waitForSelector("h1:has-text('Add patient')");
await page.fill("#patient_id", `${STAMP}-D`); await page.fill("#first_name", "Chiedza"); await page.fill("#last_name", "Möyo");
await page.fill("#date_of_birth", dob); await page.check('input[name="gender"][value="F"]'); await page.fill("#village", "Mbare");
await page.click('button:has-text("Save patient")');
await page.waitForSelector("dialog[open]", { timeout: 8000 });
report("Offline: warning still shown from this device's records (accent-insensitive)", /Chiedza Moyo/.test(await page.locator("dialog[open]").innerText()) && dupRequests.length === offlineReqs);
await page.click('dialog[open] button:has-text("Register anyway")');
await page.waitForSelector("text=Patient registered", { timeout: 8000 });
report("Offline: Register anyway saves on the device", await page.isVisible("text=Saved on this device"));
await ctx.setOffline(false);
await page.waitForTimeout(3000);

// 6. Server-only match (registered elsewhere, not yet in this device's cache)
await page.evaluate(async (id) => {
  const db = await new Promise((res) => { const r = indexedDB.open("mosi-chis-user-CHW001"); r.onsuccess = () => res(r.result); });
  await new Promise((res) => { const t = db.transaction("patients", "readwrite"); t.objectStore("patients").delete(id); t.oncomplete = res; });
  db.close();
}, target.id);
await fill(`${STAMP}-E`, "Chiedza", "Moyo", "Mbare", dob);
await page.waitForSelector("dialog[open]", { timeout: 8000 });
const serverOnly = await page.locator("dialog[open]").innerText();
report("Online: match found on the server even when not on this device", /MBR-0017/.test(serverOnly), serverOnly.slice(0, 160));
report("Several matches: each listed with its own 'View this patient'", (await page.locator('dialog[open] li button:has-text("View this patient")').count()) >= 2);
await page.locator("dialog[open] li", { hasText: "MBR-0017" }).locator('button:has-text("View this patient")').click();
await page.waitForURL(`**/patients/${target.id}`);
report("View existing for a server-only match opens it (fetched into the cache)", await page.waitForSelector("h1:has-text('Chiedza Moyo')", { timeout: 8000 }).then(() => true).catch(() => false));

const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
report("No horizontal scroll at 375px", overflow <= 0, overflow);
await browser.close();
console.log(`\nConsole/page errors: ${errors.length}`); errors.forEach((e) => console.log("  ", e));
console.log(`${pass} passed, ${fail} failed. TEST_STAMP=${STAMP}`);
