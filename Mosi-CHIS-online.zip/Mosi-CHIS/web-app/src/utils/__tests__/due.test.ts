import { describe, expect, it } from "vitest";
import { addDays, computeDue, describeDue } from "../due";

// Same cases as backend/src/__tests__/due.test.ts.
const v = (patient_id: string, visit_type: string, visit_date: string, deleted_at: string | null = null) => ({ patient_id, visit_type, visit_date, deleted_at });

describe("addDays (calendar days)", () => {
  it.each([
    ["2026-01-31", 30, "2026-03-02"], // across a short February
    ["2028-02-01", 30, "2028-03-02"], // leap year (Feb has 29 days)
    ["2028-02-29", 90, "2028-05-29"], // from a leap day
    ["2026-12-15", 30, "2027-01-14"], // year end
    ["2026-03-20", 30, "2026-04-19"], // across a DST change elsewhere - no off-by-one
  ])("%s + %i = %s", (day, n, expected) => {
    expect(addDays(day, n)).toBe(expected);
  });
});

describe("computeDue", () => {
  const today = "2026-10-05";

  it("uses the brief's intervals: Antenatal 30, Immunization 90, Growth Monitoring 30, HIV/TB 30", () => {
    const due = computeDue(
      [v("p1", "Antenatal", "2026-09-05"), v("p2", "Immunization", "2026-07-07"), v("p3", "Growth Monitoring", "2026-09-05"), v("p4", "HIV/TB Support", "2026-09-05")],
      today,
    );
    expect(due.map((d) => [d.patient_id, d.due_date, d.days_overdue])).toEqual([
      ["p1", "2026-10-05", 0],
      ["p2", "2026-10-05", 0],
      ["p3", "2026-10-05", 0],
      ["p4", "2026-10-05", 0],
    ]);
  });

  it("other visit types are never due", () => {
    expect(computeDue([v("p1", "Health Education", "2025-01-01"), v("p1", "Disease Surveillance", "2025-01-01"), v("p1", "Other", "2025-01-01")], today)).toEqual([]);
  });

  it("a visit today is not due; a newer visit of the same type clears the older one", () => {
    expect(computeDue([v("p1", "Antenatal", today)], today)).toEqual([]);
    expect(computeDue([v("p1", "Antenatal", "2026-08-01"), v("p1", "Antenatal", "2026-10-01")], today)).toEqual([]);
  });

  it("a different type doesn't clear it (types are tracked separately)", () => {
    const due = computeDue([v("p1", "Antenatal", "2026-08-01"), v("p1", "Growth Monitoring", "2026-10-01")], today);
    expect(due).toHaveLength(1);
    expect(due[0]).toMatchObject({ visit_type: "Antenatal", last_visit: "2026-08-01", due_date: "2026-08-31", days_overdue: 35 });
  });

  it("window is today .. today+6 plus everything overdue; day 7 is next week", () => {
    const due = computeDue([v("a", "Antenatal", "2026-09-11"), v("b", "Antenatal", "2026-09-12")], today);
    expect(due.map((d) => [d.patient_id, d.days_overdue])).toEqual([["a", -6]]);
  });

  it("deleted visits are ignored; server timestamps and device dates agree", () => {
    expect(computeDue([v("p1", "Antenatal", "2026-08-01", "2026-08-02T00:00:00Z")], today)).toEqual([]);
    const fromServer = computeDue([v("p1", "Antenatal", "2026-08-01T00:00:00.000Z")], today);
    const fromDevice = computeDue([v("p1", "Antenatal", "2026-08-01")], today);
    expect(fromServer).toEqual(fromDevice);
  });

  it("sorts most overdue first", () => {
    const due = computeDue([v("a", "Antenatal", "2026-09-01"), v("b", "Antenatal", "2026-08-01"), v("c", "Antenatal", "2026-09-08")], today);
    expect(due.map((d) => d.patient_id)).toEqual(["b", "a", "c"]);
  });
});

describe("describeDue", () => {
  it.each([
    [3, "3 days overdue"],
    [1, "1 day overdue"],
    [0, "Due today"],
    [-1, "Due tomorrow"],
    [-4, "Due in 4 days"],
  ])("%i -> %s", (n, text) => expect(describeDue(n)).toBe(text));
});
