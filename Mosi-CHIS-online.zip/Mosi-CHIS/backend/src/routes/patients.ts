import { Router } from "express";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { requireRole } from "../middleware/auth";
import { canAccessClinic, canModifyClinicResource, clinicScope, isSupervisorOrAdmin } from "../middleware/authz";
import { dayOf, isPossibleDuplicate } from "../utils/duplicates";
import { computeDue, FOLLOW_UP_DAYS } from "../utils/due";
import { requireStringParam } from "../utils/params";
import { parseDate, parseTimestampField } from "../utils/parseDate";
import { parsePageParams, buildPagination } from "../utils/pagination";
import { validatePatientFields } from "../services/validation";
import { writeAuditLog } from "../utils/audit";
import { reviewOnCreate, reviewOnEdit } from "../utils/review";

// Turns services/validation.ts's plain error list into the 400 AppError
// routes need. services/syncService.ts uses the same validator directly and
// turns the same list into a per-record "failed" result instead.
function validatePatientInput(body: Record<string, unknown>, { partial }: { partial: boolean }) {
  const errors = validatePatientFields(body, { partial });
  if (errors.length > 0) {
    throw new AppError(400, errors.join(". "));
  }
}

const router = Router();

router.get("/", async (req, res) => {
  const { search, village, chw_id: chwId, include_archived: includeArchived } =
    req.query as Record<string, string | undefined>;
  const pageParams = parsePageParams(req);

  // Clinic scoping (section 8): a CHW only ever sees their own clinic's
  // patients, enforced here in the query itself, not by anything the
  // frontend does or doesn't render.
  const scope = clinicScope(req.user!);
  const clinicFilter = scope ? { clinic_id: scope } : {};

  const where = {
    AND: [
      clinicFilter,
      includeArchived === "true" && isSupervisorOrAdmin(req.user!) ? {} : { deleted_at: null },
      village ? { village } : {},
      chwId ? { visits: { some: { chw_id: chwId } } } : {},
      search
        ? {
            OR: [
              { patient_id: { contains: search, mode: "insensitive" as const } },
              { first_name: { contains: search, mode: "insensitive" as const } },
              { last_name: { contains: search, mode: "insensitive" as const } },
            ],
          }
        : {},
    ],
  };

  const [patients, total] = await Promise.all([
    prisma.patient.findMany({
      where,
      orderBy: { created_at: "desc" },
      skip: pageParams.skip,
      take: pageParams.take,
    }),
    prisma.patient.count({ where }),
  ]);

  res.json({ success: true, data: patients, pagination: buildPagination(pageParams, total) });
});

// Possible duplicates for a patient about to be registered (a warning only -
// registration is never blocked). Same rule as the app's offline check:
// first + last name + village + date of birth, trimmed, case- and
// accent-insensitive. Scoped like the patient list, and returns only what
// the CHW needs to recognise the person.
router.get("/possible-duplicates", async (req, res) => {
  const { first_name: firstName, last_name: lastName, village, date_of_birth: dob } = req.query as Record<string, string | undefined>;
  if (!firstName?.trim() || !lastName?.trim() || !village?.trim() || !dob || !/^\d{4}-\d{2}-\d{2}/.test(dob)) {
    throw new AppError(400, "first_name, last_name, village and date_of_birth (YYYY-MM-DD) are required");
  }
  const day = dayOf(dob);
  const start = new Date(`${day}T00:00:00.000Z`);
  const end = new Date(start.getTime() + 24 * 60 * 60 * 1000);
  const scope = clinicScope(req.user!);

  // Narrow in the database (same birth day, scope), then apply the exact
  // accent-insensitive comparison in code (Postgres would need unaccent).
  const candidates = await prisma.patient.findMany({
    where: { deleted_at: null, date_of_birth: { gte: start, lt: end }, ...(scope ? { clinic_id: scope } : {}) },
    select: { id: true, patient_id: true, first_name: true, last_name: true, village: true, date_of_birth: true },
    take: 500,
  });
  const matches = candidates.filter((p) =>
    isPossibleDuplicate(p, { first_name: firstName, last_name: lastName, village, date_of_birth: day }),
  );
  res.json({ success: true, data: matches });
});

// "YYYY-MM-DD" naming a real calendar day (Date.parse accepts 2026-02-30).
function isRealDay(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

// Follow-ups due this week (and overdue) for the supervisor's widget.
// Same rule as the CHW's device (utils/due.ts): latest visit per patient
// and trackable type + its interval. `today` lets the browser pass its own
// calendar date (the server's UTC date can be a day behind/ahead).
router.get("/due", requireRole("SUPERVISOR"), async (req, res) => {
  const todayParam = typeof req.query.today === "string" ? req.query.today : undefined;
  if (todayParam !== undefined && !isRealDay(todayParam)) {
    throw new AppError(400, "today must be a date (YYYY-MM-DD)");
  }
  const today = todayParam ?? new Date().toISOString().slice(0, 10);
  const scope = clinicScope(req.user!);

  // Latest visit per (patient, tracked type), worked out by the database.
  const latest = await prisma.visit.groupBy({
    by: ["patient_id", "visit_type"],
    where: {
      deleted_at: null,
      visit_type: { in: Object.keys(FOLLOW_UP_DAYS) },
      patient: { deleted_at: null },
      ...(scope ? { clinic_id: scope } : {}),
    },
    _max: { visit_date: true },
  });
  const due = computeDue(
    latest.flatMap((row) => (row._max.visit_date ? [{ patient_id: row.patient_id, visit_type: row.visit_type, visit_date: row._max.visit_date }] : [])),
    today,
  );

  const shown = due.slice(0, 50);
  const patients = await prisma.patient.findMany({
    where: { id: { in: [...new Set(shown.map((d) => d.patient_id))] } },
    select: { id: true, patient_id: true, first_name: true, last_name: true, village: true },
  });
  const byId = new Map(patients.map((p) => [p.id, p]));
  const byType = Object.fromEntries(Object.keys(FOLLOW_UP_DAYS).map((t) => [t, due.filter((d) => d.visit_type === t).length]));

  res.json({
    success: true,
    data: {
      today,
      total: due.length,
      overdue: due.filter((d) => d.days_overdue > 0).length,
      by_type: byType,
      items: shown.map((d) => ({ ...d, patient: byId.get(d.patient_id) ?? null })),
    },
  });
});

router.get("/:id", async (req, res) => {
  const id = requireStringParam(req, "id");
  const patient = await prisma.patient.findUnique({
    where: { id },
    include: { visits: { where: { deleted_at: null }, orderBy: { visit_date: "desc" } } },
  });

  if (!patient || patient.deleted_at) {
    throw new AppError(404, "Patient not found");
  }
  if (!canAccessClinic(req.user!, patient.clinic_id)) {
    throw new AppError(403, "You do not have permission to access this patient");
  }

  res.json({ success: true, data: patient });
});

router.post("/", async (req, res) => {
  const body = (req.body ?? {}) as Record<string, unknown>;
  validatePatientInput(body, { partial: false });

  if (typeof body.id !== "string" || !body.id.trim()) {
    throw new AppError(400, "id (client-generated UUID) is required");
  }

  const existingByPatientId = await prisma.patient.findUnique({
    where: { patient_id: body.patient_id as string },
  });
  if (existingByPatientId) {
    throw new AppError(409, `Patient ID "${body.patient_id}" already exists`);
  }

  const now = new Date();
  // clinic_id/registered_by_chw_id come from the authenticated actor, never
  // from the request body (section 25) - this is what makes the clinic
  // scoping in GET above actually mean something.
  const patient = await prisma.patient.create({
    data: {
      id: body.id,
      patient_id: body.patient_id as string,
      first_name: body.first_name as string,
      last_name: body.last_name as string,
      date_of_birth: parseDate(body.date_of_birth, "Date of birth"),
      gender: body.gender as "M" | "F",
      village: body.village as string,
      phone_number: (body.phone_number as string | undefined) ?? null,
      created_at: body.created_at ? parseTimestampField(body.created_at, "created_at") : now,
      updated_at: body.updated_at ? parseTimestampField(body.updated_at, "updated_at") : now,
      sync_status: "synced",
      clinic_id: req.user!.clinicId,
      registered_by_chw_id: req.user!.chwId,
      ...reviewOnCreate(req.user!),
    },
  });

  await writeAuditLog({
    actor: req.user,
    action: "PATIENT_CREATED",
    resourceType: "patient",
    resourceId: patient.id,
    requestId: req.requestId,
    metadata: { patient_id: patient.patient_id, clinic_id: patient.clinic_id },
  });

  res.status(201).json({ success: true, data: patient });
});

router.put("/:id", async (req, res) => {
  const id = requireStringParam(req, "id");
  const body = (req.body ?? {}) as Record<string, unknown>;
  validatePatientInput(body, { partial: true });

  const existing = await prisma.patient.findUnique({ where: { id } });
  if (!existing || existing.deleted_at) {
    throw new AppError(404, "Patient not found");
  }
  if (!canModifyClinicResource(req.user!, existing.clinic_id)) {
    throw new AppError(403, "You do not have permission to modify this patient");
  }

  if (body.patient_id && body.patient_id !== existing.patient_id) {
    const clash = await prisma.patient.findUnique({ where: { patient_id: body.patient_id as string } });
    if (clash) {
      throw new AppError(409, `Patient ID "${body.patient_id}" already exists`);
    }
  }

  const patient = await prisma.patient.update({
    where: { id },
    data: {
      patient_id: (body.patient_id as string | undefined) ?? undefined,
      first_name: (body.first_name as string | undefined) ?? undefined,
      last_name: (body.last_name as string | undefined) ?? undefined,
      date_of_birth: body.date_of_birth ? parseDate(body.date_of_birth, "Date of birth") : undefined,
      gender: (body.gender as "M" | "F" | undefined) ?? undefined,
      village: (body.village as string | undefined) ?? undefined,
      phone_number: body.phone_number === undefined ? undefined : (body.phone_number as string | null),
      updated_at: body.updated_at ? parseTimestampField(body.updated_at, "updated_at") : new Date(),
      ...reviewOnEdit(req.user!),
    },
  });

  await writeAuditLog({
    actor: req.user,
    action: "PATIENT_UPDATED",
    resourceType: "patient",
    resourceId: patient.id,
    requestId: req.requestId,
    clinicId: existing.clinic_id,
  });

  res.json({ success: true, data: patient });
});

// Archiving (soft delete) is restricted to supervisors: neither the CHW nor
// Supervisor screen lists in the spec include a "delete patient" screen, but
// section 31 of the original spec requires the endpoint to exist -
// supervisor-only is the safer default for a destructive-looking action on
// health records. It no longer actually deletes anything (section 19): the
// row and its full visit history are kept, just excluded from normal reads.
router.delete("/:id", requireRole("SUPERVISOR"), async (req, res) => {
  const id = requireStringParam(req, "id");
  const existing = await prisma.patient.findUnique({ where: { id } });
  // Another clinic's record looks the same as a missing one.
  if (!existing || existing.deleted_at || !canModifyClinicResource(req.user!, existing.clinic_id)) {
    throw new AppError(404, "Patient not found");
  }

  await prisma.patient.update({ where: { id }, data: { deleted_at: new Date() } });

  await writeAuditLog({
    actor: req.user,
    action: "PATIENT_ARCHIVED",
    resourceType: "patient",
    resourceId: id,
    requestId: req.requestId,
    clinicId: existing.clinic_id,
  });

  res.json({ success: true, message: "Patient archived" });
});

export default router;
