import { useEffect, useRef, useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { CheckCircle2 } from "lucide-react";
import * as api from "../../services/api";
import { ApiError, NetworkError } from "../../services/api";
import { useNetwork } from "../../contexts/NetworkContext";
import { usePageTitle } from "../../hooks/usePageTitle";
import { validateAccountRequest as validate, type AccountRequestErrors as Errors } from "../../utils/validators";
import { ConnectivityIndicator } from "../../components/Connectivity";
import { Logo } from "../../components/Logo";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { TextField } from "../../components/ui/TextField";
import { Select } from "../../components/ui/Select";

const FIELD_LABELS: Record<keyof Errors, string> = {
  full_name: "Full name",
  chw_id: "CHW ID",
  clinic_id: "Clinic",
  phone_number: "Phone number",
  pin: "PIN",
  confirm: "Confirm PIN",
};

function requestErrorMessage(error: unknown): string {
  if (error instanceof NetworkError) return "Couldn't reach the Mosi server. Your request was not sent - try again when you're connected.";
  if (error instanceof ApiError && error.status < 500) return error.message;
  return "Something went wrong on the server. Your request was not sent - please try again.";
}

// Public form. Submitting creates a PENDING request only: it does not create
// an account or sign anyone in. A supervisor approves or rejects it.
function RequestAccount() {
  usePageTitle("Request an account");
  const { isOnline } = useNetwork();
  const [form, setForm] = useState({ full_name: "", chw_id: "", clinic_id: "", phone_number: "", pin: "", confirm: "" });
  const [errors, setErrors] = useState<Errors>({});
  const summaryRef = useRef<HTMLDivElement>(null);
  const doneRef = useRef<HTMLHeadingElement>(null);
  const errorRef = useRef<HTMLParagraphElement>(null);

  const clinicsQuery = useQuery({ queryKey: ["requestableClinics"], queryFn: api.getRequestableClinics, enabled: isOnline });
  const submit = useMutation({
    mutationFn: () =>
      api.requestAccount({
        full_name: form.full_name.trim(),
        chw_id: form.chw_id.trim(),
        clinic_id: form.clinic_id,
        phone_number: form.phone_number.trim() || null,
        pin: form.pin,
      }),
    // Don't keep the chosen PIN in memory once it's been sent.
    onSuccess: () => setForm((f) => ({ ...f, pin: "", confirm: "" })),
  });

  useEffect(() => {
    if (submit.isSuccess) doneRef.current?.focus();
  }, [submit.isSuccess]);
  useEffect(() => {
    if (submit.isError) errorRef.current?.focus();
  }, [submit.isError]);

  function update<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length > 0) {
      window.setTimeout(() => summaryRef.current?.focus(), 0);
      return;
    }
    submit.mutate();
  }

  const errorEntries = Object.entries(errors) as [keyof Errors, string][];

  return (
    <div className="flex min-h-screen flex-col bg-cream">
      <header className="px-6 py-5">
        <Link to="/" aria-label="Mosi home">
          <Logo size="sm" />
        </Link>
      </header>
      <main className="flex flex-1 justify-center px-4 pb-16 sm:px-6">
        <div className="w-full max-w-md space-y-5">
          {submit.isSuccess ? (
            <Card className="space-y-4 p-6 sm:p-8">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="mt-1 h-6 w-6 shrink-0 text-emerald-700" aria-hidden="true" />
                <div>
                  <h1 ref={doneRef} tabIndex={-1} className="text-xl font-semibold text-stone-900 outline-none">
                    Request submitted
                  </h1>
                  <p className="mt-1 text-sm text-stone-700">Your request has been submitted and is pending supervisor approval</p>
                </div>
              </div>
              <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 rounded-lg bg-stone-50 px-4 py-3 text-sm">
                <dt className="text-stone-600">CHW ID</dt>
                <dd className="font-medium text-stone-900">{submit.data.chw_id}</dd>
                <dt className="text-stone-600">Clinic</dt>
                <dd className="text-stone-900">{submit.data.clinic}</dd>
              </dl>
              <p className="text-sm text-stone-700">
                Once a supervisor approves it, sign in with this CHW ID and the PIN you chose. You haven't been signed in, and
                nothing works with this ID until it's approved.
              </p>
              <Button asChild size="lg" className="w-full">
                <Link to="/login">Back to sign in</Link>
              </Button>
            </Card>
          ) : (
            <Card className="space-y-5 p-6 sm:p-8">
              <div>
                <h1 className="text-xl font-semibold text-stone-900">Request an account</h1>
                <p className="mt-1 text-sm text-stone-600">
                  A supervisor checks every request. You can sign in once yours is approved.
                </p>
                <div className="mt-3">
                  <ConnectivityIndicator />
                </div>
              </div>

              {errorEntries.length > 0 && (
                <div ref={summaryRef} tabIndex={-1} role="alert" className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 outline-none">
                  <p className="text-sm font-semibold text-red-800">
                    {errorEntries.length === 1 ? "One thing needs fixing:" : `${errorEntries.length} things need fixing:`}
                  </p>
                  <ul className="mt-1 list-disc pl-5 text-sm text-red-800">
                    {errorEntries.map(([field, message]) => (
                      <li key={field}>
                        <span className="font-medium">{FIELD_LABELS[field]}:</span> {message}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <form onSubmit={handleSubmit} noValidate className="space-y-4">
                <TextField label="Full name" name="full_name" autoComplete="name" value={form.full_name} onChange={(e) => update("full_name", e.target.value)} error={errors.full_name} className="text-base sm:text-sm" />
                <TextField
                  label="CHW ID you'd like"
                  name="chw_id"
                  autoComplete="off"
                  placeholder="e.g. CHW005"
                  value={form.chw_id}
                  onChange={(e) => update("chw_id", e.target.value.toUpperCase())}
                  error={errors.chw_id}
                  className="text-base sm:text-sm"
                />
                <Select
                  label="Clinic"
                  id="clinic_id"
                  value={form.clinic_id}
                  onValueChange={(v) => update("clinic_id", v)}
                  placeholder={clinicsQuery.isPending && isOnline ? "Loading clinics…" : "Choose your clinic"}
                  options={(clinicsQuery.data ?? []).map((c) => ({ value: c.id, label: c.name }))}
                  error={errors.clinic_id}
                  disabled={!clinicsQuery.data}
                />
                <TextField
                  label="Phone number (optional)"
                  name="phone_number"
                  type="tel"
                  inputMode="numeric"
                  autoComplete="tel"
                  placeholder="0771234567"
                  value={form.phone_number}
                  onChange={(e) => update("phone_number", e.target.value.replace(/\D/g, ""))}
                  error={errors.phone_number}
                  className="text-base sm:text-sm"
                />
                <div className="grid grid-cols-2 gap-3">
                  <TextField
                    label="Choose a PIN"
                    name="pin"
                    type="password"
                    inputMode="numeric"
                    autoComplete="new-password"
                    maxLength={4}
                    value={form.pin}
                    onChange={(e) => update("pin", e.target.value.replace(/\D/g, "").slice(0, 4))}
                    error={errors.pin}
                    className="text-base sm:text-sm"
                  />
                  <TextField
                    label="Type it again"
                    name="confirm"
                    type="password"
                    inputMode="numeric"
                    autoComplete="new-password"
                    maxLength={4}
                    value={form.confirm}
                    onChange={(e) => update("confirm", e.target.value.replace(/\D/g, "").slice(0, 4))}
                    error={errors.confirm}
                    className="text-base sm:text-sm"
                  />
                </div>
                <p className="text-xs text-stone-600">4 digits. Only you should know it - supervisors never see it.</p>

                {!isOnline && (
                  <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
                    Sending a request needs the Mosi server. Connect (or turn off Work Offline) to continue.
                  </p>
                )}
                {submit.isError && (
                  <p ref={errorRef} tabIndex={-1} role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800 outline-none">
                    {requestErrorMessage(submit.error)}
                  </p>
                )}

                <Button type="submit" size="lg" className="w-full" disabled={!isOnline || submit.isPending}>
                  {submit.isPending ? "Sending…" : "Send request"}
                </Button>
              </form>
              <p className="text-center text-sm text-stone-600">
                Already have an account?{" "}
                <Link to="/login" className="font-medium text-forest-800 underline underline-offset-2">
                  Sign in
                </Link>
              </p>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}

export default RequestAccount;
