-- AlterTable
ALTER TABLE "patients" ADD COLUMN     "household_id" TEXT;

-- CreateTable
CREATE TABLE "households" (
    "id" TEXT NOT NULL,
    "household_code" TEXT NOT NULL,
    "village" TEXT NOT NULL,
    "clinic_id" TEXT NOT NULL,
    "created_by_chw_id" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "households_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "households_household_code_key" ON "households"("household_code");

-- CreateIndex
CREATE INDEX "households_clinic_id_idx" ON "households"("clinic_id");

-- CreateIndex
CREATE INDEX "households_village_idx" ON "households"("village");

-- CreateIndex
CREATE INDEX "patients_household_id_idx" ON "patients"("household_id");

-- AddForeignKey
ALTER TABLE "patients" ADD CONSTRAINT "patients_household_id_fkey" FOREIGN KEY ("household_id") REFERENCES "households"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "households" ADD CONSTRAINT "households_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

