import { describe, expect, it } from "vitest";
import pino from "pino";
import { LOG_REDACT } from "../logger";

describe("log redaction", () => {
  it("never writes session cookies, bearer tokens or Set-Cookie to the logs", () => {
    const lines: string[] = [];
    const log = pino({ redact: LOG_REDACT }, { write: (line: string) => lines.push(line) });
    log.info({
      req: { method: "GET", url: "/api/patients", headers: { cookie: "mosi_session=eyJSECRET", authorization: "Bearer eyJSECRET2", "user-agent": "test" } },
      res: { statusCode: 200, headers: { "set-cookie": "mosi_session=eyJSECRET3; HttpOnly" } },
    });
    const out = lines.join("");
    expect(out).not.toContain("eyJSECRET");
    expect(out).toContain("[redacted]");
    expect(out).toContain("/api/patients"); // the useful parts are still logged
  });
});
