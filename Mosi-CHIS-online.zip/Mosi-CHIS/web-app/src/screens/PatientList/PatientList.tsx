import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { Search, Plus, Download, Users, ChevronRight, Home } from "lucide-react";
import { db } from "../../db/indexedDb";
import * as authService from "../../services/authService";
import { formatDate } from "../../utils/formatDate";
import { downloadCsv } from "../../utils/csvExport";
import { calendarDay, localIsoDate } from "../../utils/localDate";
import { usePageTitle } from "../../hooks/usePageTitle";
import { SyncStatusBadge } from "../../components/ui/SyncStatusBadge";
import { Button } from "../../components/ui/Button";
import { Select } from "../../components/ui/Select";
import { TextField } from "../../components/ui/TextField";
import { PageHeader } from "../../components/ui/PageHeader";
import { EmptyState } from "../../components/ui/EmptyState";
import { Pagination } from "../../components/ui/Pagination";
import { Card } from "../../components/ui/Card";
import type { Patient } from "../../models/patient";
import { isSupervisorRole } from "../../models/chw";
import type { Household } from "../../models/household";

const PAGE_SIZE = 10;

const PATIENT_CSV_HEADERS = [
  "id",
  "patient_id",
  "first_name",
  "last_name",
  "date_of_birth",
  "gender",
  "village",
  "phone_number",
  "created_at",
  "updated_at",
  "sync_status",
] as const;

function patientToCsvRow(patient: Patient) {
  return [
    patient.id,
    patient.patient_id,
    patient.first_name,
    patient.last_name,
    patient.date_of_birth,
    patient.gender,
    patient.village,
    patient.phone_number,
    patient.created_at,
    patient.updated_at,
    patient.sync_status,
  ];
}

function formatLastVisit(isoDate: string | undefined): string {
  if (!isoDate) return "No visits yet";
  return `Last visit ${new Date(`${isoDate}T00:00:00`).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" })}`;
}

function PatientList() {
  usePageTitle("Patients");
  const session = authService.getSession();
  const isSupervisor = isSupervisorRole(session?.chw.role);

  const [search, setSearch] = useState("");
  const [villageFilter, setVillageFilter] = useState("");
  const [chwFilter, setChwFilter] = useState("");
  const [page, setPage] = useState(1);
  const [groupByHousehold, setGroupByHousehold] = useState(false);
  const households = useLiveQuery(() => db.households.toArray(), []);

  useEffect(() => setPage(1), [search, villageFilter, chwFilter]);

  const villages = useLiveQuery(async () => {
    const patients = await db.patients.toArray();
    return Array.from(new Set(patients.map((p) => p.village))).sort();
  }, []);

  const chws = useLiveQuery(() => db.chws.where("role").equals("CHW").toArray(), []);

  const patients = useLiveQuery(async () => {
    let result = await db.patients.toArray();

    if (chwFilter) {
      const visits = await db.visits.where("chw_id").equals(chwFilter).toArray();
      const patientIdsForChw = new Set(visits.map((v) => v.patient_id));
      result = result.filter((p) => patientIdsForChw.has(p.id));
    }

    if (villageFilter) {
      result = result.filter((p) => p.village === villageFilter);
    }

    const term = search.trim().toLowerCase();
    if (term) {
      result = result.filter(
        (p) =>
          p.patient_id.toLowerCase().includes(term) ||
          p.first_name.toLowerCase().includes(term) ||
          p.last_name.toLowerCase().includes(term) ||
          `${p.first_name} ${p.last_name}`.toLowerCase().includes(term) ||
          p.village.toLowerCase().includes(term),
      );
    }

    result.sort((a, b) => a.last_name.localeCompare(b.last_name) || a.first_name.localeCompare(b.first_name));

    return result;
  }, [search, villageFilter, chwFilter]);

  // Most recent visit date per patient, from this device's cache.
  const lastVisitByPatient = useLiveQuery(async () => {
    const map = new Map<string, string>();
    await db.visits.each((v) => {
      if (v.deleted_at) return;
      const prev = map.get(v.patient_id);
      const day = calendarDay(v.visit_date);
      if (!prev || day > prev) map.set(v.patient_id, day);
    });
    return map;
  }, []);

  const pageItems = patients?.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  function handleExport() {
    if (!patients || patients.length === 0) return;
    downloadCsv(
      `mosi-patients-${localIsoDate()}.csv`,
      [...PATIENT_CSV_HEADERS],
      patients.map(patientToCsvRow),
    );
  }

  return (
    <div className="space-y-5">
      <PageHeader
        title="Patients"
        description={isSupervisor ? "Everyone registered in your clinic." : "Search by name, patient ID or village."}
        actions={
          <>
            {isSupervisor && (
              <Button variant="secondary" onClick={handleExport} disabled={!patients || patients.length === 0}>
                <Download className="h-4 w-4" aria-hidden="true" />
                Export CSV
              </Button>
            )}
            {!isSupervisor && (
              <Button asChild>
                <Link to="/chw/patients/new">
                  <Plus className="h-4 w-4" aria-hidden="true" />
                  Add patient
                </Link>
              </Button>
            )}
          </>
        }
      />

      <div className="flex flex-wrap gap-3">
        <div className="flex-1 min-w-[200px]">
          <TextField
            icon={Search}
            type="search"
            placeholder="Name, patient ID or village"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            aria-label="Search patients by name, patient ID or village"
            className="text-base sm:text-sm"
          />
        </div>
        <Select
          value={villageFilter}
          onValueChange={setVillageFilter}
          placeholder="All villages"
          ariaLabel="Filter by village"
          className="w-auto min-w-[140px]"
          options={[
            { value: "", label: "All villages" },
            ...(villages ?? []).map((village) => ({ value: village, label: village })),
          ]}
        />
        {isSupervisor && (
        <Select
          value={chwFilter}
          onValueChange={setChwFilter}
          placeholder="All CHWs"
          ariaLabel="Filter by CHW"
          className="w-auto min-w-[140px]"
          options={[
            { value: "", label: "All CHWs" },
            ...(chws ?? []).map((chw) => ({ value: chw.chw_id, label: chw.full_name })),
          ]}
        />
        )}
        <label className="inline-flex min-h-11 cursor-pointer items-center gap-2 text-sm font-medium text-stone-700">
          <input
            type="checkbox"
            checked={groupByHousehold}
            onChange={(e) => setGroupByHousehold(e.target.checked)}
            className="h-4 w-4 accent-forest-800"
          />
          Group by household
        </label>
      </div>

      {patients === undefined && <p className="text-sm text-stone-500">Loading patients…</p>}

      {patients && patients.length === 0 && (
        <EmptyState icon={Users} title="No patients match your filters" description="Try a different search term or clear a filter." />
      )}

      {groupByHousehold && patients && patients.length > 0 && (
        <HouseholdGroups patients={patients} households={households ?? []} lastVisitByPatient={lastVisitByPatient} />
      )}

      {!groupByHousehold && pageItems && pageItems.length > 0 && (
        <>
          {/* Desktop table */}
          <Card className="hidden md:block overflow-hidden p-0">
            <table className="w-full text-sm">
              <thead className="bg-stone-50 border-b border-stone-200 text-left text-xs text-stone-500">
                <tr>
                  <th scope="col" className="px-4 py-2.5 font-medium">Name</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Patient ID</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Village</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Last visit</th>
                  <th scope="col" className="px-4 py-2.5 font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {pageItems.map((patient) => (
                  <tr key={patient.id} className="hover:bg-stone-50 transition-colors">
                    <td className="px-4 py-3">
                      <Link
                        to={`/patients/${patient.id}`}
                        className="font-medium text-forest-800 hover:text-forest-900 hover:underline"
                      >
                        {patient.first_name} {patient.last_name}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-stone-600">{patient.patient_id}</td>
                    <td className="px-4 py-3 text-stone-600">{patient.village}</td>
                    <td className="px-4 py-3 text-stone-600">
                      {formatLastVisit(lastVisitByPatient?.get(patient.id)).replace("Last visit ", "")}
                    </td>
                    <td className="px-4 py-3">
                      <SyncStatusBadge status={patient.sync_status} review={patient.review_status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          {/* Mobile list: what a CHW needs to pick the right person */}
          <ul className="md:hidden divide-y divide-stone-100 overflow-hidden rounded-xl border border-stone-200 bg-white">
            {pageItems.map((patient) => (
              <li key={patient.id}>
                <Link
                  to={`/patients/${patient.id}`}
                  className="flex min-h-16 items-center justify-between gap-3 px-4 py-3 hover:bg-stone-50"
                >
                  <div className="min-w-0">
                    <p className="font-medium text-stone-900">
                      {patient.first_name} {patient.last_name}
                    </p>
                    <p className="mt-0.5 text-xs text-stone-600">
                      {patient.patient_id} · {patient.village}
                    </p>
                    <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-stone-500">
                      {formatLastVisit(lastVisitByPatient?.get(patient.id))}
                      {patient.sync_status === "pending" && <SyncStatusBadge status="pending" />}
                    </p>
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-stone-400" aria-hidden="true" />
                </Link>
              </li>
            ))}
          </ul>

          <Pagination page={page} pageSize={PAGE_SIZE} totalItems={patients?.length ?? 0} onPageChange={setPage} itemLabel="patients" />
        </>
      )}
    </div>
  );
}

// Patients grouped under their household (code, village, member count),
// then everyone not in a household. Uses the current search/filters.
function HouseholdGroups({
  patients,
  households,
  lastVisitByPatient,
}: {
  patients: Patient[];
  households: Household[];
  lastVisitByPatient: Map<string, string> | undefined;
}) {
  const byId = new Map(households.map((h) => [h.id, h]));
  const groups = new Map<string, Patient[]>();
  const loose: Patient[] = [];
  for (const p of patients) {
    if (p.household_id && byId.has(p.household_id)) {
      const list = groups.get(p.household_id) ?? [];
      list.push(p);
      groups.set(p.household_id, list);
    } else {
      loose.push(p);
    }
  }
  const ordered = [...groups.entries()].sort(([a], [b]) => byId.get(a)!.household_code.localeCompare(byId.get(b)!.household_code));

  const row = (patient: Patient) => (
    <li key={patient.id}>
      <Link to={`/patients/${patient.id}`} className="flex min-h-14 items-center justify-between gap-3 px-4 py-2.5 hover:bg-stone-50">
        <span className="min-w-0">
          <span className="block font-medium text-stone-900">
            {patient.first_name} {patient.last_name}
          </span>
          <span className="block text-xs text-stone-600">
            {patient.patient_id} · {formatLastVisit(lastVisitByPatient?.get(patient.id))}
          </span>
        </span>
        <ChevronRight className="h-4 w-4 shrink-0 text-stone-400" aria-hidden="true" />
      </Link>
    </li>
  );

  return (
    <div className="space-y-4">
      {ordered.map(([id, members]) => {
        const h = byId.get(id)!;
        return (
          <section key={id} aria-labelledby={`hh-${id}`} className="overflow-hidden rounded-xl border border-stone-200 bg-white">
            <h2 id={`hh-${id}`} className="flex flex-wrap items-baseline justify-between gap-2 border-b border-stone-100 bg-stone-50 px-4 py-2.5 text-sm">
              <span className="font-semibold text-stone-900">
                <Home className="mr-1.5 inline h-4 w-4 align-text-bottom text-forest-800" aria-hidden="true" />
                {h.household_code}
                <span className="font-normal text-stone-600"> · {h.village}</span>
              </span>
              <span className="text-stone-600">
                {members.length} {members.length === 1 ? "member" : "members"}
              </span>
            </h2>
            <ul className="divide-y divide-stone-100">{members.map(row)}</ul>
          </section>
        );
      })}
      {loose.length > 0 && (
        <section aria-labelledby="hh-none" className="overflow-hidden rounded-xl border border-stone-200 bg-white">
          <h2 id="hh-none" className="border-b border-stone-100 bg-stone-50 px-4 py-2.5 text-sm font-semibold text-stone-900">
            Not in a household <span className="font-normal text-stone-600">({loose.length})</span>
          </h2>
          <ul className="divide-y divide-stone-100">{loose.map(row)}</ul>
        </section>
      )}
    </div>
  );
}

export default PatientList;
