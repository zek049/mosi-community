import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { QueryClientProvider } from "@tanstack/react-query";
import App from "./App";
import { NetworkProvider } from "./contexts/NetworkContext";
import { AnnouncerProvider } from "./contexts/AnnouncerContext";
import { SyncProvider } from "./contexts/SyncContext";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { queryClient } from "./lib/queryClient";
import "./index.css";

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("Root element #root not found in index.html");
}

createRoot(rootElement).render(
  <StrictMode>
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <NetworkProvider>
          <AnnouncerProvider>
            <SyncProvider>
              <App />
            </SyncProvider>
          </AnnouncerProvider>
        </NetworkProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  </StrictMode>,
);

// Production only - registering this against the Vite dev server would cache
// dev-mode module requests and fight with HMR, hiding your own edits behind
// a stale cache while iterating.
if (import.meta.env.PROD && "serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => {
      // Non-fatal: Mosi's actual offline capability lives in IndexedDB
      // (db/indexedDb.ts), not here - this only adds app-shell caching for
      // faster repeat loads and full network-independence once installed.
    });
  });
}
