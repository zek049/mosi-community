// Guards against a device with a badly wrong (or maliciously set) clock
// poisoning last-write-wins conflict resolution: a record with a far-future
// updated_at would out-rank every legitimate future edit indefinitely,
// since nothing could ever be "newer" than it (found via adversarial
// testing - a 5-years-ahead timestamp was accepted with no bound at all).
//
// The tolerance only needs to cover clock/timezone MISCONFIGURATION, not
// how long a device can stay offline: created_at/updated_at are set at the
// moment of the edit on the device, so a device offline for months still
// produces a correctly-old timestamp as long as its clock was roughly right
// at edit time - only a genuinely wrong clock produces a timestamp ahead of
// the server's own clock by more than ordinary drift/timezone confusion.
const MAX_FUTURE_SKEW_MS = 24 * 60 * 60 * 1000; // 24h - generous for timezone mistakes, not for years-ahead poisoning
const MIN_REASONABLE_DATE = new Date("2000-01-01T00:00:00.000Z"); // this system could not have produced an earlier record

export function isReasonableRecordTimestamp(date: Date): boolean {
  if (Number.isNaN(date.getTime())) return false;
  if (date.getTime() > Date.now() + MAX_FUTURE_SKEW_MS) return false;
  if (date.getTime() < MIN_REASONABLE_DATE.getTime()) return false;
  return true;
}
