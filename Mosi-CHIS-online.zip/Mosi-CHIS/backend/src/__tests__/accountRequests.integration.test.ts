import { beforeEach, describe, expect, it, vi } from "vitest";
import bcrypt from "bcryptjs";

vi.hoisted(() => {
  process.env.JWT_SECRET = "test-secret-for-integration-tests";
});

const m = vi.hoisted(() => ({
  chwFindUnique: vi.fn(),
  chwCreate: vi.fn(),
  chwFindMany: vi.fn(),
  chwUpdate: vi.fn(),
  reqFindFirst: vi.fn(),
  reqFindUnique: vi.fn(),
  reqCreate: vi.fn(),
  reqUpdate: vi.fn(),
  reqFindMany: vi.fn(),
  clinicFindUnique: vi.fn(),
  clinicFindMany: vi.fn(),
  auditLogCreate: vi.fn(),
  transaction: vi.fn(),
}));

vi.mock("../db", () => ({
  prisma: {
    chw: { findUnique: m.chwFindUnique, create: m.chwCreate, findMany: m.chwFindMany, update: m.chwUpdate },
    accountRequest: { findFirst: m.reqFindFirst, findUnique: m.reqFindUnique, create: m.reqCreate, update: m.reqUpdate, findMany: m.reqFindMany },
    clinic: { findUnique: m.clinicFindUnique, findMany: m.clinicFindMany },
    auditLog: { create: m.auditLogCreate },
    $transaction: m.transaction,
  },
}));

import request from "supertest";
import app from "../app";
import { signSessionToken } from "../middleware/auth";
import { accountRequestLimiter } from "../middleware/rateLimit";

const CLINIC = { id: "clinic-a", name: "Clinic A", active: true };
const valid = { chw_id: "chw555", full_name: "New Person", clinic_id: "clinic-a", phone_number: "0771234567", pin: "4821" };
const sup = { chw_id: "SUP001", role: "SUPERVISOR", status: "active", locked_until: null, clinic_id: "clinic-a" }; // supervisors are clinic-scoped (admin-role feature)
const chw = { chw_id: "CHW001", role: "CHW", status: "active", locked_until: null, clinic_id: "clinic-a" };
const REQ_ID = "6f1c2a8e-0000-4000-8000-000000000001";
const supToken = () => signSessionToken({ chwId: "SUP001", role: "SUPERVISOR", fullName: "Sup" });
const chwToken = () => signSessionToken({ chwId: "CHW001", role: "CHW", fullName: "Chw" });
let pinHash = "";
const pendingRequest = () => ({ id: REQ_ID, full_name: "New Person", requested_chw_id: "CHW555", clinic_id: "clinic-a", phone_number: "0771234567", pin_hash: pinHash, status: "pending" });

// authenticate() and the routes use chw.findUnique; answer by chw_id.
function accounts(rows: Record<string, unknown>[]) {
  m.chwFindUnique.mockImplementation(async ({ where }: { where: { chw_id: string } }) => rows.find((r) => r.chw_id === where.chw_id) ?? null);
}

beforeEach(async () => {
  // Every supertest request comes from the same local address; start each
  // test with a fresh allowance (the limit itself is tested at the end).
  for (const key of ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:127.0.0.0/120", "::1/56"]) await accountRequestLimiter.resetKey(key);
  vi.clearAllMocks();
  pinHash = pinHash || (await bcrypt.hash("4821", 10));
  m.auditLogCreate.mockResolvedValue({});
  m.clinicFindUnique.mockResolvedValue(CLINIC);
  m.reqFindFirst.mockResolvedValue(null);
  m.reqFindUnique.mockResolvedValue(pendingRequest());
  m.reqCreate.mockImplementation(async ({ data }: { data: Record<string, unknown> }) => ({ id: REQ_ID, status: "pending", ...data }));
  m.reqUpdate.mockImplementation(async ({ data }: { data: Record<string, unknown> }) => ({ id: REQ_ID, ...data }));
  // Like Prisma: return only the selected fields.
  m.chwCreate.mockImplementation(async ({ data, select }: { data: Record<string, unknown>; select?: Record<string, boolean> }) =>
    select ? Object.fromEntries(Object.keys(select).map((k) => [k, data[k]])) : { ...data },
  );
  m.transaction.mockImplementation(async (ops: unknown[]) => Promise.all(ops));
  accounts([sup, chw]);
});

describe("POST /api/account-requests (public)", () => {
  it("creates a PENDING request (not an account) with a hashed PIN", async () => {
    const res = await request(app).post("/api/account-requests").send(valid);
    expect(res.status).toBe(201);
    expect(res.body.data).toMatchObject({ chw_id: "CHW555", full_name: "New Person", clinic: "Clinic A", status: "pending" });
    expect(m.chwCreate).not.toHaveBeenCalled(); // no usable account yet
    const data = m.reqCreate.mock.calls[0][0].data;
    expect(data.requested_chw_id).toBe("CHW555");
    expect(data.pin_hash).not.toContain("4821");
    expect(await bcrypt.compare("4821", data.pin_hash)).toBe(true);
    expect(data.status).toBeUndefined(); // the DB default ("pending") applies, never client input
    expect(JSON.stringify(res.body)).not.toContain("4821");
    const audit = JSON.stringify(m.auditLogCreate.mock.calls);
    expect(audit).toContain("ACCOUNT_REQUESTED");
    expect(audit).not.toContain("4821");
  });

  it.each([[{ role: "SUPERVISOR" }], [{ status: "approved" }], [{ approved: true }], [{ reviewed_by: "SUP001" }]])(
    "refuses a request that tries to set privileged fields %j",
    async (extra) => {
      const res = await request(app).post("/api/account-requests").send({ ...valid, ...extra });
      expect(res.status).toBe(400);
      expect(m.reqCreate).not.toHaveBeenCalled();
    },
  );

  it("one generic 409 when the ID belongs to an account OR another pending request", async () => {
    accounts([sup, chw, { chw_id: "CHW555", status: "active" }]);
    const taken = await request(app).post("/api/account-requests").send(valid);
    accounts([sup, chw]);
    m.reqFindFirst.mockResolvedValue({ id: "other" });
    const requested = await request(app).post("/api/account-requests").send(valid);
    for (const res of [taken, requested]) {
      expect(res.status).toBe(409);
      expect(res.body.code).toBe("CHW_ID_UNAVAILABLE");
      expect(res.body.message).toBe("That CHW ID can't be used. Choose a different one, or ask your supervisor.");
    }
    expect(m.reqCreate).not.toHaveBeenCalled();
  });

  it.each([[{ pin: "12a4" }], [{ pin: "123" }], [{ full_name: "" }], [{ chw_id: "a b" }], [{ phone_number: "12345" }], [{ clinic_id: "" }]])(
    "validates input %j",
    async (bad) => {
      const res = await request(app).post("/api/account-requests").send({ ...valid, ...bad });
      expect(res.status).toBe(400);
      expect(m.reqCreate).not.toHaveBeenCalled();
    },
  );

  it.each(["1234", "0000", "2580"])("refuses a guessable PIN (%s) - 400 WEAK_PIN", async (pin) => {
    const res = await request(app).post("/api/account-requests").send({ ...valid, pin });
    expect(res.status).toBe(400);
    expect(res.body.code).toBe("WEAK_PIN");
    expect(m.reqCreate).not.toHaveBeenCalled();
  });

  it("refuses an inactive clinic", async () => {
    m.clinicFindUnique.mockResolvedValue({ ...CLINIC, active: false });
    expect((await request(app).post("/api/account-requests").send(valid)).status).toBe(400);
  });

  it("public clinic list returns only id + name", async () => {
    m.clinicFindMany.mockResolvedValue([{ id: "c1", name: "Clinic A" }]);
    const res = await request(app).get("/api/account-requests/clinics");
    expect(res.status).toBe(200);
    expect(m.clinicFindMany.mock.calls[0][0].select).toEqual({ id: true, name: true });
  });
});

describe("signing in before approval", () => {
  it("correct PIN for a pending request -> 403 ACCOUNT_PENDING, no session", async () => {
    accounts([]);
    m.reqFindFirst.mockResolvedValue({ pin_hash: pinHash });
    const res = await request(app).post("/api/auth/login").send({ chw_id: "CHW555", pin: "4821" });
    expect(res.status).toBe(403);
    expect(res.body.code).toBe("ACCOUNT_PENDING");
    expect(res.headers["set-cookie"]).toBeUndefined();
  });

  it("wrong PIN for a pending request looks exactly like an unknown ID", async () => {
    accounts([]);
    m.reqFindFirst.mockResolvedValue({ pin_hash: pinHash });
    const wrong = await request(app).post("/api/auth/login").send({ chw_id: "CHW555", pin: "0000" });
    m.reqFindFirst.mockResolvedValue(null);
    const unknown = await request(app).post("/api/auth/login").send({ chw_id: "NOPE01", pin: "0000" });
    expect(wrong.status).toBe(401);
    expect(unknown.status).toBe(401);
    expect(wrong.body).toEqual(unknown.body);
  });
});

describe("supervisor review", () => {
  it("unauthenticated users get 401 on every review endpoint", async () => {
    expect((await request(app).get("/api/account-requests")).status).toBe(401);
    expect((await request(app).post(`/api/account-requests/${REQ_ID}/approve`).send({})).status).toBe(401);
    expect((await request(app).post(`/api/account-requests/${REQ_ID}/reject`).send({})).status).toBe(401);
  });

  it("a CHW gets 403 and nothing changes", async () => {
    const auth = { Authorization: `Bearer ${chwToken()}` };
    expect((await request(app).get("/api/account-requests").set(auth)).status).toBe(403);
    expect((await request(app).post(`/api/account-requests/${REQ_ID}/approve`).set(auth).send({})).status).toBe(403);
    expect((await request(app).post(`/api/account-requests/${REQ_ID}/reject`).set(auth).send({})).status).toBe(403);
    expect(m.chwCreate).not.toHaveBeenCalled();
    expect(m.reqUpdate).not.toHaveBeenCalled();
  });

  it("supervisor lists pending requests without any PIN hash, and reviewed ones with the reviewer's name", async () => {
    m.reqFindMany.mockResolvedValue([{ ...pendingRequest(), pin_hash: undefined, clinic: { name: "Clinic A" }, reviewed_by: null }]);
    const res = await request(app).get("/api/account-requests").set("Authorization", `Bearer ${supToken()}`);
    expect(res.status).toBe(200);
    const q = m.reqFindMany.mock.calls[0][0];
    expect(q.where.status).toBe("pending");
    expect(q.select.pin_hash).toBeUndefined();
    expect(JSON.stringify(res.body)).not.toContain("pin_hash");

    m.reqFindMany.mockResolvedValue([{ ...pendingRequest(), status: "approved", clinic: { name: "Clinic A" }, reviewed_by: "SUP001" }]);
    m.chwFindMany.mockResolvedValue([{ chw_id: "SUP001", full_name: "Grace Chikwanha" }]);
    const reviewed = await request(app).get("/api/account-requests?status=reviewed").set("Authorization", `Bearer ${supToken()}`);
    expect(m.reqFindMany.mock.calls[1][0].where.status).toEqual({ in: ["approved", "rejected"] });
    expect(reviewed.body.data[0].reviewed_by_name).toBe("Grace Chikwanha");
  });

  it("approve: creates a real ACTIVE CHW account from the request (same PIN hash), marks it approved, audited", async () => {
    const res = await request(app).post(`/api/account-requests/${REQ_ID}/approve`).set("Authorization", `Bearer ${supToken()}`).send({});
    expect(res.status).toBe(200);
    const created = m.chwCreate.mock.calls[0][0].data;
    expect(created).toMatchObject({ chw_id: "CHW555", full_name: "New Person", role: "CHW", status: "active", clinic_id: "clinic-a", pin_hash: pinHash });
    const updated = m.reqUpdate.mock.calls[0][0].data;
    expect(updated).toMatchObject({ status: "approved", reviewed_by: "SUP001", pin_hash: null });
    expect(updated.reviewed_at).toBeInstanceOf(Date);
    expect(m.transaction).toHaveBeenCalledTimes(1); // account + request change together
    expect(JSON.stringify(m.auditLogCreate.mock.calls)).toContain("ACCOUNT_APPROVED");
    expect(JSON.stringify(res.body)).not.toContain(pinHash);
  });

  it("approve: supervisor can't smuggle in a role (strict body)", async () => {
    const res = await request(app).post(`/api/account-requests/${REQ_ID}/approve`).set("Authorization", `Bearer ${supToken()}`).send({ role: "SUPERVISOR" });
    expect(res.status).toBe(400);
    expect(m.chwCreate).not.toHaveBeenCalled();
  });

  it("approve: refuses if the ID was taken since the request", async () => {
    accounts([sup, chw, { chw_id: "CHW555", status: "active" }]);
    const res = await request(app).post(`/api/account-requests/${REQ_ID}/approve`).set("Authorization", `Bearer ${supToken()}`).send({});
    expect(res.status).toBe(409);
    expect(m.chwCreate).not.toHaveBeenCalled();
  });

  it("reject: marks it rejected, discards the PIN hash, creates NO account, audited", async () => {
    const res = await request(app).post(`/api/account-requests/${REQ_ID}/reject`).set("Authorization", `Bearer ${supToken()}`).send({ reason: "Not on staff list" });
    expect(res.status).toBe(200);
    expect(m.reqUpdate.mock.calls[0][0].data).toMatchObject({ status: "rejected", reviewed_by: "SUP001", pin_hash: null });
    expect(m.chwCreate).not.toHaveBeenCalled();
    expect(JSON.stringify(m.auditLogCreate.mock.calls)).toContain("ACCOUNT_REJECTED");
  });

  it("a request can't be reviewed twice; unknown ids are 404", async () => {
    const auth = { Authorization: `Bearer ${supToken()}` };
    m.reqFindUnique.mockResolvedValue({ ...pendingRequest(), status: "rejected" });
    expect((await request(app).post(`/api/account-requests/${REQ_ID}/approve`).set(auth).send({})).status).toBe(409);
    m.reqFindUnique.mockResolvedValue(null);
    expect((await request(app).post(`/api/account-requests/${REQ_ID}/reject`).set(auth).send({})).status).toBe(404);
    expect(m.chwCreate).not.toHaveBeenCalled();
  });
});

// Kept last: exhausts this process's public request limiter.
describe("request rate limit", () => {
  it("allows 5 requests per hour per network, then 429", async () => {
    const codes: number[] = [];
    for (let i = 0; i < 6; i++) codes.push((await request(app).post("/api/account-requests").send({ ...valid, chw_id: `RL${i}X` })).status);
    expect(codes.slice(0, 5).every((c) => c === 201)).toBe(true);
    expect(codes[5]).toBe(429);
  });
});
