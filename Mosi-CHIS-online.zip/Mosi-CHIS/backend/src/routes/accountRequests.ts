import { Router } from "express";
import bcrypt from "bcryptjs";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { authenticate, requireRole } from "../middleware/auth";
import { clinicScope } from "../middleware/authz";
import { accountRequestLimiter } from "../middleware/rateLimit";
import { requireStringParam } from "../utils/params";
import { parseBody, accountRequestSchema, accountApprovalSchema, accountRejectionSchema } from "../validation/schemas";
import { writeAuditLog } from "../utils/audit";
import { isWeakPin, WEAK_PIN_MESSAGE } from "../utils/pinPolicy";

// Account requests live in their own table (account_requests). A request is
// never an account: nothing in it can sign in.
//
//   pending --(supervisor approves)--> approved  + a real Chw row is created
//           --(supervisor rejects)---> rejected  (PIN hash discarded)
//
// Approval creates the Chw and marks the request in ONE transaction, using
// the PIN hash the requester produced - the supervisor never sees or sets it.

// What a supervisor sees about a request. pin_hash is never selected.
const REQUEST_SELECT = {
  id: true,
  full_name: true,
  requested_chw_id: true,
  clinic_id: true,
  phone_number: true,
  status: true,
  requested_at: true,
  reviewed_at: true,
  reviewed_by: true,
  clinic: { select: { name: true } },
} as const;

const TAKEN_MESSAGE = "That CHW ID can't be used. Choose a different one, or ask your supervisor.";

// ---------------------------------------------------------------------
// Public (no session): the request form and the clinic list it needs.
// ---------------------------------------------------------------------
export const publicAccountRequestRoutes = Router();

// Clinic names/ids only - nothing else about clinics, staff or patients.
publicAccountRequestRoutes.get("/clinics", async (_req, res) => {
  const clinics = await prisma.clinic.findMany({
    where: { active: true },
    select: { id: true, name: true },
    orderBy: { name: "asc" },
  });
  res.json({ success: true, data: clinics });
});

publicAccountRequestRoutes.post("/", accountRequestLimiter, async (req, res) => {
  // .strict(): any role / status / approval field in the body is a 400.
  const body = parseBody(accountRequestSchema, req.body ?? {});
  if (isWeakPin(body.pin)) throw new AppError(400, WEAK_PIN_MESSAGE, "WEAK_PIN");

  const [existingAccount, openRequest, clinic] = await Promise.all([
    prisma.chw.findUnique({ where: { chw_id: body.chw_id }, select: { chw_id: true } }),
    prisma.accountRequest.findFirst({ where: { requested_chw_id: body.chw_id, status: "pending" }, select: { id: true } }),
    prisma.clinic.findUnique({ where: { id: body.clinic_id } }),
  ]);
  if (!clinic || !clinic.active) {
    throw new AppError(400, "Choose one of the listed clinics.");
  }
  // One message whether the ID belongs to an account or another open request.
  if (existingAccount || openRequest) {
    throw new AppError(409, TAKEN_MESSAGE, "CHW_ID_UNAVAILABLE");
  }

  const request = await prisma.accountRequest.create({
    data: {
      full_name: body.full_name,
      requested_chw_id: body.chw_id,
      clinic_id: clinic.id,
      phone_number: body.phone_number ?? null,
      pin_hash: await bcrypt.hash(body.pin, 10),
    },
    select: { id: true, requested_chw_id: true, full_name: true, status: true },
  });

  await writeAuditLog({
    actor: null,
    action: "ACCOUNT_REQUESTED",
    resourceType: "account_request",
    resourceId: request.id,
    requestId: req.requestId,
    metadata: { requested_chw_id: request.requested_chw_id, clinic_id: clinic.id },
  });

  res.status(201).json({
    success: true,
    data: { id: request.id, chw_id: request.requested_chw_id, full_name: request.full_name, clinic: clinic.name, status: request.status },
  });
});

// ---------------------------------------------------------------------
// Supervisor review (session + SUPERVISOR role, enforced here on the server)
// ---------------------------------------------------------------------
export const accountReviewRoutes = Router();
accountReviewRoutes.use(authenticate, requireRole("SUPERVISOR"));

// ?status=pending (default) | reviewed
accountReviewRoutes.get("/", async (req, res) => {
  const reviewed = req.query.status === "reviewed";
  const scope = clinicScope(req.user!);
  const requests = await prisma.accountRequest.findMany({
    where: {
      status: reviewed ? { in: ["approved", "rejected"] } : "pending",
      ...(scope ? { clinic_id: scope } : {}),
    },
    select: REQUEST_SELECT,
    orderBy: reviewed ? { reviewed_at: "desc" } : { requested_at: "asc" },
    take: 200,
  });

  // Reviewer display names, for the "Reviewed" list.
  const reviewerIds = [...new Set(requests.map((r) => r.reviewed_by).filter((id): id is string => Boolean(id)))];
  const reviewers = reviewerIds.length
    ? await prisma.chw.findMany({ where: { chw_id: { in: reviewerIds } }, select: { chw_id: true, full_name: true } })
    : [];
  const reviewerName = new Map(reviewers.map((r) => [r.chw_id, r.full_name]));

  res.json({
    success: true,
    data: requests.map(({ clinic, ...r }) => ({
      ...r,
      clinic: clinic.name,
      reviewed_by_name: r.reviewed_by ? (reviewerName.get(r.reviewed_by) ?? r.reviewed_by) : null,
    })),
  });
});

async function findPendingInScope(id: string, actor: Express.Request["user"]) {
  const request = await prisma.accountRequest.findUnique({ where: { id } });
  const scope = clinicScope(actor!);
  // Out-of-scope requests look exactly like missing ones.
  if (!request || (scope && request.clinic_id !== scope)) throw new AppError(404, "Account request not found");
  if (request.status !== "pending") throw new AppError(409, "This request has already been reviewed", "ALREADY_REVIEWED");
  return request;
}

accountReviewRoutes.post("/:id/approve", async (req, res) => {
  const id = requireStringParam(req, "id");
  const body = parseBody(accountApprovalSchema, req.body ?? {});
  const request = await findPendingInScope(id, req.user);
  if (!request.pin_hash) throw new AppError(409, "This request has no PIN on file; ask the person to request again");

  // The supervisor may confirm or change the clinic (within their own scope).
  const clinicId = body.clinic_id ?? request.clinic_id;
  const scope = clinicScope(req.user!);
  if (scope && clinicId !== scope) throw new AppError(403, "You can only assign CHWs to your own clinic");
  const clinic = await prisma.clinic.findUnique({ where: { id: clinicId } });
  if (!clinic || !clinic.active) throw new AppError(400, "clinic_id does not refer to an active clinic");

  // The ID may have been taken since the request was made.
  if (await prisma.chw.findUnique({ where: { chw_id: request.requested_chw_id }, select: { chw_id: true } })) {
    throw new AppError(409, "That CHW ID is now used by another account. Reject this request and ask for a new one.", "CHW_ID_UNAVAILABLE");
  }

  const reviewedAt = new Date();
  const [chw] = await prisma.$transaction([
    prisma.chw.create({
      data: {
        chw_id: request.requested_chw_id,
        full_name: request.full_name,
        phone_number: request.phone_number,
        clinic_id: clinic.id,
        clinic: clinic.name,
        pin_hash: request.pin_hash,
        role: "CHW", // requests can only ever produce CHW accounts
        status: "active",
      },
      select: { chw_id: true, full_name: true, clinic: true, clinic_id: true, role: true, status: true },
    }),
    prisma.accountRequest.update({
      where: { id },
      // The hash now lives on the account; don't keep a second copy.
      data: { status: "approved", reviewed_at: reviewedAt, reviewed_by: req.user!.chwId, pin_hash: null },
    }),
  ]);

  await writeAuditLog({
    actor: req.user,
    action: "ACCOUNT_APPROVED",
    resourceType: "account_request",
    resourceId: id,
    requestId: req.requestId,
    metadata: { chw_id: chw.chw_id, clinic_id: clinic.id, requested_clinic_id: request.clinic_id },
  });

  res.json({ success: true, data: { request_id: id, status: "approved", chw } });
});

accountReviewRoutes.post("/:id/reject", async (req, res) => {
  const id = requireStringParam(req, "id");
  const body = parseBody(accountRejectionSchema, req.body ?? {});
  const request = await findPendingInScope(id, req.user);

  await prisma.accountRequest.update({
    where: { id },
    // Data minimisation: a rejected request keeps no credential.
    data: { status: "rejected", reviewed_at: new Date(), reviewed_by: req.user!.chwId, pin_hash: null },
  });

  await writeAuditLog({
    actor: req.user,
    action: "ACCOUNT_REJECTED",
    resourceType: "account_request",
    resourceId: id,
    requestId: req.requestId,
    clinicId: request.clinic_id,
    metadata: body.reason ? { reason: body.reason } : undefined,
  });

  res.json({ success: true, data: { request_id: id, status: "rejected" } });
});
