import { useEffect, useRef, useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { CheckCircle2, User } from "lucide-react";
import * as api from "../../services/api";
import { ApiError, NetworkError } from "../../services/api";
import { useNetwork } from "../../contexts/NetworkContext";
import { usePageTitle } from "../../hooks/usePageTitle";
import { ConnectivityIndicator } from "../../components/Connectivity";
import { Logo } from "../../components/Logo";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { TextField } from "../../components/ui/TextField";

// Exactly the wording a CHW sees after asking; the server gives the same
// answer whether or not the CHW ID exists.
const SENT_MESSAGE = "A supervisor will reset your PIN — check with them for your new temporary PIN.";

function ForgotPin() {
  usePageTitle("Forgot PIN");
  const { isOnline } = useNetwork();
  const [chwId, setChwId] = useState("");
  const [error, setError] = useState<string | null>(null);
  const doneRef = useRef<HTMLHeadingElement>(null);
  const send = useMutation({ mutationFn: () => api.requestPinReset(chwId.trim()) });

  useEffect(() => {
    if (send.isSuccess) doneRef.current?.focus();
  }, [send.isSuccess]);

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!chwId.trim()) {
      setError("Enter your CHW ID, for example CHW001.");
      return;
    }
    setError(null);
    send.mutate();
  }

  const sendError =
    send.error instanceof NetworkError
      ? "Couldn't reach the Mosi server. Your request wasn't sent - try again when you're connected."
      : send.error instanceof ApiError && send.error.status < 500
        ? send.error.message
        : send.isError
          ? "Something went wrong on the server. Please try again."
          : null;

  return (
    <div className="flex min-h-screen flex-col bg-cream">
      <header className="px-6 py-5">
        <Link to="/" aria-label="Mosi home">
          <Logo size="sm" />
        </Link>
      </header>
      <main className="flex flex-1 justify-center px-4 pb-16 sm:px-6">
        <div className="w-full max-w-sm">
          <Card className="space-y-5 p-6 sm:p-8">
            {send.isSuccess ? (
              <>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="mt-1 h-6 w-6 shrink-0 text-emerald-700" aria-hidden="true" />
                  <div>
                    <h1 ref={doneRef} tabIndex={-1} className="text-xl font-semibold text-stone-900 outline-none">
                      Request sent
                    </h1>
                    <p className="mt-1 text-sm text-stone-700">{SENT_MESSAGE}</p>
                  </div>
                </div>
                <p className="text-sm text-stone-600">
                  When you sign in with the temporary PIN, Mosi will ask you to choose a new one that only you know.
                </p>
                <Button asChild size="lg" className="w-full">
                  <Link to="/login">Back to sign in</Link>
                </Button>
              </>
            ) : (
              <>
                <div>
                  <h1 className="text-xl font-semibold text-stone-900">Forgot your PIN?</h1>
                  <p className="mt-1 text-sm text-stone-600">Enter your CHW ID and a supervisor will set you a temporary PIN.</p>
                  <div className="mt-3">
                    <ConnectivityIndicator />
                  </div>
                </div>
                <form onSubmit={handleSubmit} noValidate className="space-y-4">
                  <TextField
                    label="CHW ID"
                    name="forgot_chw_id"
                    icon={User}
                    autoComplete="username"
                    placeholder="e.g. CHW001"
                    value={chwId}
                    onChange={(e) => setChwId(e.target.value.toUpperCase())}
                    error={error ?? undefined}
                    className="text-base sm:text-sm"
                  />
                  {!isOnline && (
                    <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">
                      Sending this needs the Mosi server. Connect (or turn off Work Offline) to continue.
                    </p>
                  )}
                  {sendError && (
                    <p role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800">
                      {sendError}
                    </p>
                  )}
                  <Button type="submit" size="lg" className="w-full" disabled={!isOnline || send.isPending}>
                    {send.isPending ? "Sending…" : "Ask for a PIN reset"}
                  </Button>
                </form>
                <p className="text-center text-sm">
                  <Link to="/login" className="font-medium text-forest-800 underline underline-offset-2">
                    Back to sign in
                  </Link>
                </p>
              </>
            )}
          </Card>
        </div>
      </main>
    </div>
  );
}

export default ForgotPin;
