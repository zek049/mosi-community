import { useEffect, useId, useMemo, useRef, useState, type FormEvent } from "react";
import * as authService from "../../services/authService";
import { useMutation, useQuery } from "@tanstack/react-query";
import { CheckCircle2, CloudOff, Eye, EyeOff, KeyRound, Search } from "lucide-react";
import * as api from "../../services/api";
import { ApiError, NetworkError } from "../../services/api";
import { useNetwork } from "../../contexts/NetworkContext";
import { connectivityLabel } from "../../services/connectivity";
import { usePageTitle } from "../../hooks/usePageTitle";
import { generatePin, validatePinReset, type PinResetErrors } from "../../utils/validators";
import { PageHeader } from "../../components/ui/PageHeader";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { ModalDialog } from "../../components/ui/ModalDialog";
import { cn } from "../../lib/utils";
import { PinResetRequests } from "./PinResetRequests";
import type { Chw } from "../../models/chw";

function resetErrorMessage(error: unknown): string {
  if (error instanceof NetworkError) return "Couldn't reach the Mosi server. The PIN was not changed - try again when you're connected.";
  if (error instanceof ApiError) {
    if (error.status === 401) return "Your session has ended. Sign in again, then retry. The PIN was not changed.";
    if (error.status === 403) return "Your account isn't allowed to reset PINs. The PIN was not changed.";
    if (error.status === 404) return "That account no longer exists. The PIN was not changed.";
    if (error.status === 429) return "Too many requests right now. Wait a minute and try again. The PIN was not changed.";
    if (error.status === 400) return `The server didn't accept that PIN: ${error.message}`;
  }
  return "Something went wrong on the server. The PIN was not changed - please try again.";
}

type PinFieldProps = {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  visible: boolean;
  error?: string;
  hint?: string;
};

function PinField({ id, label, value, onChange, visible, error, hint }: PinFieldProps) {
  const describedBy = [hint ? `${id}-hint` : null, error ? `${id}-error` : null].filter(Boolean).join(" ") || undefined;
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-medium text-stone-700">
        {label}
      </label>
      <input
        id={id}
        type={visible ? "text" : "password"}
        inputMode="numeric"
        // A PIN chosen for someone else: never offer to save it or fill it.
        autoComplete="new-password"
        maxLength={4}
        value={value}
        onChange={(e) => onChange(e.target.value.replace(/\D/g, "").slice(0, 4))}
        aria-invalid={error ? "true" : undefined}
        aria-describedby={describedBy}
        className={cn(
          "w-40 rounded-lg border px-3.5 py-2.5 text-base tracking-[0.3em] focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700",
          error ? "border-red-400" : "border-stone-300",
        )}
      />
      {hint && (
        <p id={`${id}-hint`} className="text-xs text-stone-500">
          {hint}
        </p>
      )}
      {error && (
        <p id={`${id}-error`} className="text-sm text-red-700">
          {error}
        </p>
      )}
    </div>
  );
}

// Supervisor-only (route guarded in App.tsx; the server enforces it again
// with requireRole("SUPERVISOR") - this screen adds no authorization of its
// own). The server has no "temporary PIN" concept: the PIN set here is the
// account's PIN until it's reset again. Nobody's current PIN can be shown,
// because the server only ever stores a hash of it.
function PinReset() {
  usePageTitle("Reset a PIN");
  const { isOnline, status: connectivity } = useNetwork();
  const searchId = useId();
  const chwsQuery = useQuery({ queryKey: ["chws"], queryFn: api.getChws, enabled: isOnline });

  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState("");
  const [pin, setPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [showPin, setShowPin] = useState(false);
  const [errors, setErrors] = useState<PinResetErrors>({});
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [done, setDone] = useState<Chw | null>(null);
  const doneRef = useRef<HTMLDivElement>(null);
  const errorRef = useRef<HTMLParagraphElement>(null);

  const isAdmin = authService.getSession()?.chw.role === "ADMIN";
  const accounts = useMemo(
    () =>
      (chwsQuery.data ?? [])
        // Accounts this viewer may reset: CHWs (a supervisor's own clinic, via
        // the server's scoping); administrators also supervisors - never
        // themselves or another administrator.
        .filter((c) => c.role === "CHW" || (isAdmin && c.role === "SUPERVISOR"))
        .filter((c) => `${c.full_name} ${c.chw_id} ${c.clinic}`.toLowerCase().includes(query.trim().toLowerCase())),
    [chwsQuery.data, query, isAdmin],
  );
  const selected = chwsQuery.data?.find((c) => c.chw_id === selectedId) ?? null;

  const resetMutation = useMutation({
    mutationFn: () => api.resetChwPin(selectedId, pin),
    onSuccess: (account) => {
      // Don't keep the new PIN in memory any longer than needed.
      setPin("");
      setConfirmPin("");
      setShowPin(false);
      setDone(account);
    },
  });

  // Focus the error once it has actually rendered.
  useEffect(() => {
    if (resetMutation.isError) errorRef.current?.focus();
  }, [resetMutation.isError]);

  useEffect(() => {
    if (done) doneRef.current?.focus();
  }, [done]);

  // Clear any typed PIN if the supervisor leaves the screen.
  useEffect(() => () => setPin(""), []);

  function chooseAccount(chwId: string) {
    setSelectedId(chwId);
    setDone(null);
    resetMutation.reset();
  }

  function handleSubmit(event: FormEvent) {
    event.preventDefault();
    const found = validatePinReset(pin, confirmPin);
    setErrors(found);
    if (Object.keys(found).length > 0) {
      window.setTimeout(() => document.getElementById(found.pin ? "new-pin" : "confirm-pin")?.focus(), 0);
      return;
    }
    setConfirmOpen(true);
  }

  function handleGenerate() {
    const generated = generatePin();
    setPin(generated);
    setConfirmPin(generated);
    setShowPin(true);
    setErrors({});
  }

  return (
    <div className="max-w-3xl space-y-6">
      <PageHeader
        title="Reset a PIN"
        description="Set a temporary 4-digit PIN for a CHW who has forgotten theirs or is locked out. They choose their own PIN at their next sign-in. Nobody's current PIN can be shown - Mosi only stores a scrambled (hashed) version."
      />

      {isOnline && <PinResetRequests />}

      {isOnline && <h2 className="pt-2 text-base font-semibold text-stone-900">Reset any CHW's PIN</h2>}

      {!isOnline && (
        <Card className="flex items-start gap-3">
          <CloudOff className="mt-0.5 h-5 w-5 shrink-0 text-stone-600" aria-hidden="true" />
          <p className="text-sm text-stone-700">
            {connectivityLabel(connectivity)}. Resetting a PIN needs the Mosi server - it's available once Mosi can reach it.
          </p>
        </Card>
      )}

      {isOnline && (
        <Card className="space-y-4">
          <h3 className="text-sm font-semibold text-stone-900">1. Choose the account</h3>
          {chwsQuery.isError && (
            <div role="alert" className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-red-200 bg-red-50 px-4 py-3">
              <p className="text-sm text-red-800">Couldn't load the list of CHWs.</p>
              <Button variant="secondary" onClick={() => void chwsQuery.refetch()}>
                Try again
              </Button>
            </div>
          )}
          {chwsQuery.isPending && <p className="text-sm text-stone-500">Loading CHWs…</p>}
          {chwsQuery.data && (
            <fieldset className="space-y-3">
              <legend className="sr-only">CHW account</legend>
              <div className="relative max-w-sm">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-500" aria-hidden="true" />
                <label htmlFor={searchId} className="sr-only">
                  Search CHWs by name, CHW ID or clinic
                </label>
                <input
                  id={searchId}
                  type="search"
                  placeholder="Name, CHW ID or clinic"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="w-full rounded-lg border border-stone-300 py-2.5 pl-9 pr-3.5 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700"
                />
              </div>
              {accounts.length === 0 && <p className="text-sm text-stone-600">No CHW matches "{query}".</p>}
              <div className="grid gap-2 sm:grid-cols-2">
                {accounts.map((chw) => (
                  <label
                    key={chw.chw_id}
                    className={cn(
                      "flex min-h-14 cursor-pointer items-center gap-3 rounded-lg border px-3.5 py-2.5 has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-forest-700/40",
                      selectedId === chw.chw_id ? "border-forest-700 bg-sage-50" : "border-stone-200 bg-white hover:bg-stone-50",
                    )}
                  >
                    <input
                      type="radio"
                      name="account"
                      value={chw.chw_id}
                      checked={selectedId === chw.chw_id}
                      onChange={() => chooseAccount(chw.chw_id)}
                      className="h-4 w-4 accent-forest-800"
                    />
                    <span className="min-w-0">
                      <span className="block text-sm font-medium text-stone-900">{chw.full_name}</span>
                      <span className="block text-xs text-stone-600">
                        {chw.chw_id} · {chw.clinic}
                        {chw.status === "revoked" ? " · Revoked" : ""}
                      </span>
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>
          )}
        </Card>
      )}

      {done && (
        <div
          ref={doneRef}
          tabIndex={-1}
          role="status"
          className="flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 outline-none focus-visible:ring-2 focus-visible:ring-emerald-700"
        >
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-800" aria-hidden="true" />
          <div className="text-sm text-emerald-900">
            <p className="font-semibold">
              PIN reset for {done.full_name} ({done.chw_id}).
            </p>
            <p>
              Their old PIN no longer works and any sign-in lockout has been cleared. Give them this temporary PIN in
              person - they'll be asked to choose their own PIN when they sign in. Mosi won't show it again.
            </p>
          </div>
        </div>
      )}

      {isOnline && selected && !done && (
        <Card>
          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            <h3 className="text-sm font-semibold text-stone-900">
              2. New PIN for {selected.full_name} ({selected.chw_id})
            </h3>
            <div className="flex flex-wrap gap-4">
              <PinField
                id="new-pin"
                label="New PIN"
                value={pin}
                onChange={setPin}
                visible={showPin}
                error={errors.pin}
                hint="Exactly 4 digits."
              />
              <PinField id="confirm-pin" label="Type it again" value={confirmPin} onChange={setConfirmPin} visible={showPin} error={errors.confirm} />
            </div>
            <div className="flex flex-wrap gap-3">
              <Button type="button" variant="ghost" onClick={() => setShowPin((v) => !v)} aria-pressed={showPin}>
                {showPin ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
                {showPin ? "Hide PIN" : "Show PIN"}
              </Button>
              <Button type="button" variant="ghost" onClick={handleGenerate}>
                <KeyRound className="h-4 w-4" aria-hidden="true" />
                Generate a random PIN
              </Button>
            </div>

            {resetMutation.isError && (
              <p ref={errorRef} tabIndex={-1} role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800 outline-none">
                {resetErrorMessage(resetMutation.error)}
              </p>
            )}

            <Button type="submit" size="lg" disabled={resetMutation.isPending}>
              {resetMutation.isPending ? "Resetting…" : "Reset PIN"}
            </Button>
          </form>
        </Card>
      )}

      <ModalDialog
        open={confirmOpen}
        title={selected ? `Reset the PIN for ${selected.full_name}?` : "Reset PIN?"}
        onClose={() => setConfirmOpen(false)}
        actions={
          <>
            <Button type="button" variant="secondary" onClick={() => setConfirmOpen(false)} autoFocus>
              Cancel
            </Button>
            <Button
              type="button"
              onClick={() => {
                setConfirmOpen(false);
                resetMutation.mutate();
              }}
            >
              Reset PIN
            </Button>
          </>
        }
      >
        {selected && (
          <p>
            {selected.full_name} ({selected.chw_id}) won't be able to sign in with their current PIN any more. Make sure
            you can give them the new one.
          </p>
        )}
      </ModalDialog>
    </div>
  );
}

export default PinReset;
