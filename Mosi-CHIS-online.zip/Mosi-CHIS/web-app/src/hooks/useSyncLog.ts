import { useQuery } from "@tanstack/react-query";
import * as api from "../services/api";

// The server's sync log (GET /api/sync/log) sits behind the per-user sync
// rate limit (30 requests/minute, backend/src/middleware/rateLimit.ts),
// shared with actual syncing. Every screen that needs it - Dashboard, CHW
// Activity, Sync - reads this ONE cached query, fetched at the largest size
// any of them needs (the server's own cap), instead of three differently
// sized requests. Moving between those screens within a minute reuses the
// cached copy rather than asking the server again.
export const SYNC_LOG_LIMIT = 500;
export const SYNC_LOG_QUERY_KEY = ["syncLog", SYNC_LOG_LIMIT] as const;
const FRESH_FOR_MS = 60_000;

export function useSyncLog({ enabled = true }: { enabled?: boolean } = {}) {
  return useQuery({
    queryKey: SYNC_LOG_QUERY_KEY,
    queryFn: () => api.getSyncLog(SYNC_LOG_LIMIT),
    staleTime: FRESH_FOR_MS,
    enabled,
  });
}
