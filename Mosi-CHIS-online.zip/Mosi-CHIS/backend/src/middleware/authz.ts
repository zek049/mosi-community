// Centralized authorization policies (section 9). Each function answers one
// yes/no question given the authenticated actor and, where relevant, the
// resource already loaded from the database - the "load resource, then
// authorize" pattern, since most of these decisions need to know the
// resource's clinic_id, which only exists once it's been fetched.
//
//                         CHW        SUPERVISOR      ADMIN
// Own clinic data          YES          YES           YES
// Other clinic data         NO           NO           YES
// Manage CHW accounts       NO       own clinic    any clinic
// Manage supervisors        NO           NO           YES
// Create clinics            NO           NO           YES
// Audit / conflicts /       NO       own clinic    any clinic
//   review / dashboard
//
// Admin accounts can't be created or changed through the API at all.
import type { AuthenticatedUser } from "./auth";

export function isAdmin(actor: Pick<AuthenticatedUser, "role">): boolean {
  return actor.role === "ADMIN";
}

export function isSupervisorOrAdmin(actor: Pick<AuthenticatedUser, "role">): boolean {
  return actor.role === "SUPERVISOR" || actor.role === "ADMIN";
}

// Which clinic's data a query may return: `undefined` = every clinic
// (administrators only), a string = only that clinic. Every list query uses
// this rather than its own role check, so scoping is decided in ONE place.
export function clinicScope(actor: Pick<AuthenticatedUser, "role" | "clinicId">): string | undefined {
  return isAdmin(actor) ? undefined : actor.clinicId;
}

// Supervisors manage CHW accounts in their own clinic; administrators manage
// CHW and supervisor accounts anywhere. Nobody manages an ADMIN account (or
// themselves) through the API - no privilege escalation via account edits.
export function canManageAccount(actor: AuthenticatedUser, target: { role: string; clinic_id: string; chw_id?: string }): boolean {
  if (target.chw_id && target.chw_id === actor.chwId) return false;
  if (isAdmin(actor)) return target.role === "CHW" || target.role === "SUPERVISOR";
  if (actor.role !== "SUPERVISOR" || target.role !== "CHW") return false;
  return target.clinic_id === actor.clinicId;
}

export function canAccessClinic(actor: Pick<AuthenticatedUser, "role" | "clinicId">, clinicId: string): boolean {
  const scope = clinicScope(actor);
  return scope === undefined || scope === clinicId;
}

export function canModifyClinicResource(actor: AuthenticatedUser, clinicId: string): boolean {
  return canAccessClinic(actor, clinicId);
}
