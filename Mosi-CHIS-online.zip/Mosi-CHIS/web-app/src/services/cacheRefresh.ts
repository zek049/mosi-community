import { db } from "../db/indexedDb";
import * as api from "./api";
import { getConnectivity } from "./connectivity";

// Best-effort pull of the latest patients/visits into the local cache, so
// list/detail screens have real data to show later even when offline. Never
// throws - a failed refresh just leaves the cache as it was. Safe to call
// repeatedly; bulkPut overwrites by id, so it can never duplicate a record
// or clobber a not-yet-synced local one (different ids until synced).
//
// Deliberately plain functions, not TanStack Query queries: nothing renders
// their return value - the UI reads Dexie directly via useLiveQuery, which
// is already the correct reactive-local-read pattern. TanStack Query here
// manages the screens that genuinely display server response data instead
// (dashboard stats, CHW activity, the sync audit log) and the sync/login
// mutations - this pull-into-Dexie side effect isn't that shape of problem.
export async function refreshPatientCache(): Promise<void> {
  if (!getConnectivity().isOnline) return; // offline or Work Offline: no requests
  try {
    const patients = await api.getPatients();
    await db.patients.bulkPut(patients);
  } catch {
    // Offline, or the request failed - keep whatever's already cached.
  }
}

export async function refreshHouseholdCache(): Promise<void> {
  if (!getConnectivity().isOnline) return;
  try {
    const households = await api.getHouseholds();
    // Keep households still waiting to sync from this device as they are.
    const pendingIds = new Set(await db.households.where("sync_status").equals("pending").primaryKeys());
    await db.households.bulkPut(
      households
        .filter((h) => !pendingIds.has(h.id))
        .map(({ member_count: _count, ...h }) => ({ ...h, sync_status: "synced" as const })),
    );
  } catch {
    // Same as above.
  }
}

export async function refreshVisitCache(): Promise<void> {
  if (!getConnectivity().isOnline) return;
  try {
    const visits = await api.getVisits();
    await db.visits.bulkPut(visits);
  } catch {
    // Same as above.
  }
}
