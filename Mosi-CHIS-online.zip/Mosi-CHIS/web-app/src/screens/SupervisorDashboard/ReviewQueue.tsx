import { useEffect, useId, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import * as TabsPrimitive from "@radix-ui/react-tabs";
import { Check, Flag } from "lucide-react";
import * as api from "../../services/api";
import { formatDate } from "../../utils/formatDate";
import { Badge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { LoadErrorNotice } from "../../components/LoadErrorNotice";

const TAB_TRIGGER_CLASS =
  "min-h-11 rounded-lg px-3 py-2 text-sm font-medium transition-colors data-[state=active]:bg-forest-800 data-[state=active]:text-white text-stone-600 hover:text-stone-900";

export const REVIEW_QUERY_KEYS = [["reviewPending"], ["reviewFlagged"], ["dashboardStats"]] as const;

function when(iso: string | null | undefined): string {
  if (!iso) return "unknown time";
  return new Date(iso).toLocaleString(undefined, { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

function errorText(error: unknown): string {
  return error instanceof api.ApiError ? error.message : "Couldn't reach the server. Try again.";
}

function recordTitle(item: { record_type: "patient" | "visit"; patient: api.ReviewPatient | null; visit?: api.ReviewVisit }): string {
  const name = item.patient ? `${item.patient.first_name} ${item.patient.last_name}` : "Unknown patient";
  return item.record_type === "visit" && item.visit ? `${item.visit.visit_type} visit · ${name}` : name;
}

function RecordDetails({ item }: { item: { record_type: "patient" | "visit"; patient: api.ReviewPatient | null; visit?: api.ReviewVisit } }) {
  const rows: [string, string][] = [];
  if (item.record_type === "patient" && item.patient) {
    const p = item.patient;
    rows.push(["Patient ID", p.patient_id], ["Born", formatDate(p.date_of_birth)], ["Gender", p.gender === "F" ? "Female" : "Male"], ["Village", p.village]);
    if (p.phone_number) rows.push(["Phone", p.phone_number]);
  } else if (item.visit) {
    const v = item.visit;
    rows.push(["Visit date", formatDate(v.visit_date)]);
    if (item.patient) rows.push(["Patient", `${item.patient.patient_id} · ${item.patient.village}`]);
    if (v.weight !== null) rows.push(["Weight", `${v.weight} kg`]);
    if (v.height !== null) rows.push(["Height", `${v.height} cm`]);
    if (v.blood_pressure) rows.push(["Blood pressure", `${v.blood_pressure} mmHg`]);
    if (v.notes) rows.push(["Notes", v.notes]);
  }
  return (
    <dl className="mt-2 grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5 text-sm">
      {rows.map(([k, v]) => (
        <div key={k} className="contents">
          <dt className="text-stone-600">{k}</dt>
          <dd className="min-w-0 break-words text-stone-900">{v}</dd>
        </div>
      ))}
    </dl>
  );
}

type DecideFn = (input: { recordType: "patient" | "visit"; id: string; action: "confirm" | "flag"; reason?: string; label: string }) => Promise<void>;

// Confirm / Flag for one record. Flag opens an inline reason box (required).
function ReviewActions({ recordType, id, label, decide, allowFlag = true, confirmLabel = "Confirm" }: { recordType: "patient" | "visit"; id: string; label: string; decide: DecideFn; allowFlag?: boolean; confirmLabel?: string }) {
  const [flagging, setFlagging] = useState(false);
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const reasonId = useId();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const flagButtonId = `${reasonId}-flag`;

  useEffect(() => {
    if (flagging) textareaRef.current?.focus();
  }, [flagging]);

  async function run(action: "confirm" | "flag") {
    if (action === "flag" && reason.trim().length < 3) {
      setError("Say why you're flagging it (at least 3 characters) - the CHW will see this.");
      textareaRef.current?.focus();
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await decide({ recordType, id, action, reason: reason.trim(), label });
    } catch (e) {
      setError(errorText(e));
      setBusy(false);
    }
  }

  return (
    <div className="mt-3">
      {!flagging ? (
        <div className="flex flex-wrap gap-2">
          <Button type="button" onClick={() => void run("confirm")} disabled={busy} className="min-h-11" aria-label={`${confirmLabel}: ${label}`}>
            <Check className="h-4 w-4" aria-hidden="true" />
            {confirmLabel}
          </Button>
          {allowFlag && (
            <Button id={flagButtonId} type="button" variant="secondary" onClick={() => setFlagging(true)} disabled={busy} className="min-h-11" aria-label={`Flag: ${label}`}>
              <Flag className="h-4 w-4" aria-hidden="true" />
              Flag
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-2 rounded-lg border border-stone-200 bg-stone-50 p-3">
          <label htmlFor={reasonId} className="block text-sm font-medium text-stone-800">
            Why are you flagging this? <span className="font-normal text-stone-600">(the CHW will see it)</span>
          </label>
          <textarea
            id={reasonId}
            ref={textareaRef}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            maxLength={500}
            rows={2}
            aria-invalid={error ? true : undefined}
            aria-describedby={error ? `${reasonId}-error` : undefined}
            className="w-full rounded-lg border border-stone-300 px-3 py-2 text-base text-stone-900 focus:border-forest-700 focus:outline-none focus:ring-2 focus:ring-forest-700/30 sm:text-sm"
          />
          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="danger" onClick={() => void run("flag")} disabled={busy} className="min-h-11">
              <Flag className="h-4 w-4" aria-hidden="true" />
              Flag record
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => {
                setFlagging(false);
                setError(null);
                setReason("");
                requestAnimationFrame(() => document.getElementById(flagButtonId)?.focus());
              }}
              disabled={busy}
              className="min-h-11"
            >
              Cancel
            </Button>
          </div>
        </div>
      )}
      {error && (
        <p id={`${reasonId}-error`} role="alert" className="mt-2 text-sm text-red-700">
          {error}
        </p>
      )}
    </div>
  );
}

// The supervisor's review queue: CHW-submitted records waiting to be
// checked (grouped by CHW, then by the sync they arrived in), and flagged
// records to follow up. Part of the dashboard; the Attention panel links here.
export function ReviewQueue() {
  const queryClient = useQueryClient();
  const pending = useQuery({ queryKey: ["reviewPending"], queryFn: api.getReviewPending });
  const flagged = useQuery({ queryKey: ["reviewFlagged"], queryFn: api.getReviewFlagged });
  // n changes on every decision, so the same text twice still refocuses.
  const [announcement, setAnnouncement] = useState({ text: "", n: 0 });
  const statusRef = useRef<HTMLParagraphElement>(null);
  // The decided record leaves the list (taking focus with it), so focus moves
  // to the confirmation - after it has rendered (it's hidden while empty).
  useEffect(() => {
    if (announcement.n > 0) statusRef.current?.focus();
  }, [announcement.n]);

  const mutation = useMutation({
    mutationFn: (input: { recordType: "patient" | "visit"; id: string; action: "confirm" | "flag"; reason?: string }) =>
      input.action === "confirm" ? api.confirmRecord(input.recordType, input.id) : api.flagRecord(input.recordType, input.id, input.reason ?? ""),
  });

  const decide: DecideFn = async ({ recordType, id, action, reason, label }) => {
    try {
      await mutation.mutateAsync({ recordType, id, action, reason });
    } catch (e) {
      // Someone else decided first / it changed: show the fresh queue.
      if (e instanceof api.ApiError && e.status === 409) await Promise.all(REVIEW_QUERY_KEYS.map((key) => queryClient.invalidateQueries({ queryKey: key })));
      throw e;
    }
    setAnnouncement((a) => ({ text: action === "confirm" ? `Confirmed: ${label}.` : `Flagged: ${label}. It's listed under Flagged for follow-up.`, n: a.n + 1 }));
    await Promise.all(REVIEW_QUERY_KEYS.map((key) => queryClient.invalidateQueries({ queryKey: key })));
  };

  const pendingTotal = pending.data?.total;
  const flaggedTotal = flagged.data?.total;

  return (
    <Card id="review-queue" aria-labelledby="review-queue-heading" role="region" tabIndex={-1} className="focus:outline-none">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 id="review-queue-heading" className="text-sm font-semibold text-stone-900">
          Review queue
        </h2>
        <p className="text-xs text-stone-600">Records CHWs sent in are counted in the totals above once you confirm them.</p>
      </div>
      <p ref={statusRef} tabIndex={-1} role="status" className="mt-2 text-sm font-medium text-emerald-800 focus:outline-none empty:hidden">
        {announcement.text}
      </p>

      <TabsPrimitive.Root defaultValue="awaiting" className="mt-3">
        <TabsPrimitive.List aria-label="Review queue" className="inline-grid grid-cols-2 gap-1 rounded-xl border border-stone-200 bg-white p-1">
          <TabsPrimitive.Trigger value="awaiting" className={TAB_TRIGGER_CLASS}>
            Awaiting review{pendingTotal !== undefined ? ` (${pendingTotal})` : ""}
          </TabsPrimitive.Trigger>
          <TabsPrimitive.Trigger value="flagged" className={TAB_TRIGGER_CLASS}>
            Flagged{flaggedTotal !== undefined ? ` (${flaggedTotal})` : ""}
          </TabsPrimitive.Trigger>
        </TabsPrimitive.List>

        <TabsPrimitive.Content value="awaiting" className="mt-4">
          {pending.isPending && <p className="text-sm text-stone-500">Loading the review queue…</p>}
          {pending.isError && <LoadErrorNotice error={pending.error} what="the review queue" onRetry={() => void pending.refetch()} />}
          {pending.data && pending.data.total === 0 && <p className="text-sm text-stone-600">Nothing waiting for review. New records from CHWs will appear here.</p>}
          {pending.data && pending.data.total > 0 && (
            <div className="space-y-6">
              {pending.data.groups.map((group) => {
                const count = group.batches.reduce((n, b) => n + b.items.length, 0);
                return (
                  <section key={group.chw.chw_id ?? "unknown"} aria-label={`From ${group.chw.full_name ?? group.chw.chw_id ?? "unknown CHW"}`}>
                    <h3 className="text-sm font-semibold text-stone-900">
                      {group.chw.full_name ?? "Unknown CHW"}
                      {group.chw.chw_id && <span className="font-normal text-stone-600"> · {group.chw.chw_id}</span>}
                      <span className="font-normal text-stone-600"> · {count} {count === 1 ? "record" : "records"}</span>
                    </h3>
                    <div className="mt-2 space-y-3">
                      {group.batches.map((batch) => (
                        <div key={batch.key} className="rounded-xl border border-stone-200">
                          <p className="border-b border-stone-100 bg-stone-50 px-4 py-2 text-xs text-stone-700">
                            {batch.via === "sync" ? `Synced from the device ${when(batch.sent_at)}` : `Entered online ${when(batch.sent_at)}`}
                            {batch.via === "sync" && ` · ${batch.items.length} ${batch.items.length === 1 ? "record" : "records"} in this sync`}
                          </p>
                          <ul className="divide-y divide-stone-100">
                            {batch.items.map((item) => {
                              const label = `${recordTitle(item)} (${item.record_type})`;
                              return (
                                <li key={item.id} className="px-4 py-3">
                                  <div className="flex flex-wrap items-center gap-2">
                                    <Badge variant="neutral">{item.record_type === "patient" ? "Patient" : "Visit"}</Badge>
                                    <Badge variant={item.submission === "new" ? "info" : "warning"}>{item.submission === "new" ? "New" : "Edited"}</Badge>
                                    <p className="text-sm font-semibold text-stone-900">{recordTitle(item)}</p>
                                  </div>
                                  <p className="mt-1 text-xs text-stone-600">Submitted {when(item.submitted_at)}</p>
                                  {item.previous_review?.flag_reason && (
                                    <p className="mt-1 text-sm text-red-700">
                                      Previously flagged{item.previous_review.reviewed_at ? ` (${when(item.previous_review.reviewed_at)})` : ""}: {item.previous_review.flag_reason}
                                    </p>
                                  )}
                                  <RecordDetails item={item} />
                                  {item.patient && (
                                    <Link to={`/patients/${item.patient.id}`} className="mt-1 inline-flex min-h-11 items-center text-sm font-medium text-forest-800 underline underline-offset-2">
                                      Open patient record
                                    </Link>
                                  )}
                                  <ReviewActions recordType={item.record_type} id={item.id} label={label} decide={decide} />
                                </li>
                              );
                            })}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </section>
                );
              })}
            </div>
          )}
        </TabsPrimitive.Content>

        <TabsPrimitive.Content value="flagged" className="mt-4">
          {flagged.isPending && <p className="text-sm text-stone-500">Loading flagged records…</p>}
          {flagged.isError && <LoadErrorNotice error={flagged.error} what="flagged records" onRetry={() => void flagged.refetch()} />}
          {flagged.data && flagged.data.total === 0 && <p className="text-sm text-stone-600">No flagged records.</p>}
          {flagged.data && flagged.data.total > 0 && (
            <>
              <p className="mb-3 text-sm text-stone-600">
                Follow these up with the CHW. When the CHW corrects a record it comes back to Awaiting review; or confirm it here once it's sorted out.
              </p>
              <ul className="divide-y divide-stone-100 rounded-xl border border-stone-200">
                {flagged.data.items.map((item) => {
                  const label = `${recordTitle(item)} (${item.record_type})`;
                  return (
                    <li key={item.id} className="px-4 py-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="error" dot>
                          Flagged
                        </Badge>
                        <Badge variant="neutral">{item.record_type === "patient" ? "Patient" : "Visit"}</Badge>
                        <p className="text-sm font-semibold text-stone-900">{recordTitle(item)}</p>
                      </div>
                      <p className="mt-1 text-sm text-red-700">Reason: {item.flag_reason}</p>
                      <p className="mt-0.5 text-xs text-stone-600">
                        Flagged by {item.flagged_by_name ?? item.flagged_by ?? "a supervisor"} {when(item.flagged_at)} · CHW: {item.chw_name ?? item.chw_id ?? "unknown"}
                      </p>
                      <RecordDetails item={item} />
                      <ReviewActions recordType={item.record_type} id={item.id} label={label} decide={decide} allowFlag={false} confirmLabel="Confirm (resolved)" />
                    </li>
                  );
                })}
              </ul>
            </>
          )}
        </TabsPrimitive.Content>
      </TabsPrimitive.Root>
    </Card>
  );
}
