// Where the app is running, for install hints. Pure functions over the
// values the browser reports, so they can be tested without a browser.

type Env = {
  userAgent: string;
  platform?: string;
  maxTouchPoints?: number;
  standaloneMedia?: boolean; // matchMedia("(display-mode: standalone)").matches
  navigatorStandalone?: boolean; // iOS Safari's own navigator.standalone
};

// Already opened as an installed app (home-screen icon), on any platform.
export function isStandalone(env: Env): boolean {
  return env.standaloneMedia === true || env.navigatorStandalone === true;
}

// iPhone/iPad. iPadOS 13+ reports itself as a Mac ("MacIntel") but has touch.
export function isIos(env: Env): boolean {
  if (/iPhone|iPad|iPod/.test(env.userAgent)) return true;
  return env.platform === "MacIntel" && (env.maxTouchPoints ?? 0) > 1;
}

// Safari itself (not Chrome/Firefox/Edge for iOS, or an in-app browser):
// on iOS only Safari can "Add to Home Screen" as an app. (iOS 16.4+ also
// lets other browsers do it through their own share menu, but the steps
// differ; the hint names Safari's.)
export function isIosSafari(env: Env): boolean {
  return isIos(env) && /Safari\//.test(env.userAgent) && !/CriOS|FxiOS|EdgiOS|OPiOS|GSA\/|FBAN|FBAV|Instagram/.test(env.userAgent);
}

// iOS has no install prompt event, so Mosi shows its own short hint - only
// in Safari, and only when the app isn't already installed.
export function shouldShowIosInstallHint(env: Env): boolean {
  return isIosSafari(env) && !isStandalone(env);
}

export function currentEnv(): Env {
  if (typeof window === "undefined") return { userAgent: "" };
  return {
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    maxTouchPoints: navigator.maxTouchPoints,
    standaloneMedia: window.matchMedia?.("(display-mode: standalone)").matches ?? false,
    navigatorStandalone: (navigator as Navigator & { standalone?: boolean }).standalone === true,
  };
}
