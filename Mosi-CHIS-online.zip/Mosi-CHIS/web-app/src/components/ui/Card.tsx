import { forwardRef, type HTMLAttributes } from "react";
import { cn } from "../../lib/utils";

// The one card shell every white panel in the app (Card.tsx replaces the
// repeated "rounded-xl border border-stone-200 bg-white p-5" string that
// used to be copy-pasted onto a div in every screen) - so a spacing/radius
// tweak here applies everywhere instead of needing a find-and-replace.
// forwardRef because a couple of call sites (e.g. Login's "Forgot PIN?"
// scroll target) need a real DOM node to scroll to or measure.
export const Card = forwardRef<HTMLDivElement, HTMLAttributes<HTMLDivElement>>(function Card(
  { className, ...props },
  ref,
) {
  return (
    <div ref={ref} className={cn("rounded-xl border border-stone-200 bg-white p-5 sm:p-6", className)} {...props} />
  );
});
