-- CreateEnum
CREATE TYPE "PinResetStatus" AS ENUM ('pending', 'completed');

-- AlterTable
ALTER TABLE "chws" ADD COLUMN     "must_change_pin" BOOLEAN NOT NULL DEFAULT false;

-- CreateTable
CREATE TABLE "pin_reset_requests" (
    "id" TEXT NOT NULL,
    "chw_id" TEXT NOT NULL,
    "status" "PinResetStatus" NOT NULL DEFAULT 'pending',
    "requested_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reviewed_at" TIMESTAMP(3),
    "reviewed_by" TEXT,

    CONSTRAINT "pin_reset_requests_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "pin_reset_requests_status_idx" ON "pin_reset_requests"("status");

-- CreateIndex
CREATE INDEX "pin_reset_requests_chw_id_idx" ON "pin_reset_requests"("chw_id");

-- AddForeignKey
ALTER TABLE "pin_reset_requests" ADD CONSTRAINT "pin_reset_requests_chw_id_fkey" FOREIGN KEY ("chw_id") REFERENCES "chws"("chw_id") ON DELETE CASCADE ON UPDATE CASCADE;

