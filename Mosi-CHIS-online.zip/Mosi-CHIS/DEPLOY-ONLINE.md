# Mosi online and as an Android app: step by step

**What you end up with**

- Mosi running on the internet at one secure address, for example `https://mosi-chis.duckdns.org`
- An Android app (`.apk`) that opens that same system full-screen, works offline, and syncs when the phone has a connection

**Why it is built this way.** The app and the API share one https address. Mosi keeps the sign-in in a secure cookie, and a cookie only works reliably when the app and the server share an address. The Android app is a thin shell around that address, so it behaves exactly like the system you already use.

**Time needed:** about 1 to 2 hours the first time.

---

## Part A: Get a server and an address

### A1. Rent a small server (VPS)

You need a Linux server that is always on.

- **Operating system:** Ubuntu 24.04
- **Memory:** at least 2 GB RAM. With 1 GB the build usually runs out of memory.
- **Location:** a data centre in Johannesburg is closest to Zimbabwe. Frankfurt or Helsinki also work.
- **Cost:** roughly 5 to 12 US dollars a month. Check current prices.
- **Providers to look at:** Vultr (has Johannesburg), Hetzner, DigitalOcean, or any local provider that gives you Ubuntu with root access.

Most providers need an international bank card. If you cannot pay internationally, ask a local provider.

When the server is ready, write down:
- its **IP address** (four numbers, like `203.0.113.10`)
- its **root password**, or set up an SSH key if the provider offers one

### A2. Get an address (free option)

1. Go to **duckdns.org** and sign in with Google or GitHub.
2. Create a name, for example `mosi-chis`. Your address becomes `mosi-chis.duckdns.org`.
3. In the "current ip" box, paste your server's IP address and click **update ip**.

If you buy a real domain instead, create an **A record** pointing at the server's IP address.

Wait a few minutes, then check from your PC:
```powershell
nslookup mosi-chis.duckdns.org
```
It should show your server's IP address.

---

## Part B: Prepare the server

On your Windows PC, open PowerShell and connect (replace the IP):
```powershell
ssh root@203.0.113.10
```
Type `yes` the first time, then the password. You are now typing commands on the server.

Install Docker:
```bash
curl -fsSL https://get.docker.com | sh
```

Turn on the firewall, allowing only what Mosi needs:
```bash
ufw allow 22
ufw allow 80
ufw allow 443
ufw --force enable
```

Install the unzip tool:
```bash
apt-get install -y unzip
```

---

## Part C: Upload the project

Open a **second** PowerShell window on your PC. Go to the folder that contains `Mosi-CHIS-online.zip` and run (replace the IP):
```powershell
scp Mosi-CHIS-online.zip root@203.0.113.10:/root/
```

Back in the **server** window:
```bash
cd /root
unzip -o Mosi-CHIS-online.zip
cd Mosi-CHIS
```

---

## Part D: Fill in the settings

```bash
cp .env.production.example .env.production
```

Make two secret values. Run this twice and copy each result:
```bash
openssl rand -hex 32
```

Open the file:
```bash
nano .env.production
```

Fill in:

| Setting | What to put |
|---|---|
| `MOSI_DOMAIN` | Your address **without** `https://`, for example `mosi-chis.duckdns.org` |
| `JWT_SECRET` | The first random value |
| `POSTGRES_PASSWORD` | The second random value |
| `SEED_ON_START` | Leave as `true` for the first start only |
| `VITE_SHOW_DEMO_ACCOUNTS` | `false` |

Save with `Ctrl+O`, `Enter`, then exit with `Ctrl+X`.

---

## Part E: Start Mosi online

```bash
docker compose -f docker-compose.prod.yml --env-file .env.production up -d --build
```

The first build takes 5 to 15 minutes. When it finishes, check that all four containers are running:
```bash
docker compose -f docker-compose.prod.yml --env-file .env.production ps
```
You should see `mosi-postgres`, `mosi-backend`, `mosi-frontend` and `mosi-caddy`.

Open **https://your-address** in your browser. You should see the Mosi Sign in page with a padlock. The certificate can take a minute to arrive the first time.

### E1. Turn off reseeding (important)

While `SEED_ON_START=true`, **every restart deletes all patients and visits.** After the first successful start:

```bash
nano .env.production
```
Change `SEED_ON_START=true` to `SEED_ON_START=false`, save, then run:
```bash
docker compose -f docker-compose.prod.yml --env-file .env.production up -d
```

### E2. Change the demo PINs (important)

Everyone who has seen the README knows the PIN `1234`. Sign in as `SUP001` / `1234`, then go to **More → Reset a PIN** and set a new PIN for every account. Do this before you share the address with anyone.

---

## Part F: Check it works

1. Sign in as a CHW on your phone's Chrome browser at your address.
2. Switch on airplane mode. Mosi should still open.
3. Add a patient and a visit while offline. Both show as waiting to sync.
4. Turn airplane mode off. The changes sync automatically.
5. Sign in as a supervisor and check that the new records appear.

If something fails, see **Troubleshooting** at the end.

---

## Part G: Make the Android app (.apk)

You do this on your PC, in a browser. No coding and no Android Studio.

1. Go to **pwabuilder.com**.
2. Paste your address (`https://mosi-chis.duckdns.org`) and click **Start**.
3. Wait for the report. Mosi already has a manifest, icons and a service worker, so it should pass.
4. Click **Package for stores**, then choose **Android**.
5. Fill in the options:
   - **Package ID:** something unique, like `zw.ac.msu.mosi`
   - **App name:** `Mosi`
   - **Signing key:** choose **New**
6. Click **Generate** and download the zip.
7. **Keep the zip safe.** It contains your signing key. Without it you can never publish updates to the same app.

Inside the zip you will find:
- `app-release-signed.apk`, which you install on phones
- an `assetlinks.json` file, or its contents shown on the PWABuilder page

### G1. Link the app to your site (removes the browser bar)

Without this step the app still works, but it shows a browser address bar at the top.

On the server, open the file:
```bash
nano deploy/wellknown/assetlinks.json
```
Delete the `[]` and paste the full contents PWABuilder gave you. Save and exit.

No restart is needed. Check it in a browser:
`https://your-address/.well-known/assetlinks.json` should show the text you pasted.

### G2. Install on a phone

1. Copy the `.apk` to the phone (WhatsApp to yourself, USB, or Google Drive).
2. Open it on the phone and allow **Install unknown apps** when asked.
3. Open **Mosi** from the home screen and sign in.

To share it with other phones, send them the same `.apk` file.

---

## Part H: Looking after it

**Back up the database** (do this weekly, and before any update):
```bash
docker exec mosi-postgres pg_dump -U mosi mosi > backup-$(date +%F).sql
```
Download the file to your PC with `scp`. A backup that lives only on the server is not a backup.

**Update Mosi after a code change:** upload a new zip as in Part C, then run the command from Part E. Your data is kept.

**Stop everything:**
```bash
docker compose -f docker-compose.prod.yml --env-file .env.production down
```
Never add `-v`. That deletes the database.

**See what is happening:**
```bash
docker compose -f docker-compose.prod.yml --env-file .env.production logs -f --tail 50
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Browser says the connection is not secure or the site will not load | The address may not point at the server yet (re-check `nslookup`), or ports 80 and 443 are blocked. Check `ufw status` and the provider's firewall panel. Look at `docker logs mosi-caddy`. |
| The Sign in page loads but signing in fails | Check `docker logs mosi-backend`. Confirm `MOSI_DOMAIN` has no `https://` and no trailing slash. |
| Build fails with `ECONNRESET` | A network drop. Run the same command again. |
| Build is killed or "out of memory" | The server has too little RAM. Use at least 2 GB, or add swap space. |
| Demo accounts are missing | The first start did not seed. Set `SEED_ON_START=true`, run the `up -d` command, then set it back to `false`. |
| App shows a browser address bar | The `assetlinks.json` step (G1) is missing or has the wrong contents. |
| An old version still shows after an update | Fully close and reopen the app. The service worker updates on the next load. |

---

## Important limits

- All data in the demo is synthetic. The README states Mosi is a prototype and has not had a security audit or legal review. Do not put real patient records into it until that is done.
- Offline data on a phone is not encrypted. Use phones the clinic controls, and set a screen lock.
- A 4-digit PIN is weak against someone who can try guesses at length. The lockout (5 tries, 15 minutes) helps, but treat it as a prototype-level control.
