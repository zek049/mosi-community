import "fake-indexeddb/auto";
import Dexie from "dexie";
import { beforeEach, describe, expect, it } from "vitest";
import * as store from "../indexedDb";
import { runSync } from "../../services/syncService";
import type { Patient } from "../../models/patient";
import type { Visit } from "../../models/visit";

const now = new Date().toISOString();
function patient(id: string, sync_status: "pending" | "synced"): Patient {
  return { id, patient_id: id.toUpperCase(), first_name: "Test", last_name: id, date_of_birth: "1990-01-01", gender: "F", village: "Mbare", phone_number: null, created_at: now, updated_at: now, sync_status };
}
function visit(id: string, chw_id: string, sync_status: "pending" | "synced", patient_id = "p-x"): Visit {
  return { id, patient_id, chw_id, visit_date: "2026-09-24", visit_type: "Other", weight: null, height: null, blood_pressure: null, notes: null, created_at: now, updated_at: now, sync_status };
}

beforeEach(async () => {
  store.switchDatabaseTo(null);
  for (const name of await Dexie.getDatabaseNames()) await Dexie.delete(name);
});

describe("per-user local database", () => {
  it("names each account's database separately", () => {
    expect(store.dbNameFor("CHW001")).not.toBe(store.dbNameFor("CHW002"));
    expect(store.dbNameFor(" chw001 ")).toBe(store.dbNameFor("CHW001"));
  });

  it("user A's records - cached or unsynced - are not visible to user B, and B's sync never sends them", async () => {
    store.switchDatabaseTo("CHW001");
    await store.db.patients.bulkPut([patient("a-synced", "synced"), patient("a-pending", "pending")]);

    store.switchDatabaseTo("CHW002");
    expect(await store.db.patients.count()).toBe(0);
    expect(await store.countPending()).toBe(0);
    expect((await runSync()).attempted).toBe(0); // nothing of A's to upload

    store.switchDatabaseTo("CHW001");
    expect(await store.db.patients.get("a-pending")).toBeDefined();
  });
});

describe("sign-out cleanup", () => {
  it("with nothing unsynced: removes everything and deletes the database", async () => {
    store.switchDatabaseTo("CHW001");
    const name = store.db.name;
    await store.db.patients.bulkPut([patient("p1", "synced"), patient("p2", "synced")]);
    await store.db.visits.put(visit("v1", "CHW001", "synced"));
    await store.db.chws.put({ id: 1, chw_id: "CHW001", full_name: "A", clinic: "C", phone_number: null, role: "CHW", created_at: now });

    expect(await store.clearSyncedDataForSignOut()).toBe(0);
    expect(await Dexie.exists(name)).toBe(false);
  });

  it("with unsynced changes: keeps exactly those (and their 'couldn't sync' marker), removes the rest", async () => {
    store.switchDatabaseTo("CHW001");
    await store.db.patients.bulkPut([patient("synced-1", "synced"), patient("pending-1", "pending")]);
    await store.db.visits.bulkPut([visit("v-synced", "CHW001", "synced"), visit("v-pending", "CHW001", "pending")]);
    await store.db.syncAttempts.bulkPut([
      { id: "v-pending", record_type: "visit", status: "failed", attempted_at: now },
      { id: "synced-1", record_type: "patient", status: "conflict", attempted_at: now },
    ]);

    expect(await store.clearSyncedDataForSignOut()).toBe(2);

    store.switchDatabaseTo(null);
    store.switchDatabaseTo("CHW001"); // "reopen the app" as the same user
    expect((await store.db.patients.toArray()).map((p) => p.id)).toEqual(["pending-1"]);
    expect((await store.db.visits.toArray()).map((v) => v.id)).toEqual(["v-pending"]);
    expect((await store.db.syncAttempts.toArray()).map((a) => a.id)).toEqual(["v-pending"]);
    expect(await store.db.chws.count()).toBe(0);
  });

  it("'Remove my data from this device' deletes unsynced changes too (UI requires explicit confirmation first)", async () => {
    store.switchDatabaseTo("CHW001");
    const name = store.db.name;
    await store.db.patients.put(patient("pending-1", "pending"));
    await store.wipeCurrentUserData();
    expect(await Dexie.exists(name)).toBe(false);
  });
});

describe("migration from the old shared database (deterministic ownership)", () => {
  // Old shared DB contents, as a device used before per-user storage could hold:
  //   - a synced patient ("server-p") and a synced visit (already on the server)
  //   - an UNSYNCED patient with no owner field ("orphan-p")
  //   - unsynced visits by CHW001 and CHW002 for the synced patient
  //   - an unsynced visit by CHW001 for the unsynced (ownerless) patient
  async function seedLegacy() {
    const legacy = new store.MosiDatabase(store.LEGACY_DB_NAME);
    await legacy.patients.bulkPut([patient("server-p", "synced"), patient("orphan-p", "pending")]);
    await legacy.visits.bulkPut([
      visit("a-visit", "CHW001", "pending", "server-p"),
      visit("b-visit", "CHW002", "pending", "server-p"),
      visit("a-visit-orphan", "CHW001", "pending", "orphan-p"),
      visit("done", "CHW001", "synced", "server-p"),
    ]);
    await legacy.syncAttempts.bulkPut([
      { id: "a-visit", record_type: "visit", status: "failed", attempted_at: now },
      { id: "b-visit", record_type: "visit", status: "failed", attempted_at: now },
    ]);
    legacy.close();
  }
  async function contents(chwId: string) {
    store.switchDatabaseTo(chwId);
    return {
      patients: (await store.db.patients.toArray()).map((p) => p.id).sort(),
      visits: (await store.db.visits.toArray()).map((v) => v.id).sort(),
      attempts: (await store.db.syncAttempts.toArray()).map((a) => a.id).sort(),
    };
  }
  async function signIn(chwId: string, role = "CHW") {
    store.switchDatabaseTo(chwId);
    await store.migrateLegacyDatabase(chwId, role);
  }

  it("CHW A cannot inherit CHW B's records (and vice versa)", async () => {
    await seedLegacy();
    await signIn("CHW001");
    await signIn("CHW002");
    const a = await contents("CHW001");
    const b = await contents("CHW002");
    expect(a.visits).toEqual(["a-visit"]);
    expect(a.attempts).toEqual(["a-visit"]);
    expect(b.visits).toEqual(["b-visit"]);
    expect(b.attempts).toEqual(["b-visit"]);
  });

  it("an unsynced patient with unknown owner is never given to the signed-in user - first or second", async () => {
    await seedLegacy();
    await signIn("CHW001");
    await signIn("CHW002");
    expect((await contents("CHW001")).patients).toEqual([]);
    expect((await contents("CHW002")).patients).toEqual([]);
    // It is kept (not deleted), unassigned, together with the visit that depends on it.
    expect(await Dexie.exists(store.LEGACY_DB_NAME)).toBe(true);
    expect(await store.countUnassignedLegacyRecords()).toEqual({ patients: 1, visits: 1 });
    const legacy = new store.MosiDatabase(store.LEGACY_DB_NAME);
    expect((await legacy.patients.toArray()).map((p) => p.id)).toEqual(["orphan-p"]);
    expect((await legacy.visits.toArray()).map((v) => v.id)).toEqual(["a-visit-orphan"]);
    legacy.close();
  });

  it("is deterministic: the same result whichever CHW signs in first, and repeat sign-ins change nothing", async () => {
    await seedLegacy();
    await signIn("CHW002");
    await signIn("CHW001");
    await signIn("CHW001");
    await signIn("CHW002");
    expect(await contents("CHW001")).toEqual({ patients: [], visits: ["a-visit"], attempts: ["a-visit"] });
    expect(await contents("CHW002")).toEqual({ patients: [], visits: ["b-visit"], attempts: ["b-visit"] });
    expect(await store.countUnassignedLegacyRecords()).toEqual({ patients: 1, visits: 1 });
  });

  it("a CHW with nothing of their own in the old database gets nothing", async () => {
    await seedLegacy();
    await signIn("CHW003");
    expect(await contents("CHW003")).toEqual({ patients: [], visits: [], attempts: [] });
  });

  it("does nothing for a supervisor", async () => {
    await seedLegacy();
    await signIn("SUP001", "SUPERVISOR");
    expect(await contents("SUP001")).toEqual({ patients: [], visits: [], attempts: [] });
    expect(await store.countUnassignedLegacyRecords()).toEqual({ patients: 1, visits: 3 });
  });

  it("removes the old database once nothing unsynced is left in it (synced data is on the server)", async () => {
    const legacy = new store.MosiDatabase(store.LEGACY_DB_NAME);
    await legacy.patients.put(patient("server-p", "synced"));
    await legacy.visits.bulkPut([visit("a-visit", "CHW001", "pending", "server-p"), visit("done", "CHW001", "synced", "server-p")]);
    legacy.close();
    await signIn("CHW001");
    expect((await contents("CHW001")).visits).toEqual(["a-visit"]);
    expect(await Dexie.exists(store.LEGACY_DB_NAME)).toBe(false);
  });

  it("never creates the old database just by checking for it", async () => {
    await signIn("CHW001");
    expect(await store.countUnassignedLegacyRecords()).toEqual({ patients: 0, visits: 0 });
    expect(await Dexie.exists(store.LEGACY_DB_NAME)).toBe(false);
  });
});

describe("Dexie schema v2 (households) upgrades an existing v1 database in place", () => {
  it("keeps every existing record and adds the households store", async () => {
    const name = store.dbNameFor("CHW777");
    const v1 = new Dexie(name);
    v1.version(1).stores({
      patients: "id, patient_id, village, sync_status, last_name",
      visits: "id, patient_id, chw_id, visit_date, visit_type, sync_status",
      chws: "chw_id, role",
      syncAttempts: "id, record_type, status",
    });
    await v1.table("patients").put(patient("kept", "pending"));
    await v1.table("visits").put(visit("kept-visit", "CHW777", "synced"));
    v1.close();

    store.switchDatabaseTo("CHW777");
    expect((await store.db.patients.get("kept"))?.sync_status).toBe("pending");
    expect(await store.db.visits.count()).toBe(1);
    await store.db.households.put({ id: "h1", household_code: "MBA-7Q2K", village: "Mbare", created_at: now, sync_status: "pending" });
    await store.db.patients.update("kept", { household_id: "h1" });
    expect((await store.db.patients.where("household_id").equals("h1").toArray()).map((p) => p.id)).toEqual(["kept"]);
    expect(await store.countPending()).toBe(2); // the patient + the household
  });
});
