import { useEffect, useState } from "react";
import { ApiError } from "../services/api";
import { Button } from "./ui/Button";

const DEFAULT_WAIT_SECONDS = 60;

type Props = {
  error: unknown;
  /** What failed to load, e.g. "sync activity". */
  what: string;
  onRetry: () => void;
};

// A load failure explained in plain words, with a retry that respects the
// server. For a rate limit (HTTP 429) the retry button stays disabled until
// the server's Retry-After has passed (or a minute, if it didn't say), so an
// impatient tap can't keep the limit tripped.
export function LoadErrorNotice({ error, what, onRetry }: Props) {
  const rateLimited = error instanceof ApiError && error.status === 429;
  const waitSeconds = rateLimited ? (error.retryAfterSeconds ?? DEFAULT_WAIT_SECONDS) : 0;
  const [readyAt, setReadyAt] = useState(() => Date.now() + waitSeconds * 1000);
  const [now, setNow] = useState(Date.now());

  // Restart the wait for a new error. `now` is reset with it: left at its
  // older value, the countdown would read one second too long.
  useEffect(() => {
    const start = Date.now();
    setReadyAt(start + waitSeconds * 1000);
    setNow(start);
  }, [error, waitSeconds]);

  const remaining = Math.max(0, Math.ceil((readyAt - now) / 1000));
  useEffect(() => {
    if (remaining === 0) return;
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [remaining]);

  return (
    <div role="alert" className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-red-200 bg-red-50 px-4 py-3">
      <p className="text-sm text-red-800">
        {rateLimited
          ? `The server is limiting requests right now, so ${what} can't load for a moment. Nothing is lost.`
          : `Couldn't load ${what} from the Mosi server. Check your connection and try again.`}
      </p>
      <Button type="button" variant="secondary" onClick={onRetry} disabled={remaining > 0} className="shrink-0">
        {remaining > 0 ? `Try again in ${remaining}s` : "Try again"}
      </Button>
    </div>
  );
}
