import { useEffect, useId, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, UserPlus, XCircle } from "lucide-react";
import * as api from "../../services/api";
import { ApiError, type AccountRequest } from "../../services/api";
import { usePageTitle } from "../../hooks/usePageTitle";
import { formatDate } from "../../utils/formatDate";
import { PageHeader } from "../../components/ui/PageHeader";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { Badge } from "../../components/ui/Badge";
import { Select } from "../../components/ui/Select";
import { EmptyState } from "../../components/ui/EmptyState";
import { ModalDialog } from "../../components/ui/ModalDialog";
import { LoadErrorNotice } from "../../components/LoadErrorNotice";

type Decision = { kind: "approve" | "reject"; request: AccountRequest } | null;

function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString(undefined, { day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" });
}

function reviewErrorMessage(error: unknown): string {
  if (error instanceof ApiError && error.status < 500) return error.message;
  return "Couldn't save your decision. Check your connection and try again.";
}

// Supervisor review of account requests. The server enforces who may do
// this (SUPERVISOR role, clinic scope); approving creates the CHW account.
function AccountRequests() {
  usePageTitle("Account requests");
  const queryClient = useQueryClient();
  const reasonId = useId();
  const pendingQuery = useQuery({ queryKey: ["accountRequests", "pending"], queryFn: () => api.getAccountRequests("pending") });
  const reviewedQuery = useQuery({ queryKey: ["accountRequests", "reviewed"], queryFn: () => api.getAccountRequests("reviewed") });
  const clinicsQuery = useQuery({ queryKey: ["requestableClinics"], queryFn: api.getRequestableClinics });

  const [decision, setDecision] = useState<Decision>(null);
  const [clinicId, setClinicId] = useState("");
  const [reason, setReason] = useState("");
  const [result, setResult] = useState<string | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const decide = useMutation({
    mutationFn: async (d: NonNullable<Decision>) =>
      d.kind === "approve" ? api.approveAccountRequest(d.request.id, clinicId !== d.request.clinic_id ? clinicId : undefined) : api.rejectAccountRequest(d.request.id, reason.trim() || undefined),
    onSuccess: (_data, d) => {
      setDecision(null);
      setResult(
        d.kind === "approve"
          ? `Approved. ${d.request.full_name} can now sign in as ${d.request.requested_chw_id} with the PIN they chose.`
          : `Rejected. No account was created for ${d.request.full_name}.`,
      );
      void queryClient.invalidateQueries({ queryKey: ["accountRequests"] });
      void queryClient.invalidateQueries({ queryKey: ["chws"] });
    },
  });

  useEffect(() => {
    if (result) resultRef.current?.focus();
  }, [result]);

  function open(kind: "approve" | "reject", request: AccountRequest) {
    decide.reset();
    setClinicId(request.clinic_id);
    setReason("");
    setDecision({ kind, request });
  }

  const pending = pendingQuery.data;
  const reviewed = reviewedQuery.data;

  return (
    <div className="max-w-4xl space-y-6">
      <PageHeader title="Account requests" description="People asking for a CHW account. Approving one creates the account; rejecting it creates nothing." />

      {result && (
        <div
          ref={resultRef}
          tabIndex={-1}
          role="status"
          className="flex items-start gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 outline-none focus-visible:ring-2 focus-visible:ring-emerald-700"
        >
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-800" aria-hidden="true" />
          <p className="text-sm text-emerald-900">{result}</p>
        </div>
      )}

      <section aria-labelledby="pending-heading" className="space-y-3">
        <h2 id="pending-heading" className="text-base font-semibold text-stone-900">
          Waiting for review{pending ? ` (${pending.length})` : ""}
        </h2>
        {pendingQuery.isError && <LoadErrorNotice error={pendingQuery.error} what="account requests" onRetry={() => void pendingQuery.refetch()} />}
        {pendingQuery.isPending && <p className="text-sm text-stone-500">Loading…</p>}
        {pending && pending.length === 0 && <EmptyState icon={UserPlus} title="No requests waiting" description="New account requests appear here." />}
        {pending && pending.length > 0 && (
          <ul className="space-y-3">
            {pending.map((r) => (
              <li key={r.id}>
                <Card className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <p className="text-base font-semibold text-stone-900">{r.full_name}</p>
                    <dl className="mt-1 grid grid-cols-[auto_1fr] gap-x-3 gap-y-0.5 text-sm">
                      <dt className="text-stone-600">CHW ID</dt>
                      <dd className="text-stone-900">{r.requested_chw_id}</dd>
                      <dt className="text-stone-600">Clinic</dt>
                      <dd className="text-stone-900">{r.clinic}</dd>
                      <dt className="text-stone-600">Phone</dt>
                      <dd className="text-stone-900">{r.phone_number ?? "Not given"}</dd>
                      <dt className="text-stone-600">Requested</dt>
                      <dd className="text-stone-900">{formatDateTime(r.requested_at)}</dd>
                    </dl>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <Button variant="secondary" onClick={() => open("reject", r)}>
                      Reject<span className="sr-only"> {r.full_name}</span>
                    </Button>
                    <Button onClick={() => open("approve", r)}>
                      Approve<span className="sr-only"> {r.full_name}</span>
                    </Button>
                  </div>
                </Card>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section aria-labelledby="reviewed-heading" className="space-y-3">
        <h2 id="reviewed-heading" className="text-base font-semibold text-stone-900">
          Reviewed
        </h2>
        {reviewedQuery.isError && <LoadErrorNotice error={reviewedQuery.error} what="reviewed requests" onRetry={() => void reviewedQuery.refetch()} />}
        {reviewed && reviewed.length === 0 && <p className="text-sm text-stone-600">No requests reviewed yet.</p>}
        {reviewed && reviewed.length > 0 && (
          <Card className="p-0">
            <ul className="divide-y divide-stone-100">
              {reviewed.map((r) => (
                <li key={r.id} className="flex flex-col gap-1 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-stone-900">
                      {r.full_name} · {r.requested_chw_id}
                    </p>
                    <p className="text-xs text-stone-600">
                      {r.clinic} · {r.status === "approved" ? "Approved" : "Rejected"} by {r.reviewed_by_name ?? "a supervisor"}
                      {r.reviewed_at ? ` on ${formatDate(r.reviewed_at)}` : ""}
                    </p>
                  </div>
                  {r.status === "approved" ? (
                    <Badge variant="success">
                      <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                      Approved
                    </Badge>
                  ) : (
                    <Badge variant="neutral">
                      <XCircle className="h-3.5 w-3.5" aria-hidden="true" />
                      Rejected
                    </Badge>
                  )}
                </li>
              ))}
            </ul>
          </Card>
        )}
      </section>

      <ModalDialog
        open={decision !== null}
        title={decision ? (decision.kind === "approve" ? `Approve ${decision.request.full_name}?` : `Reject ${decision.request.full_name}?`) : ""}
        onClose={() => setDecision(null)}
        busy={decide.isPending}
        actions={
          <>
            <Button type="button" variant="secondary" onClick={() => setDecision(null)} disabled={decide.isPending} autoFocus>
              Cancel
            </Button>
            <Button
              type="button"
              variant={decision?.kind === "reject" ? "danger" : "primary"}
              onClick={() => decision && decide.mutate(decision)}
              disabled={decide.isPending || (decision?.kind === "approve" && !clinicId)}
            >
              {decide.isPending ? "Saving…" : decision?.kind === "approve" ? "Approve and create account" : "Reject request"}
            </Button>
          </>
        }
      >
        {decision?.kind === "approve" && (
          <>
            <p>
              This creates a CHW account <span className="font-medium">{decision.request.requested_chw_id}</span>. They sign in with the
              PIN they chose when requesting - you won't see it.
            </p>
            <Select
              label="Clinic"
              id="approve-clinic"
              value={clinicId}
              onValueChange={setClinicId}
              placeholder="Choose a clinic"
              options={(clinicsQuery.data ?? []).map((c) => ({ value: c.id, label: c.name }))}
            />
          </>
        )}
        {decision?.kind === "reject" && (
          <>
            <p>No account will be created, and the PIN they chose is discarded.</p>
            <div className="space-y-1.5">
              <label htmlFor={reasonId} className="block text-sm font-medium text-stone-700">
                Reason (optional, kept in the activity log only)
              </label>
              <textarea
                id={reasonId}
                rows={2}
                maxLength={300}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full rounded-lg border border-stone-300 px-3 py-2 text-base sm:text-sm focus:outline-none focus:ring-2 focus:ring-forest-700/30 focus:border-forest-700"
              />
            </div>
          </>
        )}
        {decide.isError && (
          <p role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-red-800">
            {reviewErrorMessage(decide.error)}
          </p>
        )}
      </ModalDialog>
    </div>
  );
}

export default AccountRequests;
