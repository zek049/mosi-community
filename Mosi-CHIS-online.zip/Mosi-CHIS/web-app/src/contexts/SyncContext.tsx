import { createContext, useCallback, useContext, useEffect, useRef, useState, useSyncExternalStore, type ReactNode } from "react";
import { useLiveQuery } from "dexie-react-hooks";
import { countPending, db } from "../db/indexedDb";
import { runSync, type SyncOutcome } from "../services/syncService";
import * as api from "../services/api";
import { ApiError, NetworkError } from "../services/api";
import * as authService from "../services/authService";
import { useNetwork } from "./NetworkContext";
import { useAnnouncer } from "./AnnouncerContext";
import { SyncNotAllowedError, type ConnectivityStatus } from "../services/connectivity";
import { syncPausedMessage, syncResultMessage, syncStartAnnouncement } from "../utils/syncMessages";

// The single source of truth for "what's the sync state right now", read by
// the status pill, Sync Status, CHW Home and the save confirmations - so
// they can never disagree, and none of them shows "Synced" just because the
// network happens to be up. Everything here is derived from the real sync
// engine (services/syncService.ts) and the real local queue (IndexedDB).

export type SyncPhase = "idle" | "syncing" | "paused";

type SyncValue = {
  phase: SyncPhase;
  /** Records currently being uploaded (the batch size, not live progress -
   *  the server processes one batch per request, so per-record progress
   *  isn't observable and isn't faked). */
  syncingCount: number;
  /** Last time the server acknowledged a sync from THIS device. */
  lastSyncAt: string | null;
  lastOutcome: SyncOutcome | null;
  /** Plain-language result of the last completed sync (from the server's verdicts). */
  lastResultMessage: string | null;
  /** Human-readable reason the last attempt didn't complete. */
  lastError: string | null;
  pendingCount: number;
  failedCount: number;
  flaggedCount: number;
  countsReady: boolean;
  syncNow: (options?: { manual?: boolean }) => Promise<void>;
};

const SyncContext = createContext<SyncValue | undefined>(undefined);

// Per signed-in CHW, so on a shared clinic device the next person to sign
// in never sees the previous user's "last synced" time.
function lastSyncKey(): string | null {
  const chwId = authService.getSession()?.chw.chw_id;
  return chwId ? `mosi.lastSyncAt.${chwId}` : null;
}

function readLastSync(): string | null {
  const key = lastSyncKey();
  if (!key) return null;
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}


// Why a sync can't run right now, in plain words.
function notConnectedMessage(status: ConnectivityStatus): string {
  if (status === "work-offline") return "Work Offline is on. Your changes are saved on this device and won't sync until you turn it off.";
  if (status === "server-unreachable") return "Can't reach the Mosi server right now. Your changes are saved on this device.";
  if (status === "checking") return "Checking the connection. Your changes are saved on this device.";
  return "You're offline. Your changes are saved on this device and will sync when you're connected.";
}

function humanSyncError(error: unknown): string {
  if (error instanceof ApiError && error.code === "PIN_CHANGE_REQUIRED") {
    return "A supervisor set you a temporary PIN. Choose a new PIN to keep syncing - your changes are still saved on this device.";
  }
  if (error instanceof SyncNotAllowedError) return notConnectedMessage(error.status);
  if (error instanceof NetworkError) return "Couldn't reach the Mosi server.";
  if (error instanceof ApiError && (error.status === 401 || error.status === 403)) {
    return "Your session has ended. Sign in again to sync - your changes are still saved on this device.";
  }
  if (error instanceof ApiError && error.status === 429) return "The server asked Mosi to slow down. Try again in a minute.";
  return "The server couldn't accept these changes right now.";
}

function isChwSession(): boolean {
  return authService.getSession()?.chw.role === "CHW";
}

export function SyncProvider({ children }: { children: ReactNode }) {
  const { isOnline, status: connectivity, reportServerUnreachable } = useNetwork();
  const { announce } = useAnnouncer();

  const [phase, setPhase] = useState<SyncPhase>("idle");
  const [syncingCount, setSyncingCount] = useState(0);
  // Re-read on every render (a cheap localStorage lookup) rather than held
  // in state, so signing in as someone else picks up *their* value
  // immediately; bumping this counter forces the re-render after a sync.
  const [, setLastSyncVersion] = useState(0);
  const lastSyncAt = readLastSync();
  const [lastOutcome, setLastOutcome] = useState<SyncOutcome | null>(null);
  const [lastError, setLastError] = useState<string | null>(null);
  const inFlight = useRef(false);
  const startupChecked = useRef(false);
  // Whose database is open (see db/indexedDb.ts). Everything below is
  // keyed on it, so signing out and in as someone else never shows the
  // previous person's counts or last result.
  const chwId = useSyncExternalStore(authService.subscribeToSession, authService.currentChwId);

  const counts = useLiveQuery(async () => {
    if (!chwId) return { pending: 0, failed: 0, flagged: 0 };
    const [pendingPatients, pendingVisits, pendingHouseholds, attempts] = await Promise.all([
      db.patients.where("sync_status").equals("pending").primaryKeys(),
      db.visits.where("sync_status").equals("pending").primaryKeys(),
      db.households.where("sync_status").equals("pending").primaryKeys(),
      db.syncAttempts.toArray(),
    ]);
    const pendingIds = new Set<string>([...pendingPatients, ...pendingVisits, ...pendingHouseholds]);
    return {
      pending: pendingIds.size,
      failed: attempts.filter((a) => a.status === "failed" && pendingIds.has(a.id)).length,
      flagged: attempts.filter((a) => a.status === "conflict").length,
    };
  }, [chwId]);

  useEffect(() => {
    setPhase("idle");
    setLastOutcome(null);
    setLastError(null);
    startupChecked.current = false;
  }, [chwId]);

  const pendingCount = counts?.pending ?? 0;

  const syncNow = useCallback(
    async ({ manual = false }: { manual?: boolean } = {}) => {
      if (inFlight.current || !authService.currentChwId()) return;
      // Nothing can sync until a temporary PIN has been replaced.
      if (authService.getSession()?.mustChangePin) return;
      if (!isOnline) {
        if (manual) announce(notConnectedMessage(connectivity));
        return;
      }

      inFlight.current = true;
      const queued = await countPending();
      setSyncingCount(queued);
      setPhase("syncing");
      setLastError(null);
      const startMessage = syncStartAnnouncement(queued);
      if (startMessage) announce(startMessage);

      try {
        const outcome = await runSync();
        // Nothing to upload: runSync never contacts the server in that case,
        // so confirm the server is actually reachable before calling this
        // device "up to date" - otherwise "Last synced" would be a guess.
        if (outcome.attempted === 0) await api.getHealth();

        const key = lastSyncKey();
        try {
          if (key) localStorage.setItem(key, new Date().toISOString());
        } catch {
          // Non-fatal: only affects the "last synced" label.
        }
        setLastSyncVersion((v) => v + 1);
        setLastOutcome(outcome);
        setPhase(outcome.failed > 0 ? "paused" : "idle");

        if (outcome.attempted > 0 || manual) announce(syncResultMessage(outcome));
      } catch (error) {
        if (error instanceof SyncNotAllowedError) {
          // Stopped on purpose (Work Offline switched on, or the connection
          // dropped mid-sync) - nothing failed, the changes just wait.
          setPhase("idle");
          announce(notConnectedMessage(error.status));
          return;
        }
        // A real request couldn't reach the server: feed that back into the
        // one connectivity state instead of waiting for the next health check.
        if (error instanceof NetworkError) reportServerUnreachable();
        if (error instanceof ApiError && error.code === "PIN_CHANGE_REQUIRED") authService.markMustChangePin(true);
        setLastError(humanSyncError(error));
        setPhase("paused");
        announce(syncPausedMessage(queued));
      } finally {
        setSyncingCount(0);
        inFlight.current = false;
      }
    },
    [announce, isOnline, connectivity, reportServerUnreachable],
  );

  // Connectivity changes: say so once, and when a CHW comes back online
  // with changes waiting, sync them without making them hunt for a button.
  // The first health check after opening the app ("checking" -> "online")
  // is not a reconnection, so it isn't announced.
  const previousStatus = useRef<ConnectivityStatus>(connectivity);
  useEffect(() => {
    const previous = previousStatus.current;
    if (previous === connectivity) return;
    previousStatus.current = connectivity;
    if (connectivity === "checking") return;
    if (!isOnline) {
      if (connectivity === "work-offline") announce("Working offline. Changes are saved on this device and won't sync until you turn off Work Offline.");
      else if (connectivity === "server-unreachable") announce("Can't reach the Mosi server. Changes will be saved on this device.");
      else announce("You're offline. Changes will be saved on this device.");
      return;
    }
    if (previous === "checking") return; // startup - handled below
    if (isChwSession() && pendingCount > 0) {
      announce(previous === "work-offline" ? "Back online. Checking for pending changes." : "Connection restored. Checking for pending changes.");
      void syncNow();
    } else {
      announce(previous === "work-offline" ? "Back online." : "Connection restored.");
    }
  }, [announce, connectivity, isOnline, pendingCount, syncNow]);

  // Opening the app with changes left over from an offline session (the
  // "close and reopen" case) - sync them once, quietly, as soon as the
  // first health check confirms the server is reachable.
  useEffect(() => {
    if (startupChecked.current || counts === undefined || !isOnline) return;
    startupChecked.current = true;
    if (isChwSession() && counts.pending > 0) void syncNow();
  }, [counts, isOnline, syncNow]);

  const value: SyncValue = {
    phase,
    syncingCount,
    lastSyncAt,
    lastOutcome,
    lastResultMessage: lastOutcome ? syncResultMessage(lastOutcome) : null,
    lastError,
    pendingCount,
    failedCount: counts?.failed ?? 0,
    flaggedCount: counts?.flagged ?? 0,
    countsReady: counts !== undefined,
    syncNow,
  };

  return <SyncContext.Provider value={value}>{children}</SyncContext.Provider>;
}

export function useSync(): SyncValue {
  const context = useContext(SyncContext);
  if (!context) throw new Error("useSync must be used within a SyncProvider");
  return context;
}
