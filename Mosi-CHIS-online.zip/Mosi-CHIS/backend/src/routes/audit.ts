import { Router } from "express";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { parsePageParams, buildPagination } from "../utils/pagination";
import { clinicScope } from "../middleware/authz";

// The activity log (GET /api/audit-logs). Mounted supervisor/admin-only in
// app.ts. A supervisor sees their own clinic's activity: entries tagged with
// their clinic, plus older entries from before entries carried a clinic
// (clinic_id NULL) that were made by an account in their clinic. An
// administrator sees everything. Entries never contain PINs or tokens
// (utils/audit.ts), and this route returns nothing beyond the entry itself
// plus display names.
const router = Router();

// ISO date-time (the browser sends its own local start/end of day, so a
// "day" means the viewer's day, not UTC's).
function parseBound(value: string | undefined, name: string): Date | undefined {
  if (value === undefined || value === "") return undefined;
  const d = new Date(value);
  if (!/^\d{4}-\d{2}-\d{2}/.test(value) || Number.isNaN(d.getTime())) throw new AppError(400, `${name} must be a date-time (ISO 8601)`);
  return d;
}

router.get("/", async (req, res) => {
  const { actor_id: actorId, action, resource_type: resourceType, from, to } = req.query as Record<string, string | undefined>;
  const pageParams = parsePageParams(req);
  const fromDate = parseBound(from, "from");
  const toDate = parseBound(to, "to");
  if (fromDate && toDate && fromDate > toDate) throw new AppError(400, "from must be before to");

  const scope = clinicScope(req.user!);
  const clinicActors = scope
    ? (await prisma.chw.findMany({ where: { clinic_id: scope }, select: { chw_id: true } })).map((c) => c.chw_id)
    : null;

  const where = {
    AND: [
      scope ? { OR: [{ clinic_id: scope }, { clinic_id: null, actor_id: { in: clinicActors ?? [] } }] } : {},
      actorId ? { actor_id: actorId } : {},
      action ? { action: { in: action.split(",").map((a) => a.trim()).filter(Boolean) } } : {},
      resourceType ? { resource_type: resourceType } : {},
      fromDate || toDate ? { created_at: { ...(fromDate ? { gte: fromDate } : {}), ...(toDate ? { lte: toDate } : {}) } } : {},
    ],
  };

  const [entries, total] = await Promise.all([
    prisma.auditLog.findMany({
      where,
      orderBy: [{ created_at: "desc" }, { id: "desc" }],
      skip: pageParams.skip,
      take: pageParams.take,
    }),
    prisma.auditLog.count({ where }),
  ]);

  // Display names for the people and clinics on this page.
  const actorIds = [...new Set(entries.map((e) => e.actor_id).filter((id): id is string => !!id))];
  const clinicIds = [...new Set(entries.map((e) => e.clinic_id).filter((id): id is string => !!id))];
  const [actors, clinics] = await Promise.all([
    actorIds.length ? prisma.chw.findMany({ where: { chw_id: { in: actorIds } }, select: { chw_id: true, full_name: true } }) : [],
    clinicIds.length ? prisma.clinic.findMany({ where: { id: { in: clinicIds } }, select: { id: true, name: true } }) : [],
  ]);
  const actorName = new Map(actors.map((a) => [a.chw_id, a.full_name]));
  const clinicName = new Map(clinics.map((c) => [c.id, c.name]));

  res.json({
    success: true,
    data: entries.map((e) => ({
      ...e,
      actor_name: e.actor_id ? (actorName.get(e.actor_id) ?? null) : null,
      clinic_name: e.clinic_id ? (clinicName.get(e.clinic_id) ?? null) : null,
    })),
    pagination: buildPagination(pageParams, total),
  });
});

export default router;
