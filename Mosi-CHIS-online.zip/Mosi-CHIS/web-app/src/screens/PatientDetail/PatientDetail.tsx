import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { ArrowLeft, ClipboardPlus, UserX } from "lucide-react";
import { db } from "../../db/indexedDb";
import * as authService from "../../services/authService";
import { usePageTitle } from "../../hooks/usePageTitle";
import { formatDate } from "../../utils/formatDate";
import { calendarDay } from "../../utils/localDate";
import { SyncStatusBadge } from "../../components/ui/SyncStatusBadge";
import { VisitTypeBadge } from "../../components/ui/VisitTypeBadge";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { EmptyState } from "../../components/ui/EmptyState";
import type { Visit } from "../../models/visit";

const INITIAL_VISITS_SHOWN = 5;

function measurements(visit: Visit): string[] {
  const parts: string[] = [];
  if (visit.weight !== null) parts.push(`Weight ${visit.weight} kg`);
  if (visit.height !== null) parts.push(`Height ${visit.height} cm`);
  if (visit.blood_pressure !== null) parts.push(`BP ${visit.blood_pressure} mmHg`);
  return parts;
}

function PatientDetail() {
  const { id } = useParams<{ id: string }>();
  const session = authService.getSession();
  const isChw = session?.chw.role === "CHW";
  const [showAllVisits, setShowAllVisits] = useState(false);

  // Dexie's .get() resolves to undefined both while loading AND when the
  // record doesn't exist - wrapping it tells the two apart.
  const patientQuery = useLiveQuery(async () => {
    if (!id) return { patient: undefined };
    const patient = await db.patients.get(id);
    return { patient: patient && !patient.deleted_at ? patient : undefined };
  }, [id]);

  const visits = useLiveQuery(async () => {
    if (!id) return [];
    const list = (await db.visits.where("patient_id").equals(id).toArray()).filter((v) => !v.deleted_at);
    list.sort((a, b) => (calendarDay(a.visit_date) === calendarDay(b.visit_date) ? (a.created_at < b.created_at ? 1 : -1) : calendarDay(a.visit_date) < calendarDay(b.visit_date) ? 1 : -1));
    return list;
  }, [id]);

  const chws = useLiveQuery(() => db.chws.toArray(), []);
  // The patient's household and its other members (from this device).
  const householdInfo = useLiveQuery(async () => {
    if (!id) return null;
    const p = await db.patients.get(id);
    if (!p?.household_id) return null;
    const [household, members] = await Promise.all([
      db.households.get(p.household_id),
      db.patients.where("household_id").equals(p.household_id).toArray(),
    ]);
    return household ? { household, others: members.filter((m) => m.id !== id && !m.deleted_at) } : null;
  }, [id]);
  const patient = patientQuery?.patient;
  usePageTitle(patient ? `${patient.first_name} ${patient.last_name}` : "Patient");

  function chwName(chwId: string): string {
    if (chwId === session?.chw.chw_id) return "you";
    return chws?.find((c) => c.chw_id === chwId)?.full_name ?? "another CHW";
  }

  if (patientQuery === undefined) {
    return <p className="text-sm text-stone-500">Loading patient…</p>;
  }

  if (!patient) {
    return (
      <div className="space-y-4">
        <BackLink />
        <EmptyState
          icon={UserX}
          title="Patient not found"
          description="This patient isn't on this device. They may have been removed, or not synced here yet."
        />
      </div>
    );
  }

  const age = Math.floor((Date.now() - new Date(patient.date_of_birth).getTime()) / (365.25 * 24 * 60 * 60 * 1000));
  const lastVisit = visits?.[0];
  const shownVisits = visits ? (showAllVisits ? visits : visits.slice(0, INITIAL_VISITS_SHOWN)) : [];

  return (
    <div className="space-y-6">
      <BackLink />

      <header className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <h1 className="text-2xl font-semibold text-stone-900">
            {patient.first_name} {patient.last_name}
          </h1>
          <p className="mt-1 text-sm text-stone-600">
            {patient.gender === "F" ? "Female" : "Male"} · {age} years · {patient.village}
          </p>
          <p className="mt-1 flex flex-wrap items-center gap-2 text-sm text-stone-500">
            {patient.patient_id}
            {patient.sync_status === "pending" && <SyncStatusBadge status="pending" />}
          </p>
        </div>
        {isChw && (
          <Button asChild size="lg" className="w-full sm:w-auto shrink-0">
            <Link to={`/chw/visits/new?patient_id=${patient.id}`}>
              <ClipboardPlus className="h-5 w-5" aria-hidden="true" />
              Record visit
            </Link>
          </Button>
        )}
      </header>

      <div className="grid gap-4 lg:grid-cols-[3fr_2fr]">
        <div className="space-y-4">
          <Card>
            <h2 className="text-sm font-semibold text-stone-900">Last visit</h2>
            {visits === undefined && <p className="mt-2 text-sm text-stone-500">Loading…</p>}
            {visits && !lastVisit && <p className="mt-2 text-sm text-stone-600">No visits recorded yet.</p>}
            {lastVisit && (
              <div className="mt-2 space-y-1.5">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-base font-medium text-stone-900">{formatDate(lastVisit.visit_date)}</p>
                  <VisitTypeBadge type={lastVisit.visit_type} />
                </div>
                <p className="text-sm text-stone-600">
                  {measurements(lastVisit).join(" · ") || "No measurements recorded"}
                </p>
                {lastVisit.notes && <p className="text-sm text-stone-700">{lastVisit.notes}</p>}
                <p className="text-xs text-stone-500">Recorded by {chwName(lastVisit.chw_id)}</p>
              </div>
            )}
          </Card>

          {visits && visits.length > 1 && (
            <Card>
              <h2 className="text-sm font-semibold text-stone-900">Visit history</h2>
              <p className="mt-0.5 text-xs text-stone-500">
                {visits.length} visits, most recent first
              </p>
              <ol className="mt-3 divide-y divide-stone-100">
                {shownVisits.map((visit) => (
                  <li key={visit.id} className="py-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-medium text-stone-900">{formatDate(visit.visit_date)}</p>
                      <VisitTypeBadge type={visit.visit_type} />
                      {visit.sync_status === "pending" && <SyncStatusBadge status="pending" />}
                    </div>
                    <p className="mt-0.5 text-xs text-stone-600">
                      {[...measurements(visit), `Recorded by ${chwName(visit.chw_id)}`].join(" · ")}
                    </p>
                    {visit.notes && <p className="mt-1 text-xs text-stone-600">{visit.notes}</p>}
                  </li>
                ))}
              </ol>
              {visits.length > INITIAL_VISITS_SHOWN && (
                <Button type="button" variant="ghost" onClick={() => setShowAllVisits((v) => !v)} className="mt-1">
                  {showAllVisits ? "Show fewer visits" : `Show all ${visits.length} visits`}
                </Button>
              )}
            </Card>
          )}
        </div>

        <div className="space-y-4">
        <Card>
          <h2 className="text-sm font-semibold text-stone-900">Household</h2>
          {!householdInfo ? (
            <p className="mt-2 text-sm text-stone-600">Not in a household.</p>
          ) : (
            <>
              <p className="mt-2 text-sm text-stone-900">
                <span className="font-semibold">{householdInfo.household.household_code}</span>
                <span className="text-stone-600"> · {householdInfo.household.village}</span>
              </p>
              {householdInfo.others.length === 0 ? (
                <p className="mt-1 text-sm text-stone-600">No other members recorded yet.</p>
              ) : (
                <ul className="mt-2 divide-y divide-stone-100" aria-label="Other household members">
                  {householdInfo.others.map((m) => (
                    <li key={m.id}>
                      <Link to={`/patients/${m.id}`} className="flex min-h-11 items-center justify-between gap-2 py-2 text-sm text-forest-800 underline-offset-2 hover:underline">
                        <span>
                          {m.first_name} {m.last_name}
                          <span className="text-stone-600"> · {m.gender === "F" ? "Female" : "Male"}, born {formatDate(m.date_of_birth)}</span>
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </>
          )}
        </Card>
        <Card>
          <h2 className="text-sm font-semibold text-stone-900">Details</h2>
          <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
            <div>
              <dt className="text-xs text-stone-500">Date of birth</dt>
              <dd className="mt-0.5 text-stone-900">{formatDate(patient.date_of_birth)}</dd>
            </div>
            <div>
              <dt className="text-xs text-stone-500">Gender</dt>
              <dd className="mt-0.5 text-stone-900">{patient.gender === "F" ? "Female" : "Male"}</dd>
            </div>
            <div>
              <dt className="text-xs text-stone-500">Village</dt>
              <dd className="mt-0.5 text-stone-900">{patient.village}</dd>
            </div>
            <div>
              <dt className="text-xs text-stone-500">Phone</dt>
              <dd className="mt-0.5 text-stone-900">
                {patient.phone_number ? (
                  <a href={`tel:${patient.phone_number}`} className="text-forest-800 underline underline-offset-2">
                    {patient.phone_number}
                  </a>
                ) : (
                  "Not recorded"
                )}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-stone-500">Patient ID</dt>
              <dd className="mt-0.5 text-stone-900">{patient.patient_id}</dd>
            </div>
            <div>
              <dt className="text-xs text-stone-500">Registered</dt>
              <dd className="mt-0.5 text-stone-900">{formatDate(patient.created_at)}</dd>
            </div>
          </dl>
        </Card>
        </div>
      </div>
    </div>
  );
}

function BackLink() {
  return (
    <Link
      to="/patients"
      className="inline-flex min-h-11 items-center gap-1.5 text-sm font-medium text-stone-600 hover:text-stone-900"
    >
      <ArrowLeft className="h-4 w-4" aria-hidden="true" />
      All patients
    </Link>
  );
}

export default PatientDetail;
