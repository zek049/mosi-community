// Follow-up / due tracking. A patient is due for another visit of a
// trackable type once FOLLOW_UP_DAYS have passed since their latest visit of
// that type. Only the latest visit per (patient, type) counts, so recording
// the follow-up clears it. Other visit types are never "due".
//
// All maths is on calendar days ("YYYY-MM-DD"), never on Date times, so the
// device's time zone and daylight-saving can't shift a due date by a day.
// Mirrors web-app/src/utils/due.ts (same tests on both sides).
// Server dates come back as Date (midnight UTC) or ISO strings; either way
// the first 10 characters of the ISO form are the calendar day.
const calendarDay = (value: string | Date) => (typeof value === "string" ? value : value.toISOString()).slice(0, 10);

export const FOLLOW_UP_DAYS = {
  Antenatal: 30,
  Immunization: 90,
  "Growth Monitoring": 30,
  "HIV/TB Support": 30,
} as const;

export type TrackedVisitType = keyof typeof FOLLOW_UP_DAYS;

export type DueVisitInput = { patient_id: string; visit_type: string; visit_date: string | Date; deleted_at?: string | Date | null };

export type DueItem = {
  patient_id: string;
  visit_type: TrackedVisitType;
  last_visit: string; // YYYY-MM-DD
  due_date: string; // YYYY-MM-DD
  days_overdue: number; // > 0 overdue, 0 due today, < 0 due in that many days
};

function dayNumber(day: string): number {
  const [y, m, d] = day.split("-").map(Number);
  return Date.UTC(y, m - 1, d) / 86_400_000;
}

export function addDays(day: string, days: number): string {
  return new Date((dayNumber(day) + days) * 86_400_000).toISOString().slice(0, 10);
}

export function isTracked(type: string): type is TrackedVisitType {
  return Object.prototype.hasOwnProperty.call(FOLLOW_UP_DAYS, type);
}

// Everything due on or before `today + withinDays - 1`, including overdue,
// most overdue first. withinDays = 7 is "due this week" (today + 6 days).
export function computeDue(visits: DueVisitInput[], today: string, withinDays = 7): DueItem[] {
  const latest = new Map<string, { patient_id: string; visit_type: TrackedVisitType; day: string }>();
  for (const v of visits) {
    if (v.deleted_at || !isTracked(v.visit_type)) continue;
    const key = `${v.patient_id}\u0000${v.visit_type}`;
    const day = calendarDay(v.visit_date);
    const prev = latest.get(key);
    if (!prev || day > prev.day) latest.set(key, { patient_id: v.patient_id, visit_type: v.visit_type, day });
  }
  const todayNum = dayNumber(today);
  const items: DueItem[] = [];
  for (const { patient_id, visit_type, day } of latest.values()) {
    const due_date = addDays(day, FOLLOW_UP_DAYS[visit_type]);
    const days_overdue = todayNum - dayNumber(due_date);
    if (days_overdue > -withinDays) items.push({ patient_id, visit_type, last_visit: day, due_date, days_overdue });
  }
  return items.sort((a, b) => b.days_overdue - a.days_overdue || a.patient_id.localeCompare(b.patient_id) || a.visit_type.localeCompare(b.visit_type));
}

export function describeDue(daysOverdue: number): string {
  if (daysOverdue > 0) return `${daysOverdue} ${daysOverdue === 1 ? "day" : "days"} overdue`;
  if (daysOverdue === 0) return "Due today";
  if (daysOverdue === -1) return "Due tomorrow";
  return `Due in ${-daysOverdue} days`;
}
