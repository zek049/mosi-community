import { Router } from "express";
import { prisma } from "../db";
import { AppError } from "../utils/AppError";
import { requireRole } from "../middleware/auth";
import { canAccessClinic, canModifyClinicResource, clinicScope, isSupervisorOrAdmin } from "../middleware/authz";
import { requireStringParam } from "../utils/params";
import { parseDate, parseTimestampField } from "../utils/parseDate";
import { parsePageParams, buildPagination } from "../utils/pagination";
import { validateVisitFields } from "../services/validation";
import { writeAuditLog } from "../utils/audit";
import { reviewOnCreate, reviewOnEdit } from "../utils/review";

// Turns services/validation.ts's plain error list into the 400 AppError
// routes need. services/syncService.ts uses the same validator directly and
// turns the same list into a per-record "failed" result instead.
async function validateVisitInput(body: Record<string, unknown>, { partial }: { partial: boolean }) {
  const errors = await validateVisitFields(body, { partial });
  if (errors.length > 0) {
    throw new AppError(400, errors.join(". "));
  }
}

const router = Router();

router.get("/", async (req, res) => {
  const { visit_type: visitType, chw_id: chwId, patient_id: patientId, date, include_archived: includeArchived } =
    req.query as Record<string, string | undefined>;
  const pageParams = parsePageParams(req);

  const scope = clinicScope(req.user!);
  const clinicFilter = scope ? { clinic_id: scope } : {};

  const where = {
    AND: [
      clinicFilter,
      includeArchived === "true" && isSupervisorOrAdmin(req.user!) ? {} : { deleted_at: null },
      visitType ? { visit_type: visitType } : {},
      chwId ? { chw_id: chwId } : {},
      patientId ? { patient_id: patientId } : {},
      date
        ? {
            visit_date: {
              gte: new Date(`${date}T00:00:00.000Z`),
              lt: new Date(`${date}T23:59:59.999Z`),
            },
          }
        : {},
    ],
  };

  const [visits, total] = await Promise.all([
    prisma.visit.findMany({
      where,
      include: {
        patient: { select: { patient_id: true, first_name: true, last_name: true } },
        chw: { select: { chw_id: true, full_name: true } },
      },
      orderBy: { visit_date: "desc" },
      skip: pageParams.skip,
      take: pageParams.take,
    }),
    prisma.visit.count({ where }),
  ]);

  res.json({ success: true, data: visits, pagination: buildPagination(pageParams, total) });
});

router.get("/:id", async (req, res) => {
  const id = requireStringParam(req, "id");
  const visit = await prisma.visit.findUnique({
    where: { id },
    include: {
      patient: true,
      chw: { select: { chw_id: true, full_name: true, clinic: true } },
    },
  });

  if (!visit || visit.deleted_at) {
    throw new AppError(404, "Visit not found");
  }
  if (!canAccessClinic(req.user!, visit.clinic_id)) {
    throw new AppError(403, "You do not have permission to access this visit");
  }

  res.json({ success: true, data: visit });
});

router.post("/", async (req, res) => {
  const body = { ...(req.body ?? {}) } as Record<string, unknown>;

  // Actor identity comes from the authenticated session, never the request
  // body (section 18): a CHW can only ever record a visit as themselves, no
  // matter what chw_id the client sends. A supervisor may record on behalf
  // of a specific CHW, so their request's chw_id is respected as given.
  if (req.user!.role === "CHW") {
    body.chw_id = req.user!.chwId;
  }

  await validateVisitInput(body, { partial: false });

  if (typeof body.id !== "string" || !body.id.trim()) {
    throw new AppError(400, "id (client-generated UUID) is required");
  }

  const patient = await prisma.patient.findUnique({ where: { id: body.patient_id as string } });
  if (!patient || patient.deleted_at) {
    throw new AppError(404, "Patient not found");
  }
  // A visit's clinic is always the patient's clinic - this is also what
  // stops a CHW from recording a visit against a patient in another clinic,
  // since canAccessClinic checks the *patient's* clinic_id against the
  // actor's own.
  if (!canAccessClinic(req.user!, patient.clinic_id)) {
    throw new AppError(403, "You do not have permission to record a visit for this patient");
  }

  const now = new Date();
  const visit = await prisma.visit.create({
    data: {
      id: body.id,
      patient_id: body.patient_id as string,
      chw_id: body.chw_id as string,
      visit_date: parseDate(body.visit_date, "visit_date"),
      visit_type: body.visit_type as string,
      weight: (body.weight as number | undefined) ?? null,
      height: (body.height as number | undefined) ?? null,
      blood_pressure: (body.blood_pressure as string | undefined) ?? null,
      notes: (body.notes as string | undefined) ?? null,
      created_at: body.created_at ? parseTimestampField(body.created_at, "created_at") : now,
      updated_at: body.updated_at ? parseTimestampField(body.updated_at, "updated_at") : now,
      sync_status: "synced",
      clinic_id: patient.clinic_id,
      ...reviewOnCreate(req.user!),
    },
  });

  await writeAuditLog({
    actor: req.user,
    action: "VISIT_CREATED",
    resourceType: "visit",
    resourceId: visit.id,
    requestId: req.requestId,
    metadata: { patient_id: visit.patient_id, clinic_id: visit.clinic_id },
  });

  res.status(201).json({ success: true, data: visit });
});

router.put("/:id", async (req, res) => {
  const id = requireStringParam(req, "id");
  const body = { ...(req.body ?? {}) } as Record<string, unknown>;

  const existing = await prisma.visit.findUnique({ where: { id } });
  if (!existing || existing.deleted_at) {
    throw new AppError(404, "Visit not found");
  }
  if (!canModifyClinicResource(req.user!, existing.clinic_id)) {
    throw new AppError(403, "You do not have permission to modify this visit");
  }
  // Same anti-impersonation rule as create - a CHW editing a visit can't
  // reassign it to another CHW via the request body.
  if (req.user!.role === "CHW") {
    body.chw_id = existing.chw_id;
  }

  await validateVisitInput(body, { partial: true });

  const visit = await prisma.visit.update({
    where: { id },
    data: {
      patient_id: (body.patient_id as string | undefined) ?? undefined,
      chw_id: (body.chw_id as string | undefined) ?? undefined,
      visit_date: body.visit_date ? parseDate(body.visit_date, "visit_date") : undefined,
      visit_type: (body.visit_type as string | undefined) ?? undefined,
      weight: body.weight === undefined ? undefined : (body.weight as number | null),
      height: body.height === undefined ? undefined : (body.height as number | null),
      blood_pressure: body.blood_pressure === undefined ? undefined : (body.blood_pressure as string | null),
      notes: body.notes === undefined ? undefined : (body.notes as string | null),
      updated_at: body.updated_at ? parseTimestampField(body.updated_at, "updated_at") : new Date(),
      ...reviewOnEdit(req.user!),
    },
  });

  await writeAuditLog({
    actor: req.user,
    action: "VISIT_UPDATED",
    resourceType: "visit",
    resourceId: visit.id,
    requestId: req.requestId,
    clinicId: existing.clinic_id,
  });

  res.json({ success: true, data: visit });
});

// Supervisor-only, soft delete - same reasoning as patients.ts.
router.delete("/:id", requireRole("SUPERVISOR"), async (req, res) => {
  const id = requireStringParam(req, "id");
  const existing = await prisma.visit.findUnique({ where: { id } });
  // Another clinic's record looks the same as a missing one.
  if (!existing || existing.deleted_at || !canModifyClinicResource(req.user!, existing.clinic_id)) {
    throw new AppError(404, "Visit not found");
  }

  await prisma.visit.update({ where: { id }, data: { deleted_at: new Date() } });

  await writeAuditLog({
    actor: req.user,
    action: "VISIT_ARCHIVED",
    resourceType: "visit",
    resourceId: id,
    requestId: req.requestId,
    clinicId: existing.clinic_id,
  });

  res.json({ success: true, message: "Visit archived" });
});

export default router;
