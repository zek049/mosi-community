-- MVP hardening: clinics as a first-class entity, CHW account lifecycle,
-- clinic-scoped ownership on patients/visits, soft delete, a resolvable
-- sync-conflict object, and an audit log.
--
-- clinic_id on chws/patients/visits is added NULLABLE first, backfilled from
-- existing data, then made NOT NULL - Prisma can't generate this part
-- automatically because the tables aren't empty (3 chws, 50 patients, 133
-- visits at the time this was written). This is the "existing database ->
-- migration -> application startup" upgrade path, not just the "fresh
-- database" path - see prisma/migrations/20260916090440_init for the fresh
-- baseline this builds on.

-- pgcrypto's gen_random_uuid() is core in PostgreSQL 13+ (this project runs
-- 16-alpine), but this is a defensive no-op if it's ever missing rather than
-- assuming a specific PG version's extension availability.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- CreateEnum
CREATE TYPE "AccountStatus" AS ENUM ('active', 'inactive');

-- CreateTable
CREATE TABLE "clinics" (
    "id" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "location" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "clinics_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sync_conflicts" (
    "id" SERIAL NOT NULL,
    "record_type" TEXT NOT NULL,
    "record_id" TEXT NOT NULL,
    "incoming_version" JSONB NOT NULL,
    "server_version" JSONB NOT NULL,
    "incoming_timestamp" TIMESTAMP(3) NOT NULL,
    "server_timestamp" TIMESTAMP(3) NOT NULL,
    "detected_by" TEXT,
    "detected_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "status" TEXT NOT NULL DEFAULT 'open',
    "resolution" TEXT,
    "resolved_by" TEXT,
    "resolved_at" TIMESTAMP(3),

    CONSTRAINT "sync_conflicts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "audit_log" (
    "id" SERIAL NOT NULL,
    "actor_id" TEXT,
    "actor_role" TEXT,
    "action" TEXT NOT NULL,
    "resource_type" TEXT,
    "resource_id" TEXT,
    "request_id" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "metadata" JSONB,

    CONSTRAINT "audit_log_pkey" PRIMARY KEY ("id")
);

-- AlterTable: clinic_id added NULLABLE for now - see backfill below.
ALTER TABLE "chws" ADD COLUMN     "clinic_id" TEXT,
ADD COLUMN     "failed_login_count" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "last_login_at" TIMESTAMP(3),
ADD COLUMN     "locked_until" TIMESTAMP(3),
ADD COLUMN     "status" "AccountStatus" NOT NULL DEFAULT 'active',
ADD COLUMN     "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- AlterTable
ALTER TABLE "patients" ADD COLUMN     "clinic_id" TEXT,
ADD COLUMN     "deleted_at" TIMESTAMP(3),
ADD COLUMN     "registered_by_chw_id" TEXT;

-- AlterTable
ALTER TABLE "visits" ADD COLUMN     "clinic_id" TEXT,
ADD COLUMN     "deleted_at" TIMESTAMP(3);

-- ---------------------------------------------------------------------------
-- Data backfill (existing-database upgrade path)
-- ---------------------------------------------------------------------------

-- One clinic row per distinct chws.clinic display string seen today. Derived
-- from actual data, not hardcoded clinic names - this table is meant to
-- support any number of clinics going forward.
INSERT INTO "clinics" ("id", "code", "name", "active", "created_at", "updated_at")
SELECT
  gen_random_uuid()::text,
  upper(substring(regexp_replace(c.clinic, '[^A-Za-z]', '', 'g') FROM 1 FOR 4)) || '-' || lpad((row_number() OVER (ORDER BY c.clinic))::text, 2, '0'),
  c.clinic,
  true,
  now(),
  now()
FROM (SELECT DISTINCT "clinic" FROM "chws" WHERE "clinic" IS NOT NULL) c;

-- chws.clinic_id: exact match on the existing display string.
UPDATE "chws" c
SET "clinic_id" = cl."id"
FROM "clinics" cl
WHERE cl."name" = c."clinic";

-- patients.clinic_id, best available signal in order of preference:
--   1. the clinic of the CHW who recorded this patient's earliest visit
--   2. a village-name match against a clinic name (demo data has village
--      names embedded in clinic names, e.g. "Mbare" / "Mbare Clinic")
--   3. the oldest clinic row, as an absolute fallback so NOT NULL can be
--      applied below with no orphaned rows
UPDATE "patients" p
SET "clinic_id" = sub."clinic_id"
FROM (
  SELECT DISTINCT ON (v."patient_id") v."patient_id", chw."clinic_id"
  FROM "visits" v
  JOIN "chws" chw ON chw."chw_id" = v."chw_id"
  WHERE chw."clinic_id" IS NOT NULL
  ORDER BY v."patient_id", v."visit_date" ASC
) sub
WHERE p."id" = sub."patient_id";

UPDATE "patients" p
SET "clinic_id" = cl."id"
FROM "clinics" cl
WHERE p."clinic_id" IS NULL
  AND cl."name" ILIKE '%' || p."village" || '%';

UPDATE "patients" p
SET "clinic_id" = (SELECT "id" FROM "clinics" ORDER BY "created_at" ASC LIMIT 1)
WHERE p."clinic_id" IS NULL;

-- patients.registered_by_chw_id: best-effort attribution to whoever recorded
-- the earliest visit. Left NULL (the column is nullable) when a patient has
-- no visits at all - there's no signal to attribute it to.
UPDATE "patients" p
SET "registered_by_chw_id" = sub."chw_id"
FROM (
  SELECT DISTINCT ON (v."patient_id") v."patient_id", v."chw_id"
  FROM "visits" v
  ORDER BY v."patient_id", v."visit_date" ASC
) sub
WHERE p."id" = sub."patient_id";

-- visits.clinic_id: always the patient's clinic (every visit has a valid
-- patient_id FK, and every patient now has a clinic_id from above).
UPDATE "visits" v
SET "clinic_id" = p."clinic_id"
FROM "patients" p
WHERE v."patient_id" = p."id";

-- Now that every row has a value, the columns can be made required.
ALTER TABLE "chws" ALTER COLUMN "clinic_id" SET NOT NULL;
ALTER TABLE "patients" ALTER COLUMN "clinic_id" SET NOT NULL;
ALTER TABLE "visits" ALTER COLUMN "clinic_id" SET NOT NULL;

-- ---------------------------------------------------------------------------
-- Indexes and foreign keys
-- ---------------------------------------------------------------------------

-- CreateIndex
CREATE UNIQUE INDEX "clinics_code_key" ON "clinics"("code");

-- CreateIndex
CREATE INDEX "sync_conflicts_record_type_record_id_idx" ON "sync_conflicts"("record_type", "record_id");

-- CreateIndex
CREATE INDEX "sync_conflicts_status_idx" ON "sync_conflicts"("status");

-- CreateIndex
CREATE INDEX "sync_conflicts_detected_at_idx" ON "sync_conflicts"("detected_at");

-- CreateIndex
CREATE INDEX "audit_log_actor_id_idx" ON "audit_log"("actor_id");

-- CreateIndex
CREATE INDEX "audit_log_resource_type_resource_id_idx" ON "audit_log"("resource_type", "resource_id");

-- CreateIndex
CREATE INDEX "audit_log_action_idx" ON "audit_log"("action");

-- CreateIndex
CREATE INDEX "audit_log_created_at_idx" ON "audit_log"("created_at");

-- CreateIndex
CREATE INDEX "chws_clinic_id_idx" ON "chws"("clinic_id");

-- CreateIndex
CREATE INDEX "chws_status_idx" ON "chws"("status");

-- CreateIndex
CREATE INDEX "patients_clinic_id_idx" ON "patients"("clinic_id");

-- CreateIndex
CREATE INDEX "patients_deleted_at_idx" ON "patients"("deleted_at");

-- CreateIndex
CREATE INDEX "visits_clinic_id_idx" ON "visits"("clinic_id");

-- CreateIndex
CREATE INDEX "visits_deleted_at_idx" ON "visits"("deleted_at");

-- AddForeignKey
ALTER TABLE "patients" ADD CONSTRAINT "patients_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "patients" ADD CONSTRAINT "patients_registered_by_chw_id_fkey" FOREIGN KEY ("registered_by_chw_id") REFERENCES "chws"("chw_id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "visits" ADD CONSTRAINT "visits_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "chws" ADD CONSTRAINT "chws_clinic_id_fkey" FOREIGN KEY ("clinic_id") REFERENCES "clinics"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
