import { beforeEach, describe, expect, it, vi } from "vitest";

vi.hoisted(() => {
  process.env.JWT_SECRET = "test-secret-for-integration-tests";
});

// One mock per delegate method, created on demand.
const m = vi.hoisted(() => {
  const fns: Record<string, ReturnType<typeof vi.fn>> = {};
  const fn = (name: string) => (fns[name] ??= vi.fn());
  return { fns, fn };
});

vi.mock("../db", () => {
  const delegate = (model: string) =>
    new Proxy({}, { get: (_t, method: string) => m.fn(`${model}.${method}`) });
  return {
    prisma: {
      chw: delegate("chw"),
      patient: delegate("patient"),
      visit: delegate("visit"),
      household: delegate("household"),
      clinic: delegate("clinic"),
      auditLog: delegate("auditLog"),
      syncLog: delegate("syncLog"),
      syncConflict: delegate("syncConflict"),
      accountRequest: delegate("accountRequest"),
      pinResetRequest: delegate("pinResetRequest"),
      $queryRaw: m.fn("$queryRaw"),
      $transaction: m.fn("$transaction"),
    },
  };
});

import request from "supertest";
import app from "../app";
import { signSessionToken } from "../middleware/auth";

const MBARE = "clinic-mbare";
const HATCLIFFE = "clinic-hatcliffe";
const HQ = "clinic-hq";

// Accounts as the DATABASE has them (authenticate() reads role + clinic from here).
const accounts: Record<string, { chw_id: string; role: string; clinic_id: string; status: string; locked_until: null; must_change_pin: boolean }> = {};
function account(chw_id: string, role: string, clinic_id: string) {
  accounts[chw_id] = { chw_id, role, clinic_id, status: "active", locked_until: null, must_change_pin: false };
}
const auth = (chwId: string, tokenRole = "SUPERVISOR") => ({
  Authorization: `Bearer ${signSessionToken({ chwId, role: tokenRole as "SUPERVISOR", fullName: chwId })}`,
});
const mbareSup = () => auth("SUP002");
const admin = () => auth("SUP001");

const hatcliffePatient = { id: "p-hat", clinic_id: HATCLIFFE, deleted_at: null, review_status: "awaiting_review", patient_id: "HAT-0001" };
const hatcliffeVisit = { id: "v-hat", clinic_id: HATCLIFFE, deleted_at: null, review_status: "awaiting_review", chw_id: "CHW002", patient_id: "p-hat" };

beforeEach(() => {
  for (const f of Object.values(m.fns)) f.mockReset();
  for (const k of Object.keys(accounts)) delete accounts[k];
  account("SUP001", "ADMIN", HQ);
  account("SUP002", "SUPERVISOR", MBARE);
  account("CHW001", "CHW", MBARE);
  account("CHW002", "CHW", HATCLIFFE);
  account("SUP003", "SUPERVISOR", HATCLIFFE);

  m.fn("chw.findUnique").mockImplementation(async ({ where }: { where: { chw_id: string } }) => accounts[where.chw_id] ?? null);
  m.fn("chw.findMany").mockResolvedValue([]);
  m.fn("chw.count").mockResolvedValue(0);
  m.fn("chw.update").mockImplementation(async ({ where, data }: { where: { chw_id: string }; data: object }) => ({ ...accounts[where.chw_id], ...data }));
  m.fn("chw.create").mockImplementation(async ({ data }: { data: object }) => data);
  m.fn("patient.findUnique").mockResolvedValue(hatcliffePatient);
  m.fn("patient.findMany").mockResolvedValue([]);
  m.fn("patient.count").mockResolvedValue(0);
  m.fn("patient.groupBy").mockResolvedValue([]);
  m.fn("visit.findUnique").mockResolvedValue(hatcliffeVisit);
  m.fn("visit.findMany").mockResolvedValue([]);
  m.fn("visit.count").mockResolvedValue(0);
  m.fn("visit.groupBy").mockResolvedValue([]);
  m.fn("clinic.findUnique").mockImplementation(async ({ where }: { where: { id?: string; code?: string } }) => (where.id ? { id: where.id, name: where.id, active: true } : null));
  m.fn("clinic.findMany").mockResolvedValue([]);
  m.fn("clinic.create").mockImplementation(async ({ data }: { data: object }) => ({ id: "new-clinic", ...data }));
  m.fn("auditLog.create").mockResolvedValue({});
  m.fn("auditLog.findMany").mockResolvedValue([]);
  m.fn("auditLog.count").mockResolvedValue(0);
  m.fn("syncLog.findMany").mockResolvedValue([]);
  m.fn("syncLog.groupBy").mockResolvedValue([]);
  m.fn("syncConflict.findMany").mockResolvedValue([]);
  m.fn("syncConflict.count").mockResolvedValue(0);
  m.fn("syncConflict.findUnique").mockResolvedValue({ id: 7, record_type: "patient", record_id: "p-hat", status: "open" });
  m.fn("household.findMany").mockResolvedValue([]);
  m.fn("accountRequest.findMany").mockResolvedValue([]);
  m.fn("accountRequest.findUnique").mockResolvedValue({ id: "r1", clinic_id: HATCLIFFE, status: "pending", pin_hash: "x", requested_chw_id: "NEW01" });
  m.fn("pinResetRequest.findMany").mockResolvedValue([]);
  m.fn("pinResetRequest.findUnique").mockResolvedValue({ id: "pr1", chw_id: "CHW002", status: "pending", chw: accounts.CHW002 });
  m.fn("$queryRaw").mockResolvedValue([]);
});

const whereOf = (name: string, call = 0) => m.fn(name).mock.calls[call][0].where;

describe("a Mbare supervisor can't see Hatcliffe data", () => {
  it("patient and visit lists are filtered to Mbare", async () => {
    await request(app).get("/api/patients").set(mbareSup());
    await request(app).get("/api/visits").set(mbareSup());
    expect(JSON.stringify(whereOf("patient.findMany"))).toContain(MBARE);
    expect(JSON.stringify(whereOf("visit.findMany"))).toContain(MBARE);
  });

  it("a Hatcliffe patient / visit by id -> 403, edit -> 403, archive -> 404/403", async () => {
    expect((await request(app).get("/api/patients/p-hat").set(mbareSup())).status).toBe(403);
    expect((await request(app).get("/api/visits/v-hat").set(mbareSup())).status).toBe(403);
    expect((await request(app).put("/api/patients/p-hat").set(mbareSup()).send({ village: "X" })).status).toBe(403);
    // Archiving another clinic's record (this check was missing before).
    expect((await request(app).delete("/api/patients/p-hat").set(mbareSup())).status).toBe(404);
    expect((await request(app).delete("/api/visits/v-hat").set(mbareSup())).status).toBe(404);
    expect(m.fn("patient.update")).not.toHaveBeenCalled();
    expect(m.fn("visit.update")).not.toHaveBeenCalled();
  });

  it("CHW list and management list are filtered to Mbare", async () => {
    await request(app).get("/api/chws").set(mbareSup());
    expect(JSON.stringify(whereOf("chw.findMany"))).toContain(MBARE);
    m.fn("chw.findMany").mockClear();
    await request(app).get("/api/chws/manage").set(mbareSup());
    expect(whereOf("chw.findMany")).toEqual({ role: "CHW", clinic_id: MBARE });
  });

  it("can't revoke, edit, delete or reset the PIN of a Hatcliffe CHW (404, nothing changes)", async () => {
    expect((await request(app).post("/api/chws/CHW002/revoke").set(mbareSup())).status).toBe(404);
    expect((await request(app).patch("/api/chws/CHW002").set(mbareSup()).send({ pin: "4829" })).status).toBe(404);
    expect((await request(app).delete("/api/chws/CHW002").set(mbareSup())).status).toBe(404);
    expect((await request(app).post("/api/pin-reset-requests/pr1/complete").set(mbareSup()).send({ new_pin: "4829" })).status).toBe(404);
    expect(m.fn("chw.update")).not.toHaveBeenCalled();
    expect(m.fn("chw.delete")).not.toHaveBeenCalled();
  });

  it("can't add a CHW to Hatcliffe, or approve a Hatcliffe account request", async () => {
    expect((await request(app).post("/api/chws").set(mbareSup()).send({ chw_id: "CHW050", full_name: "New", clinic_id: HATCLIFFE, pin: "4829" })).status).toBe(403);
    expect((await request(app).post("/api/account-requests/r1/approve").set(mbareSup()).send({})).status).toBe(404);
    expect(m.fn("chw.create")).not.toHaveBeenCalled();
  });

  it("review queue: Hatcliffe records -> 404; the queue itself asks for Mbare only", async () => {
    expect((await request(app).post("/api/review/patients/p-hat/confirm").set(mbareSup()).send({})).status).toBe(404);
    expect((await request(app).post("/api/review/visits/v-hat/flag").set(mbareSup()).send({ reason: "Wrong weight" })).status).toBe(404);
    expect(m.fn("patient.updateMany")).not.toHaveBeenCalled();
    await request(app).get("/api/review/pending").set(mbareSup());
    expect(whereOf("patient.findMany")).toMatchObject({ clinic_id: MBARE });
  });

  it("conflicts: list limited to Mbare records; resolving a Hatcliffe conflict -> 404", async () => {
    m.fn("$queryRaw").mockResolvedValue([{ id: 3 }]);
    await request(app).get("/api/conflicts").set(mbareSup());
    expect(whereOf("syncConflict.findMany")).toMatchObject({ id: { in: [3] } });
    const res = await request(app).post("/api/conflicts/7/resolve").set(mbareSup()).send({ resolution: "KEEP_SERVER" });
    expect(res.status).toBe(404);
    expect(m.fn("syncConflict.update")).not.toHaveBeenCalled();
  });

  it("sync log and audit log are limited to Mbare", async () => {
    m.fn("$queryRaw").mockResolvedValue([{ id: 11 }]);
    await request(app).get("/api/sync/log").set(mbareSup());
    expect(whereOf("syncLog.findMany")).toEqual({ id: { in: [11] } });
    m.fn("chw.findMany").mockResolvedValue([{ chw_id: "SUP002" }, { chw_id: "CHW001" }]);
    await request(app).get("/api/audit-logs").set(mbareSup());
    expect(JSON.stringify(whereOf("auditLog.findMany"))).toContain('"actor_id":{"in":["SUP002","CHW001"]}');
  });

  it("dashboard: every count is for Mbare", async () => {
    const res = await request(app).get("/api/dashboard/stats").set(mbareSup());
    expect(res.status).toBe(200);
    for (const name of ["patient.count", "visit.count", "chw.count", "patient.groupBy", "visit.findMany"]) {
      for (const call of m.fn(name).mock.calls) expect(JSON.stringify(call[0].where), name).toContain(MBARE);
    }
  });

  it("follow-ups due, households and duplicate checks are limited to Mbare", async () => {
    await request(app).get("/api/patients/due?today=2026-10-06").set(mbareSup());
    expect(whereOf("visit.groupBy")).toMatchObject({ clinic_id: MBARE });
    await request(app).get("/api/households").set(mbareSup());
    expect(JSON.stringify(whereOf("household.findMany"))).toContain(MBARE);
    await request(app).get("/api/patients/possible-duplicates?first_name=A&last_name=B&village=C&date_of_birth=1990-01-01").set(mbareSup());
    expect(JSON.stringify(m.fn("patient.findMany").mock.calls.at(-1)![0].where)).toContain(MBARE);
  });
});

describe("administrator", () => {
  it("sees every clinic (no clinic filter)", async () => {
    await request(app).get("/api/patients").set(admin());
    expect(JSON.stringify(whereOf("patient.findMany"))).not.toContain("clinic_id");
    expect((await request(app).get("/api/patients/p-hat").set(admin())).status).toBe(200);
    await request(app).get("/api/sync/log").set(admin());
    expect(m.fn("$queryRaw")).not.toHaveBeenCalled();
  });

  it("manages supervisor accounts: list, create, revoke", async () => {
    const list = await request(app).get("/api/chws/manage?role=SUPERVISOR").set(admin());
    expect(list.status).toBe(200);
    expect(whereOf("chw.findMany")).toEqual({ role: "SUPERVISOR" });
    m.fn("chw.findUnique").mockImplementation(async ({ where }: { where: { chw_id: string } }) => accounts[where.chw_id] ?? null);
    const created = await request(app).post("/api/chws").set(admin()).send({ chw_id: "SUP010", full_name: "New Sup", clinic_id: HATCLIFFE, role: "SUPERVISOR", pin: "4829" });
    expect(created.status).toBe(201);
    expect(m.fn("chw.create").mock.calls[0][0].data).toMatchObject({ role: "SUPERVISOR", clinic_id: HATCLIFFE, must_change_pin: true });
    expect((await request(app).post("/api/chws/SUP003/revoke").set(admin())).status).toBe(200);
  });

  it("supervisors can't list or create supervisor accounts", async () => {
    expect((await request(app).get("/api/chws/manage?role=SUPERVISOR").set(mbareSup())).status).toBe(403);
    expect((await request(app).post("/api/chws").set(mbareSup()).send({ chw_id: "SUP011", full_name: "X", clinic_id: MBARE, role: "SUPERVISOR", pin: "4829" })).status).toBe(403);
    expect(m.fn("chw.create")).not.toHaveBeenCalled();
  });

  it("nobody can create an ADMIN, or revoke/delete/edit themselves or an admin", async () => {
    expect((await request(app).post("/api/chws").set(admin()).send({ chw_id: "ADM2", full_name: "X", clinic_id: HQ, role: "ADMIN", pin: "4829" })).status).toBe(400);
    expect((await request(app).post("/api/chws/SUP001/revoke").set(admin())).status).toBe(404);
    expect((await request(app).delete("/api/chws/SUP001").set(admin())).status).toBe(404);
    expect((await request(app).patch("/api/chws/SUP001").set(admin()).send({ pin: "4829" })).status).toBe(404);
    expect((await request(app).post("/api/chws/SUP002/revoke").set(auth("SUP002"))).status).toBe(404); // a supervisor on themselves
    expect(m.fn("chw.create")).not.toHaveBeenCalled();
    expect(m.fn("chw.update")).not.toHaveBeenCalled();
  });

  it("only an administrator creates clinics", async () => {
    expect((await request(app).post("/api/clinics").set(mbareSup()).send({ code: "NEW", name: "New Clinic" })).status).toBe(403);
    expect((await request(app).post("/api/clinics").set(admin()).send({ code: "NEW", name: "New Clinic" })).status).toBe(201);
  });
});

describe("the role comes from the database, not the session token", () => {
  it("a supervisor demoted to CHW loses supervisor access on the next request", async () => {
    account("SUP002", "CHW", MBARE);
    expect((await request(app).get("/api/dashboard/stats").set(auth("SUP002", "SUPERVISOR"))).status).toBe(403);
  });

  it("a token claiming ADMIN for a supervisor account gets supervisor (Mbare) scope only", async () => {
    await request(app).get("/api/patients").set(auth("SUP002", "ADMIN"));
    expect(JSON.stringify(whereOf("patient.findMany"))).toContain(MBARE);
    expect((await request(app).get("/api/chws/manage?role=SUPERVISOR").set(auth("SUP002", "ADMIN"))).status).toBe(403);
  });

  it("a CHW sees only their own clinic's CHW list", async () => {
    await request(app).get("/api/chws").set(auth("CHW001", "CHW"));
    expect(JSON.stringify(whereOf("chw.findMany"))).toContain(MBARE);
  });
});
