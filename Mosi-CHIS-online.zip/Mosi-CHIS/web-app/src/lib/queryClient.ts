import { QueryClient } from "@tanstack/react-query";
import { ApiError } from "../services/api";

// Governs the handful of genuine server round-trips (dashboard stats, the
// sync audit log, CHW activity, sync itself) - not the app's actual offline
// data, which lives in IndexedDB via Dexie's useLiveQuery and is deliberately
// untouched by this client. Refetch-on-focus is off: during a live demo,
// tabbing away and back shouldn't trigger a surprise network request. A
// single retry (not TanStack's default of 3) so a genuinely unreachable
// server surfaces its error quickly rather than after a long silent delay.
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // One retry for a dropped connection or a server error - never for a
      // 4xx: the same request would be refused the same way, and retrying a
      // 429 immediately only digs the rate-limit hole deeper.
      retry: (failureCount, error) => !(error instanceof ApiError && error.status < 500) && failureCount < 1,
      refetchOnWindowFocus: false,
    },
  },
});
