import { Component, type ErrorInfo, type ReactNode } from "react";

interface Props {
  children: ReactNode;
}

interface State {
  error: Error | null;
}

// React only offers error boundaries as class components - there's no hook
// equivalent. Mounted once at the app root (main.tsx) so an unexpected
// render error anywhere in Mosi shows this instead of an unrecoverable
// blank white screen. Local data in IndexedDB is untouched either way -
// this only concerns the current render tree crashing.
export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("Mosi crashed:", error, info.componentStack);
  }

  render() {
    if (this.state.error) {
      return (
        <div className="min-h-screen bg-cream flex items-center justify-center px-6">
          <div className="w-full max-w-sm bg-white rounded-2xl border border-stone-200 shadow-sm p-8 text-center space-y-4">
            <h1 className="text-lg font-semibold text-stone-900">Something went wrong</h1>
            <p className="text-sm text-stone-600">
              Mosi hit an unexpected error. Your saved patients and visits are safe on this device - reloading
              should get you back on track.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="w-full rounded-lg bg-forest-800 hover:bg-forest-900 text-white text-sm font-medium px-4 py-2.5"
            >
              Reload Mosi
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
