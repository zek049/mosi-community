-- CHW account status becomes active | revoked (Feature 3).
--
-- Value-preserving: every existing 'inactive' account becomes 'revoked'
-- (same meaning: cannot sign in, history kept). 'pending' / 'rejected' were
-- added by an earlier, never-released design and are unused (account
-- requests now live in account_requests); any row still holding them would
-- also map to 'revoked' - i.e. it can never sign in. Postgres can't drop
-- enum values, so the type is recreated and the column converted.
ALTER TYPE "AccountStatus" RENAME TO "AccountStatus_old";
CREATE TYPE "AccountStatus" AS ENUM ('active', 'revoked');
ALTER TABLE "chws" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "chws" ALTER COLUMN "status" TYPE "AccountStatus"
  USING (CASE "status"::text WHEN 'active' THEN 'active' ELSE 'revoked' END)::"AccountStatus";
ALTER TABLE "chws" ALTER COLUMN "status" SET DEFAULT 'active';
DROP TYPE "AccountStatus_old";
