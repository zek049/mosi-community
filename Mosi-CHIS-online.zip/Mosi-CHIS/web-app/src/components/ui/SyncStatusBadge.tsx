import type { ReviewStatus, SyncStatus } from "../../models/patient";
import { Badge } from "./Badge";

// Shared across Patient List, Patient Detail, Visit List, and Sync Status
// so a record's state always looks the same. Once the server has a record,
// its supervisor-review state is what's shown - a record waiting for review
// is never labelled as confirmed. "Synced" only appears when this device
// doesn't know the review state yet.
export function SyncStatusBadge({ status, review }: { status: SyncStatus; review?: ReviewStatus }) {
  if (status === "pending") {
    return (
      <Badge variant="warning" dot>
        Waiting to sync
      </Badge>
    );
  }
  if (review === "awaiting_review") {
    return (
      <Badge variant="info" dot>
        Awaiting review
      </Badge>
    );
  }
  if (review === "flagged") {
    return (
      <Badge variant="error" dot>
        Flagged
      </Badge>
    );
  }
  if (review === "confirmed") {
    return (
      <Badge variant="success" dot>
        Confirmed
      </Badge>
    );
  }
  return (
    <Badge variant="neutral" dot>
      Synced
    </Badge>
  );
}
