// PINs a person chooses for themselves (account request, change-PIN) must
// not be among the most guessable 4-digit values (NIST SP 800-63B: compare
// user-chosen secrets against commonly used values). Supervisor-set
// temporary PINs aren't checked - they must be changed on first sign-in.
// Mirrored in web-app/src/utils/validators.ts (isWeakPin).

const COMMON = new Set(["1234", "4321", "1212", "1122", "2580", "0852", "6969", "1004", "2000", "2001", "1010", "7777", "1313", "5683"]);

export function isWeakPin(pin: string): boolean {
  if (!/^\d{4}$/.test(pin)) return false; // format is validated separately
  if (/^(\d)\1{3}$/.test(pin)) return true; // 0000, 1111, ...
  const digits = [...pin].map(Number);
  const steps = digits.slice(1).map((d, i) => d - digits[i]);
  if (steps.every((s) => s === 1) || steps.every((s) => s === -1)) return true; // 0123, 3456, 9876, ...
  return COMMON.has(pin);
}

export const WEAK_PIN_MESSAGE = "That PIN is too easy to guess (like 1234, 0000 or 2580). Choose a less obvious one.";
