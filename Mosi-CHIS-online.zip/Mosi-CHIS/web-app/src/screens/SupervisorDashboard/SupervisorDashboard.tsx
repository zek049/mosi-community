import { useQuery, useQueries } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import {
  Users,
  UserRound,
  Stethoscope,
  RefreshCw,
  GitPullRequestArrow,
  XCircle,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Hourglass,
  Flag,
} from "lucide-react";
import * as api from "../../services/api";
import * as authService from "../../services/authService";
import { usePageTitle } from "../../hooks/usePageTitle";
import { getGreeting } from "../../utils/greeting";
import { summarizeChwActivity } from "../../utils/chwActivity";
import { formatDate } from "../../utils/formatDate";
import { StatCard } from "../../components/ui/StatCard";
import { Card } from "../../components/ui/Card";
import { Badge } from "../../components/ui/Badge";
import CoverageTrendChart from "./CoverageTrendChart";
import { ReviewQueue } from "./ReviewQueue";
import { LoadErrorNotice } from "../../components/LoadErrorNotice";
import { useSyncLog } from "../../hooks/useSyncLog";
import { DueList } from "../../components/DueList";
import { localIsoDate } from "../../utils/localDate";

const SYNC_LOG_WINDOW = 200;

// The Attention panel only reports what the server genuinely knows: open
// conflicts (the resolvable SyncConflict table) and sync attempts the server
// rejected among its most recent sync_log events. "Records waiting on a CHW's
// phone" is deliberately absent - the server can't see data it hasn't got.
function countRejected(entries: api.SyncLogEntry[]): number {
  return entries.filter((entry) => entry.status === "failed").length;
}

function trendSummary(trend: { date: string; visits: number }[]): string {
  if (trend.length === 0) return "No visits recorded in the last 30 days.";
  const total = trend.reduce((sum, d) => sum + d.visits, 0);
  const busiest = trend.reduce((best, d) => (d.visits > best.visits ? d : best), trend[0]);
  return `${total} visits over the last 30 days. Busiest day: ${formatDate(busiest.date)} with ${busiest.visits} visits.`;
}

function SupervisorDashboard() {
  usePageTitle("Dashboard");
  const session = authService.getSession();

  const statsQuery = useQuery({ queryKey: ["dashboardStats"], queryFn: api.getDashboardStats });
  const syncLogQuery = useSyncLog();
  const dueQuery = useQuery({ queryKey: ["dueFollowUps"], queryFn: () => api.getDueFollowUps(localIsoDate()) });
  const [chwsQuery, visitsQuery] = useQueries({
    queries: [
      { queryKey: ["chws"], queryFn: api.getChws },
      { queryKey: ["visits"], queryFn: () => api.getVisits() },
    ],
  });

  const stats = statsQuery.data ?? null;
  const rejected = syncLogQuery.data ? countRejected(syncLogQuery.data.slice(0, SYNC_LOG_WINDOW)) : 0;
  const activityRows =
    chwsQuery.data && visitsQuery.data && syncLogQuery.data
      ? summarizeChwActivity(chwsQuery.data, visitsQuery.data, syncLogQuery.data)
      : null;

  const loadFailed = statsQuery.isError || syncLogQuery.isError;

  function retry() {
    void statsQuery.refetch();
    void syncLogQuery.refetch();
    void chwsQuery.refetch();
    void visitsQuery.refetch();
  }

  const firstName = session?.chw.full_name.split(" ")[0] ?? "";
  const openConflicts = stats?.openConflicts ?? 0;
  const awaitingReview = stats ? stats.awaitingReview.patients + stats.awaitingReview.visits : 0;
  const flaggedRecords = stats ? stats.flagged.patients + stats.flagged.visits : 0;
  const allClear =
    stats !== null && syncLogQuery.data !== undefined && openConflicts === 0 && rejected === 0 && awaitingReview === 0 && flaggedRecords === 0;
  const today = new Date().toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-stone-900">
          {getGreeting()}, {firstName}
        </h1>
        <p className="mt-1 text-sm text-stone-500">
          {session?.chw.clinic ? `${session.chw.clinic} · ` : ""}
          {today}
        </p>
      </div>

      {loadFailed && (
        <LoadErrorNotice error={statsQuery.error ?? syncLogQuery.error} what="the dashboard" onRetry={retry} />
      )}

      {statsQuery.isPending && <p className="text-sm text-stone-500">Loading dashboard…</p>}

      {stats && (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 sm:gap-4">
            <StatCard label="Active CHWs" value={`${stats.activeChws} of ${stats.chws}`} icon={Users} tone="teal" />
            <StatCard label="Confirmed patients" value={stats.patients} icon={UserRound} tone="blue" />
            <StatCard label="Confirmed visits" value={stats.visits} icon={Stethoscope} tone="amber" />
            <StatCard
              label="Sync success"
              value={stats.syncSuccessRate === null ? "No syncs" : stats.syncSuccessRate}
              suffix={stats.syncSuccessRate === null ? "" : "%"}
              icon={RefreshCw}
              tone="teal"
            />
            <StatCard label="Open conflicts" value={stats.openConflicts} icon={GitPullRequestArrow} tone="violet" />
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-sm font-semibold text-stone-900">Visits per day</h2>
                <span className="text-xs text-stone-500">Last 30 days</span>
              </div>
              <p className="sr-only">{trendSummary(stats.trend)}</p>
              <div className="mt-4" aria-hidden="true">
                <CoverageTrendChart data={stats.trend} />
              </div>
            </Card>

            <Card>
              <h2 className="text-sm font-semibold text-stone-900">Needs your attention</h2>
              {allClear && (
                <div className="mt-3 flex items-start gap-3">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-800">
                    <CheckCircle2 className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-emerald-900">All clear</p>
                    <p className="text-sm text-stone-600">No conflicts or records waiting for review.</p>
                  </div>
                </div>
              )}
              {!allClear && (openConflicts > 0 || rejected > 0 || awaitingReview > 0 || flaggedRecords > 0) && (
                <ul className="mt-3 space-y-4">
                  {awaitingReview > 0 && stats && (
                    <AttentionItem
                      icon={Hourglass}
                      tone="text-sky-800 bg-sky-50"
                      title={`${awaitingReview} ${awaitingReview === 1 ? "record is" : "records are"} awaiting review`}
                      description={`${stats.awaitingReview.patients} ${stats.awaitingReview.patients === 1 ? "patient" : "patients"}, ${stats.awaitingReview.visits} ${stats.awaitingReview.visits === 1 ? "visit" : "visits"} from CHWs - not in the totals until confirmed.`}
                      link={{ to: "#review-queue", label: "Go to the review queue" }}
                    />
                  )}
                  {flaggedRecords > 0 && (
                    <AttentionItem
                      icon={Flag}
                      tone="text-red-700 bg-red-50"
                      title={`${flaggedRecords} flagged ${flaggedRecords === 1 ? "record" : "records"} to follow up`}
                      description="Records you or another supervisor flagged. Follow up with the CHW."
                      link={{ to: "#review-queue", label: "See flagged records" }}
                    />
                  )}
                  {openConflicts > 0 && (
                    <AttentionItem
                      icon={AlertTriangle}
                      tone="text-amber-800 bg-amber-50"
                      title={`${openConflicts} ${openConflicts === 1 ? "conflict needs" : "conflicts need"} review`}
                      description="A record was changed in two places. Choose which version to keep."
                      link={{ to: "/supervisor/conflicts", label: "Review conflicts" }}
                    />
                  )}
                  {rejected > 0 && (
                    <AttentionItem
                      icon={XCircle}
                      tone="text-red-700 bg-red-50"
                      title={`${rejected} ${rejected === 1 ? "record was" : "records were"} rejected`}
                      description={`Among the last ${SYNC_LOG_WINDOW} sync events. CHW devices keep these and retry automatically.`}
                      link={{ to: "/sync", label: "View sync activity" }}
                    />
                  )}
                </ul>
              )}
            </Card>
          </div>

          <ReviewQueue />

          <Card>
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h2 className="text-sm font-semibold text-stone-900">Follow-ups due this week</h2>
              {dueQuery.data && (
                <p className="text-sm text-stone-700">
                  <span className="font-semibold text-stone-900">{dueQuery.data.total}</span> due
                  {dueQuery.data.overdue > 0 && (
                    <>
                      {" · "}
                      <span className="font-semibold text-red-700">{dueQuery.data.overdue}</span> overdue
                    </>
                  )}
                </p>
              )}
            </div>
            {dueQuery.isPending && <p className="mt-2 text-sm text-stone-500">Loading follow-ups…</p>}
            {dueQuery.isError && <p className="mt-2 text-sm text-stone-600">Follow-ups couldn't be loaded. They'll show when the server is reachable.</p>}
            {dueQuery.data && dueQuery.data.total === 0 && <p className="mt-2 text-sm text-stone-600">No follow-up visits due in the next 7 days.</p>}
            {dueQuery.data && dueQuery.data.total > 0 && (
              <>
                <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-stone-600" aria-label="Due by visit type">
                  {Object.entries(dueQuery.data.by_type)
                    .filter(([, n]) => n > 0)
                    .map(([type, n]) => (
                      <li key={type}>
                        {type}: <span className="font-semibold text-stone-900">{n}</span>
                      </li>
                    ))}
                </ul>
                <div className="mt-3">
                  <DueList
                    rows={dueQuery.data.items.slice(0, 5).flatMap((d) =>
                      d.patient
                        ? [{ key: `${d.patient_id}-${d.visit_type}`, patientRecordId: d.patient.id, name: `${d.patient.first_name} ${d.patient.last_name}`, detail: `${d.patient.patient_id} · ${d.patient.village}`, visitType: d.visit_type, daysOverdue: d.days_overdue }]
                        : [],
                    )}
                  />
                </div>
                {dueQuery.data.total > 5 && <p className="mt-2 text-xs text-stone-500">Showing the 5 most overdue of {dueQuery.data.total}.</p>}
              </>
            )}
          </Card>

          <Card>
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-sm font-semibold text-stone-900">CHW activity</h2>
              <Link
                to="/supervisor/chw-activity"
                className="inline-flex min-h-11 items-center gap-1 text-sm font-medium text-forest-800 hover:text-forest-900"
              >
                View all
                <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
              </Link>
            </div>

            {!activityRows && <p className="mt-3 text-sm text-stone-500">Loading…</p>}
            {activityRows && activityRows.length === 0 && <p className="mt-3 text-sm text-stone-500">No CHWs in this clinic yet.</p>}

            {activityRows && activityRows.length > 0 && (
              <>
                <table className="mt-3 hidden w-full text-sm md:table">
                  <thead className="border-b border-stone-200 text-left text-xs text-stone-500">
                    <tr>
                      <th scope="col" className="pb-2 font-medium">Name</th>
                      <th scope="col" className="pb-2 font-medium">Clinic</th>
                      <th scope="col" className="pb-2 font-medium">Visits</th>
                      <th scope="col" className="pb-2 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {activityRows.slice(0, 5).map((row) => (
                      <tr key={row.chw.chw_id}>
                        <td className="py-2.5 font-medium text-stone-900">{row.chw.full_name}</td>
                        <td className="py-2.5 text-stone-600">{row.chw.clinic}</td>
                        <td className="py-2.5 text-stone-600">{row.visitCount}</td>
                        <td className="py-2.5">
                          <ActiveBadge active={row.isActive} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <ul className="mt-2 divide-y divide-stone-100 md:hidden">
                  {activityRows.slice(0, 5).map((row) => (
                    <li key={row.chw.chw_id} className="flex items-center justify-between gap-3 py-3">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium text-stone-900">{row.chw.full_name}</p>
                        <p className="text-xs text-stone-500">
                          {row.visitCount} {row.visitCount === 1 ? "visit" : "visits"}
                        </p>
                      </div>
                      <ActiveBadge active={row.isActive} />
                    </li>
                  ))}
                </ul>
              </>
            )}
          </Card>
        </>
      )}

      <p className="border-t border-stone-200 pt-4 text-xs text-stone-500">
        Synthetic demonstration data - not real patient records.
      </p>
    </div>
  );
}

function ActiveBadge({ active }: { active: boolean }) {
  return active ? (
    <Badge variant="success" dot>
      Active
    </Badge>
  ) : (
    <Badge variant="neutral" dot>
      Inactive
    </Badge>
  );
}

function AttentionItem({
  icon: Icon,
  tone,
  title,
  description,
  link,
}: {
  icon: typeof XCircle;
  tone: string;
  title: string;
  description: string;
  link: { to: string; label: string };
}) {
  return (
    <li className="flex items-start gap-3">
      <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${tone}`}>
        <Icon className="h-4 w-4" aria-hidden="true" />
      </span>
      <div>
        <p className="text-sm font-semibold text-stone-900">{title}</p>
        <p className="text-sm text-stone-600">{description}</p>
        {link.to.startsWith("#") ? (
          // Same-page jump (e.g. to the review queue below): moves focus there too.
          <a
            href={link.to}
            onClick={(e) => {
              const target = document.getElementById(link.to.slice(1));
              if (!target) return;
              e.preventDefault();
              target.scrollIntoView({ behavior: "smooth", block: "start" });
              target.focus({ preventScroll: true });
            }}
            className="mt-1 inline-flex min-h-11 items-center gap-1 text-sm font-medium text-forest-800 hover:text-forest-900"
          >
            {link.label}
            <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </a>
        ) : (
          <Link
            to={link.to}
            className="mt-1 inline-flex min-h-11 items-center gap-1 text-sm font-medium text-forest-800 hover:text-forest-900"
          >
            {link.label}
            <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </Link>
        )}
      </div>
    </li>
  );
}

export default SupervisorDashboard;
