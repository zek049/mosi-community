// Feature 9 - Households. Production build (:4173), real backend (:4000).
// Creates two test patients (P12-...) in one new household, offline, then syncs.
import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const BASE = "http://localhost:4173";
const API = "http://localhost:4000/api";
const STAMP = `P12-${String(Date.now()).slice(-6)}`;
const axeSource = readFileSync(new URL("./node_modules/axe-core/axe.min.js", import.meta.url), "utf8");
let pass = 0, fail = 0;
const errors = [];
function report(label, ok, extra) {
  ok ? pass++ : fail++;
  console.log(`${ok ? "OK  " : "FAIL"} - ${label}${extra !== undefined ? " :: " + JSON.stringify(extra) : ""}`);
}
async function axe(page, label) {
  await page.addScriptTag({ content: axeSource });
  const v = await page.evaluate(async () => (await window.axe.run(document, { runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"] } })).violations.map((x) => `${x.impact} ${x.id}: ${x.nodes.map((n) => n.target.join(" ")).slice(0, 3).join(" | ")}`));
  report(`axe (WCAG A/AA): no violations - ${label}`, v.length === 0, v.length ? v : undefined);
}
const local = (page, store) => page.evaluate(async (store) => {
  const db = await new Promise((res) => { const r = indexedDB.open("mosi-chis-user-CHW001"); r.onsuccess = () => res(r.result); });
  const rows = await new Promise((res) => { const c = db.transaction(store).objectStore(store).getAll(); c.onsuccess = () => res(c.result); });
  db.close();
  return rows;
}, store);
const noHScroll = (page) => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 375, height: 812 }, bypassCSP: true });
const page = await ctx.newPage();
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => { if (m.type() === "error" && !/ERR_INTERNET_DISCONNECTED|Failed to fetch/.test(m.text())) errors.push(m.text()); });

await page.goto(`${BASE}/login`, { waitUntil: "networkidle" });
await page.waitForFunction(() => document.body.innerText.includes("Online"));
await page.fill("#chwId", "CHW001"); await page.fill("#pin", "1234"); await page.press("#pin", "Enter");
await page.waitForURL("**/chw");
await page.waitForTimeout(2000);
const householdsBefore = (await local(page, "households")).length;

async function fillPatient(id, first, last, birth, gender) {
  await page.fill("#patient_id", id); await page.fill("#first_name", first); await page.fill("#last_name", last);
  await page.fill("#date_of_birth", birth); await page.check(`input[name="gender"][value="${gender}"]`); await page.fill("#village", "Mbare");
}

// 1. Offline: register a patient in a NEW household
await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "domcontentloaded" });
await page.waitForSelector("h1:has-text('Add patient')");
await ctx.setOffline(true);
await page.waitForTimeout(1500);
await fillPatient(`${STAMP}-A`, "Tariro", "Household", "1990-03-14", "F");
report("Household field: 'No household' is the default", await page.getByRole("radio", { name: "No household" }).isChecked());
await page.getByRole("radio", { name: "New household" }).check();
const codeText = await page.locator("text=New household code:").innerText();
const code1 = codeText.match(/([A-Z]{3}-[A-Z0-9]{6})/)?.[1];
report("New household: device-made code shown, Mbare prefix, 6 characters", /^MBA-[23456789ABCDEFGHJKMNPQRSTUVWXYZ]{6}$/.test(code1 ?? ""), codeText);
await page.click('button:has-text("New code")');
const code = (await page.locator("text=New household code:").innerText()).match(/([A-Z]{3}-[A-Z0-9]{6})/)?.[1];
report("'New code' gives a different code", code && code !== code1, { code1, code });
await axe(page, "Add patient with New household (offline)");
report("No horizontal scroll at 375px (household field)", await noHScroll(page));
await page.click('button:has-text("Save patient")');
await page.waitForSelector("text=Patient registered", { timeout: 8000 });
report("Offline: saved on the device", await page.isVisible("text=Saved on this device"));
let hh = (await local(page, "households")).filter((h) => h.household_code === code);
const patientsA = (await local(page, "patients")).filter((p) => p.patient_id === `${STAMP}-A`);
report("Dexie: household stored pending with the code", hh.length === 1 && hh[0].sync_status === "pending" && hh[0].village === "Mbare", hh);
report("Dexie: patient linked to that household", patientsA[0]?.household_id === hh[0]?.id);

// 2. Offline: 'Existing household' without picking one -> validation message
await page.goto(`${BASE}/chw/patients/new`, { waitUntil: "domcontentloaded" });
await page.waitForSelector("h1:has-text('Add patient')");
await fillPatient(`${STAMP}-B`, "Kuda", "Household", "2019-07-02", "M");
await page.getByRole("radio", { name: "Existing household" }).check();
await page.click('button:has-text("Save patient")');
report("Existing chosen but none picked -> clear message", await page.waitForSelector("text=Choose the household, or pick 'No household'.", { timeout: 4000 }).then(() => true).catch(() => false));

// 3. Offline: pick the new household as existing (search by code)
await page.fill('input[type="search"][placeholder="Household code or village"]', code.slice(-4).toLowerCase());
const option = page.getByRole("radio", { name: new RegExp(code) });
report("Search finds the household by part of its code (case-insensitive), shows 1 member", (await option.count()) === 1 && /1 member/.test(await option.locator("xpath=..").innerText()));
await option.check();
await axe(page, "Add patient with Existing household picked");
await page.click('button:has-text("Save patient")');
await page.waitForSelector("text=Patient registered", { timeout: 8000 });
const patientsB = (await local(page, "patients")).filter((p) => p.patient_id === `${STAMP}-B`);
report("Dexie: second patient joined the same household", patientsB[0]?.household_id === hh[0]?.id);
report("No extra household created by picking an existing one", (await local(page, "households")).length === householdsBefore + 1);

// 4. Back online -> sync sends the household first, then patients
await ctx.setOffline(false);
const syncBodies = [];
page.on("request", (r) => { if (r.url().endsWith("/api/sync") && r.method() === "POST") syncBodies.push(r.postDataJSON()); });
await page.goto(`${BASE}/sync`, { waitUntil: "domcontentloaded" });
await page.waitForFunction(() => document.body.innerText.includes("Online"), null, { timeout: 15000 });
const btn = page.locator('button:has-text("Sync now")');
if (await btn.isEnabled().catch(() => false)) await btn.click();
await page.waitForFunction(async () => {
  const db = await new Promise((res) => { const r = indexedDB.open("mosi-chis-user-CHW001"); r.onsuccess = () => res(r.result); });
  const n = await new Promise((res) => { const c = db.transaction("households").objectStore("households").index("sync_status").count("pending"); c.onsuccess = () => res(c.result); });
  db.close();
  return n === 0;
}, null, { timeout: 20000, polling: 500 }).catch(() => {});
hh = (await local(page, "households")).filter((h) => h.household_code === code);
report("After sync: household marked synced on the device", hh[0]?.sync_status === "synced", hh[0]?.sync_status);
const sentHH = syncBodies.find((b) => b.households?.some((h) => h.household_code === code));
report("Sync batch carried the household (with its patients)", !!sentHH && sentHH.patients.some((p) => p.patient_id === `${STAMP}-A`), syncBodies.length);
const server = await page.evaluate(async (API) => (await (await fetch(`${API}/households`, { credentials: "include" })).json()), API);
const onServer = (server.data ?? server).find?.((h) => h.household_code === code);
report("Server: household exists with 2 members, Mbare, clinic-scoped list", onServer?.member_count === 2 && onServer?.village === "Mbare", onServer);
const members = await page.evaluate(async ([API, id]) => (await (await fetch(`${API}/households/${id}/patients`, { credentials: "include" })).json()), [API, hh[0]?.id]);
const memberIds = members.data?.patients?.map((p) => p.patient_id).sort();
report("Server: GET /households/:id/patients lists both members", JSON.stringify(memberIds) === JSON.stringify([`${STAMP}-A`, `${STAMP}-B`]), memberIds);

// 5. Patient list: group by household
await page.goto(`${BASE}/patients`, { waitUntil: "domcontentloaded" });
await page.waitForSelector("h1");
await page.getByRole("checkbox", { name: "Group by household" }).check();
const group = page.getByRole("region", { name: new RegExp(code) });
await group.waitFor({ timeout: 5000 });
const groupText = await group.innerText();
report("Group by household: section for the code with 2 members listing both", /2 members/.test(groupText) && /Tariro Household/.test(groupText) && /Kuda Household/.test(groupText), groupText);
report("Group by household: 'Not in a household' section present for the rest", await page.getByRole("region", { name: /Not in a household/ }).isVisible());
await axe(page, "Patient list grouped by household");
for (const w of [360, 400]) {
  await page.setViewportSize({ width: w, height: 800 });
  report(`No horizontal scroll at ${w}px (grouped list)`, await noHScroll(page));
}
await page.setViewportSize({ width: 375, height: 812 });

// 6. Patient detail: household card with the other member
await page.goto(`${BASE}/patients/${patientsA[0].id}`, { waitUntil: "domcontentloaded" });
await page.waitForSelector("h1:has-text('Tariro Household')");
const card = await page.locator("h2:has-text('Household') >> xpath=..").innerText();
report("Patient detail: household code + village shown", card.includes(code) && card.includes("Mbare"), card);
const memberLink = page.getByRole("list", { name: "Other household members" }).getByRole("link");
report("Patient detail: the other member is listed (and only them)", (await memberLink.count()) === 1 && /Kuda Household/.test(await memberLink.innerText()));
await memberLink.click();
report("Member link opens that patient", await page.waitForSelector("h1:has-text('Kuda Household')", { timeout: 5000 }).then(() => true).catch(() => false));
await axe(page, "Patient detail with household");
report("No horizontal scroll at 375px (patient detail)", await noHScroll(page));

// 7. Existing patient without a household
const plain = (await local(page, "patients")).find((p) => !p.household_id && !/^P[0-9]+-/.test(p.patient_id));
await page.goto(`${BASE}/patients/${plain.id}`, { waitUntil: "domcontentloaded" });
await page.waitForSelector("h2:has-text('Household')");
report("Existing (pre-feature) patient shows 'Not in a household.'", await page.isVisible("text=Not in a household."));

report("No page errors or console errors", errors.length === 0, errors.length ? errors.slice(0, 5) : undefined);
console.log(`\n${pass} passed, ${fail} failed  (household ${code}, patients ${STAMP}-A/B)`);
await browser.close();
process.exit(fail ? 1 : 0);
