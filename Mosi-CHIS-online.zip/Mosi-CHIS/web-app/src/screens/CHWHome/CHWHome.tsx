import { useState } from "react";
import { Link } from "react-router-dom";
import { useLiveQuery } from "dexie-react-hooks";
import { ChevronRight, ClipboardPlus, UserPlus } from "lucide-react";
import { db } from "../../db/indexedDb";
import * as authService from "../../services/authService";
import { useSync } from "../../contexts/SyncContext";
import { usePageTitle } from "../../hooks/usePageTitle";
import { getGreeting } from "../../utils/greeting";
import { calendarDay, localIsoDate } from "../../utils/localDate";
import { Card } from "../../components/ui/Card";
import { InstallHint } from "../../components/InstallHint";
import { DueList, type DueRow } from "../../components/DueList";
import { computeDue, FOLLOW_UP_DAYS } from "../../utils/due";
import type { Patient } from "../../models/patient";

const RECENT_PATIENTS = 5;
const DUE_SHOWN = 5;

function formatVisitDay(isoDate: string): string {
  const today = localIsoDate();
  const yesterday = localIsoDate(new Date(Date.now() - 24 * 60 * 60 * 1000));
  if (isoDate === today) return "today";
  if (isoDate === yesterday) return "yesterday";
  return new Date(`${isoDate}T00:00:00`).toLocaleDateString(undefined, { day: "numeric", month: "short" });
}

type RecentPatient = { patient: Patient; lastVisit: string | null };

// "What do I need to do today?" - the one primary action, what I've done
// today, and the people I'm most likely to see again. Everything is read
// from this device, so it works the same offline.
function CHWHome() {
  usePageTitle("Home");
  const session = authService.getSession();
  const chwId = session?.chw.chw_id ?? "";
  const { pendingCount, countsReady } = useSync();

  const today = useLiveQuery(async () => {
    const todayIso = localIsoDate();
    const [visitsToday, patients] = await Promise.all([
      db.visits.filter((v) => v.chw_id === chwId && calendarDay(v.visit_date) === todayIso && !v.deleted_at).count(),
      db.patients.toArray(),
    ]);
    // Registered by me today: synced ones carry the server's
    // registered_by_chw_id; ones still pending were created on this device.
    const patientsToday = patients.filter(
      (p) =>
        localIsoDate(new Date(p.created_at)) === todayIso &&
        (p.registered_by_chw_id === chwId || p.sync_status === "pending") &&
        !p.deleted_at,
    ).length;
    return { visitsToday, patientsToday };
  }, [chwId]);

  const recentPatients = useLiveQuery(async (): Promise<RecentPatient[]> => {
    const [patients, visits] = await Promise.all([db.patients.toArray(), db.visits.toArray()]);
    const byId = new Map(patients.filter((p) => !p.deleted_at).map((p) => [p.id, p]));
    const lastVisitByPatient = new Map<string, string>();
    for (const v of visits) {
      if (v.deleted_at) continue;
      const prev = lastVisitByPatient.get(v.patient_id);
      const day = calendarDay(v.visit_date);
      if (!prev || day > prev) lastVisitByPatient.set(v.patient_id, day);
    }
    // People I visited most recently first, then anyone I registered.
    const mine = visits
      .filter((v) => v.chw_id === chwId && !v.deleted_at)
      .sort((a, b) => (calendarDay(a.visit_date) === calendarDay(b.visit_date) ? (a.created_at < b.created_at ? 1 : -1) : calendarDay(a.visit_date) < calendarDay(b.visit_date) ? 1 : -1));
    const seen = new Set<string>();
    const result: RecentPatient[] = [];
    for (const v of mine) {
      const patient = byId.get(v.patient_id);
      if (!patient || seen.has(patient.id)) continue;
      seen.add(patient.id);
      result.push({ patient, lastVisit: lastVisitByPatient.get(patient.id) ?? null });
      if (result.length === RECENT_PATIENTS) return result;
    }
    const registered = [...byId.values()]
      .filter((p) => !seen.has(p.id) && (p.registered_by_chw_id === chwId || p.sync_status === "pending"))
      .sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
    for (const patient of registered) {
      result.push({ patient, lastVisit: lastVisitByPatient.get(patient.id) ?? null });
      if (result.length === RECENT_PATIENTS) break;
    }
    return result;
  }, [chwId]);

  // Follow-ups due in the next 7 days (and overdue), from this device so it
  // works offline. Recording the visit clears it straight away.
  const due = useLiveQuery(async (): Promise<DueRow[]> => {
    const [patients, visits] = await Promise.all([db.patients.toArray(), db.visits.toArray()]);
    const byId = new Map(patients.filter((p) => !p.deleted_at).map((p) => [p.id, p]));
    return computeDue(visits, localIsoDate()).flatMap((d) => {
      const p = byId.get(d.patient_id);
      if (!p) return [];
      return [{ key: `${d.patient_id}-${d.visit_type}`, patientRecordId: p.id, name: `${p.first_name} ${p.last_name}`, detail: p.village, visitType: d.visit_type, daysOverdue: d.days_overdue }];
    });
  }, []);
  const [showAllDue, setShowAllDue] = useState(false);

  const firstName = session?.chw.full_name.split(" ")[0] ?? "";

  const activity = [
    { label: "Visits recorded", value: today?.visitsToday },
    { label: "Patients registered", value: today?.patientsToday },
    { label: "Waiting to sync", value: countsReady ? pendingCount : undefined, to: "/sync" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-stone-900">
          {getGreeting()}, {firstName}
        </h1>
        <p className="mt-1 text-sm text-stone-500">{session?.chw.clinic}</p>
      </div>

      <div className="grid gap-3 sm:grid-cols-[2fr_1fr]">
        <Link
          to="/chw/visits/new"
          className="flex min-h-16 items-center justify-center gap-3 rounded-xl bg-forest-800 px-5 py-4 text-base font-semibold text-white transition-colors hover:bg-forest-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-forest-700 focus-visible:ring-offset-2"
        >
          <ClipboardPlus className="h-6 w-6" aria-hidden="true" />
          Record visit
        </Link>
        <Link
          to="/chw/patients/new"
          className="flex min-h-12 items-center justify-center gap-2 rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm font-medium text-stone-800 transition-colors hover:bg-stone-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-forest-700 focus-visible:ring-offset-2"
        >
          <UserPlus className="h-5 w-5 text-forest-800" aria-hidden="true" />
          Add patient
        </Link>
      </div>

      <InstallHint />

      <section aria-labelledby="today-heading">
        <h2 id="today-heading" className="text-sm font-semibold text-stone-900">
          Today
        </h2>
        <Card className="mt-2 p-0">
          <ul className="grid grid-cols-3 divide-x divide-stone-100">
            {activity.map((item) => {
              const body = (
                <>
                  <span className="block text-2xl font-semibold text-stone-900">{item.value ?? "…"}</span>
                  <span className="mt-0.5 block text-xs leading-tight text-stone-600">{item.label}</span>
                </>
              );
              return (
                <li key={item.label}>
                  {item.to ? (
                    <Link to={item.to} className="block h-full rounded-r-xl px-3 py-4 text-center hover:bg-stone-50">
                      {body}
                    </Link>
                  ) : (
                    <div className="px-3 py-4 text-center">{body}</div>
                  )}
                </li>
              );
            })}
          </ul>
        </Card>
      </section>

      <section aria-labelledby="due-heading">
        <div className="flex items-baseline justify-between gap-2">
          <h2 id="due-heading" className="text-sm font-semibold text-stone-900">
            Due this week{due && due.length > 0 ? ` (${due.length})` : ""}
          </h2>
          {due && due.some((d) => d.daysOverdue > 0) && (
            <span className="text-xs text-red-700">{due.filter((d) => d.daysOverdue > 0).length} overdue</span>
          )}
        </div>
        {due === undefined && <p className="mt-2 text-sm text-stone-500">Loading…</p>}
        {due && due.length === 0 && (
          <p className="mt-2 text-sm text-stone-600">
            No follow-up visits due in the next 7 days.
          </p>
        )}
        {due && due.length > 0 && (
          <>
            <div className="mt-2">
              <DueList rows={showAllDue ? due : due.slice(0, DUE_SHOWN)} />
            </div>
            {due.length > DUE_SHOWN && (
              <button
                type="button"
                onClick={() => setShowAllDue((v) => !v)}
                aria-expanded={showAllDue}
                className="mt-1 inline-flex min-h-11 items-center text-sm font-medium text-forest-800 underline-offset-2 hover:underline"
              >
                {showAllDue ? "Show fewer" : `Show all ${due.length}`}
              </button>
            )}
          </>
        )}
        <p className="mt-2 text-xs text-stone-500">
          Follow-up after {Object.entries(FOLLOW_UP_DAYS).map(([type, days]) => `${type} ${days} days`).join(", ")}.
        </p>
      </section>

      <section aria-labelledby="recent-heading">
        <div className="flex items-center justify-between">
          <h2 id="recent-heading" className="text-sm font-semibold text-stone-900">
            Your recent patients
          </h2>
          <Link to="/patients" className="text-sm font-medium text-forest-800 underline-offset-2 hover:underline">
            All patients
          </Link>
        </div>
        {recentPatients === undefined && <p className="mt-2 text-sm text-stone-500">Loading…</p>}
        {recentPatients && recentPatients.length === 0 && (
          <p className="mt-2 text-sm text-stone-600">
            Patients you visit or register will show here for quick access.
          </p>
        )}
        {recentPatients && recentPatients.length > 0 && (
          <ul className="mt-2 divide-y divide-stone-100 overflow-hidden rounded-xl border border-stone-200 bg-white">
            {recentPatients.map(({ patient, lastVisit }) => (
              <li key={patient.id}>
                <Link
                  to={`/patients/${patient.id}`}
                  className="flex min-h-14 items-center justify-between gap-3 px-4 py-3 hover:bg-stone-50"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-stone-900">
                      {patient.first_name} {patient.last_name}
                    </p>
                    <p className="truncate text-xs text-stone-500">
                      {patient.village} · {lastVisit ? `Last visit ${formatVisitDay(lastVisit)}` : "No visits yet"}
                    </p>
                  </div>
                  <ChevronRight className="h-4 w-4 shrink-0 text-stone-400" aria-hidden="true" />
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <p className="border-t border-stone-200 pt-4 text-xs text-stone-500">
        Synthetic demonstration data - not real patient records.
      </p>
    </div>
  );
}

export default CHWHome;
