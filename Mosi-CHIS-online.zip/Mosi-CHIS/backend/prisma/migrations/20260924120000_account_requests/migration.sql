-- Account requests reuse the existing account status model: a requested
-- account is a Chw row in status "pending" until a supervisor approves it
-- (-> active) or rejects it (-> rejected). Additive only; existing rows and
-- values are untouched.
ALTER TYPE "AccountStatus" ADD VALUE IF NOT EXISTS 'pending';
ALTER TYPE "AccountStatus" ADD VALUE IF NOT EXISTS 'rejected';
