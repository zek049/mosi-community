// Public contact details shown in the landing page's Contact notice.
//
// Set these at BUILD time (Vite inlines VITE_* variables into the bundle),
// e.g. in web-app/.env.production or as Docker build args - see
// web-app/.env.example. Nothing is hard-coded here on purpose: Mosi must
// never show an invented address. When they're unset (or invalid), the
// notice tells people to contact their supervisor or system administrator.

export type PublicContact = { name: string; email: string };

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function readPublicContact(env: Record<string, string | undefined> = import.meta.env): PublicContact | null {
  const email = env.VITE_PUBLIC_CONTACT_EMAIL?.trim() ?? "";
  if (!EMAIL_PATTERN.test(email)) return null;
  const name = env.VITE_PUBLIC_CONTACT_NAME?.trim() || "the Mosi team";
  return { name, email };
}
