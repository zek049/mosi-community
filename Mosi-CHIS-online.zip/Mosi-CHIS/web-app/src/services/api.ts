import type { Patient } from "../models/patient";
import type { Visit } from "../models/visit";
import type { Chw } from "../models/chw";
import type { Household } from "../models/household";
import type { ReviewStatus } from "../models/patient";

export const API_BASE_URL = import.meta.env.VITE_API_URL ?? "http://localhost:4000/api";

export class ApiError extends Error {
  status: number;
  /** Seconds the server asked us to wait (Retry-After on a 429), when it said. */
  retryAfterSeconds: number | null;
  /** Machine-readable reason from the server, e.g. "ACCOUNT_PENDING". */
  code: string | null;
  constructor(status: number, message: string, retryAfterSeconds: number | null = null, code: string | null = null) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.retryAfterSeconds = retryAfterSeconds;
    this.code = code;
  }
}

function readRetryAfter(response: Response): number | null {
  return parseRetryAfter(response.headers.get("Retry-After"));
}

/** Retry-After is either a number of seconds or an HTTP date. */
export function parseRetryAfter(value: string | null, now = Date.now()): number | null {
  if (!value) return null;
  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds >= 0) return seconds;
  const date = Date.parse(value);
  return Number.isNaN(date) ? null : Math.max(0, Math.round((date - now) / 1000));
}

// Thrown when fetch itself fails - no connection, DNS failure, server not
// running - as opposed to ApiError, where the server WAS reached and
// responded with an error. services/syncService.ts's retry/backoff only
// applies to NetworkError: a 400 from the server will fail identically on
// retry, but a dropped connection might succeed a few seconds later.
export class NetworkError extends Error {
  constructor(message = "Could not reach the Mosi server") {
    super(message);
    this.name = "NetworkError";
  }
}

export type PageInfo = { page: number; limit: number; total: number; totalPages: number };
type ApiEnvelope<T> = { success: true; data: T; pagination?: PageInfo } | { success: false; message: string; code?: string };

async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  return (await apiFetchEnvelope<T>(path, options)).data;
}

// For paginated lists: the data plus the server's page information.
async function apiFetchPage<T>(path: string): Promise<{ data: T; pagination: PageInfo }> {
  const body = await apiFetchEnvelope<T>(path);
  return { data: body.data, pagination: body.pagination ?? { page: 1, limit: 0, total: 0, totalPages: 1 } };
}

async function apiFetchEnvelope<T>(path: string, options: RequestInit = {}): Promise<{ data: T; pagination?: PageInfo }> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string> | undefined),
  };

  let response: Response;
  try {
    // credentials:"include" (not the default "same-origin") so the browser
    // sends the httpOnly session cookie the server set at login even though
    // the frontend and API run on different origins (different ports in
    // dev; possibly different subdomains in production) - there is no
    // token for this code to read or attach itself anymore, by design.
    response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers, credentials: "include" });
  } catch {
    throw new NetworkError();
  }

  let body: ApiEnvelope<T>;
  try {
    body = (await response.json()) as ApiEnvelope<T>;
  } catch {
    throw new ApiError(response.status, "The server returned an unexpected response", readRetryAfter(response));
  }

  if (!body.success) {
    throw new ApiError(response.status, body.message, response.status === 429 ? readRetryAfter(response) : null, body.code ?? null);
  }

  return body;
}

function toQueryString(params: Record<string, string | undefined>): string {
  const entries = Object.entries(params).filter((entry): entry is [string, string] => Boolean(entry[1]));
  if (entries.length === 0) return "";
  return `?${new URLSearchParams(entries)}`;
}

// --- Auth ---

export type LoginResponse = {
  chw: Pick<Chw, "chw_id" | "full_name" | "clinic" | "role"> & { must_change_pin?: boolean };
};

/** Requires a session; also the only call allowed while a temporary PIN is in force. */
export function changePin(currentPin: string, newPin: string): Promise<{ must_change_pin: false }> {
  return apiFetch("/auth/change-pin", { method: "POST", body: JSON.stringify({ current_pin: currentPin, new_pin: newPin }) });
}

/** Public. Always the same answer, whether or not the ID exists. */
export function requestPinReset(chwId: string): Promise<{ message: string }> {
  return apiFetch("/pin-reset-requests", { method: "POST", body: JSON.stringify({ chw_id: chwId }) });
}

export type PinResetRequest = {
  id: string;
  chw_id: string;
  full_name: string;
  clinic: string;
  status: "pending" | "completed";
  requested_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
  reviewed_by_name: string | null;
};

/** Supervisor-only on the server. */
export function getPinResetRequests(status: "pending" | "completed" = "pending"): Promise<PinResetRequest[]> {
  return apiFetch(`/pin-reset-requests?status=${status}`);
}

/** Sets a temporary PIN; the CHW must choose a new one at next sign-in. */
export function completePinReset(id: string, newPin: string): Promise<{ request_id: string; status: "completed"; chw_id: string }> {
  return apiFetch(`/pin-reset-requests/${encodeURIComponent(id)}/complete`, { method: "POST", body: JSON.stringify({ new_pin: newPin }) });
}

export function login(chwId: string, pin: string): Promise<LoginResponse> {
  return apiFetch<LoginResponse>("/auth/login", {
    method: "POST",
    body: JSON.stringify({ chw_id: chwId, pin }),
  });
}

// Best-effort: clears the httpOnly cookie server-side. Never blocks signing
// out locally if it fails (e.g. offline) - see services/authService.ts.
export function logout(): Promise<void> {
  return apiFetch<void>("/auth/logout", { method: "POST" });
}

// --- Patients ---

export function getPatients(params: { search?: string; village?: string; chw_id?: string } = {}): Promise<Patient[]> {
  return apiFetch<Patient[]>(`/patients${toQueryString(params)}`);
}

export function getPatient(id: string): Promise<Patient & { visits: Visit[] }> {
  return apiFetch(`/patients/${id}`);
}

export function createPatient(patient: Patient): Promise<Patient> {
  return apiFetch<Patient>("/patients", { method: "POST", body: JSON.stringify(patient) });
}

export function updatePatient(id: string, patient: Partial<Patient>): Promise<Patient> {
  return apiFetch<Patient>(`/patients/${id}`, { method: "PUT", body: JSON.stringify(patient) });
}

export function deletePatient(id: string): Promise<void> {
  return apiFetch<void>(`/patients/${id}`, { method: "DELETE" });
}

// --- Visits ---

export function getVisits(
  params: { visit_type?: string; chw_id?: string; patient_id?: string; date?: string } = {},
): Promise<Visit[]> {
  return apiFetch<Visit[]>(`/visits${toQueryString(params)}`);
}

export function getVisit(id: string): Promise<Visit & { patient: Patient; chw: Pick<Chw, "chw_id" | "full_name" | "clinic"> }> {
  return apiFetch(`/visits/${id}`);
}

export function createVisit(visit: Visit): Promise<Visit> {
  return apiFetch<Visit>("/visits", { method: "POST", body: JSON.stringify(visit) });
}

export function updateVisit(id: string, visit: Partial<Visit>): Promise<Visit> {
  return apiFetch<Visit>(`/visits/${id}`, { method: "PUT", body: JSON.stringify(visit) });
}

export function deleteVisit(id: string): Promise<void> {
  return apiFetch<void>(`/visits/${id}`, { method: "DELETE" });
}

// --- CHWs ---

export function getChws(): Promise<Chw[]> {
  return apiFetch<Chw[]>("/chws");
}

// Supervisor-only on the server (PATCH /api/chws/:chwId, requireRole
// SUPERVISOR). The server hashes the PIN, clears any sign-in lockout, never
// returns the PIN or its hash, and leaves the PIN out of the audit log.
export function resetChwPin(chwId: string, pin: string): Promise<Chw> {
  return apiFetch<Chw>(`/chws/${encodeURIComponent(chwId)}`, { method: "PATCH", body: JSON.stringify({ pin }) });
}

// --- Households (clinic-scoped on the server) ---

export type ServerHousehold = Omit<Household, "sync_status"> & { member_count: number };

export function getHouseholds(): Promise<ServerHousehold[]> {
  return apiFetch("/households");
}

// --- Possible duplicate patients (clinic-scoped on the server) ---

export type PossibleDuplicate = Pick<Patient, "id" | "patient_id" | "first_name" | "last_name" | "village" | "date_of_birth">;

export function getPossibleDuplicates(q: { first_name: string; last_name: string; village: string; date_of_birth: string }, signal?: AbortSignal): Promise<PossibleDuplicate[]> {
  return apiFetch(`/patients/possible-duplicates?${new URLSearchParams(q)}`, { signal });
}

// --- CHW account management (supervisor-only on the server) ---

export type ManagedChw = Chw & { visit_count: number; patients_registered: number; can_delete: boolean };

/** role SUPERVISOR = supervisor accounts (administrators only). */
export function getManagedChws(role: "CHW" | "SUPERVISOR" = "CHW"): Promise<ManagedChw[]> {
  return apiFetch(role === "SUPERVISOR" ? "/chws/manage?role=SUPERVISOR" : "/chws/manage");
}

export function createChw(input: { chw_id: string; full_name: string; clinic_id: string; phone_number?: string | null; pin: string; role?: "CHW" | "SUPERVISOR" }): Promise<Chw> {
  return apiFetch("/chws", { method: "POST", body: JSON.stringify(input) });
}

export function revokeChw(chwId: string): Promise<Chw> {
  return apiFetch(`/chws/${encodeURIComponent(chwId)}/revoke`, { method: "POST" });
}

export function reactivateChw(chwId: string): Promise<Chw> {
  return apiFetch(`/chws/${encodeURIComponent(chwId)}/reactivate`, { method: "POST" });
}

export function deleteChw(chwId: string): Promise<{ chw_id: string; deleted: true }> {
  return apiFetch(`/chws/${encodeURIComponent(chwId)}`, { method: "DELETE" });
}

// --- Account requests ---
// A request is NOT an account: only a supervisor's approval creates one.

export type AccountRequestInput = {
  chw_id: string;
  full_name: string;
  clinic_id: string;
  phone_number?: string | null;
  pin: string;
};

export type AccountRequest = {
  id: string;
  full_name: string;
  requested_chw_id: string;
  clinic_id: string;
  clinic: string;
  phone_number: string | null;
  status: "pending" | "approved" | "rejected";
  requested_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
  reviewed_by_name: string | null;
};

/** Public: clinic ids + names for the request form. */
export function getRequestableClinics(): Promise<{ id: string; name: string }[]> {
  return apiFetch("/account-requests/clinics");
}

/** Public: creates a pending request; it can't be used to sign in until approved. */
export function requestAccount(input: AccountRequestInput): Promise<{ id: string; chw_id: string; full_name: string; clinic: string; status: "pending" }> {
  return apiFetch("/account-requests", { method: "POST", body: JSON.stringify(input) });
}

/** Supervisor-only on the server. */
export function getAccountRequests(status: "pending" | "reviewed" = "pending"): Promise<AccountRequest[]> {
  return apiFetch(`/account-requests?status=${status}`);
}

/** Creates the CHW account from the request. clinic_id optionally changes the requested clinic. */
export function approveAccountRequest(id: string, clinicId?: string): Promise<{ request_id: string; status: "approved"; chw: Pick<Chw, "chw_id" | "full_name" | "clinic"> }> {
  return apiFetch(`/account-requests/${encodeURIComponent(id)}/approve`, { method: "POST", body: JSON.stringify(clinicId ? { clinic_id: clinicId } : {}) });
}

export function rejectAccountRequest(id: string, reason?: string): Promise<{ request_id: string; status: "rejected" }> {
  return apiFetch(`/account-requests/${encodeURIComponent(id)}/reject`, { method: "POST", body: JSON.stringify(reason ? { reason } : {}) });
}

// --- Sync ---

export type SyncRecordResult = {
  id: string;
  status: "synced" | "conflict" | "failed";
  message?: string;
  /** Patients/visits: review state on the server after this sync. */
  review_status?: ReviewStatus;
};
export type SyncBatchResponse = { households?: SyncRecordResult[]; patients: SyncRecordResult[]; visits: SyncRecordResult[] };

export function postSync(payload: { households?: Household[]; patients: Patient[]; visits: Visit[] }): Promise<SyncBatchResponse> {
  return apiFetch<SyncBatchResponse>("/sync", { method: "POST", body: JSON.stringify(payload) });
}

export type SyncLogEntry = {
  id: number;
  record_type: string;
  record_id: string;
  action: string;
  synced_at: string;
  status: string;
};

export function getSyncLog(limit = 100): Promise<SyncLogEntry[]> {
  return apiFetch<SyncLogEntry[]>(`/sync/log?limit=${limit}`);
}

// --- Conflicts ---

export type SyncConflict = {
  id: number;
  record_type: "patient" | "visit";
  record_id: string;
  incoming_version: Record<string, unknown>;
  server_version: Record<string, unknown>;
  incoming_timestamp: string;
  server_timestamp: string;
  detected_by: string | null;
  detected_at: string;
  status: "open" | "resolved";
  resolution: "KEEP_SERVER" | "APPLY_INCOMING" | null;
  resolved_by: string | null;
  resolved_at: string | null;
};

export function getConflicts(status: "open" | "resolved" = "open"): Promise<SyncConflict[]> {
  return apiFetch<SyncConflict[]>(`/conflicts?status=${status}&limit=100`);
}

export function resolveConflict(id: number, resolution: "KEEP_SERVER" | "APPLY_INCOMING"): Promise<SyncConflict> {
  return apiFetch<SyncConflict>(`/conflicts/${id}/resolve`, {
    method: "POST",
    body: JSON.stringify({ resolution }),
  });
}

// --- Dashboard ---

export type DashboardStats = {
  chws: number;
  activeChws: number;
  patients: number;
  visits: number;
  coveragePercent: number;
  trend: { date: string; visits: number }[];
  openConflicts: number;
  syncSuccessRate: number | null;
  patientsByClinic: { clinic_id: string; clinic_name: string; patients: number }[];
  // patients/visits above count CONFIRMED records only; these are separate.
  awaitingReview: { patients: number; visits: number };
  flagged: { patients: number; visits: number };
};

// --- Review queue (supervisor-only on the server) ---

export type ReviewPatient = {
  id: string;
  patient_id: string;
  first_name: string;
  last_name: string;
  date_of_birth: string;
  gender: "M" | "F";
  village: string;
  phone_number?: string | null;
};
export type ReviewVisit = {
  id: string;
  patient_id: string;
  chw_id: string;
  visit_date: string;
  visit_type: string;
  weight: number | null;
  height: number | null;
  blood_pressure: string | null;
  notes: string | null;
};
export type ReviewItem = {
  record_type: "patient" | "visit";
  id: string;
  submitted_by: string | null;
  submitted_at: string;
  submission: "new" | "edit";
  previous_review: { flag_reason: string | null; reviewed_at: string | null } | null;
  patient: ReviewPatient | null;
  visit?: ReviewVisit;
};
export type ReviewBatch = { key: string; via: "sync" | "online"; device_batch_id: string | null; sent_at: string; items: ReviewItem[] };
export type ReviewPending = {
  total: number;
  counts: { patients: number; visits: number };
  groups: { chw: { chw_id: string | null; full_name: string | null }; batches: ReviewBatch[] }[];
};
export type FlaggedItem = {
  record_type: "patient" | "visit";
  id: string;
  flag_reason: string | null;
  flagged_at: string | null;
  flagged_by: string | null;
  flagged_by_name: string | null;
  chw_id: string | null;
  chw_name: string | null;
  patient: ReviewPatient | null;
  visit?: ReviewVisit;
};

export function getReviewPending(): Promise<ReviewPending> {
  return apiFetch<ReviewPending>("/review/pending");
}

export function getReviewFlagged(): Promise<{ total: number; items: FlaggedItem[] }> {
  return apiFetch("/review/flagged");
}

export function confirmRecord(recordType: "patient" | "visit", id: string): Promise<unknown> {
  return apiFetch(`/review/${recordType}s/${encodeURIComponent(id)}/confirm`, { method: "POST", body: JSON.stringify({}) });
}

export function flagRecord(recordType: "patient" | "visit", id: string, reason: string): Promise<unknown> {
  return apiFetch(`/review/${recordType}s/${encodeURIComponent(id)}/flag`, { method: "POST", body: JSON.stringify({ reason }) });
}

// --- Follow-ups due (supervisor widget; CHWs compute this on the device) ---

export type DueFollowUps = {
  today: string;
  total: number;
  overdue: number;
  by_type: Record<string, number>;
  items: {
    patient_id: string;
    visit_type: string;
    last_visit: string;
    due_date: string;
    days_overdue: number;
    patient: { id: string; patient_id: string; first_name: string; last_name: string; village: string } | null;
  }[];
};

export function getDueFollowUps(today: string): Promise<DueFollowUps> {
  return apiFetch<DueFollowUps>(`/patients/due?today=${encodeURIComponent(today)}`);
}

// --- Activity log (supervisor: own clinic; administrator: all) ---

export type ActivityLogEntry = {
  id: number;
  action: string;
  actor_id: string | null;
  actor_role: string | null;
  actor_name: string | null;
  resource_type: string | null;
  resource_id: string | null;
  clinic_id: string | null;
  clinic_name: string | null;
  created_at: string;
  metadata: Record<string, unknown> | null;
};

export type ActivityLogQuery = { page: number; limit: number; action?: string; actor_id?: string; from?: string; to?: string };

export function getActivityLog(q: ActivityLogQuery): Promise<{ data: ActivityLogEntry[]; pagination: PageInfo }> {
  return apiFetchPage<ActivityLogEntry[]>(
    `/audit-logs${toQueryString({ page: String(q.page), limit: String(q.limit), action: q.action, actor_id: q.actor_id, from: q.from, to: q.to })}`,
  );
}

export function getDashboardStats(): Promise<DashboardStats> {
  return apiFetch<DashboardStats>("/dashboard/stats");
}

// --- Health ---

export function getHealth(): Promise<{ message: string; timestamp: string }> {
  return apiFetch("/health");
}
