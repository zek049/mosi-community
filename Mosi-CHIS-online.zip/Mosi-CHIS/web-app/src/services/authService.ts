import * as api from "./api";
import { isSupervisorRole } from "../models/chw";
import {
  db,
  switchDatabaseTo,
  migrateLegacyDatabase,
  clearSyncedDataForSignOut,
  wipeCurrentUserData,
} from "../db/indexedDb";
import { queryClient } from "../lib/queryClient";
import { refreshHouseholdCache, refreshPatientCache, refreshVisitCache } from "./cacheRefresh";
import { getStoredSession, setStoredSession, clearStoredSession, type StoredSession } from "../utils/session";

// Login always requires a network round-trip - the server verifies the PIN
// (its hash never leaves the server, see backend/src/routes/auth.ts), so
// there is nothing to check locally. The server sets the actual session as
// an httpOnly cookie (see api.ts's apiFetch, credentials:"include") - this
// module never sees or stores the real token, only the non-sensitive
// {chw_id, full_name, clinic, role} the UI needs to render offline (see
// getSession below): an already-authenticated CHW can reopen the app fully
// offline and keep working, per section 13, without needing to read a
// cookie JavaScript has no access to anyway.
export async function login(chwId: string, pin: string): Promise<StoredSession["chw"]> {
  const { chw: response } = await api.login(chwId, pin);
  const { must_change_pin: mustChangePin, ...chw } = response;
  setStoredSession({ chw, ...(mustChangePin ? { mustChangePin: true } : {}) });
  // Open THIS user's local database before anything reads or writes data
  // (see db/indexedDb.ts - one database per account on a shared device).
  switchDatabaseTo(chw.chw_id);
  await migrateLegacyDatabase(chw.chw_id, chw.role);
  notifySessionChanged();

  // A temporary PIN must be changed first; the server refuses everything
  // else until then, so don't fire requests that are bound to be refused.
  if (mustChangePin) return chw;

  // Best-effort refresh of the local read caches right after login, so
  // list/detail screens have real data on first visit. Must never block or
  // fail the login itself.
  try {
    await Promise.all([
      api.getChws().then((chws) => db.chws.bulkPut(chws)),
      refreshHouseholdCache(),
      refreshPatientCache(),
      refreshVisitCache(),
    ]);
  } catch {
    // Nothing to do - the cache just stays whatever it was before.
  }

  return chw;
}

export type SignOutMode =
  /** Remove synced copies; keep anything unsynced for this user's next sign-in. */
  | "keep-unsynced"
  /** Remove everything this user has on the device, unsynced changes included. */
  | "wipe";

export type SignOutResult = { keptUnsynced: number };

// Local state is cleared without waiting on the network, so signing out
// works offline too; the httpOnly cookie is cleared best-effort in the
// background (if that fails offline, the cookie simply expires - 12h).
//
// Unsynced records are never deleted here unless the caller passes "wipe",
// which the UI only does after an explicit, informed confirmation.
export async function signOut(mode: SignOutMode = "keep-unsynced"): Promise<SignOutResult> {
  const chwId = getStoredSession()?.chw.chw_id;
  let keptUnsynced = 0;
  try {
    if (mode === "wipe") await wipeCurrentUserData();
    else keptUnsynced = await clearSyncedDataForSignOut();
  } catch {
    // If IndexedDB is unavailable the data can't have been stored either;
    // never let cleanup failure trap someone in a signed-in session.
  }
  try {
    if (chwId) localStorage.removeItem(`mosi.lastSyncAt.${chwId}`);
  } catch {
    // Non-fatal.
  }
  try {
    // Read (then removed) by the Login screen, whichever route gets there
    // first - see readSignOutNotice().
    sessionStorage.setItem(SIGNED_OUT_KEY, JSON.stringify({ keptUnsynced }));
  } catch {
    // Non-fatal: only the confirmation message is lost.
  }
  clearStoredSession();
  switchDatabaseTo(null);
  // Server responses held in memory (dashboard stats, CHW lists, conflicts)
  // belong to this session too.
  queryClient.clear();
  notifySessionChanged();
  void api.logout().catch(() => {});
  return { keptUnsynced };
}

/** Where a signed-in session should land: the forced PIN change comes first. */
export function entryRoute(session: StoredSession): string {
  if (session.mustChangePin) return "/change-pin";
  return isSupervisorRole(session.chw.role) ? "/supervisor" : "/chw";
}

/** The server said a temporary PIN is in force (e.g. reset while signed in). */
export function markMustChangePin(value: boolean): void {
  const session = getStoredSession();
  if (!session) return;
  const { mustChangePin: _old, ...rest } = session;
  setStoredSession(value ? { ...rest, mustChangePin: true } : rest);
  notifySessionChanged();
}

export function getSession(): StoredSession | null {
  return getStoredSession();
}

export function isAuthenticated(): boolean {
  return getStoredSession() !== null;
}

// --- "You've signed out" confirmation for the Login screen ---

const SIGNED_OUT_KEY = "mosi.signedOutNotice";

export function readSignOutNotice(): SignOutResult | null {
  try {
    const raw = sessionStorage.getItem(SIGNED_OUT_KEY);
    return raw ? (JSON.parse(raw) as SignOutResult) : null;
  } catch {
    return null;
  }
}

export function dismissSignOutNotice(): void {
  try {
    sessionStorage.removeItem(SIGNED_OUT_KEY);
  } catch {
    // Nothing to do.
  }
}

// --- Session-change signal (for long-lived providers such as SyncContext) ---

const SESSION_EVENT = "mosi:session-changed";

function notifySessionChanged(): void {
  window.dispatchEvent(new Event(SESSION_EVENT));
}

export function subscribeToSession(callback: () => void): () => void {
  window.addEventListener(SESSION_EVENT, callback);
  // Another tab signing in/out changes localStorage too.
  window.addEventListener("storage", callback);
  return () => {
    window.removeEventListener(SESSION_EVENT, callback);
    window.removeEventListener("storage", callback);
  };
}

export function currentChwId(): string | null {
  return getStoredSession()?.chw.chw_id ?? null;
}
