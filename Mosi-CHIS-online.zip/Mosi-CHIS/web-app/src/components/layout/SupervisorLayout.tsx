import { useEffect } from "react";
import { Outlet } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { LayoutDashboard, Users, Stethoscope, UserCheck, RefreshCw, GitPullRequestArrow, KeyRound, UserPlus, UsersRound, ShieldCheck, History } from "lucide-react";
import * as authService from "../../services/authService";
import * as api from "../../services/api";
import { useNetwork } from "../../contexts/NetworkContext";
import { refreshHouseholdCache, refreshPatientCache, refreshVisitCache } from "../../services/cacheRefresh";
import { AppShell } from "./AppShell";
import { connectivityLabel } from "../../services/connectivity";
import type { NavItem } from "./Sidebar";

const CORE_ITEMS: NavItem[] = [
  { to: "/supervisor", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/patients", label: "Patients", icon: Users },
  { to: "/visits", label: "Visits", icon: Stethoscope },
  { to: "/sync", label: "Sync", icon: RefreshCw },
];

function SupervisorLayout() {
  const session = authService.getSession();
  const { isOnline, status: connectivity, setWorkOffline } = useNetwork();

  // Same query key/fn as the Conflicts screen, so both share one cache: a
  // resolution there updates this badge immediately. Refetched periodically
  // so a conflict raised by a CHW's sync shows up without a reload.
  const conflictsQuery = useQuery({
    queryKey: ["conflicts"],
    queryFn: () => api.getConflicts("open"),
    enabled: isOnline,
    refetchInterval: 60_000,
  });
  const openConflicts = conflictsQuery.data?.length ?? 0;

  // Same query key as the Account requests screen, so approving there
  // updates this badge immediately.
  const requestsQuery = useQuery({
    queryKey: ["accountRequests", "pending"],
    queryFn: () => api.getAccountRequests("pending"),
    enabled: isOnline,
    refetchInterval: 60_000,
  });
  const pendingRequests = requestsQuery.data?.length ?? 0;
  const pinRequestsQuery = useQuery({
    queryKey: ["pinResetRequests", "pending"],
    queryFn: () => api.getPinResetRequests("pending"),
    enabled: isOnline,
    refetchInterval: 60_000,
  });
  const pendingPinRequests = pinRequestsQuery.data?.length ?? 0;

  const isAdmin = session?.chw.role === "ADMIN";
  const secondaryItems: NavItem[] = [
    { to: "/supervisor/chw-activity", label: "CHW Activity", icon: UserCheck },
    { to: "/supervisor/chws", label: "Manage CHWs", icon: UsersRound },
    { to: "/supervisor/conflicts", label: "Conflicts", icon: GitPullRequestArrow, badge: openConflicts },
    { to: "/supervisor/account-requests", label: "Account requests", icon: UserPlus, badge: pendingRequests },
    { to: "/supervisor/pin-reset", label: "Reset a PIN", icon: KeyRound, badge: pendingPinRequests },
    { to: "/supervisor/activity", label: "Activity log", icon: History },
    // Supervisor accounts are an administrator's job (server enforces it too).
    ...(isAdmin ? [{ to: "/supervisor/supervisors", label: "Manage supervisors", icon: ShieldCheck }] : []),
  ];

  useEffect(() => {
    if (isOnline) {
      void refreshHouseholdCache();
      void refreshPatientCache();
      void refreshVisitCache();
    }
  }, [isOnline]);

  return (
    <AppShell
      navItems={[...CORE_ITEMS, ...secondaryItems]}
      mobileNavItems={CORE_ITEMS}
      mobileMoreItems={secondaryItems}
      userName={session?.chw.full_name ?? ""}
      userSubtitle={isAdmin ? "Administrator · all clinics" : `Supervisor · ${session?.chw.clinic ?? ""}`}
    >
      {/* Supervisor screens read live server data; while Mosi isn't online
          those requests wait (they resume automatically), so say why. */}
      {!isOnline && connectivity !== "checking" && (
        <div role="status" className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-stone-300 bg-stone-50 px-4 py-3">
          <p className="text-sm text-stone-800">
            <span className="font-semibold">{connectivityLabel(connectivity)}.</span> Server data on these screens loads once Mosi can
            reach the server.
          </p>
          {connectivity === "work-offline" && (
            <button type="button" onClick={() => setWorkOffline(false)} className="min-h-11 px-2 text-sm font-medium text-forest-800 underline underline-offset-2">
              Turn off Work Offline
            </button>
          )}
        </div>
      )}
      <Outlet />
    </AppShell>
  );
}

export default SupervisorLayout;
