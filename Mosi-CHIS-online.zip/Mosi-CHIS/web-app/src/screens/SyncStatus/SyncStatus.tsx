import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import * as TabsPrimitive from "@radix-ui/react-tabs";
import { useLiveQuery } from "dexie-react-hooks";
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  CloudOff,
  Flag,
  GitPullRequestArrow,
  Hourglass,
  PauseCircle,
  RefreshCw,
  UploadCloud,
  type LucideIcon,
} from "lucide-react";
import { db } from "../../db/indexedDb";
import * as authService from "../../services/authService";
import * as api from "../../services/api";
import { useNetwork } from "../../contexts/NetworkContext";
import { useSync } from "../../contexts/SyncContext";
import { usePageTitle } from "../../hooks/usePageTitle";
import { timeAgo } from "../../utils/timeAgo";
import { Button } from "../../components/ui/Button";
import { Card } from "../../components/ui/Card";
import { PageHeader } from "../../components/ui/PageHeader";
import { cn } from "../../lib/utils";
import { connectivityLabel, syncLaterHint } from "../../services/connectivity";
import { ClearDeviceSection } from "../../components/ClearDeviceSection";
import { LoadErrorNotice } from "../../components/LoadErrorNotice";
import { useSyncLog } from "../../hooks/useSyncLog";
import { syncingLabel, syncPausedMessage } from "../../utils/syncMessages";
import { classifySyncBuckets, type BucketRow, type SyncBuckets } from "../../utils/syncBuckets";

function plural(n: number, one: string, many: string) {
  return `${n} ${n === 1 ? one : many}`;
}

// Re-render every 30s so "2 minutes ago" stays true while the page is open.
function useNow(intervalMs = 30_000) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), intervalMs);
    return () => window.clearInterval(timer);
  }, [intervalMs]);
  return now;
}

const MAX_ROWS_SHOWN = 20;

const ROW_STATUS: Record<keyof SyncBuckets, { label: string; icon: LucideIcon; className: string }> = {
  waiting: { label: "Waiting", icon: Clock, className: "bg-amber-50 text-amber-800 border-amber-200" },
  failed: { label: "Couldn't sync", icon: AlertCircle, className: "bg-red-50 text-red-700 border-red-200" },
  conflict: { label: "Conflict", icon: GitPullRequestArrow, className: "bg-amber-50 text-amber-800 border-amber-200" },
  awaiting: { label: "Awaiting review", icon: Hourglass, className: "bg-sky-50 text-sky-800 border-sky-200" },
  confirmed: { label: "Confirmed", icon: CheckCircle2, className: "bg-emerald-50 text-emerald-800 border-emerald-200" },
  flagged: { label: "Flagged", icon: Flag, className: "bg-red-50 text-red-700 border-red-200" },
  synced: { label: "Synced", icon: CheckCircle2, className: "bg-stone-50 text-stone-700 border-stone-200" },
};

const BUCKET_NOTES: Partial<Record<keyof SyncBuckets, string>> = {
  failed: "The server didn't accept these yet. They're safe on this device and Mosi tries again on every sync.",
  conflict:
    "These were also changed somewhere else at the same time. Your supervisor will decide which version to keep - there's nothing more you need to do.",
  awaiting: "The server has these. Your supervisor hasn't checked them yet, so they aren't confirmed.",
  confirmed: "Checked and confirmed by your supervisor.",
  flagged: "Your supervisor found a problem with these. The reason is shown under each one - check with your supervisor.",
  synced: "The server has these. Their review status will show the next time this device is online.",
};

function RecordList({ rows, kind, emptyText, now }: { rows: BucketRow[]; kind: keyof typeof ROW_STATUS; emptyText: string; now: number }) {
  if (rows.length === 0) return <p className="py-8 text-center text-sm text-stone-500">{emptyText}</p>;

  const sorted = rows.slice().sort((a, b) => (a.timestamp < b.timestamp ? 1 : -1));
  const visible = sorted.slice(0, MAX_ROWS_SHOWN);
  const status = ROW_STATUS[kind];
  const StatusIcon = status.icon;

  return (
    <>
      {BUCKET_NOTES[kind] && <p className="mb-3 text-sm text-stone-600">{BUCKET_NOTES[kind]}</p>}
      <ul className="divide-y divide-stone-100">
        {visible.map((row) => (
          <li key={row.id} className="flex items-center justify-between gap-3 py-3">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium text-stone-900">{row.title}</p>
              <p className="truncate text-xs text-stone-500">
                {row.subtitle} · changed {timeAgo(row.timestamp, now)}
              </p>
              {row.flagReason && <p className="mt-0.5 text-xs text-red-700">Reason: {row.flagReason}</p>}
            </div>
            <span
              className={cn(
                "inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium",
                status.className,
              )}
            >
              <StatusIcon className="h-3.5 w-3.5" aria-hidden="true" />
              {status.label}
            </span>
          </li>
        ))}
      </ul>
      {sorted.length > visible.length && (
        <p className="pt-3 text-xs text-stone-500">
          Showing the {visible.length} most recent of {sorted.length}.
        </p>
      )}
    </>
  );
}

// The one card that answers "is my work safe and on the server?" in plain
// words, with the single action that makes sense right now.
function SyncStateCard({ now }: { now: number }) {
  const { isOnline, status: connectivity, setWorkOffline, recheck } = useNetwork();
  const { phase, syncingCount, lastSyncAt, lastError, lastResultMessage, pendingCount, failedCount, flaggedCount, countsReady, syncNow } =
    useSync();

  let Icon: LucideIcon = CheckCircle2;
  let title = "Everything is up to date";
  let detail = "All your patients and visits are on the server.";
  let tone = "border-emerald-200 bg-emerald-50";
  let iconTone = "bg-emerald-100 text-emerald-800";
  let action: { label: string; run?: () => void } | null = { label: "Sync now" };

  if (!isOnline) {
    Icon = CloudOff;
    title =
      connectivity === "work-offline"
        ? "Working offline"
        : connectivity === "server-unreachable"
          ? "Can't reach the Mosi server"
          : connectivity === "checking"
            ? "Checking connection…"
            : "You're offline";
    detail =
      pendingCount > 0
        ? `${plural(pendingCount, "change is", "changes are")} saved on this device. ${syncLaterHint(connectivity).replace("It will", pendingCount === 1 ? "It will" : "They will")}`
        : connectivity === "work-offline"
          ? "Nothing is sent to the server while Work Offline is on. New records are saved on this device."
          : "You can keep working. New records are saved on this device.";
    tone = "border-stone-300 bg-stone-50";
    iconTone = "bg-stone-200 text-stone-700";
    action =
      connectivity === "work-offline"
        ? { label: "Turn off Work Offline", run: () => setWorkOffline(false) }
        : connectivity === "server-unreachable"
          ? { label: "Check again", run: () => void recheck() }
          : null;
  } else if (phase === "syncing") {
    Icon = RefreshCw;
    title = syncingLabel(syncingCount);
    // One batch, one answer: the count sent is known, per-record progress
    // is not (see utils/syncMessages.ts), so none is shown.
    detail = "Sent as one batch. You can keep working while the server checks them.";
    tone = "border-sage-100 bg-sage-50";
    iconTone = "bg-sage-100 text-forest-800";
    action = null;
  } else if (phase === "paused") {
    Icon = PauseCircle;
    title = "Sync paused";
    // Either the batch got no answer (lastError), or it did and some
    // records were rejected (lastResultMessage has the real counts).
    detail = lastError
      ? `${lastError} ${syncPausedMessage(pendingCount).replace("Sync paused. ", "")} They're safe on this device.`
      : `${lastResultMessage ?? ""} They're safe on this device.`;
    tone = "border-amber-200 bg-amber-50";
    iconTone = "bg-amber-100 text-amber-800";
    action = { label: "Retry sync" };
  } else if (pendingCount > 0) {
    Icon = UploadCloud;
    title = `${plural(pendingCount, "change", "changes")} waiting to sync`;
    detail = "Saved on this device. Sync now to send them to the server.";
    tone = "border-amber-200 bg-amber-50";
    iconTone = "bg-amber-100 text-amber-800";
  }

  return (
    <section aria-labelledby="sync-state-title" className={cn("rounded-2xl border p-5 sm:p-6", tone)}>
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-4">
          <span className={cn("flex h-12 w-12 shrink-0 items-center justify-center rounded-full", iconTone)}>
            <Icon className={cn("h-6 w-6", phase === "syncing" && isOnline && "animate-spin motion-reduce:animate-none")} aria-hidden="true" />
          </span>
          <div>
            <h2 id="sync-state-title" className="text-lg font-semibold text-stone-900">
              {countsReady ? title : "Checking this device…"}
            </h2>
            {countsReady && <p className="mt-0.5 text-sm text-stone-700">{detail}</p>}
            <p className="mt-2 text-xs text-stone-600">
              {lastSyncAt
                ? `Last synced ${timeAgo(lastSyncAt, now)}`
                : pendingCount > 0
                  ? "Not synced from this device yet"
                  : "Nothing from this device has needed syncing yet"}
            </p>
            {lastResultMessage && phase === "idle" && isOnline && (
              <p className="mt-1 text-xs text-stone-600">Last sync: {lastResultMessage}</p>
            )}
          </div>
        </div>
        {action && countsReady && (
          <Button size="lg" onClick={() => (action.run ? action.run() : void syncNow({ manual: true }))} className="shrink-0">
            <RefreshCw className="h-4 w-4" aria-hidden="true" />
            {action.label}
          </Button>
        )}
      </div>

      {countsReady && (
        <dl className="mt-5 grid grid-cols-3 gap-2 border-t border-black/5 pt-4 text-center">
          {[
            { label: "Waiting", value: pendingCount },
            { label: "Couldn't sync", value: failedCount },
            { label: "Conflicts", value: flaggedCount },
          ].map((item) => (
            <div key={item.label}>
              <dt className="text-xs text-stone-600">{item.label}</dt>
              <dd className="text-xl font-semibold text-stone-900">{item.value}</dd>
            </div>
          ))}
        </dl>
      )}
    </section>
  );
}

const TAB_TRIGGER_CLASS =
  "min-h-11 rounded-lg px-3 py-2 text-sm font-medium transition-colors data-[state=active]:bg-forest-800 data-[state=active]:text-white text-stone-600 hover:text-stone-900";

const TABS: { value: keyof SyncBuckets; label: string; empty: string }[] = [
  { value: "waiting", label: "Waiting", empty: "Nothing waiting - the server has everything." },
  { value: "failed", label: "Couldn't sync", empty: "Nothing failed to sync." },
  { value: "conflict", label: "Conflict", empty: "No conflicts." },
  { value: "awaiting", label: "Awaiting review", empty: "Nothing is waiting for your supervisor." },
  { value: "confirmed", label: "Confirmed", empty: "None of your records are confirmed yet." },
  { value: "flagged", label: "Flagged", empty: "Nothing flagged." },
  { value: "synced", label: "Synced", empty: "" },
];

function ChwSyncStatus() {
  const now = useNow();
  const chwId = authService.getSession()?.chw.chw_id ?? "";
  const patients = useLiveQuery(() => db.patients.toArray(), []);
  const visits = useLiveQuery(() => db.visits.toArray(), []);
  const attempts = useLiveQuery(() => db.syncAttempts.toArray(), []);
  const sections = patients && visits && attempts ? classifySyncBuckets(chwId, patients, visits, attempts) : null;
  // "Synced" (review state unknown) only appears while it has something in it.
  const tabs = sections ? TABS.filter((t) => t.value !== "synced" || sections.synced.length > 0) : [];

  return (
    <div className="space-y-6">
      <PageHeader title="Sync" description="What's saved on this device, what the server has, and what your supervisor has checked." />
      <SyncStateCard now={now} />

      {sections && (
        <TabsPrimitive.Root defaultValue={sections.failed.length > 0 ? "failed" : sections.flagged.length > 0 ? "flagged" : "waiting"}>
          <TabsPrimitive.List aria-label="Your records" className="grid grid-cols-2 gap-1 rounded-xl border border-stone-200 bg-white p-1 sm:grid-cols-3 lg:grid-cols-6">
            {tabs.map((t) => (
              <TabsPrimitive.Trigger key={t.value} value={t.value} className={TAB_TRIGGER_CLASS}>
                {t.label} ({sections[t.value].length})
              </TabsPrimitive.Trigger>
            ))}
          </TabsPrimitive.List>
          <Card className="mt-3">
            {tabs.map((t) => (
              <TabsPrimitive.Content key={t.value} value={t.value}>
                <RecordList rows={sections[t.value]} kind={t.value} emptyText={t.empty} now={now} />
              </TabsPrimitive.Content>
            ))}
          </Card>
        </TabsPrimitive.Root>
      )}

      <ClearDeviceSection />
    </div>
  );
}

const ACTION_LABELS: Record<string, string> = { create: "Added", update: "Updated", delete: "Removed" };

// Supervisors don't keep a local queue - their view is the health of
// syncing across their clinic, from the server's own records.
function SupervisorSyncStatus() {
  const now = useNow();
  const { isOnline, status: supervisorConnectivity } = useNetwork();
  const statsQuery = useQuery({ queryKey: ["dashboardStats"], queryFn: api.getDashboardStats, enabled: isOnline });
  const logQuery = useSyncLog({ enabled: isOnline });
  const stats = statsQuery.data;
  const entries = logQuery.data?.slice(0, 50);

  return (
    <div className="space-y-6">
      <PageHeader title="Sync" description="How CHW devices in your clinic are syncing." />

      {!isOnline && (
        <Card className="flex items-start gap-3">
          <CloudOff className="mt-0.5 h-5 w-5 shrink-0 text-stone-600" aria-hidden="true" />
          <p className="text-sm text-stone-700">
            {connectivityLabel(supervisorConnectivity)}. Sync health comes from the server - it shows here once Mosi can reach it.
          </p>
        </Card>
      )}

      {isOnline && (
        <div className="grid gap-4 sm:grid-cols-2">
          <Card>
            <h2 className="text-sm font-medium text-stone-600">Sync success</h2>
            <p className="mt-1 text-2xl font-semibold text-stone-900">
              {stats ? (stats.syncSuccessRate === null ? "No syncs yet" : `${stats.syncSuccessRate}%`) : "…"}
            </p>
            <p className="mt-1 text-xs text-stone-500">Share of synced records the server accepted without a problem.</p>
          </Card>
          <Card>
            <h2 className="text-sm font-medium text-stone-600">Conflicts to review</h2>
            {stats && stats.openConflicts === 0 ? (
              <p className="mt-1 flex items-center gap-2 text-base font-semibold text-emerald-800">
                <CheckCircle2 className="h-5 w-5" aria-hidden="true" />
                All clear
              </p>
            ) : (
              <p className="mt-1 text-2xl font-semibold text-stone-900">{stats ? stats.openConflicts : "…"}</p>
            )}
            {stats && stats.openConflicts > 0 && (
              <Link to="/supervisor/conflicts" className="mt-1 inline-block text-sm font-medium text-forest-800 underline underline-offset-2">
                Review conflicts
              </Link>
            )}
          </Card>
        </div>
      )}

      {isOnline && (
        <Card>
          <h2 className="text-sm font-semibold text-stone-900">Recent sync activity</h2>
          {logQuery.isError && (
            <div className="mt-2">
              <LoadErrorNotice error={logQuery.error} what="sync activity" onRetry={() => void logQuery.refetch()} />
            </div>
          )}
          {entries === undefined && !logQuery.isError && <p className="mt-2 text-sm text-stone-500">Loading…</p>}
          {entries && entries.length === 0 && <p className="mt-2 text-sm text-stone-500">No sync activity yet.</p>}
          {entries && entries.length > 0 && (
            <ul className="mt-2 divide-y divide-stone-100">
              {entries.map((entry) => {
                const kind = entry.status === "success" ? "synced" : entry.status === "conflict" ? "conflict" : "failed";
                const status = ROW_STATUS[kind];
                const StatusIcon = status.icon;
                return (
                  <li key={entry.id} className="flex items-center justify-between gap-3 py-2.5">
                    <div className="min-w-0">
                      <p className="text-sm text-stone-900">
                        {entry.record_type === "visit" ? "Visit" : "Patient"} {(ACTION_LABELS[entry.action] ?? "changed").toLowerCase()}
                      </p>
                      <p className="text-xs text-stone-500">{timeAgo(entry.synced_at, now)}</p>
                    </div>
                    <span className={cn("inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium", status.className)}>
                      <StatusIcon className="h-3.5 w-3.5" aria-hidden="true" />
                      {status.label}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      )}

      <ClearDeviceSection />
    </div>
  );
}

function SyncStatus() {
  usePageTitle("Sync");
  const isChw = authService.getSession()?.chw.role === "CHW";
  return isChw ? <ChwSyncStatus /> : <SupervisorSyncStatus />;
}

export default SyncStatus;
