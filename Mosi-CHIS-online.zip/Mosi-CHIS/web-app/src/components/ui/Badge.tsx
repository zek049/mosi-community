import type { HTMLAttributes } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../lib/utils";

// Generic status pill - SyncStatusBadge and VisitTypeBadge (and Sync
// Status's audit log rows) all build on this so every colored pill in the
// app shares one visual language instead of each screen inventing its own.
// Color communicates state, per the design system rule - never decoration.
const badgeVariants = cva("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium", {
  variants: {
    variant: {
      success: "bg-emerald-50 text-emerald-800 border border-emerald-100",
      warning: "bg-amber-50 text-amber-800 border border-amber-100",
      error: "bg-red-50 text-red-700 border border-red-100",
      info: "bg-sage-50 text-forest-800 border border-sage-100",
      neutral: "bg-stone-100 text-stone-600 border border-stone-200",
    },
    dot: {
      true: "",
      false: "",
    },
  },
  defaultVariants: { variant: "neutral", dot: false },
});

const DOT_COLOR: Record<string, string> = {
  success: "bg-emerald-500",
  warning: "bg-amber-500",
  error: "bg-red-500",
  info: "bg-forest-600",
  neutral: "bg-stone-400",
};

type BadgeProps = HTMLAttributes<HTMLSpanElement> & VariantProps<typeof badgeVariants>;

export function Badge({ variant = "neutral", dot = false, className, children, ...props }: BadgeProps) {
  return (
    <span className={cn(badgeVariants({ variant }), className)} {...props}>
      {dot && <span className={cn("h-1.5 w-1.5 rounded-full", DOT_COLOR[variant ?? "neutral"])} aria-hidden="true" />}
      {children}
    </span>
  );
}
