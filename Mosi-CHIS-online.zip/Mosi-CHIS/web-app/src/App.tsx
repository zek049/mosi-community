import { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "./screens/Landing/Landing";
import Login from "./screens/Login/Login";
import ChwLayout from "./components/layout/ChwLayout";
import SupervisorLayout from "./components/layout/SupervisorLayout";
import SharedLayout from "./components/layout/SharedLayout";
import ProtectedRoute from "./components/layout/ProtectedRoute";
import InstallPrompt from "./components/InstallPrompt";
import { ScreenSkeleton } from "./components/ui/ScreenSkeleton";

// Landing and Login stay in the main bundle (they're the entry points);
// every authenticated screen is split into its own chunk so the public page
// doesn't pay for Recharts, Radix Tabs, etc. public/sw.js precaches every
// chunk from Vite's build manifest, so lazy loading doesn't break offline
// navigation to a screen the CHW hasn't opened yet.
const CHWHome = lazy(() => import("./screens/CHWHome/CHWHome"));
const NotFound = lazy(() => import("./screens/NotFound/NotFound"));
const PinReset = lazy(() => import("./screens/PinReset/PinReset"));
const RequestAccount = lazy(() => import("./screens/RequestAccount/RequestAccount"));
const AccountRequests = lazy(() => import("./screens/AccountRequests/AccountRequests"));
const ManageChws = lazy(() => import("./screens/ManageChws/ManageChws"));
const ActivityLog = lazy(() => import("./screens/ActivityLog/ActivityLog"));
const ManageSupervisors = lazy(() => import("./screens/ManageChws/ManageChws").then((m) => ({ default: m.ManageSupervisors })));
const ForgotPin = lazy(() => import("./screens/ForgotPin/ForgotPin"));
const ChangePin = lazy(() => import("./screens/ChangePin/ChangePin"));
const SupervisorDashboard = lazy(() => import("./screens/SupervisorDashboard/SupervisorDashboard"));
const PatientList = lazy(() => import("./screens/PatientList/PatientList"));
const PatientDetail = lazy(() => import("./screens/PatientDetail/PatientDetail"));
const AddPatient = lazy(() => import("./screens/AddPatient/AddPatient"));
const VisitList = lazy(() => import("./screens/VisitList/VisitList"));
const AddVisit = lazy(() => import("./screens/AddVisit/AddVisit"));
const CHWActivity = lazy(() => import("./screens/CHWActivity/CHWActivity"));
const SyncStatus = lazy(() => import("./screens/SyncStatus/SyncStatus"));
const Conflicts = lazy(() => import("./screens/Conflicts/Conflicts"));

function App() {
  return (
    <BrowserRouter>
      <InstallPrompt />
      {/* Backstop only - AppShell has its own boundary so the sidebar and
          nav stay put while a screen chunk loads. */}
      <Suspense fallback={<div className="p-6"><ScreenSkeleton /></div>}>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/request-account" element={<RequestAccount />} />
          <Route path="/forgot-pin" element={<ForgotPin />} />
          <Route path="/change-pin" element={<ChangePin />} />

          <Route
            element={
              <ProtectedRoute allowedRoles={["CHW"]}>
                <ChwLayout />
              </ProtectedRoute>
            }
          >
            <Route path="/chw" element={<CHWHome />} />
            <Route path="/chw/patients/new" element={<AddPatient />} />
            <Route path="/chw/visits/new" element={<AddVisit />} />
          </Route>

          <Route
            element={
              <ProtectedRoute allowedRoles={["SUPERVISOR", "ADMIN"]}>
                <SupervisorLayout />
              </ProtectedRoute>
            }
          >
            <Route path="/supervisor" element={<SupervisorDashboard />} />
            <Route path="/supervisor/chw-activity" element={<CHWActivity />} />
            <Route path="/supervisor/conflicts" element={<Conflicts />} />
            <Route path="/supervisor/pin-reset" element={<PinReset />} />
            <Route path="/supervisor/account-requests" element={<AccountRequests />} />
            <Route path="/supervisor/chws" element={<ManageChws />} />
            <Route path="/supervisor/activity" element={<ActivityLog />} />
            <Route
              path="/supervisor/supervisors"
              element={
                <ProtectedRoute allowedRoles={["ADMIN"]}>
                  <ManageSupervisors />
                </ProtectedRoute>
              }
            />
          </Route>

          {/* Screens both roles use - SharedLayout picks the right shell. */}
          <Route element={<SharedLayout />}>
            <Route path="/patients" element={<PatientList />} />
            <Route path="/patients/:id" element={<PatientDetail />} />
            <Route path="/visits" element={<VisitList />} />
            <Route path="/sync" element={<SyncStatus />} />
          </Route>

          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}

export default App;
